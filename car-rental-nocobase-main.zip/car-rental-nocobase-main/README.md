# car-rental-nocobase

本项目是基于 NocoBase 的内部汽车租赁记账与运营系统。

## 当前项目阶段

当前仓库不是完整 NocoBase 应用，也不是可直接部署的生产系统。当前内容是业务规则文档、插件源码骨架、Collection 注册草案、纯函数服务、类型定义、多语言资源草案和测试 TODO。

`packages/plugins` 下的三个插件仍是“待接入真实 NocoBase 工程的插件源码骨架”。后续必须放入完整 NocoBase 源码工程进行开发调试，或构建为第三方插件包后通过 `storage/plugins` / 插件安装流程在测试环境启用。

请不要将当前仓库直接用于生产 NAS 或生产数据库。

## 系统定位

- 这是内部汽车租赁记账与运营系统。
- 不是客户自助平台。
- 不是短租预订系统。
- 司机不登录系统。
- 不按车型出租，每份合同必须绑定具体车牌。
- 每日租金台账是应收、已付、欠款、免除、未来应收和日历显示的核心事实来源。

## 三个插件职责

- `plugin-rental-core`：司机、车辆、合同、每日租金台账、付款分配、超付校验、押金、欠款、免除、权限过滤、操作日志和财务/日历汇总。
- `plugin-iopgps`：IOPGPS 配置、token 状态、车辆位置、每日里程、GPS 设备状态归一化和 GPS 错误日志。GPS 数据不参与租金计算。
- `plugin-contract-documents`：中文、英文、法文合同模板、合同文件记录、打印状态、线下签署状态和签署扫描件状态管理。

## 当前已实现的纯函数能力

- 每日台账生成预览和日期计费工具。
- 付款分配、单日不可超付校验和付款冲正。
- 未付原因、欠款、争议、待免除审批和免除审批状态处理。
- 合同财务汇总、司机日历汇总和敏感字段权限过滤。
- 押金创建、抵扣、退款、免除和可用金额计算。
- 操作日志生成和敏感字段脱敏。
- IOPGPS token 状态判断、状态归一化、定位快照、每日里程和错误日志脱敏。
- 合同模板选择、合同文件草稿/生成记录、打印状态、签署扫描件状态和状态流转校验。

这些能力当前都以纯函数或结构化草案形式存在，不直接写数据库、不调用真实 NocoBase API、不调用真实 IOPGPS API、不生成真实合同文件。

## 当前未完成内容

- NocoBase 真实插件注册和生命周期钩子。
- 真实 Collection 注册或数据库迁移。
- 前端 UI 和收租日历页面。
- 真实 IOPGPS HTTP 请求和定时同步任务。
- 真实 Word/PDF 合同生成。
- 真实文件上传、文件访问权限和合同扫描件存储。
- Docker / NAS 生产部署。
- 自动化集成测试和真实权限验证。

## 后续接入真实 NocoBase 工程还需要做什么

1. 确认目标 NocoBase 版本和插件格式。
2. 校验三个插件的 `package.json`、server/client 入口和插件元数据。
3. 将 Collection 草案转换为真实 NocoBase Collection 定义或迁移。
4. 接入服务端事务、权限系统、i18n、操作日志、定时任务和文件存储。
5. 使用测试数据库和测试数据验证插件启用、Collection 注册、服务端动作和回滚。
6. 编写并运行单元测试、集成测试、权限测试和失败隔离测试。

更多接入说明见：

- `docs/nocobase-plugin-integration.md`
- `docs/plugin-integration-checklist.md`
- `docs/test-environment-plan.md`

## 插件注册适配状态

当前三个插件新增了 `pluginRegistration.ts`、动作草案、定时任务草案和权限草案，用于描述后续接入真实 NocoBase 时需要注册的 Collection、服务方法、权限、i18n、定时任务、操作按钮/动作和工作流触发点。

这些文件不调用真实 NocoBase API，不创建数据库，不执行 IOPGPS 同步，不生成合同文件，也不表示当前仓库已经是完整可运行的 NocoBase 应用。详细计划见 `docs/nocobase-plugin-registration-plan.md`。

## mock 测试数据

当前仓库新增 `test-data/fixtures/` 与 `test-data/generated/`，并提供 `npm run seed:test-data`、`npm run validate:test-data`、`npm run clear:test-data` 三个本地文件级脚本。测试数据全部使用 `TEST-*` 占位值，不连接真实 NocoBase，不写数据库，不调用 IOPGPS，不生成真实合同文件。详细说明见 `docs/test-data.md`。

## NAS 测试部署准备

当前新增 `docker-compose.test.yml`、`.env.test.example`、NAS 测试部署文档和插件接入测试文档，仅用于后续 Synology NAS 测试环境准备，不是生产部署配置。`.env.test.example` 可以提交，实际 `.env.test` 不得提交；真实司机证件、真实付款截图、真实合同扫描件、真实 IOPGPS 密钥和真实数据库文件均不得提交。

入口文档：

- `docs/deployment-nas-test.md`
- `docs/plugin-install-test.md`
- `docs/test-data.md`

## NAS 测试前最终自检

当前新增插件打包测试草案、插件结构检查、插件注册描述检查、NAS 测试前自检、Smoke Test 清单和测试执行顺序文档。建议真正去 NAS 前先运行：

```bash
npm run check:plugin-structure
npm run check:plugin-registration
npm run preflight:nas-test
```

这些命令只检查仓库内文件和结构，不做真实部署、不连接数据库、不调用 IOPGPS，也不代表当前已经可以生产部署。更多说明见 `docs/plugin-package-test.md`、`docs/nas-smoke-test-checklist.md` 和 `docs/nas-test-runbook.md`。

## 自动化正式上线测试路线

用户不再采用手动 MVP 搭建方式；后续不会要求用户在 NocoBase UI 中手动创建 Collections、页面、菜单、权限或测试数据。当前 NAS 环境只是官方 NocoBase + PostgreSQL 的基础空环境，登录后为空应用是正常状态，当前仍不能生产上线。

下一阶段目标是由 Codex 自动化完成：

- 插件可安装化。
- Collection 自动注册或 migration。
- 页面、菜单和区块自动初始化。
- 权限角色和敏感字段策略自动初始化。
- mock 测试数据自动导入。
- smoke test 自动执行并输出报告。

自动化正式上线测试路线见 `docs/automated-go-live-test-roadmap.md`；NocoBase 自动化构建方案见 `docs/automated-nocobase-build-plan.md`；插件自动安装计划见 `docs/automated-plugin-install-plan.md`；自动化 UAT 用例见 `docs/automated-uat-test-plan.md`；上线测试检查表见 `docs/automated-go-live-test-checklist.md`。

## 自动化接入 dry-run 适配层

当前新增 `packages/shared/nocobase-automation`，用于把三个插件的注册描述合并为自动化注册计划，并通过 dry-run 校验插件顺序、Collections、权限、页面计划、mock 数据导入计划和 smoke test 计划。

可运行：

```bash
npm run generate:registration-plan
npm run validate:registration-plan
```

该流程不会连接真实 NocoBase、不会安装插件、不会写数据库、不会创建页面或权限、不会调用 IOPGPS，也不会导入真实数据。后续仍需在完整 NocoBase 工程中实现真实 adapter。详细说明见 `docs/automated-nocobase-registration-layer.md`。

## Collection 自动注册 dry-run

本轮新增 Collection 自动注册 dry-run 适配层，用于在真实接入 NocoBase 前验证 Collection 注册计划。该层会标准化字段、关系、索引、唯一约束和敏感字段，使用 mock adapter 模拟注册步骤，并输出文件级 dry-run 结果。

可运行命令：

```bash
npm run generate:registration-plan
npm run validate:registration-plan
npm run dry-run:register-collections
npm run validate:collection-registration
```

这些命令不连接真实 NocoBase、不写数据库、不执行 migration、不安装插件、不创建页面或权限。用户仍不需要手动在 NocoBase UI 中建表；真实 Collection 注册必须等后续在完整 NocoBase 工程中实现真实 adapter 后再进行。

## Runtime 自动注册 dry-run

本轮新增服务方法、动作、权限、定时任务和 i18n 的 runtime dry-run 适配层，用于在真实接入 NocoBase 前验证 runtime 注册计划。该层会校验核心服务、核心动作、六个内部角色、三语言 i18n、IOPGPS 定时任务默认关闭以及禁止业务模式。

可运行命令：

```bash
npm run generate:registration-plan
npm run validate:registration-plan
npm run dry-run:register-runtime
npm run validate:runtime-registration
```

这些命令不连接真实 NocoBase、不写数据库、不注册真实 API、不注册真实按钮、不注册真实 ACL、不执行真实定时任务。用户仍不需要手动在 NocoBase UI 中创建权限、按钮或动作；真实 runtime 注册必须等后续在完整 NocoBase 工程中实现真实 adapter 后再进行。

## 页面初始化 dry-run

当前自动化路线新增页面、菜单、区块、筛选器和按钮动作的 dry-run 初始化计划。该计划用于验证后续 Codex 自动化创建内部业务页面的范围，包括司机、车辆、合同、每日租金台账、收租日历、付款、押金、合同文件、GPS 和操作日志页面。

本阶段仍不连接真实 NocoBase，不创建真实页面，不注册真实按钮，不导入真实数据。用户不需要手动在 NocoBase UI 中搭建页面；后续必须等待真实 NocoBase adapter 完成并通过 UAT 后，才能进入正式上线测试。

## mock 测试数据导入 dry-run

当前自动化路线新增 mock 测试数据导入 dry-run，用于验证 `test-data/generated` 中的测试数据能否按依赖顺序自动导入。该流程只读取 JSON 并使用 mock adapter 记录导入步骤，不连接真实 NocoBase，不写数据库，不上传文件，不调用 IOPGPS。

可运行：

```bash
npm run seed:test-data
npm run validate:test-data
npm run dry-run:import-test-data
npm run validate:seed-data-import
```

用户不需要手动导入测试数据；真实导入必须等待完整 NocoBase 工程中的真实 adapter 完成后再执行。

## 自动化 Smoke Test dry-run

本仓库新增统一 smoke test dry-run 编排脚本，用于串联注册计划生成与校验、Collection dry-run、Runtime dry-run、页面初始化 dry-run、mock 测试数据生成与导入 dry-run，以及 NAS 文件预检。

```bash
npm run smoke:dry-run
npm run validate:smoke-report
```

报告输出到 `test-data/generated/automated-smoke-test-report.generated.json` 和 `test-data/generated/automated-smoke-test-report.generated.md`。该流程仍然只使用 mock adapter 和本地文件，不连接真实 NocoBase，不写数据库，不调用 IOPGPS，也不生成真实合同文件，因此不能视为正式上线测试。

## 正式上线测试前 readiness 报告

在 smoke dry-run 通过后，可以生成正式上线测试前总预检报告：

```bash
npm run generate:go-live-readiness
npm run validate:go-live-readiness
```

报告输出到 `test-data/generated/go-live-readiness-report.generated.json` 和 `test-data/generated/go-live-readiness-report.generated.md`。该报告用于判断当前是否仍停留在 dry-run 阶段、哪些 gate 阻塞真实插件接入测试、UAT 或生产部署。当前下一阶段应是实现真实 NocoBase adapter，不能把本仓库误标记为 `production_ready`。

## 真实 NocoBase adapter 最小接口说明

本轮新增真实 NocoBase adapter 的最小接口落地，但当前仍不是完整真实接入：

- 已定义 adapter 模式、状态、能力矩阵、环境检测结果、真实 adapter 接口、未配置占位实现、factory 和受控错误。
- 已补充环境检测和测试，确保未配置 adapter 不会报告 ready，不会连接数据库，不会伪造真实注册成功。
- 当前仍没有真实可用的 NocoBase adapter，不能进入真实插件接入测试，也不能真实创建 Collections、权限、页面、服务或测试数据。
- 下一轮应实现真实 adapter 的第一项能力：Collection 注册 adapter 草案，但仍必须在完整 NocoBase 工程内验证目标版本官方 API。

## 真实 Collection 注册 Adapter 草案

本仓库新增真实 Collection 注册 adapter 草案，用于把自动化 Collection plan 转换为 NocoBase schema draft，并生成注册步骤、回滚计划、后置验证计划和安全检查报告。

可执行命令：

```bash
npm run generate:real-collection-plan
npm run validate:real-collection-plan
```

该能力仍然不连接真实 NocoBase、不创建真实 Collections、不执行 migration、不写数据库、不调用 `app.collection` 或 `db.collection`，也不代表项目已经具备正式上线测试条件。详细说明见 `docs/real-collection-registration-adapter.md`。

## 真实 Runtime 注册 Adapter 草案

本轮新增真实 Runtime 注册 adapter 草案，覆盖服务方法、动作、权限、i18n 和定时任务。当前仅生成 schema draft、注册步骤、回滚计划和后置验证计划，不连接真实 NocoBase、不注册真实服务、不注册按钮或 API、不注册 ACL、不注册 scheduler、不加载 i18n。

新增命令：

- `npm run generate:real-runtime-plan`：从自动化注册计划生成真实 Runtime 注册草案。
- `npm run validate:real-runtime-plan`：校验真实 Runtime 注册草案保持 `plan_only`、未真实执行、核心服务/动作/六角色/三语言和业务禁用边界。

## 真实 Seed Data Import Adapter 草案

当前新增真实 Seed Data Import adapter 草案，用于把已有 mock 测试数据导入 dry-run 计划转换为真实导入 schema draft，并生成导入步骤、事务计划、回滚计划和导入后验证计划。新增脚本：

```bash
npm run generate:real-seed-data-plan
npm run validate:real-seed-data-plan
```

该草案不连接真实 NocoBase、不写数据库、不上传文件、不创建记录、不执行真实事务，也不表示测试数据已真实导入。当前仓库仍不能正式上线测试；后续必须在完整 NocoBase 测试工程中接入真实 repository/db、事务、文件存储、备份、回滚和后置验证。

## 2026-06-04 真实 Smoke Test Adapter 草案

本轮在真实 Collection、Runtime、Page、Seed Data Import 草案之后，新增“真实 Smoke Test Adapter 草案”。当前阶段只设计接口边界、计划转换器、校验器、草案 adapter、脚本、测试和文档，不连接真实 NocoBase、不写数据库、不安装插件、不执行业务流程、不调用 IOPGPS、不生成合同文件，也不伪造任何 NocoBase API 成功。

本轮计划覆盖环境前置检查、Collection 注册验证、Runtime 注册验证、Page 注册验证、Seed Data 导入验证、核心业务流程、权限、GPS mock、合同文件、失败隔离、回滚验证和报告草案。`real` 模式在当前仓库必须被阻断，后续只有在独立测试环境、备份、回滚、mock 数据、禁用真实 IOPGPS 等条件全部满足后，才能进入下一阶段设计。

## 真实 Backup / Rollback 草案

本仓库新增真实 Backup / Rollback adapter 草案，用于生成数据库、文件存储、插件状态、schema、runtime、page、seed data、日志和环境配置存在性的备份计划，以及对应回滚、失败恢复和回滚后验证计划。

可用命令：

```bash
npm run generate:real-backup-rollback-plan
npm run validate:real-backup-rollback-plan
```

当前命令只生成和校验草案，不连接真实 NocoBase，不执行真实备份，不执行真实回滚，不读取 `.env.test` 真实值，不删除文件，不修改 storage，也不禁用真实插件。

## 2026-06-05 真实 Backup / Rollback 草案复核

本轮复核后，真实 Backup / Rollback adapter 仍只生成计划和校验报告：备份步骤、回滚步骤和失败恢复步骤均不可执行，后置验证计划只记录隔离测试环境需要验证的项目和操作人草案归档提示。当前仓库仍不能正式上线测试，下一阶段应在完整 NocoBase 隔离测试工程中接入真实备份、回滚、storage snapshot 和人工确认机制。

## 真实 NocoBase 工程接入 Runbook

本轮已补充真实 NocoBase 工程接入 Runbook、真实 Adapter 实施顺序、宿主工程要求、风险清单和 readiness 检查脚本。当前所有真实 Adapter 草案已经覆盖 Collection、Runtime、Page、Seed Data、Smoke Test、Backup / Rollback 六个方向。

下一阶段不是继续新增草案，而是在完整 NocoBase 工程中开始真实 adapter 实现。当前仓库仍只是插件骨架、dry-run 自动化层和真实 Adapter 草案仓库，不连接真实 NocoBase，不创建真实 Collections，不写数据库，仍不能正式上线测试，也不能生产部署。

进入下一阶段前，应先阅读：

- `docs/real-nocobase-integration-runbook.md`
- `docs/real-adapter-implementation-sequence.md`
- `docs/real-nocobase-host-requirements.md`
- `docs/real-integration-risk-register.md`

可在当前仓库运行以下检查，确认文档与草案条件是否齐备：

```bash
npm run validate:real-integration-readiness
```

## 2026-06-06 NocoBase 目标版本与插件 API 调研补充

本轮已新增目标版本与真实插件 API 映射调研文档：

- `docs/nocobase-target-version-research.md`
- `docs/nocobase-plugin-api-research.md`
- `docs/real-adapter-api-mapping.md`
- `docs/real-adapter-gap-analysis.md`
- `docs/real-adapter-implementation-backlog.md`

本轮结论如下：

- 下一阶段是锁定 NocoBase 目标版本和验证官方 API。
- 当前 `latest-full` 只能继续用于 NAS 基础环境测试，不能作为真实 adapter、UAT 或生产部署基准。
- 当前仍不能实现真实 adapter；未经官方 API 验证不得写真实 adapter。
- 当前不能正式上线测试，也不能生产部署。
- 任何无法确认的 NocoBase API 必须标记为待验证，不得伪造 API。
- 验证只能在完整 NocoBase 源码测试工程和隔离 PostgreSQL、隔离 storage 中进行，不得生产库调试。

## 当前阶段：NocoBase 宿主工程接入准备

本轮新增目标版本决策记录、完整 NocoBase 宿主工程准备 Runbook、宿主工程接入分支计划、源码 API 验证计划，以及默认 dry-run 的宿主准备脚本草案。

当前仓库仍是汽车租赁业务插件、自动化 dry-run 与真实 adapter 草案仓库，不是完整 NocoBase 宿主工程。不要把完整 NocoBase 源码提交进当前仓库，不要在生产库调试，不要把 `latest-full` 当作真实接入基准。

目标 NocoBase 版本已经确认为 `v2.0.61`，包管理器基准已修正为 `yarn`。下一阶段仍只允许完整宿主工程接入准备；不应真实安装插件，不应连接真实 NocoBase，不应写数据库。当前仍不能正式上线测试，当前仍不能生产部署。

新增校验命令：

```bash
npm run validate:host-bootstrap-docs
```

## 目标 NocoBase 版本人工确认包补充

当前目标 NocoBase 版本已确认为 `v2.0.61`，来源为 release，包管理器基准为 `yarn`。在插件与 shared automation 复制到独立宿主工程、真实环境检测 adapter 通过、隔离测试库和备份策略确认前，不应实现真实 Collection、Runtime、Page、Seed Data、Smoke Test、Backup / Rollback adapter，也不应在 NAS 上安装插件。

本轮新增目标版本人工确认资料与校验机制：

- `docs/nocobase-target-version-manual-confirmation.md`：人工确认清单。
- `docs/nocobase-target-version-freeze-template.md`：版本冻结模板。
- `docs/nocobase-target-version-input-schema.md`：下一阶段确认输入 Schema。
- `scripts/nocobase/validate-target-version-confirmation.ts`：阻止未确认版本进入真实 adapter 的校验脚本。
- `scripts/nocobase/generate-target-version-confirmation-template.ts`：生成待填写确认草案。

新增命令：

```bash
npm run generate:target-version-template
npm run validate:target-version-confirmation
```

当前 `validate:target-version-confirmation` 应基于已确认的 `v2.0.61` 与 `package_manager = yarn` 通过。下一步不是重新确认版本，而是把三个插件与 shared automation 复制到独立宿主工程并完成环境检测；当前仍不能正式上线测试，也不能生产部署。

## 目标版本确认应用与真实 adapter 门禁

当前 NocoBase 目标版本为 `decision_status = confirmed`、`target_version = v2.0.61`，包管理器为 `yarn`，并保持 `iopgps_real_sync_allowed = false`、`mock_data_only = true`。未来如需变更版本，确认输入仍不得包含密码、`APP_KEY`、`DB_PASSWORD`、`IOPGPS_LOGIN_KEY`。

确认输入应先运行 `npm run validate:target-version-input -- --file test-data/generated/nocobase-target-version-confirmation.filled.json`，再运行 `npm run apply:target-version-confirmation -- --file test-data/generated/nocobase-target-version-confirmation.filled.json` 做 dry-run。只有用户明确决定应用时，才可运行 `npm run apply:target-version-confirmation -- --file test-data/generated/nocobase-target-version-confirmation.filled.json --execute`。

当前 `npm run validate:target-version-confirmation` 与 `npm run validate:can-start-real-adapter` 应通过，但只表示可进入下一轮完整宿主工程接入准备。当前仍不能正式上线测试，仍不能生产部署，也不能实现真实 Collection adapter。详见 `docs/nocobase-target-version-confirmation-workflow.md`。

## NocoBase 目标版本人工确认审查流程

当前目标版本已确认为 `v2.0.61`。未来如需变更目标版本，仍应通过 GitHub Issue + `filled.json` + apply 脚本 + PR 审查完成：先用 `.github/ISSUE_TEMPLATE/nocobase-target-version-confirmation.yml` 收集人工确认信息，再复制 `test-data/generated/nocobase-target-version-confirmation.template.json` 为 `test-data/generated/nocobase-target-version-confirmation.filled.json`，运行 `npm run validate:target-version-input -- --file test-data/generated/nocobase-target-version-confirmation.filled.json` 与 apply dry-run，最后通过 PR 模板进行安全审查。

本阶段保留 `npm run validate:target-version-workflow-files`，用于校验 Issue 模板、PR 模板、人工确认操作清单、提交规范、review checklist、既有工作流文档和门禁脚本是否齐备。当前门禁通过也只允许进入完整宿主工程接入准备；当前仍不能正式上线测试，仍不能生产部署。

## 本轮补充：NocoBase v2.0.61 宿主工程接入任务包

> 包管理器修正：完整 NocoBase v2.0.61 宿主工程环境检测已确认当前接入基准为 `package_manager = yarn`。后续宿主工程人工命令应使用 `yarn`，不得把 `pnpm` 作为当前默认值；除非重新验证目标版本源码工程确实支持 `pnpm`。

目标版本已确认：`v2.0.61`。本轮在仓库全盘扫描和目标版本门禁通过后，新增完整 NocoBase v2.0.61 宿主工程接入任务包，用于下一阶段“完整 NocoBase v2.0.61 宿主工程接入准备”。

新增任务包文档包括：

- `docs/nocobase-v2.0.61-host-integration-task.md`
- `docs/nocobase-v2.0.61-host-directory-plan.md`
- `docs/nocobase-v2.0.61-host-bootstrap-commands.md`
- `docs/nocobase-v2.0.61-plugin-copy-plan.md`
- `docs/task-real-environment-adapter-v2.0.61.md`
- `docs/task-real-collection-adapter-v2.0.61.md`

新增校验命令：

```bash
npm run validate:v2-host-integration-task
```

当前项目仍不包含完整 NocoBase 源码，不在当前仓库 clone NocoBase 源码，不提交完整 NocoBase 源码，不创建 Git submodule。本轮仍不安装依赖、不连接 NocoBase、不写数据库、不创建宿主工程、不真实复制插件、不启用真实 IOPGPS。当前仍不能正式上线测试，当前仍不能生产部署，当前不能标记为 `production_ready`。
