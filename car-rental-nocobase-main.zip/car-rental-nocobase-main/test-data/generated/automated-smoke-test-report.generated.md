# 自动化 Smoke Test dry-run 报告

- 报告编号：SMOKE-DRY-RUN-20260606
- 生成时间：2026-06-06T10:34:43.341Z
- 执行环境：Codex Web 本地 dry-run 工作区
- 是否成功：是
- dry-run 边界：未连接真实 NocoBase，未写数据库，未调用 IOPGPS，未生成真实合同文件。

## 步骤统计

- 通过步骤：15
- 失败步骤：0
- 警告步骤：0
- 跳过步骤：0

## 步骤明细

| 步骤 | 状态 | 耗时毫秒 | 命令 |
| --- | --- | ---: | --- |
| repository_scan | passed | 27 | find . -maxdepth 5 -type f -not -path './node_modules/*' -not -path './.git/*' -not -path './.test-dist/*' -not -path './storage-test/*' -not -path './backups-test/*' -not -path './logs-test/*' -not -path './test-runtime/*' | sort |
| generate_registration_plan | passed | 4125 | npm run generate:registration-plan |
| validate_registration_plan | passed | 4059 | npm run validate:registration-plan |
| dry_run_register_collections | passed | 4006 | npm run dry-run:register-collections |
| validate_collection_registration | passed | 3995 | npm run validate:collection-registration |
| dry_run_register_runtime | passed | 4199 | npm run dry-run:register-runtime |
| validate_runtime_registration | passed | 4327 | npm run validate:runtime-registration |
| dry_run_initialize_pages | passed | 4199 | npm run dry-run:initialize-pages |
| validate_page_initialization | passed | 4224 | npm run validate:page-initialization |
| seed_test_data | passed | 4518 | npm run seed:test-data |
| validate_test_data | passed | 4267 | npm run validate:test-data |
| dry_run_import_test_data | passed | 4486 | npm run dry-run:import-test-data |
| validate_seed_data_import | passed | 4269 | npm run validate:seed-data-import |
| preflight_nas_test | passed | 4238 | npm run preflight:nas-test |
| generate_smoke_report | passed | 3 | 生成 JSON 与 Markdown 报告 |

## 阻塞项

- 无

## 警告

- 无

## 产物

- docs/current-repository-scan.md
- test-data/generated/automated-registration-plan.generated.json
- test-data/generated/collection-registration-dry-run.generated.json
- test-data/generated/runtime-registration-dry-run.generated.json
- test-data/generated/page-initialization-dry-run.generated.json
- test-data/generated/generation-summary.generated.json
- test-data/generated/seed-data-import-dry-run.generated.json
- docker-compose.test.yml
- .env.test.example
- test-data/generated/automated-smoke-test-report.generated.json
- test-data/generated/automated-smoke-test-report.generated.md

## 下一步

- 保留 dry-run 边界，进入真实 NocoBase adapter 设计与隔离测试环境准备。
