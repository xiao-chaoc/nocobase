declare const require: any;

import { assert, test } from '../testHarness';
import { clearTestData } from '../../scripts/clear-test-data';
import { seedTestData } from '../../scripts/seed-test-data';
import { validateTestData } from '../../scripts/validate-test-data';
import { listGeneratedJsonFiles } from '../../scripts/test-data-common';

const fs = require('fs');

test('clear 脚本只清理 generated JSON 且不会删除 fixtures', () => {
  seedTestData();
  assert(listGeneratedJsonFiles().length > 0, '清理前应存在生成文件。');
  const deleted = clearTestData();
  assert(deleted.some((fileName) => fileName === 'drivers.generated.json'), '应删除 generated JSON。');
  assert(fs.existsSync('test-data/fixtures/drivers.json'), 'clear 不得删除 fixtures。');
  assert(listGeneratedJsonFiles().length === 0, '清理后 generated JSON 应为空。');
  seedTestData();
});

test('validate 脚本在重新生成后可以校验通过', () => {
  seedTestData();
  const result = validateTestData();
  assert(result.passed, result.errors.join('\n'));
});
