declare const require: any;

import { assert, test } from '../testHarness';
import { seedTestData } from '../../scripts/seed-test-data';
import { validateTestData } from '../../scripts/validate-test-data';
import { listGeneratedJsonFiles, readGenerated } from '../../scripts/test-data-common';

const fs = require('fs');

test('seed 脚本能生成完整测试数据文件', () => {
  const files = seedTestData();
  for (const fileName of [
    'drivers.generated.json',
    'vehicles.generated.json',
    'gps-devices.generated.json',
    'lease-contracts.generated.json',
    'rent-daily-ledgers.generated.json',
    'rent-payments.generated.json',
    'rent-payment-allocations.generated.json',
    'deposit-records.generated.json',
    'gps-location-snapshots.generated.json',
    'gps-daily-mileages.generated.json',
    'contract-documents.generated.json',
    'operation-logs.generated.json',
  ]) {
    assert(files.includes(fileName), `缺少生成文件：${fileName}`);
  }
  assert(listGeneratedJsonFiles().length >= 13, '生成目录应包含完整 JSON 文件。');
});

test('生成数据可通过本地一致性校验', () => {
  seedTestData();
  const result = validateTestData();
  assert(result.passed, result.errors.join('\n'));
});

test('生成数据不包含真实敏感文件路径或短租数据', () => {
  seedTestData();
  const generated = listGeneratedJsonFiles().map((fileName) => readGenerated(fileName));
  const text = JSON.stringify(generated).toLowerCase();
  assert(!text.includes('http://') && !text.includes('https://') && !text.includes('/uploads/') && !text.includes('file://'), '生成数据不得包含真实文件路径。');
  assert(!text.includes('booking') && !text.includes('reservation') && !text.includes('short_rental_orders'), '生成数据不得包含短租预订数据。');
  assert(fs.existsSync('test-data/fixtures/drivers.json'), 'fixtures 必须保留。');
});
