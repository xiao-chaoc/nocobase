import { assert, test } from '../testHarness';
import { inspectNocobaseEnvironment, RealSmokeTestAdapter } from '../../packages/shared/nocobase-automation/src';
import { generateRealSmokeTestPlan } from '../../scripts/nocobase/generate-real-smoke-test-plan';
import { validateGeneratedRealSmokeTestPlan } from '../../scripts/nocobase/validate-real-smoke-test-plan';
import type { RealSmokeTestContext } from '../../packages/shared/nocobase-automation/src';

const context = (mode: RealSmokeTestContext['mode'] = 'plan_only'): RealSmokeTestContext => ({
  mode,
  adapterEnvironment: inspectNocobaseEnvironment({ mode: 'dry_run' }),
  allowRealExecution: false,
  requireBackup: true,
  requireRollbackPlan: true,
  requireIsolatedDatabase: true,
  requireMockDataOnly: true,
  requireIopgpsDisabled: true,
  operator: 'test',
  notes: ['测试只生成草案。'],
});

test('adapter 只生成计划，不执行测试', () => {
  const adapter = new RealSmokeTestAdapter();
  const plan = adapter.buildRealSmokeTestPlan({ context: context() });
  const report = adapter.generateRealSmokeTestReportDraft(plan);
  assert(report.executed === false, '报告必须 executed=false。');
  assert(report.stepsExecutable === 0, '草案步骤不得可执行。');
  assert(plan.steps.every((step) => !step.canExecute), '所有步骤均不可执行。');
});

test('adapter 不调用真实 NocoBase API', () => {
  let called = false;
  const fakeApi = { db: { collection: { create: () => { called = true; } } }, acl: { allow: () => { called = true; } }, iopgps: { sync: () => { called = true; } } };
  const adapter = new RealSmokeTestAdapter();
  const plan = adapter.buildRealSmokeTestPlan({ context: context() });
  assert(fakeApi && !called, 'adapter 不应调用真实 API。');
  assert(plan.notes.join(' ').includes('不调用真实 NocoBase API'), '计划应说明不调用真实 NocoBase API。');
});

test('adapter 在 real 模式返回错误', () => {
  const adapter = new RealSmokeTestAdapter();
  const plan = adapter.buildRealSmokeTestPlan({ context: context('real') });
  const report = adapter.generateRealSmokeTestReportDraft(plan);
  assert(report.errors.some((error) => error.includes('当前仓库') || error.includes('real')), 'real 模式必须返回错误。');
  assert(report.executed === false, 'real 模式也不得执行。');
});

test('脚本能生成 real-smoke-test-plan.generated.json', () => {
  const result = generateRealSmokeTestPlan();
  assert(result.output.plan.mode === 'plan_only', '生成脚本默认 plan_only。');
  assert(result.output.plan.steps.length > 0, '应生成 smoke test 步骤。');
});

test('校验脚本能通过 plan_only 结果', () => {
  generateRealSmokeTestPlan();
  const result = validateGeneratedRealSmokeTestPlan();
  assert(result.passed, `校验脚本应通过：${result.errors.join('；')}`);
});
