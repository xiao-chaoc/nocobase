import { assert, test } from '../testHarness';
import { contractDocumentsPluginRegistration } from '../../packages/plugins/plugin-contract-documents/src/server/pluginRegistration';
import { iopgpsPluginRegistration } from '../../packages/plugins/plugin-iopgps/src/server/pluginRegistration';
import { rentalCorePluginRegistration } from '../../packages/plugins/plugin-rental-core/src/server/pluginRegistration';
import { buildAutomatedRegistrationPlan, validateAutomatedRegistrationPlan, validateCollectionUniquenessRules, validateSensitiveFieldCoverage } from '../../packages/shared/nocobase-automation/src';

const basePlan = buildAutomatedRegistrationPlan([
  rentalCorePluginRegistration,
  contractDocumentsPluginRegistration,
  iopgpsPluginRegistration,
]);

test('自动化注册计划校验器接受有效计划', () => {
  const result = validateAutomatedRegistrationPlan(basePlan);
  assert(result.passed, result.errors.join('\n'));
  assert(validateSensitiveFieldCoverage(basePlan).passed, '敏感字段覆盖应通过。');
  assert(validateCollectionUniquenessRules(basePlan).passed, '唯一约束校验应通过。');
});

test('校验器拒绝短租、司机登录和按车型出租对象', () => {
  const invalid = { ...basePlan, pages: [...basePlan.pages, { ...basePlan.pages[0], name: 'booking', collections: ['short_rental_orders'], notes: ['driver_login', 'vehicle_category_rental'] }] };
  const result = validateAutomatedRegistrationPlan(invalid);
  assert(!result.passed, '包含禁用对象时必须失败。');
  assert(result.errors.some((error) => error.includes('booking')), '应拒绝 booking。');
  assert(result.errors.some((error) => error.includes('short_rental_orders')), '应拒绝 short_rental_orders。');
  assert(result.errors.some((error) => error.includes('driver_login')), '应拒绝 driver_login。');
  assert(result.errors.some((error) => error.includes('vehicle_category_rental')), '应拒绝按车型出租。');
});

test('校验器拒绝 GPS 参与租金计算', () => {
  const invalid = { ...basePlan, notes: ['GPS 参与租金计算'] };
  const result = validateAutomatedRegistrationPlan(invalid);
  assert(!result.passed, 'GPS 参与租金计算时必须失败。');
  assert(result.errors.some((error) => error.includes('GPS')), '应返回 GPS 错误。');
});

test('校验器拒绝缺失关键唯一约束', () => {
  const invalid = { ...basePlan, collections: basePlan.collections.map((collection) => collection.name === 'rent_daily_ledgers' ? { ...collection, uniqueConstraints: [] } : collection) };
  const result = validateCollectionUniquenessRules(invalid);
  assert(!result.passed, '缺失 contract_id + rent_date 时必须失败。');
});
