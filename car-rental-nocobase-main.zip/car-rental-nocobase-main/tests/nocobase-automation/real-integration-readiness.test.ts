declare const require: any;
declare const process: { cwd(): string };

const { readFileSync, existsSync } = require('fs');
const path = require('path');
import { assert, test } from '../testHarness';

const rootDir = process.cwd();
const readText = (filePath: string): string => readFileSync(path.join(rootDir, filePath), 'utf8');
const exists = (filePath: string): boolean => existsSync(path.join(rootDir, filePath));

const runbook = readText('docs/real-nocobase-integration-runbook.md');
const sequence = readText('docs/real-adapter-implementation-sequence.md');
const hostRequirements = readText('docs/real-nocobase-host-requirements.md');
const riskRegister = readText('docs/real-integration-risk-register.md');
const readinessScript = readText('scripts/nocobase/validate-real-integration-readiness.ts');
const packageJson = JSON.parse(readText('package.json')) as { scripts?: Record<string, string> };

test('真实接入 Runbook 文档存在', () => {
  assert(exists('docs/real-nocobase-integration-runbook.md'), 'Runbook 文档应存在。');
});

test('真实 Adapter 实施顺序文档存在', () => {
  assert(exists('docs/real-adapter-implementation-sequence.md'), '实施顺序文档应存在。');
});

test('真实 NocoBase 宿主工程要求文档存在', () => {
  assert(exists('docs/real-nocobase-host-requirements.md'), '宿主工程要求文档应存在。');
});

test('真实接入风险清单存在', () => {
  assert(exists('docs/real-integration-risk-register.md'), '风险清单应存在。');
});

test('真实接入 readiness 检查脚本存在', () => {
  assert(exists('scripts/nocobase/validate-real-integration-readiness.ts'), 'readiness 检查脚本应存在。');
});

test('package.json 包含 validate:real-integration-readiness', () => {
  assert(Boolean(packageJson.scripts?.['validate:real-integration-readiness']), 'package.json 应包含 readiness 检查脚本。');
});

test('风险清单包含 NocoBase API 版本不匹配', () => {
  assert(riskRegister.includes('NocoBase API 版本不匹配'), '风险清单应包含 API 版本风险。');
});

test('风险清单包含敏感字段暴露', () => {
  assert(riskRegister.includes('敏感字段暴露'), '风险清单应包含敏感字段暴露风险。');
});

test('风险清单包含 IOPGPS 被误启用', () => {
  assert(riskRegister.includes('IOPGPS 被误启用'), '风险清单应包含 IOPGPS 误启用风险。');
});

test('风险清单包含回滚失败', () => {
  assert(riskRegister.includes('回滚失败'), '风险清单应包含回滚失败风险。');
});

test('Runbook 明确禁止生产库调试', () => {
  assert(runbook.includes('不在生产库上调试'), 'Runbook 应禁止生产库调试。');
});

test('Runbook 明确不把 dry-run 当成真实接入', () => {
  assert(runbook.includes('不把 dry-run 成功当成真实接入成功'), 'Runbook 应说明 dry-run 不等于真实接入。');
});

test('宿主工程要求明确需要完整 NocoBase 工程', () => {
  assert(hostRequirements.includes('真实接入需要完整 NocoBase 工程'), '宿主工程要求应明确完整工程要求。');
});

test('宿主工程要求明确 IOPGPS_SYNC_ENABLED=false', () => {
  assert(hostRequirements.includes('IOPGPS_SYNC_ENABLED=false'), '宿主工程要求应明确禁用真实 IOPGPS。');
});

test('实施顺序明确 Collection 在 Runtime 之前', () => {
  assert(sequence.indexOf('实现 Collection 真实 adapter') < sequence.indexOf('实现 Runtime 真实 adapter'), 'Collection 应在 Runtime 之前。');
  assert(sequence.includes('Collection 必须在 Runtime 之前'), '文档应明确 Collection 在 Runtime 之前。');
});

test('实施顺序明确 Backup / Rollback 在 Smoke Test 之前', () => {
  assert(sequence.indexOf('实现 Backup / Rollback 真实 adapter') < sequence.indexOf('实现 Smoke Test 真实 adapter'), 'Backup / Rollback 应在 Smoke Test 之前。');
  assert(sequence.includes('Backup / Rollback 必须在 Smoke Test 之前'), '文档应明确 Backup / Rollback 在 Smoke Test 之前。');
});

test('检查脚本不连接真实 NocoBase', () => {
  assert(readinessScript.includes('不连接 NocoBase'), '脚本输出应明确不连接 NocoBase。');
  assert(!readinessScript.includes('createConnection'), '脚本不应创建数据库连接。');
});

test('检查脚本不读取 .env.test 真实值', () => {
  assert(readinessScript.includes('不读取 .env.test'), '脚本输出应明确不读取 .env.test。');
  assert(!readinessScript.includes("readFileSync(toAbsolute('.env.test')"), '脚本不应读取 .env.test 内容。');
});
