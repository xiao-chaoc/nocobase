import { assert, test } from '../testHarness';
import { buildSeedDataImportPlan } from '../../packages/shared/nocobase-automation/src';
import { extractFileFieldDrafts, extractRelationDrafts, mapSeedDataEntityPlanToRealSchemaDraft, mapSeedDataImportPlanToRealSchemaDraft } from '../../packages/shared/nocobase-automation/src/realSeedDataSchemaMapper';

const seedPlan = buildSeedDataImportPlan();

const orderOf = (entityType: string) => mapSeedDataImportPlanToRealSchemaDraft(seedPlan).find((entity) => entity.entityType === entityType)?.importOrder ?? 999;

test('真实 Seed Data schema mapper 能将 seed data import plan 映射为 schema draft 并保留导入顺序', () => {
  const drafts = mapSeedDataImportPlanToRealSchemaDraft(seedPlan);
  assert(drafts.length === seedPlan.entities.length, '不得新增或删除实体。');
  assert(drafts[0].entityType === 'drivers', '应保留导入顺序。');
  assert(drafts.some((entity) => entity.entityType === 'operation_logs'), '应保留 operation_logs。');
});

test('真实 Seed Data schema mapper 保留核心父子实体顺序', () => {
  assert(orderOf('drivers') < orderOf('lease_contracts'), 'drivers 必须在 lease_contracts 之前。');
  assert(orderOf('vehicles') < orderOf('lease_contracts'), 'vehicles 必须在 lease_contracts 之前。');
  assert(orderOf('lease_contracts') < orderOf('rent_daily_ledgers'), 'lease_contracts 必须在 rent_daily_ledgers 之前。');
  assert(orderOf('rent_payments') < orderOf('rent_payment_allocations'), 'rent_payments 必须在 rent_payment_allocations 之前。');
});

test('真实 Seed Data schema mapper 能识别文件字段且默认敏感', () => {
  const drivers = seedPlan.entities.find((entity) => entity.entityType === 'drivers');
  assert(drivers, '应存在 drivers。');
  const fileFields = extractFileFieldDrafts(drivers!);
  assert(fileFields.some((field) => field.fieldName === 'id_front_file'), '应识别司机证件文件字段。');
  assert(fileFields.every((field) => field.sensitive), '文件字段默认必须敏感。');
  const draft = mapSeedDataEntityPlanToRealSchemaDraft(drivers!);
  assert(draft.sensitiveFields.includes('license_back_file'), '不得删除敏感字段。');
});

test('真实 Seed Data schema mapper 能识别 relation draft', () => {
  const contracts = seedPlan.entities.find((entity) => entity.entityType === 'lease_contracts');
  assert(contracts, '应存在 lease_contracts。');
  const relations = extractRelationDrafts(contracts!);
  assert(relations.some((relation) => relation.relationField === 'driver_id' && relation.targetEntityType === 'drivers'), '应识别 driver_id 引用。');
  assert(relations.some((relation) => relation.relationField === 'vehicle_id' && relation.targetEntityType === 'vehicles'), '应识别 vehicle_id 引用。');
});
