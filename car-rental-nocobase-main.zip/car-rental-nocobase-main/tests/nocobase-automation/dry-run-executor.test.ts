import { assert, test } from '../testHarness';
import { contractDocumentsPluginRegistration } from '../../packages/plugins/plugin-contract-documents/src/server/pluginRegistration';
import { iopgpsPluginRegistration } from '../../packages/plugins/plugin-iopgps/src/server/pluginRegistration';
import { rentalCorePluginRegistration } from '../../packages/plugins/plugin-rental-core/src/server/pluginRegistration';
import { buildAutomatedRegistrationPlan, dryRunAutomatedRegistration } from '../../packages/shared/nocobase-automation/src';

const plan = buildAutomatedRegistrationPlan([
  rentalCorePluginRegistration,
  contractDocumentsPluginRegistration,
  iopgpsPluginRegistration,
]);

test('dry-run 返回步骤、warnings 和摘要', () => {
  const result = dryRunAutomatedRegistration(plan);
  assert(result.success, result.errors.join('\n'));
  assert(result.steps.length >= 14, 'dry-run 应返回完整注册步骤。');
  assert(result.warnings.length > 0, 'dry-run 应返回 warnings。');
  assert(result.summary.dryRunOnly === true, 'dry-run 摘要必须标记 dryRunOnly。');
});

test('dry-run 不连接数据库、不调用 IOPGPS、不生成合同文件', () => {
  const result = dryRunAutomatedRegistration(plan);
  const text = `${result.warnings.join('|')}|${JSON.stringify(result.steps)}`;
  assert(text.includes('未连接数据库') || text.includes('不创建数据库表'), 'dry-run 必须说明不连接或不写数据库。');
  assert(text.includes('未调用 IOPGPS') || text.includes('不调用 IOPGPS'), 'dry-run 必须说明不调用 IOPGPS。');
  assert(text.includes('未生成合同文件') || text.includes('不生成合同文件'), 'dry-run 必须说明不生成合同文件。');
});
