import { assert, test } from '../testHarness';
import { buildRealSmokeTestPlan, inspectNocobaseEnvironment, validateRealSmokeTestPlan, validateRealSmokeTestSafety } from '../../packages/shared/nocobase-automation/src';
import type { RealSmokeTestContext } from '../../packages/shared/nocobase-automation/src';

const context = (overrides: Partial<RealSmokeTestContext> = {}): RealSmokeTestContext => ({
  mode: 'plan_only',
  adapterEnvironment: inspectNocobaseEnvironment({ mode: 'dry_run' }),
  allowRealExecution: false,
  requireBackup: true,
  requireRollbackPlan: true,
  requireIsolatedDatabase: true,
  requireMockDataOnly: true,
  requireIopgpsDisabled: true,
  operator: 'test',
  notes: ['测试只生成草案。'],
  ...overrides,
});
const plan = () => buildRealSmokeTestPlan({ context: context() });

test('mode = real 且 allowRealExecution = false 时拒绝', () => {
  const c = context({ mode: 'real', allowRealExecution: false });
  const result = validateRealSmokeTestSafety(buildRealSmokeTestPlan({ context: c }), c);
  assert(!result.passed && result.errors.some((error) => error.includes('allowRealExecution')), '应拒绝未授权 real。');
});

test('mode = real 且无 backup 时拒绝', () => {
  const c = context({ mode: 'real', allowRealExecution: true, requireBackup: false });
  const result = validateRealSmokeTestSafety(buildRealSmokeTestPlan({ context: c }), c);
  assert(result.errors.some((error) => error.includes('requireBackup') || error.includes('备份')), '应拒绝无备份 real。');
});

test('mode = real 且无 isolated database 时拒绝', () => {
  const c = context({ mode: 'real', allowRealExecution: true, requireIsolatedDatabase: false });
  const result = validateRealSmokeTestSafety(buildRealSmokeTestPlan({ context: c }), c);
  assert(result.errors.some((error) => error.includes('requireIsolatedDatabase') || error.includes('隔离')), '应拒绝无隔离数据库 real。');
});

test('mode = real 且 IOPGPS 未禁用时拒绝', () => {
  const c = context({ mode: 'real', allowRealExecution: true, requireIopgpsDisabled: false });
  const result = validateRealSmokeTestSafety(buildRealSmokeTestPlan({ context: c }), c);
  assert(result.errors.some((error) => error.includes('IOPGPS') || error.includes('Iopgps')), '应拒绝真实 IOPGPS。');
});

test('当前仓库环境下不能执行 real', () => {
  const c = context({ mode: 'real', allowRealExecution: true });
  const result = validateRealSmokeTestSafety(buildRealSmokeTestPlan({ context: c }), c);
  assert(result.errors.some((error) => error.includes('当前仓库')), '当前仓库必须阻断 real。');
});

for (const forbidden of ['booking', 'driver_login', 'vehicle_category_rental', 'gps_rent_calculation', 'deposit_as_rent_payment']) {
  test(`出现 ${forbidden} 被拒绝`, () => {
    const p = plan();
    p.steps.push({ ...p.steps[0], name: forbidden, plannedAction: forbidden, title: forbidden });
    const result = validateRealSmokeTestPlan(p);
    assert(!result.passed && result.errors.some((error) => error.includes(forbidden) || error.includes('GPS') || error.includes('押金')), `应拒绝 ${forbidden}。`);
  });
}
