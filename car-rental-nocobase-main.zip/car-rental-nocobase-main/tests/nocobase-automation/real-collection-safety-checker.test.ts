import { assert, test } from '../testHarness';
import { createDefaultRealCollectionRegistrationContext, mapCollectionPlanToRealSchemaDraft, validateRealCollectionRegistrationSafety, validateRealCollectionSchemaDraft } from '../../packages/shared/nocobase-automation/src';
import type { NocobaseCollectionPlan, RealCollectionRegistrationPlan, RealCollectionSchemaDraft } from '../../packages/shared/nocobase-automation/src';

const baseCollection: NocobaseCollectionPlan = {
  name: 'safe_collection',
  title: '安全表',
  fields: ['name'],
  indexes: [],
  uniqueConstraints: [['name']],
  sensitiveFields: ['name'],
  relations: [],
  sourcePlugin: 'plugin-rental-core',
  notes: [],
};

function plan(mode: 'plan_only' | 'real' = 'plan_only'): RealCollectionRegistrationPlan {
  return { mode, collections: [mapCollectionPlanToRealSchemaDraft(baseCollection)], steps: [], safetyChecks: [], rollbackPlan: ['未真实执行，无数据库回滚。'], warnings: [], errors: [], notes: [] };
}

function renamed(name: string, notes: string[] = []): RealCollectionSchemaDraft {
  return { ...mapCollectionPlanToRealSchemaDraft({ ...baseCollection, name, notes }), name };
}

test('mode 默认不是 real', () => {
  const context = createDefaultRealCollectionRegistrationContext();
  assert(context.mode !== 'real', '默认模式不得为 real。');
});

test('mode = real 且 allowRealExecution = false 时拒绝', () => {
  const context = createDefaultRealCollectionRegistrationContext('real');
  const checks = validateRealCollectionRegistrationSafety(plan('real'), context);
  assert(checks.some((check) => check.errors.some((error) => error.includes('allowRealExecution') || error.includes('未显式允许'))), '应拒绝未显式允许的 real。');
});

test('mode = real 且无 backup 时拒绝', () => {
  const context = { ...createDefaultRealCollectionRegistrationContext('real'), allowRealExecution: true, requireBackup: false };
  const checks = validateRealCollectionRegistrationSafety(plan('real'), context);
  assert(checks.some((check) => check.errors.some((error) => error.includes('requireBackup'))), '应要求备份。');
});

test('mode = real 且无 rollbackPlan 时拒绝', () => {
  const context = { ...createDefaultRealCollectionRegistrationContext('real'), allowRealExecution: true, requireBackup: true, requireRollbackPlan: false };
  const checks = validateRealCollectionRegistrationSafety({ ...plan('real'), rollbackPlan: [] }, context);
  assert(checks.some((check) => check.errors.some((error) => error.includes('requireRollbackPlan') || error.includes('rollbackPlan'))), '应要求回滚方案。');
});

test('当前仓库环境下不能执行 real', () => {
  const context = { ...createDefaultRealCollectionRegistrationContext('real'), allowRealExecution: true, requireBackup: true, requireRollbackPlan: true };
  const checks = validateRealCollectionRegistrationSafety(plan('real'), context);
  assert(checks.some((check) => check.errors.some((error) => error.includes('当前仓库'))), '当前仓库应禁止 real。');
});

test('出现 booking 被拒绝', () => {
  assert(!validateRealCollectionSchemaDraft(renamed('bookings')).passed, 'bookings 应被拒绝。');
});

test('出现 driver_login 被拒绝', () => {
  assert(!validateRealCollectionSchemaDraft(renamed('driver_login')).passed, 'driver_login 应被拒绝。');
});

test('出现 vehicle_category_rental 被拒绝', () => {
  assert(!validateRealCollectionSchemaDraft(renamed('vehicle_category_rental')).passed, 'vehicle_category_rental 应被拒绝。');
});

test('GPS 参与租金计算被拒绝', () => {
  const result = validateRealCollectionSchemaDraft(renamed('gps_bad', ['GPS 参与租金计算']));
  assert(!result.passed, 'GPS 参与租金计算应被拒绝。');
});

test('押金计入租金已付被拒绝', () => {
  const result = validateRealCollectionSchemaDraft(renamed('deposit_bad', ['押金计入租金已付']));
  assert(!result.passed, '押金计入租金已付应被拒绝。');
});
