import { assert, test } from '../testHarness';
import { contractDocumentsPluginRegistration } from '../../packages/plugins/plugin-contract-documents/src/server/pluginRegistration';
import { iopgpsPluginRegistration } from '../../packages/plugins/plugin-iopgps/src/server/pluginRegistration';
import { rentalCorePluginRegistration } from '../../packages/plugins/plugin-rental-core/src/server/pluginRegistration';
import { buildAutomatedRegistrationPlan, MockCollectionAdapter } from '../../packages/shared/nocobase-automation/src';

const plan = buildAutomatedRegistrationPlan([
  iopgpsPluginRegistration,
  rentalCorePluginRegistration,
  contractDocumentsPluginRegistration,
]);
const drivers = plan.collections.find((collection) => collection.name === 'drivers')!;

test('Mock adapter 能注册 Collection 且不连接真实 NocoBase', () => {
  const adapter = new MockCollectionAdapter();
  const result = adapter.registerCollection(drivers);
  assert(result.success && result.created, '应成功记录 mock 注册。');
  assert(result.steps.some((step) => step.includes('不连接真实 NocoBase')), '步骤应说明不连接真实 NocoBase。');
  assert(result.steps.some((step) => step.includes('不写数据库')), '步骤应说明不写数据库。');
});

test('Mock adapter 遇到重复 Collection 时 skipped', () => {
  const adapter = new MockCollectionAdapter();
  adapter.registerCollection(drivers);
  const duplicate = adapter.registerCollection(drivers);
  assert(duplicate.success && duplicate.skipped, '重复注册应跳过。');
  assert(duplicate.warnings.some((warning) => warning.includes('已存在')), '应输出已存在警告。');
});
