import { assert, test } from '../testHarness';
import { contractDocumentsPluginRegistration } from '../../packages/plugins/plugin-contract-documents/src/server/pluginRegistration';
import { iopgpsPluginRegistration } from '../../packages/plugins/plugin-iopgps/src/server/pluginRegistration';
import { rentalCorePluginRegistration } from '../../packages/plugins/plugin-rental-core/src/server/pluginRegistration';
import { buildAutomatedRegistrationPlan, buildPageInitializationPlan, MockPageAdapter } from '../../packages/shared/nocobase-automation/src';

const automatedPlan = buildAutomatedRegistrationPlan([rentalCorePluginRegistration, contractDocumentsPluginRegistration, iopgpsPluginRegistration]);
const pagePlan = buildPageInitializationPlan(automatedPlan);

test('MockPageAdapter 不连接真实 NocoBase 且能记录菜单页面区块', () => {
  const adapter = new MockPageAdapter();
  const menuResults = adapter.registerMenus(pagePlan.menus.slice(0, 1));
  const pageResults = adapter.registerPages(pagePlan.pages.slice(0, 1));
  const blockResults = adapter.registerBlocks(pagePlan.blocks.slice(0, 1));
  assert(menuResults[0].success && pageResults[0].success && blockResults[0].success, 'mock adapter 应 dry-run 注册成功。');
  assert(menuResults[0].steps.join('').includes('不连接真实 NocoBase'), 'steps 应说明不连接真实 NocoBase。');
});

test('MockPageAdapter 遇到重复页面时 skipped', () => {
  const adapter = new MockPageAdapter();
  adapter.registerPages(pagePlan.pages.slice(0, 1));
  const repeated = adapter.registerPages(pagePlan.pages.slice(0, 1));
  assert(repeated[0].skipped, '重复页面应跳过。');
});
