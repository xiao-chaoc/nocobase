import { assert, test } from '../testHarness';
import { contractDocumentsPluginRegistration } from '../../packages/plugins/plugin-contract-documents/src/server/pluginRegistration';
import { iopgpsPluginRegistration } from '../../packages/plugins/plugin-iopgps/src/server/pluginRegistration';
import { rentalCorePluginRegistration } from '../../packages/plugins/plugin-rental-core/src/server/pluginRegistration';
import {
  buildAutomatedRegistrationPlan,
  buildCollectionRegistrationPlanFromAutomatedPlan,
  dryRunRegisterCollections,
  summarizeCollectionRegistrationResult,
} from '../../packages/shared/nocobase-automation/src';

const plan = buildAutomatedRegistrationPlan([
  iopgpsPluginRegistration,
  rentalCorePluginRegistration,
  contractDocumentsPluginRegistration,
]);

test('能从自动化注册计划提取 Collection 注册计划', () => {
  const collectionPlans = buildCollectionRegistrationPlanFromAutomatedPlan(plan);
  assert(collectionPlans.some((collection) => collection.name === 'drivers'), '应包含 drivers。');
  assert(collectionPlans.some((collection) => collection.name === 'contract_documents'), '应包含 contract_documents。');
});

test('dryRunRegisterCollections 返回中文步骤且不连接真实系统', () => {
  const collectionPlans = buildCollectionRegistrationPlanFromAutomatedPlan(plan);
  const result = dryRunRegisterCollections(collectionPlans);
  assert(result.success, `dry-run 应成功：${result.errors.join('；')}`);
  assert(result.results.some((item) => item.steps.some((step) => step.includes('dry-run'))), '步骤应包含 dry-run。');
  assert(result.warnings.some((warning) => warning.includes('不连接真实 NocoBase')), '警告应说明不连接真实 NocoBase。');
  assert(result.warnings.some((warning) => warning.includes('不写数据库')), '警告应说明不写数据库。');
  const summary = summarizeCollectionRegistrationResult(result);
  assert(summary.includes('关键唯一约束状态：通过'), '摘要应包含唯一约束状态。');
  assert(summary.includes('敏感字段覆盖状态：通过'), '摘要应包含敏感字段状态。');
});
