import { assert, test } from '../testHarness';
import { contractDocumentsPluginRegistration } from '../../packages/plugins/plugin-contract-documents/src/server/pluginRegistration';
import { iopgpsPluginRegistration } from '../../packages/plugins/plugin-iopgps/src/server/pluginRegistration';
import { rentalCorePluginRegistration } from '../../packages/plugins/plugin-rental-core/src/server/pluginRegistration';
import { buildAutomatedRegistrationPlan, buildRuntimeRegistrationPlanFromAutomatedPlan, normalizeSchedulePlans } from '../../packages/shared/nocobase-automation/src';

const runtimePlan = buildRuntimeRegistrationPlanFromAutomatedPlan(buildAutomatedRegistrationPlan([rentalCorePluginRegistration, contractDocumentsPluginRegistration, iopgpsPluginRegistration]));

test('能标准化定时任务计划', () => {
  const schedules = normalizeSchedulePlans(runtimePlan.schedules);
  assert(schedules.length >= 3, '应包含定时任务计划。');
  assert(schedules.every((schedule) => schedule.name && schedule.sourcePlugin && schedule.serviceName), '定时任务应包含 name/sourcePlugin/serviceName。');
});

test('iopgps 定时任务默认不应真实启用', () => {
  const schedules = normalizeSchedulePlans(runtimePlan.schedules).filter((schedule) => schedule.sourcePlugin === 'plugin-iopgps');
  assert(schedules.length > 0, '应包含 iopgps 定时任务。');
  assert(schedules.every((schedule) => schedule.enabledByDefault === false), 'iopgps 定时任务 dry-run 默认关闭。');
});
