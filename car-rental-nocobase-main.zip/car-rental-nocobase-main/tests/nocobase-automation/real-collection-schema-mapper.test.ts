import { assert, test } from '../testHarness';
import { mapCollectionPlanToRealSchemaDraft, mapFieldPlanToRealFieldSchemaDraft } from '../../packages/shared/nocobase-automation/src';
import type { CollectionFieldPlan, NocobaseCollectionPlan } from '../../packages/shared/nocobase-automation/src';

const samplePlan: NocobaseCollectionPlan = {
  name: 'sample_collections',
  title: '示例 Collection',
  fields: ['name', 'count', 'amount', 'status', 'driver_id', 'attachment_file', 'secret'],
  indexes: ['name'],
  uniqueConstraints: [['name']],
  sensitiveFields: ['secret'],
  relations: [{ field: 'driver_id', target: 'drivers.driver_id', type: 'belongsTo' }],
  sourcePlugin: 'plugin-rental-core',
  notes: ['仅用于测试。'],
  fieldPlans: [
    { name: 'name', type: 'text', title: '名称', required: true, enumValues: [], sensitive: false, unique: true, index: true, notes: [] },
    { name: 'count', type: 'integer', title: '数量', required: false, enumValues: [], sensitive: false, unique: false, index: false, notes: [] },
    { name: 'amount', type: 'decimal', title: '金额', required: false, enumValues: [], sensitive: false, unique: false, index: false, notes: [] },
    { name: 'status', type: 'enum', title: '状态', required: true, enumValues: ['active', 'inactive'], sensitive: false, unique: false, index: false, notes: [] },
    { name: 'driver_id', type: 'relation', title: '司机', required: false, enumValues: [], relation: { sourceCollection: 'sample_collections', sourceField: 'driver_id', targetCollection: 'drivers', relationType: 'belongsTo', foreignKey: 'driver_id', targetKey: 'driver_id', notes: [] }, sensitive: false, unique: false, index: true, notes: [] },
    { name: 'attachment_file', type: 'file', title: '附件', required: false, enumValues: [], sensitive: false, unique: false, index: false, notes: [] },
    { name: 'secret', type: 'encrypted text', title: '秘密', required: false, enumValues: [], sensitive: true, unique: false, index: false, notes: [] },
  ],
};

function field(type: string): CollectionFieldPlan {
  return { name: `${type}_field`, type, title: type, required: false, enumValues: [], sensitive: false, unique: false, index: false, notes: [] };
}

test('能将 Collection plan 映射为 schema draft', () => {
  const draft = mapCollectionPlanToRealSchemaDraft(samplePlan);
  assert(draft.name === 'sample_collections', '应保留 Collection 名称。');
  assert(draft.fields.length === samplePlan.fieldPlans!.length, '应转换全部字段计划。');
  assert(draft.sourcePlugin === 'plugin-rental-core', '应保留 sourcePlugin。');
});

test('text 字段能映射', () => {
  assert(mapFieldPlanToRealFieldSchemaDraft(field('text')).nocobaseFieldType === 'text', 'text 应映射为 text 草案。');
});

test('integer 字段能映射', () => {
  assert(mapFieldPlanToRealFieldSchemaDraft(field('integer')).nocobaseFieldType === 'integer', 'integer 应映射为 integer 草案。');
});

test('decimal 字段能映射', () => {
  assert(mapFieldPlanToRealFieldSchemaDraft(field('decimal')).nocobaseFieldType === 'decimal', 'decimal 应映射为 decimal 草案。');
});

test('enum 字段能映射为草案', () => {
  const draft = mapFieldPlanToRealFieldSchemaDraft({ ...field('enum'), enumValues: ['a', 'b'] });
  assert(draft.nocobaseFieldType === 'select', 'enum 应映射为 select/enum 草案。');
  assert(draft.enumValues.includes('a'), '应保留枚举值。');
});

test('relation 字段能保留 relation 草案', () => {
  const draft = mapCollectionPlanToRealSchemaDraft(samplePlan);
  const relationField = draft.fields.find((item) => item.name === 'driver_id');
  assert(relationField?.relation?.targetCollection === 'drivers', '应保留关系目标。');
});

test('file 字段能标记为文件草案', () => {
  const draft = mapFieldPlanToRealFieldSchemaDraft(field('file'));
  assert(draft.nocobaseFieldType === 'file', 'file 应映射为文件草案。');
  assert(draft.notes.some((note) => note.includes('文件') || note.includes('附件')), '应提示文件/附件草案。');
});

test('encrypted/password 字段能标记需要验证', () => {
  const encrypted = mapFieldPlanToRealFieldSchemaDraft(field('encrypted'));
  const password = mapFieldPlanToRealFieldSchemaDraft(field('password'));
  assert(encrypted.notes.some((note) => note.includes('验证')), 'encrypted 应提示需要验证。');
  assert(password.notes.some((note) => note.includes('验证')), 'password 应提示需要验证。');
});

test('uniqueConstraints 被保留', () => {
  const draft = mapCollectionPlanToRealSchemaDraft(samplePlan);
  assert(draft.uniqueConstraints.some((constraint) => constraint.includes('name')), '应保留唯一约束。');
});

test('sensitiveFields 被保留', () => {
  const draft = mapCollectionPlanToRealSchemaDraft(samplePlan);
  assert(draft.sensitiveFields.includes('secret'), '应保留敏感字段。');
});
