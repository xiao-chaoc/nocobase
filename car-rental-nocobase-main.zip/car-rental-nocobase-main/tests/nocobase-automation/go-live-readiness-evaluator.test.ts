import { assert, test } from '../testHarness';
import {
  buildGoLiveReadinessGates,
  evaluateGoLiveReadiness,
  type GoLiveReadinessContext,
} from '../../packages/shared/nocobase-automation/src';

function baseContext(overrides: Partial<GoLiveReadinessContext> = {}): GoLiveReadinessContext {
  const files = [
    'docs/current-repository-scan.md',
    'docker-compose.test.yml',
    '.env.test.example',
    'docs/deployment-nas-test.md',
    'docs/nas-test-runbook.md',
    'docs/nas-smoke-test-checklist.md',
    'test-data/generated/automated-registration-plan.generated.json',
    'test-data/generated/collection-registration-dry-run.generated.json',
    'test-data/generated/runtime-registration-dry-run.generated.json',
    'test-data/generated/page-initialization-dry-run.generated.json',
    'test-data/generated/seed-data-import-dry-run.generated.json',
    'test-data/generated/automated-smoke-test-report.generated.json',
    'test-data/generated/drivers.generated.json',
    'test-data/generated/vehicles.generated.json',
    'test-data/generated/generation-summary.generated.json',
  ];
  return {
    repository: 'car-rental-nocobase',
    branch: 'work',
    generatedAt: '2026-06-03T00:00:00.000Z',
    files,
    directories: ['packages/plugins/plugin-rental-core', 'packages/plugins/plugin-iopgps', 'packages/plugins/plugin-contract-documents'],
    fileContents: {
      'docs/current-repository-scan.md': '缺失项\n\n无。',
      'docker-compose.test.yml': 'volumes:\n  - ./storage-test/postgres:/var/lib/postgresql/data\n  - ./storage-test/nocobase:/app/nocobase/storage',
    },
    generatedReports: { 'test-data/generated/automated-smoke-test-report.generated.json': { report: { success: true } } },
    commandResults: { typecheck: true, unit_tests: true, seed_data_validation: true },
    ...overrides,
  };
}

test('smoke dry-run 通过但 real adapter 未实现时，不能标记 production_ready', () => {
  const report = evaluateGoLiveReadiness(buildGoLiveReadinessGates(baseContext()), { generatedAt: '2026-06-03T00:00:00.000Z' });
  assert(report.readiness_level !== 'production_ready', '当前阶段不能为 production_ready。');
  assert(report.forbidden_next_stage.includes('production_deployment'), '生产部署必须在禁止下一阶段中。');
});

test('real_nocobase_adapter_readiness 未通过时不能进入插件接入测试', () => {
  const report = evaluateGoLiveReadiness(buildGoLiveReadinessGates(baseContext()));
  assert(report.forbidden_next_stage.includes('plugin_integration_test_ready'), '真实 adapter 未通过时不能进入插件接入测试。');
});

test('缺少 smoke report 时产生 blocker', () => {
  const context = baseContext({ files: baseContext().files.filter((file) => !file.includes('automated-smoke-test-report')),
    generatedReports: {} });
  const gate = buildGoLiveReadinessGates(context).find((item) => item.name === 'smoke_test_dry_run');
  assert(gate?.status === 'failed', '缺少 smoke report 应失败。');
  assert((gate?.blockers.length ?? 0) > 0, '缺少 smoke report 应产生 blocker。');
});

test('缺少 NAS 文件时产生 blocker', () => {
  const context = baseContext({ files: baseContext().files.filter((file) => file !== 'docker-compose.test.yml') });
  const gate = buildGoLiveReadinessGates(context).find((item) => item.name === 'nas_test_files');
  assert(gate?.status === 'failed', '缺少 NAS 文件应失败。');
  assert(gate?.blockers.some((item) => item.includes('docker-compose.test.yml')), '应指出缺少 docker-compose.test.yml。');
});

test('发现 .env 或 .env.test 时 readiness failed', () => {
  for (const envFile of ['.env', '.env.test']) {
    const context = baseContext({ files: [...baseContext().files, envFile] });
    const gate = buildGoLiveReadinessGates(context).find((item) => item.name === 'security_boundary');
    assert(gate?.status === 'failed', `${envFile} 应导致安全 gate 失败。`);
  }
});

test('发现真实 access_token 风险时 readiness failed', () => {
  const context = baseContext({ fileContents: { ...baseContext().fileContents, 'test-data/generated/risk.generated.json': 'access_token = REAL_TOKEN_1234567890' } });
  const gate = buildGoLiveReadinessGates(context).find((item) => item.name === 'security_boundary');
  assert(gate?.status === 'failed', '真实 access_token 风险应失败。');
});

test('发现禁止业务模式时 readiness failed', () => {
  for (const forbidden of ['booking', 'driver_login', 'vehicle_category_rental']) {
    const context = baseContext({ fileContents: { ...baseContext().fileContents, 'test-data/generated/forbidden.generated.json': forbidden } });
    const gate = buildGoLiveReadinessGates(context).find((item) => item.name === 'forbidden_business_patterns');
    assert(gate?.status === 'failed', `${forbidden} 应导致禁止业务模式 gate 失败。`);
  }
});

test('NocoBase storage 和 PostgreSQL 数据目录混放时 readiness failed', () => {
  const context = baseContext({ fileContents: { ...baseContext().fileContents, 'docker-compose.test.yml': '- ./storage-test:/app/nocobase/storage' } });
  const gate = buildGoLiveReadinessGates(context).find((item) => item.name === 'nas_test_files');
  assert(gate?.status === 'failed', '混放 storage 应失败。');
});

test('docker-compose.test.yml 直接挂载 packages/plugins 时产生 blocker', () => {
  const context = baseContext({ fileContents: { ...baseContext().fileContents, 'docker-compose.test.yml': '- ./storage-test/postgres:/var/lib/postgresql/data\n- ./storage-test/nocobase:/app/nocobase/storage\n- ./packages/plugins:/app/nocobase/plugins' } });
  const gate = buildGoLiveReadinessGates(context).find((item) => item.name === 'nas_test_files');
  assert(gate?.status === 'failed', '直接挂载 packages/plugins 应失败。');
});
