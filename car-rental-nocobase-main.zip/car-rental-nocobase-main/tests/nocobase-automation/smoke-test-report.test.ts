import { assert, assertEqual, test } from '../testHarness';
import {
  buildSmokeTestReport,
  createSmokeTestStepResult,
  summarizeSmokeTestResult,
  type SmokeTestReport,
  type SmokeTestStepName,
} from '../../packages/shared/nocobase-automation/src';

const allSteps: SmokeTestStepName[] = [
  'repository_scan',
  'generate_registration_plan',
  'validate_registration_plan',
  'dry_run_register_collections',
  'validate_collection_registration',
  'dry_run_register_runtime',
  'validate_runtime_registration',
  'dry_run_initialize_pages',
  'validate_page_initialization',
  'seed_test_data',
  'validate_test_data',
  'dry_run_import_test_data',
  'validate_seed_data_import',
  'preflight_nas_test',
  'generate_smoke_report',
];

function safeReport(): SmokeTestReport {
  const steps = allSteps.map((name) => createSmokeTestStepResult({
    name,
    status: 'passed',
    started_at: '2026-06-03T00:00:00.000Z',
    finished_at: '2026-06-03T00:00:01.000Z',
    duration_ms: 1000,
    command: 'dry-run',
    output_summary: '本地 dry-run 通过。',
    artifacts: ['test-data/generated/automated-smoke-test-report.generated.json'],
  }));
  return buildSmokeTestReport(summarizeSmokeTestResult(steps));
}

test('buildSmokeTestReport 生成 report_no 与统计字段', () => {
  const report = safeReport();
  assert(report.report_no.startsWith('SMOKE-DRY-RUN-'), '报告编号应带有 dry-run 前缀。');
  assertEqual(report.failed_steps, 0, '安全报告不应有失败步骤。');
  assert(report.notes.some((note) => note.includes('真实 NocoBase')), '报告应说明不代表真实 NocoBase 上线测试。');
});

test('Smoke Test 报告不应包含真实密钥', () => {
  const serialized = JSON.stringify(safeReport());
  assert(!/sk-[A-Za-z0-9_-]{20,}/.test(serialized), '报告不应包含真实密钥。');
  assert(!/AKIA[0-9A-Z]{16}/.test(serialized), '报告不应包含云服务访问密钥。');
});

test('Smoke Test 报告不应包含禁止业务模式', () => {
  const serialized = JSON.stringify(safeReport()).toLowerCase();
  for (const forbidden of ['booking', 'reservation', 'driver_login', 'vehicle_category_rental']) {
    assert(!serialized.includes(forbidden), `报告不应包含禁止业务模式：${forbidden}`);
  }
});
