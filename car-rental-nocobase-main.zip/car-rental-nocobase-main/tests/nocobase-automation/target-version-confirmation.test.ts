import { assert, test } from '../testHarness';
declare const require: any;

const fs = require('fs');
const childProcess = require('child_process');

const read = (filePath: string): string => fs.readFileSync(filePath, 'utf8') as string;
const write = (filePath: string, content: string): void => fs.writeFileSync(filePath, content);

const manualDoc = 'docs/nocobase-target-version-manual-confirmation.md';
const freezeTemplateDoc = 'docs/nocobase-target-version-freeze-template.md';
const inputSchemaDoc = 'docs/nocobase-target-version-input-schema.md';
const decisionDoc = 'docs/nocobase-target-version-decision.md';
const validateScript = 'scripts/nocobase/validate-target-version-confirmation.ts';
const generateScript = 'scripts/nocobase/generate-target-version-confirmation-template.ts';
const generatedTemplate = 'test-data/generated/nocobase-target-version-confirmation.template.json';

let scriptsBuilt = false;

const ensureScriptsBuilt = (): void => {
  if (scriptsBuilt) return;
  childProcess.execFileSync('npm', ['run', 'build:scripts', '--silent'], { stdio: 'ignore' });
  scriptsBuilt = true;
};

const runValidate = (): { ok: boolean; output: string } => {
  ensureScriptsBuilt();
  try {
    const output = childProcess.execFileSync('node', ['.test-dist/scripts/scripts/nocobase/validate-target-version-confirmation.js'], {
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'pipe'],
    }) as string;
    return { ok: true, output };
  } catch (error) {
    const execError = error as { stdout?: string; stderr?: string };
    return { ok: false, output: `${execError.stdout ?? ''}${execError.stderr ?? ''}` };
  }
};

const makeDecisionContent = (overrides: Record<string, string>): string => {
  const fields: Record<string, string> = {
    decision_status: 'confirmed',
    target_version: 'manual-confirmed-test-version',
    source_reference: 'manual-test-source-reference',
    package_manager: 'yarn',
    confirmed_package_manager: 'yarn',
    iopgps_real_sync_allowed: 'false',
    mock_data_only: 'true',
    confirmed_by: 'manual-test-user',
    confirmed_at: '2026-06-06',
    ...overrides,
  };

  return [
    '# NocoBase 目标版本决策记录',
    '',
    '## 决策状态',
    '',
    '| 字段 | 值 |',
    '| --- | --- |',
    ...Object.entries(fields).map(([key, value]) => `| \`${key}\` | \`${value}\` |`),
    '',
    '目标版本未确认前不得实现真实 adapter。',
  ].join('\n');
};

const withDecisionContent = (content: string, assertion: () => void): void => {
  const original = read(decisionDoc);
  try {
    write(decisionDoc, content);
    assertion();
  } finally {
    write(decisionDoc, original);
  }
};

test('人工确认清单文档存在', () => {
  assert(fs.existsSync(manualDoc), '缺少人工确认清单文档。');
});

test('版本冻结模板存在', () => {
  assert(fs.existsSync(freezeTemplateDoc), '缺少版本冻结模板。');
});

test('输入 Schema 文档存在', () => {
  assert(fs.existsSync(inputSchemaDoc), '缺少输入 Schema 文档。');
});

test('validate-target-version-confirmation.ts 存在', () => {
  assert(fs.existsSync(validateScript), '缺少目标版本确认校验脚本。');
});

test('generate-target-version-confirmation-template.ts 存在', () => {
  assert(fs.existsSync(generateScript), '缺少目标版本确认草案生成脚本。');
});

test('package.json 包含 generate:target-version-template', () => {
  const packageJson = JSON.parse(read('package.json')) as { scripts?: Record<string, string> };
  assert(Boolean(packageJson.scripts?.['generate:target-version-template']), 'package.json 缺少 generate:target-version-template。');
});

test('package.json 包含 validate:target-version-confirmation', () => {
  const packageJson = JSON.parse(read('package.json')) as { scripts?: Record<string, string> };
  assert(Boolean(packageJson.scripts?.['validate:target-version-confirmation']), 'package.json 缺少 validate:target-version-confirmation。');
});

test('decision_status = pending_manual_confirmation 时校验失败', () => {
  withDecisionContent(makeDecisionContent({ decision_status: 'pending_manual_confirmation' }), () => {
    const result = runValidate();
    assert(!result.ok && result.output.includes('decision_status'), 'pending_manual_confirmation 应导致校验失败。');
  });
});

test('target_version = unset 时校验失败', () => {
  withDecisionContent(makeDecisionContent({ target_version: 'unset' }), () => {
    const result = runValidate();
    assert(!result.ok && result.output.includes('target_version'), 'unset 应导致校验失败。');
  });
});

test('target_version = latest-full 时校验失败', () => {
  withDecisionContent(makeDecisionContent({ target_version: 'latest-full' }), () => {
    const result = runValidate();
    assert(!result.ok && result.output.includes('latest-full'), 'latest-full 应导致校验失败。');
  });
});


test('package_manager = pnpm 时校验失败', () => {
  withDecisionContent(makeDecisionContent({ package_manager: 'pnpm' }), () => {
    const result = runValidate();
    assert(!result.ok && result.output.includes('package_manager'), 'package_manager 为 pnpm 应导致校验失败。');
  });
});

test('confirmed_package_manager = pnpm 时校验失败', () => {
  withDecisionContent(makeDecisionContent({ confirmed_package_manager: 'pnpm' }), () => {
    const result = runValidate();
    assert(!result.ok && result.output.includes('confirmed_package_manager'), 'confirmed_package_manager 为 pnpm 应导致校验失败。');
  });
});

test('iopgps_real_sync_allowed = true 时校验失败', () => {
  withDecisionContent(makeDecisionContent({ iopgps_real_sync_allowed: 'true' }), () => {
    const result = runValidate();
    assert(!result.ok && result.output.includes('iopgps_real_sync_allowed'), '允许真实 IOPGPS 应导致校验失败。');
  });
});

test('mock_data_only = false 时校验失败', () => {
  withDecisionContent(makeDecisionContent({ mock_data_only: 'false' }), () => {
    const result = runValidate();
    assert(!result.ok && result.output.includes('mock_data_only'), 'mock_data_only 为 false 应导致校验失败。');
  });
});

test('缺少 confirmed_by 时校验失败', () => {
  withDecisionContent(makeDecisionContent({ confirmed_by: 'unset' }), () => {
    const result = runValidate();
    assert(!result.ok && result.output.includes('confirmed_by'), '缺少 confirmed_by 应导致校验失败。');
  });
});

test('缺少 confirmed_at 时校验失败', () => {
  withDecisionContent(makeDecisionContent({ confirmed_at: 'unset' }), () => {
    const result = runValidate();
    assert(!result.ok && result.output.includes('confirmed_at'), '缺少 confirmed_at 应导致校验失败。');
  });
});

test('模板生成脚本不包含 APP_KEY', () => {
  assert(!read(generateScript).includes('APP_KEY') || read(generateScript).includes('不得包含真实密钥、APP_KEY'), '生成脚本不得包含真实 APP_KEY。');
});

test('模板生成脚本不包含 DB_PASSWORD', () => {
  assert(!read(generateScript).includes('DB_PASSWORD') || read(generateScript).includes('不得包含真实密钥、APP_KEY、DB_PASSWORD'), '生成脚本不得包含真实 DB_PASSWORD。');
});

test('模板生成脚本不包含 IOPGPS_LOGIN_KEY', () => {
  assert(!read(generateScript).includes('IOPGPS_LOGIN_KEY'), '生成脚本不得包含 IOPGPS_LOGIN_KEY。');
});

test('脚本不读取 .env.test', () => {
  const scripts = [read(validateScript), read(generateScript)].join('\n');
  assert(!scripts.includes("readFileSync(path.join(rootDir, '.env.test')") && !scripts.includes('readFileSync(\'.env.test\')'), '脚本不得读取 .env.test。');
});

test('脚本不连接 NocoBase', () => {
  const scripts = [read(validateScript), read(generateScript)].join('\n');
  assert(!scripts.includes('axios') && !scripts.includes('fetch(') && !scripts.includes('pluginManager'), '脚本不得连接 NocoBase。');
});

test('文档明确版本未确认前不得实现真实 adapter', () => {
  const combined = [manualDoc, freezeTemplateDoc, inputSchemaDoc, decisionDoc].map(read).join('\n');
  assert(combined.includes('目标版本未确认前不得实现真实 adapter') || combined.includes('不继续写真实 adapter'), '文档必须明确版本未确认前不得实现真实 adapter。');
});

test('生成后的模板不包含敏感密钥字段', () => {
  ensureScriptsBuilt();
  childProcess.execFileSync('node', ['.test-dist/scripts/scripts/nocobase/generate-target-version-confirmation-template.js'], { stdio: 'ignore' });
  const generated = read(generatedTemplate);
  assert(!generated.includes('APP_KEY'), '生成模板不得包含 APP_KEY。');
  assert(!generated.includes('DB_PASSWORD'), '生成模板不得包含 DB_PASSWORD。');
  assert(!generated.includes('IOPGPS_LOGIN_KEY'), '生成模板不得包含 IOPGPS_LOGIN_KEY。');
});
