import { assert, test } from '../testHarness';
import { createDefaultRealRuntimeRegistrationContext, RealRuntimeRegistrationAdapter } from '../../packages/shared/nocobase-automation/src';
import { generateAutomatedRegistrationPlan } from '../../scripts/nocobase/generate-automated-registration-plan';
import { generateRealRuntimeRegistrationPlan } from '../../scripts/nocobase/generate-real-runtime-registration-plan';
import { validateGeneratedRealRuntimeRegistrationPlan } from '../../scripts/nocobase/validate-real-runtime-registration-plan';
import type { RuntimeRegistrationPlan } from '../../packages/shared/nocobase-automation/src';

const runtimePlan: RuntimeRegistrationPlan = {
  services: [{ name: 'paymentAllocationService.allocateRentPayment', sourcePlugin: 'plugin-rental-core', handlerName: 'allocateRentPayment', permissions: ['rent_payments:create'], transactional: true, notes: ['GPS 数据不参与租金计算', '押金不计入租金'] }],
  actions: [{ name: 'confirm_rent_payment', title: '确认付款', sourcePlugin: 'plugin-rental-core', inputSchema: ['paymentId'], outputSchema: 'paymentResult', requiredPermissions: ['rent_payments:create'], serviceName: 'paymentAllocationService.allocateRentPayment', notes: [] }],
  permissions: [
    { role: 'system_admin', collections: ['rent_payments', 'deposit_records'], actions: ['read', 'create', 'update', '审批免除'], fieldVisibility: { payment_screenshot: 'visible', total_paid_amount: 'visible', future_receivable_amount: 'visible', current_debt_amount: 'visible' }, sensitiveFields: ['payment_screenshot'], notes: ['审批'] },
    { role: 'manager', collections: ['rent_payments', 'deposit_records'], actions: ['read', '审批免除'], fieldVisibility: { payment_screenshot: 'masked', total_paid_amount: 'visible', future_receivable_amount: 'visible', current_debt_amount: 'visible' }, sensitiveFields: ['payment_screenshot'], notes: ['可审批免除'] },
    { role: 'accountant', collections: ['rent_payments', 'deposit_records'], actions: ['read'], fieldVisibility: { payment_screenshot: 'visible', total_paid_amount: 'visible', future_receivable_amount: 'visible', current_debt_amount: 'visible' }, sensitiveFields: ['payment_screenshot'], notes: [] },
    { role: 'operator', collections: ['drivers'], actions: ['read'], fieldVisibility: { payment_screenshot: 'hidden', total_paid_amount: 'hidden', future_receivable_amount: 'hidden', current_debt_amount: 'hidden' }, sensitiveFields: ['payment_screenshot'], notes: [] },
    { role: 'gps_maintenance', collections: ['gps_devices'], actions: ['read'], fieldVisibility: { payment_screenshot: 'hidden', total_paid_amount: 'hidden', future_receivable_amount: 'hidden', current_debt_amount: 'hidden' }, sensitiveFields: ['payment_screenshot'], notes: [] },
    { role: 'readonly_auditor', collections: ['drivers'], actions: ['read'], fieldVisibility: { payment_screenshot: 'hidden', total_paid_amount: 'masked', future_receivable_amount: 'masked', current_debt_amount: 'masked' }, sensitiveFields: ['payment_screenshot'], notes: [] },
  ],
  schedules: [{ name: 'iopgps_sync_location', title: '同步定位', sourcePlugin: 'plugin-iopgps', cron: '*/30 * * * *', enabledByDefault: false, serviceName: 'iopgpsLocationService.syncLocation', notes: ['GPS 数据不参与租金计算'] }],
  i18n: [{ namespace: 'plugin-rental-core', sourcePlugin: 'plugin-rental-core', languages: ['zh-CN', 'en-US', 'fr-FR'], localeFiles: ['zh-CN.json', 'en-US.json', 'fr-FR.json'], notes: [] }],
  warnings: [],
  notes: ['GPS 数据不参与租金计算', '押金不计入租金'],
};

test('adapter 只生成计划，不注册服务', () => {
  const adapter = new RealRuntimeRegistrationAdapter();
  const plan = adapter.buildRealRuntimeRegistrationPlan(runtimePlan, createDefaultRealRuntimeRegistrationContext('plan_only'));
  const report = adapter.validateRealRuntimeRegistrationPlan(plan);
  assert(plan.services.length === 1, '应生成服务草案。');
  assert(report.executed === false && report.runtimeExecutable === 0, '不得标记真实执行。');
});

test('adapter 不调用真实 NocoBase API', () => {
  const adapter = new RealRuntimeRegistrationAdapter();
  const plan = adapter.buildRealRuntimeRegistrationPlan(runtimePlan);
  assert(plan.notes.some((note) => note.includes('不连接 NocoBase')), '应声明不连接 NocoBase。');
  assert(plan.steps.every((step) => step.canExecute === false), '所有步骤均不可真实执行。');
});

test('脚本能生成 real-runtime-registration-plan.generated.json', () => {
  generateAutomatedRegistrationPlan();
  const result = generateRealRuntimeRegistrationPlan();
  assert(result.output.plan.mode === 'plan_only', '生成脚本默认应使用 plan_only。');
  assert(result.output.plan.services.length > 0, '应生成 Runtime schema draft。');
});

test('校验脚本能通过 plan_only 结果', () => {
  generateAutomatedRegistrationPlan();
  generateRealRuntimeRegistrationPlan();
  const result = validateGeneratedRealRuntimeRegistrationPlan();
  assert(result.passed, `校验脚本应通过：${result.errors.join('；')}`);
});
