import { assert, assertEqual, assertThrows, test } from '../testHarness';
import {
  assertRealAdapterReady,
  createNocobaseAutomationAdapter,
  detectNocobaseAdapterMode,
  UnconfiguredNocobaseRealAdapter,
} from '../../packages/shared/nocobase-automation/src';

test('createNocobaseAutomationAdapter 在 disabled 模式返回未配置 adapter', () => {
  const adapter = createNocobaseAutomationAdapter({ mode: 'disabled' });
  assert(adapter instanceof UnconfiguredNocobaseRealAdapter, 'disabled 模式应返回未配置 adapter。');
  assertEqual(adapter.inspectEnvironment().mode, 'disabled', '环境模式应为 disabled。');
});

test('createNocobaseAutomationAdapter 在 real 但缺少 app 时返回未配置 adapter', () => {
  const adapter = createNocobaseAutomationAdapter({ mode: 'real', db: {}, acl: {}, uiSchema: {}, pluginManager: {} });
  assert(adapter instanceof UnconfiguredNocobaseRealAdapter, '缺少 app 时应返回未配置 adapter。');
  assert(adapter.inspectEnvironment().errors.some((error) => error.includes('真实 NocoBase app')), '应输出缺少 app 错误。');
});

test('detectNocobaseAdapterMode 能识别 dry_run', () => {
  const detection = detectNocobaseAdapterMode({ mode: 'dry_run' });
  assertEqual(detection.mode, 'dry_run', '应识别 dry-run 模式。');
  assertEqual(detection.errors.length, 0, 'dry-run 模式不应因为缺少真实对象而阻塞模式识别。');
});

test('detectNocobaseAdapterMode 能识别 disabled', () => {
  const detection = detectNocobaseAdapterMode({});
  assertEqual(detection.mode, 'disabled', '未配置时应为 disabled。');
  assert(detection.errors.length > 0, 'disabled 模式应报告不可真实执行。');
});

test('assertRealAdapterReady 对未配置 adapter 抛出受控错误', () => {
  const adapter = createNocobaseAutomationAdapter({ mode: 'real' });
  assertThrows(() => assertRealAdapterReady(adapter), 'nocobase_adapter_not_configured');
});
