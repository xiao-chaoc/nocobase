import { assert, test } from '../testHarness';
import { buildPageInitializationPlan, createDefaultRealPageRegistrationContext, RealPageRegistrationAdapter, validateRealPageSchemaDraft } from '../../packages/shared/nocobase-automation/src';
import { generateAutomatedRegistrationPlan } from '../../scripts/nocobase/generate-automated-registration-plan';
import { generateRealPageRegistrationPlan } from '../../scripts/nocobase/generate-real-page-registration-plan';
import { validateGeneratedRealPageRegistrationPlan } from '../../scripts/nocobase/validate-real-page-registration-plan';
import type { PageInitializationPlan } from '../../packages/shared/nocobase-automation/src';

const automatedPlan = generateAutomatedRegistrationPlan().output.plan;
const pagePlan: PageInitializationPlan = buildPageInitializationPlan(automatedPlan);

test('真实 Page adapter 只生成草案，不创建真实页面', () => {
  const adapter = new RealPageRegistrationAdapter();
  const plan = adapter.buildRealPageRegistrationPlan(pagePlan, createDefaultRealPageRegistrationContext('plan_only'));
  const report = adapter.validateRealPageRegistrationPlan(plan);
  assert(plan.pages.length >= 12, '应生成核心页面草案。');
  assert(report.executed === false, '不得标记真实执行。');
  assert(plan.notes.some((note) => note.includes('未调用真实 NocoBase')), '应声明未调用真实 NocoBase API。');
});

test('真实 Page schema 草案保留敏感字段权限提示', () => {
  const plan = new RealPageRegistrationAdapter().buildRealPageRegistrationPlan(pagePlan);
  const text = JSON.stringify(plan);
  assert(text.includes('字段级权限'), '敏感字段必须提示字段级权限控制。');
  assert(plan.blocks.some((block) => block.sensitiveFieldWarnings.length > 0), '敏感区块应生成警告。');
});

test('真实 Page schema 缺少页面 route 会被拒绝', () => {
  const brokenPlan = { ...pagePlan, pages: [{ ...pagePlan.pages[0], route: '' }] };
  const plan = new RealPageRegistrationAdapter().buildRealPageRegistrationPlan(brokenPlan);
  const result = validateRealPageSchemaDraft(plan);
  assert(!result.passed && result.errors.some((error) => error.includes('route')), '缺少 route 应被拒绝。');
});

test('真实 Page adapter 的 real 模式在当前仓库被拒绝', () => {
  const plan = new RealPageRegistrationAdapter().buildRealPageRegistrationPlan(pagePlan, createDefaultRealPageRegistrationContext('real'));
  assert(plan.errors.some((error) => error.includes('当前仓库') || error.includes('real')), '当前仓库不能执行 real Page 注册。');
});

test('脚本能生成 real-page-registration-plan.generated.json', () => {
  generateAutomatedRegistrationPlan();
  const result = generateRealPageRegistrationPlan();
  assert(result.output.plan.mode === 'plan_only', '生成脚本默认应使用 plan_only。');
  assert(result.output.plan.pages.length > 0, '应生成 Page schema draft。');
});

test('真实 Page 校验脚本能通过 plan_only 结果', () => {
  generateAutomatedRegistrationPlan();
  generateRealPageRegistrationPlan();
  const result = validateGeneratedRealPageRegistrationPlan();
  assert(result.passed, `校验脚本应通过：${result.errors.join('；')}`);
});
