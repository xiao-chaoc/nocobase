import { assert, test } from '../testHarness';
import { buildFailureRecoveryPlans, buildPostRollbackVerificationPlan, buildRealBackupPlan, buildRealRollbackPlan, inspectNocobaseEnvironment } from '../../packages/shared/nocobase-automation/src';
import type { RealBackupRollbackContext } from '../../packages/shared/nocobase-automation/src';

const context = (overrides: Partial<RealBackupRollbackContext> = {}): RealBackupRollbackContext => ({
  mode: 'plan_only',
  adapterEnvironment: inspectNocobaseEnvironment({ mode: 'dry_run' }),
  allowRealExecution: false,
  requireOperatorConfirmation: false,
  requireIsolatedDatabase: true,
  requireMockDataOnly: true,
  requireIopgpsDisabled: true,
  backupDirectory: 'backups-test/real-backup-rollback-draft',
  rollbackDirectory: 'backups-test/real-backup-rollback-draft/rollback',
  operator: 'test',
  notes: ['测试只生成草案。'],
  ...overrides,
});

test('能生成 backup plan', () => {
  const plan = buildRealBackupPlan(context());
  assert(plan.steps.length > 0, '应生成备份步骤。');
  assert(plan.mode !== 'real', '默认模式不能是 real。');
});

for (const target of ['database', 'file_storage', 'plugin_storage', 'collection_schema', 'runtime_registry', 'page_schema', 'seed_data', 'logs', 'environment_config'] as const) {
  test(`backup plan 包含 ${target}`, () => {
    const plan = buildRealBackupPlan(context());
    assert(plan.targets.includes(target), `应包含 ${target}。`);
    assert(plan.steps.some((step) => step.targetType === target), `应包含 ${target} 步骤。`);
  });
}

test('backup plan 不读取 .env.test 真实值', () => {
  const plan = buildRealBackupPlan(context());
  const text = JSON.stringify(plan);
  assert(text.includes('存在性'), '应只记录环境配置存在性要求。');
  assert(!text.includes('DB_PASSWORD=') && !text.includes('IopgpsTokenValue'), '不得包含真实环境值。');
});



test('回滚后验证计划包含操作人草案记录且不包含密钥', () => {
  const steps = buildPostRollbackVerificationPlan(context({ operator: 'test-operator' }));
  const text = steps.join(' ');
  assert(text.includes('NocoBase') && text.includes('PostgreSQL'), '应包含服务启动验证。');
  assert(text.includes('test-operator'), '应包含操作人草案归档提示。');
  assert(!text.includes('DB_PASSWORD=') && !text.includes('secret='), '不得包含真实密钥。');
});

test('能生成 rollback plan', () => {
  const plan = buildRealRollbackPlan(context());
  assert(plan.steps.length > 0, '应生成回滚步骤。');
  assert(plan.verificationSteps.length > 0, '应生成后置验证计划。');
});

for (const target of ['database_restore', 'file_storage_restore', 'plugin_disable', 'seed_data_cleanup', 'logs_preserve'] as const) {
  test(`rollback plan 包含 ${target}`, () => {
    const plan = buildRealRollbackPlan(context());
    assert(plan.targets.includes(target), `应包含 ${target}。`);
    assert(plan.steps.some((step) => step.targetType === target), `应包含 ${target} 步骤。`);
  });
}

test('能生成 failure recovery plans', () => {
  const plans = buildFailureRecoveryPlans(context());
  assert(plans.length >= 10, '应覆盖主要失败类型。');
});

for (const failureType of ['collection_registration_failed', 'runtime_registration_failed', 'page_registration_failed', 'seed_data_import_failed', 'smoke_test_failed', 'sensitive_data_exposure_detected'] as const) {
  test(`failure recovery 覆盖 ${failureType}`, () => {
    const plans = buildFailureRecoveryPlans(context());
    const plan = plans.find((item) => item.failureType === failureType);
    assert(!!plan, `应覆盖 ${failureType}。`);
    assert(!!plan?.detectionMethod && plan.isolationSteps.length > 0 && plan.rollbackSteps.length > 0 && plan.verificationSteps.length > 0 && plan.escalationSteps.length > 0, '失败恢复计划结构应完整。');
  });
}
