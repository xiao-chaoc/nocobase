import { assert, test } from '../testHarness';
import { contractDocumentsPluginRegistration } from '../../packages/plugins/plugin-contract-documents/src/server/pluginRegistration';
import { iopgpsPluginRegistration } from '../../packages/plugins/plugin-iopgps/src/server/pluginRegistration';
import { rentalCorePluginRegistration } from '../../packages/plugins/plugin-rental-core/src/server/pluginRegistration';
import { buildAutomatedRegistrationPlan, buildRuntimeRegistrationPlanFromAutomatedPlan, extractSensitiveFieldPermissionCoverage, validateRolePermissionCoverage } from '../../packages/shared/nocobase-automation/src';

const runtimePlan = buildRuntimeRegistrationPlanFromAutomatedPlan(buildAutomatedRegistrationPlan([rentalCorePluginRegistration, contractDocumentsPluginRegistration, iopgpsPluginRegistration]));

test('能标准化权限计划并包含六个角色', () => {
  const roles = runtimePlan.permissions.map((permission) => permission.role);
  for (const role of ['system_admin', 'manager', 'accountant', 'operator', 'gps_maintenance', 'readonly_auditor']) {
    assert(roles.includes(role), `缺少角色：${role}`);
  }
});

test('敏感字段权限覆盖符合默认规则', () => {
  const coverage = extractSensitiveFieldPermissionCoverage(runtimePlan.permissions);
  assert(coverage.operator.payment_screenshot === 'hidden', 'operator 默认不能查看付款截图。');
  assert(coverage.gps_maintenance.total_paid_amount === 'hidden', 'gps_maintenance 默认不能查看财务汇总。');
  assert(runtimePlan.permissions.find((permission) => permission.role === 'accountant')!.collections.includes('rent_payments'), 'accountant 可访问付款。');
  assert(runtimePlan.permissions.find((permission) => permission.role === 'accountant')!.collections.includes('deposit_records'), 'accountant 可访问押金。');
  assert(JSON.stringify(runtimePlan.permissions.find((permission) => permission.role === 'manager')).includes('审批'), 'manager 可审批免除。');
  const result = validateRolePermissionCoverage(runtimePlan);
  assert(result.passed, `角色权限覆盖应通过：${result.errors.join('；')}`);
});
