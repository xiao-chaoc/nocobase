import { assert, test } from '../testHarness';
import { contractDocumentsPluginRegistration } from '../../packages/plugins/plugin-contract-documents/src/server/pluginRegistration';
import { iopgpsPluginRegistration } from '../../packages/plugins/plugin-iopgps/src/server/pluginRegistration';
import { rentalCorePluginRegistration } from '../../packages/plugins/plugin-rental-core/src/server/pluginRegistration';
import {
  buildAutomatedRegistrationPlan,
  extractRelations,
  extractSensitiveFields,
  extractUniqueConstraints,
  normalizeCollectionPlan,
  normalizeCollectionPlans,
} from '../../packages/shared/nocobase-automation/src';

const plan = buildAutomatedRegistrationPlan([
  iopgpsPluginRegistration,
  rentalCorePluginRegistration,
  contractDocumentsPluginRegistration,
]);
const collections = normalizeCollectionPlans(plan.collections);

const findCollection = (name: string) => {
  const collection = collections.find((item) => item.name === name);
  if (!collection) throw new Error(`缺少 Collection：${name}`);
  return collection;
};

test('能标准化 Collection 草案并补齐字段计划', () => {
  const drivers = normalizeCollectionPlan(findCollection('drivers'));
  assert(drivers.fieldPlans && drivers.fieldPlans.length > 0, '应生成字段计划。');
  assert(drivers.fieldPlans!.every((field) => field.title && typeof field.required === 'boolean'), '字段应补齐 title 和 required。');
});

test('能提取敏感字段', () => {
  const drivers = findCollection('drivers');
  const sensitiveFields = extractSensitiveFields(drivers);
  assert(sensitiveFields.includes('id_no'), '应提取司机证件号敏感字段。');
  assert(sensitiveFields.includes('license_front_file'), '应提取驾照照片敏感字段。');
});

test('能提取唯一约束', () => {
  const ledger = findCollection('rent_daily_ledgers');
  const uniqueConstraints = extractUniqueConstraints(ledger);
  assert(uniqueConstraints.some((fields) => fields.includes('contract_id') && fields.includes('rent_date')), '应提取台账合同+日期唯一约束。');
});

test('能提取关系字段', () => {
  const contract = findCollection('lease_contracts');
  const relations = extractRelations(contract);
  assert(relations.some((relation) => relation.targetCollection === 'drivers'), '合同应包含司机关系计划。');
  assert(relations.some((relation) => relation.targetCollection === 'vehicles'), '合同应包含车辆关系计划。');
});
