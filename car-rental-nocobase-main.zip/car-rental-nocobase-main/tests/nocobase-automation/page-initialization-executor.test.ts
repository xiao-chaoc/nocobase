import { assert, test } from '../testHarness';
import { contractDocumentsPluginRegistration } from '../../packages/plugins/plugin-contract-documents/src/server/pluginRegistration';
import { iopgpsPluginRegistration } from '../../packages/plugins/plugin-iopgps/src/server/pluginRegistration';
import { rentalCorePluginRegistration } from '../../packages/plugins/plugin-rental-core/src/server/pluginRegistration';
import { buildAutomatedRegistrationPlan, buildPageInitializationPlan, dryRunInitializePages, summarizePageInitializationResult } from '../../packages/shared/nocobase-automation/src';

const automatedPlan = buildAutomatedRegistrationPlan([rentalCorePluginRegistration, contractDocumentsPluginRegistration, iopgpsPluginRegistration]);
const pagePlan = buildPageInitializationPlan(automatedPlan);

test('dryRunInitializePages 返回中文步骤和 summary', () => {
  const result = dryRunInitializePages(pagePlan);
  const summary = summarizePageInitializationResult(result);
  assert(result.success, result.errors.join('；'));
  assert(result.menuResults[0].steps.join('').includes('dry-run'), '步骤应包含 dry-run。');
  assert(result.menuResults[0].steps.join('').includes('不连接真实 NocoBase'), '步骤应说明不连接真实 NocoBase。');
  assert(summary.includes('菜单数量'), 'summary 应为中文摘要。');
});
