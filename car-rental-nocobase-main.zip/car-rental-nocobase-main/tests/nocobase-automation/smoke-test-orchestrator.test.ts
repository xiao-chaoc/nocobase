import { assert, assertEqual, test } from '../testHarness';
import {
  buildSmokeTestPlan,
  createSmokeTestStepResult,
  summarizeSmokeTestResult,
  validateSmokeTestPrerequisites,
  type SmokeTestStepName,
} from '../../packages/shared/nocobase-automation/src';

const expectedOrder: SmokeTestStepName[] = [
  'repository_scan',
  'generate_registration_plan',
  'validate_registration_plan',
  'dry_run_register_collections',
  'validate_collection_registration',
  'dry_run_register_runtime',
  'validate_runtime_registration',
  'dry_run_initialize_pages',
  'validate_page_initialization',
  'seed_test_data',
  'validate_test_data',
  'dry_run_import_test_data',
  'validate_seed_data_import',
  'preflight_nas_test',
  'generate_smoke_report',
];

function passedStep(name: SmokeTestStepName) {
  return createSmokeTestStepResult({
    name,
    status: 'passed',
    started_at: '2026-06-03T00:00:00.000Z',
    finished_at: '2026-06-03T00:00:01.000Z',
    duration_ms: 1000,
    command: 'dry-run',
    output_summary: '通过。',
    artifacts: [],
  });
}

test('buildSmokeTestPlan 返回固定步骤并保持顺序', () => {
  const plan = buildSmokeTestPlan();
  assertEqual(plan.map((step) => step.name).join(','), expectedOrder.join(','), 'smoke test 步骤顺序必须固定。');
});

test('Smoke Test 计划包含 registration plan、collection、runtime、page 和 seed-data dry-run', () => {
  const names = new Set(buildSmokeTestPlan().map((step) => step.name));
  assert(names.has('generate_registration_plan'), '应包含 registration plan 生成步骤。');
  assert(names.has('dry_run_register_collections'), '应包含 collection dry-run。');
  assert(names.has('dry_run_register_runtime'), '应包含 runtime dry-run。');
  assert(names.has('dry_run_initialize_pages'), '应包含 page initialization dry-run。');
  assert(names.has('dry_run_import_test_data'), '应包含 seed data import dry-run。');
});

test('summarizeSmokeTestResult 能识别成功结果', () => {
  const result = summarizeSmokeTestResult(expectedOrder.map(passedStep));
  assert(result.success, '全部步骤通过时 success 应为 true。');
  assertEqual(result.summary.failed_steps, 0);
});

test('summarizeSmokeTestResult 能识别失败并在阻塞步骤失败时 success=false', () => {
  const steps = expectedOrder.map(passedStep);
  steps[3] = createSmokeTestStepResult({
    name: 'dry_run_register_collections',
    status: 'failed',
    errors: ['Collection dry-run 失败。'],
  });
  const result = summarizeSmokeTestResult(steps);
  assert(!result.success, '阻塞步骤失败时 success 必须为 false。');
  assert(result.summary.blocking_failed_steps > 0, '应统计阻塞失败步骤。');
});

test('非阻塞 warning 不一定导致 success=false', () => {
  const steps = expectedOrder.map(passedStep);
  steps[14] = createSmokeTestStepResult({
    name: 'generate_smoke_report',
    status: 'warning',
    warnings: ['报告生成存在非阻塞提示。'],
  });
  const result = summarizeSmokeTestResult(steps);
  assert(result.success, '非阻塞 warning 不应直接导致失败。');
  assertEqual(result.summary.warning_steps, 1);
});

test('validateSmokeTestPrerequisites 能发现缺失文件', () => {
  const validation = validateSmokeTestPrerequisites(['package.json']);
  assert(!validation.passed, '缺少前置文件时校验应失败。');
  assert(validation.errors.some((error) => error.includes('docker-compose.test.yml')), '应指出缺失的 docker compose 测试文件。');
});
