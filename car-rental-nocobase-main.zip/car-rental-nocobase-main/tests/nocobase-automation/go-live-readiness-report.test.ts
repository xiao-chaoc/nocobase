import { assert, test } from '../testHarness';
import {
  buildGoLiveReadinessGates,
  evaluateGoLiveReadiness,
  renderGoLiveReadinessMarkdown,
  summarizeGoLiveReadiness,
  type GoLiveReadinessContext,
} from '../../packages/shared/nocobase-automation/src';

const context: GoLiveReadinessContext = {
  files: [
    'docs/current-repository-scan.md',
    'docker-compose.test.yml',
    '.env.test.example',
    'docs/deployment-nas-test.md',
    'docs/nas-test-runbook.md',
    'docs/nas-smoke-test-checklist.md',
    'test-data/generated/automated-registration-plan.generated.json',
    'test-data/generated/collection-registration-dry-run.generated.json',
    'test-data/generated/runtime-registration-dry-run.generated.json',
    'test-data/generated/page-initialization-dry-run.generated.json',
    'test-data/generated/seed-data-import-dry-run.generated.json',
    'test-data/generated/automated-smoke-test-report.generated.json',
    'test-data/generated/drivers.generated.json',
    'test-data/generated/vehicles.generated.json',
    'test-data/generated/generation-summary.generated.json',
  ],
  directories: ['packages/plugins/plugin-rental-core', 'packages/plugins/plugin-iopgps', 'packages/plugins/plugin-contract-documents'],
  fileContents: {
    'docs/current-repository-scan.md': '缺失项\n\n无。',
    'docker-compose.test.yml': 'volumes:\n  - ./storage-test/postgres:/var/lib/postgresql/data\n  - ./storage-test/nocobase:/app/nocobase/storage',
  },
  generatedReports: { 'test-data/generated/automated-smoke-test-report.generated.json': { report: { success: true } } },
  commandResults: { typecheck: true, unit_tests: true, seed_data_validation: true },
};

test('production_readiness 当前阶段必须 not_applicable 或 failed', () => {
  const gate = buildGoLiveReadinessGates(context).find((item) => item.name === 'production_readiness');
  assert(gate?.status === 'not_applicable' || gate?.status === 'failed', '生产准备 gate 当前不能通过。');
});

test('next_actions 必须包含下一阶段建议', () => {
  const report = evaluateGoLiveReadiness(buildGoLiveReadinessGates(context));
  assert(report.next_actions.length > 0, 'next_actions 不能为空。');
  assert(report.next_actions.some((item) => item.includes('真实 NocoBase adapter')), '下一步应指向真实 NocoBase adapter。');
});

test('报告 Markdown 能生成中文摘要', () => {
  const report = evaluateGoLiveReadiness(buildGoLiveReadinessGates(context), { generatedAt: '2026-06-03T00:00:00.000Z' });
  const summary = summarizeGoLiveReadiness(report);
  const markdown = renderGoLiveReadinessMarkdown(report);
  assert(summary.includes('当前 readiness_level'), '摘要应包含 readiness_level。');
  assert(markdown.includes('正式上线测试前 readiness 报告'), 'Markdown 应包含中文标题。');
  assert(markdown.includes('下一步建议'), 'Markdown 应包含下一步建议。');
});
