import { assert, test } from '../testHarness';
import { contractDocumentsPluginRegistration } from '../../packages/plugins/plugin-contract-documents/src/server/pluginRegistration';
import { iopgpsPluginRegistration } from '../../packages/plugins/plugin-iopgps/src/server/pluginRegistration';
import { rentalCorePluginRegistration } from '../../packages/plugins/plugin-rental-core/src/server/pluginRegistration';
import { buildAutomatedRegistrationPlan } from '../../packages/shared/nocobase-automation/src';

const plan = buildAutomatedRegistrationPlan([
  iopgpsPluginRegistration,
  rentalCorePluginRegistration,
  contractDocumentsPluginRegistration,
]);
const collectionNames = plan.collections.map((collection) => collection.name);

test('能构建自动化注册计划并按依赖排序', () => {
  assert(plan.plugins.map((plugin) => plugin.pluginName).join('>') === 'plugin-rental-core>plugin-contract-documents>plugin-iopgps', '插件顺序不正确。');
  const rental = plan.plugins.find((plugin) => plugin.pluginName === 'plugin-rental-core');
  const contract = plan.plugins.find((plugin) => plugin.pluginName === 'plugin-contract-documents');
  const iopgps = plan.plugins.find((plugin) => plugin.pluginName === 'plugin-iopgps');
  assert(Boolean(rental), '缺少 rental-core。');
  assert(!rental!.dependencies.includes('plugin-iopgps'), 'rental-core 不得依赖 iopgps。');
  assert(!rental!.dependencies.includes('plugin-contract-documents'), 'rental-core 不得依赖 contract-documents。');
  assert(contract!.dependencies.includes('plugin-rental-core'), 'contract-documents 必须依赖 rental-core。');
  assert(iopgps!.dependencies.includes('plugin-rental-core'), 'iopgps 必须依赖 rental-core。');
});

test('注册计划包含核心 Collection', () => {
  for (const name of ['drivers', 'vehicles', 'lease_contracts', 'rent_daily_ledgers', 'rent_payments', 'rent_payment_allocations', 'deposit_records']) {
    assert(collectionNames.includes(name), `缺少 rental-core Collection：${name}`);
  }
  for (const name of ['gps_devices', 'gps_daily_mileages', 'iopgps_settings']) {
    assert(collectionNames.includes(name), `缺少 iopgps Collection：${name}`);
  }
  for (const name of ['contract_templates', 'contract_documents']) {
    assert(collectionNames.includes(name), `缺少合同文件 Collection：${name}`);
  }
});

test('注册计划包含页面、权限和 smoke test 计划', () => {
  assert(plan.pages.length >= 12, '应包含页面初始化计划。');
  assert(plan.permissions.length >= 6, '应包含权限计划。');
  assert(plan.smokeTests.length >= 10, '应包含 smoke test 计划。');
  assert(plan.pages.some((page) => page.name === 'rent_calendar_page'), '应包含收租日历占位页面计划。');
});
