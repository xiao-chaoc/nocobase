import { assert, test } from '../testHarness';
import { buildSeedDataImportPlan, validateDepositBusinessRules, validateGpsMockRules, validatePaymentAllocationBusinessRules, validateRentLedgerBusinessRules, validateSeedDataFilesExist, validateSeedDataImportPlan, validateSeedDataReferences, validateSeedDataUniqueKeys, validateNoSensitiveRealData } from '../../packages/shared/nocobase-automation/src';

const validData = () => ({
  drivers: [{ driver_id: 'D1', driver_no: 'TEST-D1' }],
  vehicles: [{ vehicle_id: 'V1', vehicle_no: 'TEST-V1', plate_no: 'TEST-P1' }],
  gps_devices: [{ device_id: 'G1', imei: 'TEST-I1' }],
  lease_contracts: [{ contract_id: 'C1', contract_no: 'TEST-C1', driver_id: 'D1', vehicle_id: 'V1' }],
  contract_billing_weeks: [{ billing_week_id: 'B1', contract_id: 'C1' }],
  rent_daily_ledgers: [{ ledger_id: 'L1', contract_id: 'C1', driver_id: 'D1', vehicle_id: 'V1', rent_date: '2026-01-01', is_payable: true, due_amount: 100, paid_amount: 100, waived_amount: 0, balance_amount: 0 }],
  rent_payments: [{ payment_id: 'P1', payment_no: 'TEST-PAY1', paid_amount: 100, status: 'confirmed', payment_screenshot: 'TEST_SCREENSHOT' }],
  rent_payment_allocations: [{ allocation_id: 'A1', payment_id: 'P1', ledger_id: 'L1', allocated_amount: 100 }],
  deposit_records: [{ deposit_id: 'DEP1', contract_id: 'C1', required_amount: 1000, received_amount: 1000, deducted_amount: 0, refunded_amount: 0, waived_amount: 0, proof_file: 'TEST_PROOF' }],
  gps_location_snapshots: [{ snapshot_id: 'S1', device_id: 'G1', raw_response: { token: 'TEST_TOKEN' } }],
  gps_daily_mileages: [{ mileage_id: 'M1', device_id: 'G1', mileage_date: '2026-01-01', raw_response: { login_key: 'TEST_LOGIN_KEY' }, remark: 'GPS 不参与租金计算' }],
  contract_documents: [{ document_id: 'DOC1', document_no: 'TEST-DOC1', contract_id: 'C1', signed_scan_file: 'TEST_SCAN' }],
  operation_logs: [{ log_id: 'O1', action: 'TEST_ACTION' }],
});

test('导入计划和缺失文件校验有效', () => {
  const plan = buildSeedDataImportPlan();
  assert(validateSeedDataImportPlan(plan).passed, '完整导入计划应通过。');
  assert(!validateSeedDataFilesExist(plan, '/tmp/not-exists-seed-data').passed, '缺少 drivers、vehicles 等文件应报错。');
});

test('引用不存在会报错', () => {
  const missingDriver = validData();
  missingDriver.lease_contracts[0].driver_id = 'MISSING';
  assert(!validateSeedDataReferences(missingDriver as any).passed, '引用不存在的 driver_id 应报错。');
  const missingVehicle = validData();
  missingVehicle.lease_contracts[0].vehicle_id = 'MISSING';
  assert(!validateSeedDataReferences(missingVehicle as any).passed, '引用不存在的 vehicle_id 应报错。');
});

test('台账、付款、押金和 GPS 业务规则能拒绝错误数据', () => {
  const duplicateLedger = validData();
  duplicateLedger.rent_daily_ledgers.push({ ...duplicateLedger.rent_daily_ledgers[0], ledger_id: 'L2' });
  assert(!validateSeedDataUniqueKeys(duplicateLedger as any).passed, 'contract_id + rent_date 重复应报错。');
  const overpaid = validData();
  overpaid.rent_daily_ledgers[0].paid_amount = 101;
  assert(!validateRentLedgerBusinessRules(overpaid as any).passed, '单日超付应报错。');
  const freeDay = validData();
  freeDay.rent_daily_ledgers[0].is_payable = false;
  freeDay.rent_daily_ledgers[0].due_amount = 100;
  assert(!validateRentLedgerBusinessRules(freeDay as any).passed, '免租日 due_amount 非 0 应报错。');
  const zeroDue = validData();
  zeroDue.rent_daily_ledgers[0].due_amount = 0;
  assert(!validateRentLedgerBusinessRules(zeroDue as any).passed, '应收日 due_amount 小于等于 0 应报错。');
  const missingLedger = validData();
  missingLedger.rent_payment_allocations[0].ledger_id = 'MISSING';
  assert(!validatePaymentAllocationBusinessRules(missingLedger as any).passed, 'allocation 指向不存在 ledger 应报错。');
  const depositInPayment = validData();
  (depositInPayment.rent_payments[0] as any).remark = 'deposit';
  assert(!validateDepositBusinessRules(depositInPayment as any).passed, '押金计入 rent_payments 应报错。');
  const gpsRent = validData();
  gpsRent.gps_daily_mileages[0].remark = 'gps_rent_calculation';
  assert(!validateGpsMockRules(gpsRent as any).passed, 'GPS 参与租金计算应报错。');
});

test('禁止模式和真实 token 会被拒绝', () => {
  assert(!validateNoSensitiveRealData({ gps_location_snapshots: [{ raw_response: { access_token: 'real-secret-token' } }] } as any).passed, '真实 access_token 应报错。');
  assert(!validateNoSensitiveRealData({ gps_location_snapshots: [{ raw_response: { login_key: 'real-login-key' } }] } as any).passed, '真实 login_key 应报错。');
  const forbiddenPlan = buildSeedDataImportPlan();
  forbiddenPlan.notes.push('driver_login');
  assert(!validateSeedDataImportPlan(forbiddenPlan).passed, 'driver_login 应报错。');
});
