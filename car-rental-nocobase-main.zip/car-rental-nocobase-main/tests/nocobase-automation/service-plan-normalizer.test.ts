import { assert, test } from '../testHarness';
import { contractDocumentsPluginRegistration } from '../../packages/plugins/plugin-contract-documents/src/server/pluginRegistration';
import { iopgpsPluginRegistration } from '../../packages/plugins/plugin-iopgps/src/server/pluginRegistration';
import { rentalCorePluginRegistration } from '../../packages/plugins/plugin-rental-core/src/server/pluginRegistration';
import { buildAutomatedRegistrationPlan, buildRuntimeRegistrationPlanFromAutomatedPlan, extractTransactionalServices, normalizeServicePlan } from '../../packages/shared/nocobase-automation/src';

const automatedPlan = buildAutomatedRegistrationPlan([rentalCorePluginRegistration, contractDocumentsPluginRegistration, iopgpsPluginRegistration]);
const runtimePlan = buildRuntimeRegistrationPlanFromAutomatedPlan(automatedPlan);

test('能标准化服务计划', () => {
  const normalized = normalizeServicePlan({ name: 'plugin-rental-core.allocateRentPayment', sourcePlugin: 'plugin-rental-core', handlerName: '', permissions: [], transactional: undefined as unknown as boolean, notes: [] });
  assert(normalized.handlerName === 'plugin-rental-core.allocateRentPayment' || normalized.handlerName === normalized.name, 'handlerName 缺失时应使用 name 兜底。');
  assert(normalized.notes.some((note) => note.includes('缺少权限')), '权限缺失应产生警告说明。');
});

test('能识别事务服务', () => {
  const transactional = extractTransactionalServices(runtimePlan.services).map((service) => service.handlerName);
  for (const name of ['activateLeaseContract', 'generateFixedTermDailyLedgers', 'allocateRentPayment', 'reverseRentPayment', 'approveRentWaiver', 'createDepositRecord', 'deductDeposit', 'refundDeposit']) {
    assert(transactional.includes(name), `应识别事务服务：${name}`);
  }
});


test('缺少 handlerName 但 name 含事务方法时仍能识别事务服务', () => {
  const transactional = extractTransactionalServices([
    { name: 'plugin-rental-core.allocateRentPayment', sourcePlugin: 'plugin-rental-core', handlerName: '', permissions: ['manager'], transactional: undefined as unknown as boolean, notes: [] },
  ]);
  assert(transactional.length === 1, '带插件前缀的事务服务名称也应被识别。');
  assert(transactional[0].transactional, '标准化后应标记 transactional。');
});
