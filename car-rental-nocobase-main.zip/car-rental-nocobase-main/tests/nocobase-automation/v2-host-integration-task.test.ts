import { assert, test } from '../testHarness';
declare const require: any;

const fs = require('fs');

const read = (filePath: string): string => fs.readFileSync(filePath, 'utf8') as string;

const taskDoc = 'docs/nocobase-v2.0.61-host-integration-task.md';
const directoryPlanDoc = 'docs/nocobase-v2.0.61-host-directory-plan.md';
const bootstrapCommandsDoc = 'docs/nocobase-v2.0.61-host-bootstrap-commands.md';
const pluginCopyPlanDoc = 'docs/nocobase-v2.0.61-plugin-copy-plan.md';
const environmentAdapterTaskDoc = 'docs/task-real-environment-adapter-v2.0.61.md';
const collectionAdapterTaskDoc = 'docs/task-real-collection-adapter-v2.0.61.md';
const validateScript = 'scripts/nocobase/validate-v2-host-integration-task.ts';

const docsContent = (): string =>
  [
    taskDoc,
    directoryPlanDoc,
    bootstrapCommandsDoc,
    pluginCopyPlanDoc,
    environmentAdapterTaskDoc,
    collectionAdapterTaskDoc,
  ]
    .map(read)
    .join('\n');

const scriptContent = (): string => read(validateScript);

test('v2 host integration task 文档存在', () => {
  assert(fs.existsSync(taskDoc), '缺少 v2 host integration task 文档。');
});

test('v2 host directory plan 文档存在', () => {
  assert(fs.existsSync(directoryPlanDoc), '缺少 v2 host directory plan 文档。');
});

test('v2 host bootstrap commands 文档存在', () => {
  assert(fs.existsSync(bootstrapCommandsDoc), '缺少 v2 host bootstrap commands 文档。');
});

test('plugin copy plan 文档存在', () => {
  assert(fs.existsSync(pluginCopyPlanDoc), '缺少 plugin copy plan 文档。');
});

test('real environment adapter task 文档存在', () => {
  assert(fs.existsSync(environmentAdapterTaskDoc), '缺少 real environment adapter task 文档。');
});

test('real collection adapter task 文档存在', () => {
  assert(fs.existsSync(collectionAdapterTaskDoc), '缺少 real collection adapter task 文档。');
});

test('validate-v2-host-integration-task.ts 存在', () => {
  assert(fs.existsSync(validateScript), '缺少 validate-v2-host-integration-task.ts。');
});

test('package.json 包含 validate:v2-host-integration-task', () => {
  const packageJson = JSON.parse(read('package.json')) as { scripts?: Record<string, string> };
  assert(Boolean(packageJson.scripts?.['validate:v2-host-integration-task']), 'package.json 缺少 validate:v2-host-integration-task。');
});

test('文档包含 v2.0.61', () => {
  assert(docsContent().includes('v2.0.61'), '文档必须包含 v2.0.61。');
});

test('文档包含 yarn', () => {
  assert(docsContent().includes('yarn'), '文档必须包含 yarn。');
});

test('文档包含 postgresql', () => {
  assert(docsContent().includes('postgresql'), '文档必须包含 postgresql。');
});

test('文档包含 source_host', () => {
  assert(docsContent().includes('source_host'), '文档必须包含 source_host。');
});

test('文档包含 packages_plugins', () => {
  assert(docsContent().includes('packages_plugins'), '文档必须包含 packages_plugins。');
});

test('文档包含 iopgps_real_sync_allowed = false', () => {
  assert(docsContent().includes('iopgps_real_sync_allowed = false'), '文档必须包含 iopgps_real_sync_allowed = false。');
});

test('文档包含 mock_data_only = true', () => {
  assert(docsContent().includes('mock_data_only = true'), '文档必须包含 mock_data_only = true。');
});

test('文档明确不 clone NocoBase 源码到当前仓库', () => {
  assert(docsContent().includes('不 clone NocoBase 源码到当前仓库'), '文档必须明确不 clone NocoBase 源码到当前仓库。');
});

test('文档明确不提交完整 NocoBase 源码', () => {
  assert(docsContent().includes('不提交完整 NocoBase 源码'), '文档必须明确不提交完整 NocoBase 源码。');
});

test('文档明确不使用生产库', () => {
  assert(docsContent().includes('不使用生产库'), '文档必须明确不使用生产库。');
});

test('文档明确不复制 .env', () => {
  assert(docsContent().includes('不复制 `.env`'), '文档必须明确不复制 .env。');
});

test('文档明确不复制 filled.json', () => {
  assert(docsContent().includes('不复制 `filled.json`'), '文档必须明确不复制 filled.json。');
});

test('校验脚本不连接 NocoBase', () => {
  assert(scriptContent().includes('不连接 NocoBase'), '校验脚本必须明确不连接 NocoBase。');
});

test('校验脚本不访问外部网络', () => {
  assert(scriptContent().includes('不访问外部网络'), '校验脚本必须明确不访问外部网络。');
});
