import { assert, test } from '../testHarness';
declare const require: any;

const fs = require('fs');

const read = (filePath: string): string => fs.readFileSync(filePath, 'utf8') as string;

const targetVersionDecisionDoc = 'docs/nocobase-target-version-decision.md';
const hostRunbookDoc = 'docs/nocobase-host-bootstrap-runbook.md';
const branchPlanDoc = 'docs/nocobase-host-integration-branch-plan.md';
const apiVerificationPlanDoc = 'docs/nocobase-source-api-verification-plan.md';
const hostScriptsDir = 'scripts/host';
const prepareScript = 'scripts/host/prepare-nocobase-host-workspace.sh';
const prerequisitesScript = 'scripts/host/check-host-prerequisites.ts';
const copyScript = 'scripts/host/copy-project-plugins-to-host.ts';
const validateWorkspaceScript = 'scripts/host/validate-host-workspace.ts';
const validateDocsScript = 'scripts/nocobase/validate-host-bootstrap-docs.ts';

const docContent = (): string => [targetVersionDecisionDoc, hostRunbookDoc, branchPlanDoc, apiVerificationPlanDoc].map(read).join('\n');
const scriptContent = (): string => [prepareScript, prerequisitesScript, copyScript, validateWorkspaceScript].map(read).join('\n');

test('目标版本决策文档存在', () => {
  assert(fs.existsSync(targetVersionDecisionDoc), '缺少目标版本决策文档。');
});

test('宿主工程 Runbook 存在', () => {
  assert(fs.existsSync(hostRunbookDoc), '缺少宿主工程 Runbook。');
});

test('接入分支计划存在', () => {
  assert(fs.existsSync(branchPlanDoc), '缺少接入分支计划。');
});

test('API 验证计划存在', () => {
  assert(fs.existsSync(apiVerificationPlanDoc), '缺少 API 验证计划。');
});

test('host 脚本目录存在', () => {
  assert(fs.existsSync(hostScriptsDir), '缺少 host 脚本目录。');
});

test('prepare-nocobase-host-workspace.sh 存在', () => {
  assert(fs.existsSync(prepareScript), '缺少宿主准备脚本。');
});

test('check-host-prerequisites.ts 存在', () => {
  assert(fs.existsSync(prerequisitesScript), '缺少前置条件检查脚本。');
});

test('copy-project-plugins-to-host.ts 存在', () => {
  assert(fs.existsSync(copyScript), '缺少插件复制 dry-run 脚本。');
});

test('validate-host-workspace.ts 存在', () => {
  assert(fs.existsSync(validateWorkspaceScript), '缺少宿主工作区校验脚本。');
});

test('validate-host-bootstrap-docs.ts 存在', () => {
  assert(fs.existsSync(validateDocsScript), '缺少宿主准备文档校验脚本。');
});

test('package.json 包含 validate:host-bootstrap-docs', () => {
  const packageJson = JSON.parse(read('package.json')) as { scripts?: Record<string, string> };
  assert(Boolean(packageJson.scripts?.['validate:host-bootstrap-docs']), 'package.json 缺少 validate:host-bootstrap-docs。');
});

test('文档明确不得提交完整 NocoBase 源码', () => {
  assert(docContent().includes('不要把完整 NocoBase 源码提交进当前仓库'), '文档必须明确不得提交完整 NocoBase 源码。');
});

test('文档明确不得生产库调试', () => {
  assert(docContent().includes('不在生产库调试'), '文档必须明确不得生产库调试。');
});

test('文档明确目标版本必须确认', () => {
  const content = docContent();
  assert(content.includes('目标版本必须人工确认') || content.includes('人工确认目标 NocoBase 版本'), '文档必须明确目标版本必须确认。');
});

test('文档明确 latest-full 不作为真实接入基准', () => {
  const content = docContent();
  assert(content.includes('latest-full') && content.includes('不能作为真实接入基准'), '文档必须明确 latest-full 不作为真实接入基准。');
});

test('脚本默认 dry-run', () => {
  assert(scriptContent().includes('默认 dry-run'), '脚本必须明确默认 dry-run。');
});

test('脚本不读取 .env.test 真实值', () => {
  assert(scriptContent().includes('不读取 .env.test 真实值'), '脚本必须明确不读取 .env.test 真实值。');
});

test('脚本不默认写入宿主工程', () => {
  const content = scriptContent();
  assert(content.includes('不会默认') || content.includes('不默认写入宿主工程'), '脚本必须明确不默认写入宿主工程。');
});
