import { assert, test } from '../testHarness';
import { contractDocumentsPluginRegistration } from '../../packages/plugins/plugin-contract-documents/src/server/pluginRegistration';
import { iopgpsPluginRegistration } from '../../packages/plugins/plugin-iopgps/src/server/pluginRegistration';
import { rentalCorePluginRegistration } from '../../packages/plugins/plugin-rental-core/src/server/pluginRegistration';
import {
  buildAutomatedRegistrationPlan,
  validateCollectionRegistrationPlan,
  validateCriticalCollections,
  validateCriticalUniqueConstraints,
} from '../../packages/shared/nocobase-automation/src';
import type { NocobaseCollectionPlan } from '../../packages/shared/nocobase-automation/src';

const plan = buildAutomatedRegistrationPlan([
  iopgpsPluginRegistration,
  rentalCorePluginRegistration,
  contractDocumentsPluginRegistration,
]);
const collections = plan.collections;

const cloneCollections = () => JSON.parse(JSON.stringify(collections)) as NocobaseCollectionPlan[];

const removeCollection = (name: string) => cloneCollections().filter((collection) => collection.name !== name);

const expectRejected = (plans: NocobaseCollectionPlan[], messagePart: string) => {
  const result = validateCollectionRegistrationPlan(plans);
  assert(!result.passed, `应拒绝：${messagePart}`);
  assert(result.errors.some((error) => error.includes(messagePart)), `错误中应包含：${messagePart}，实际：${result.errors.join('；')}`);
};

test('完整 Collection 注册计划可以通过校验', () => {
  const result = validateCollectionRegistrationPlan(collections);
  assert(result.passed, `完整计划应通过：${result.errors.join('；')}`);
});

test('缺少 name、fields、敏感字段或唯一约束字段会被拒绝', () => {
  const missingName = cloneCollections();
  missingName[0].name = '';
  expectRejected(missingName, 'Collection name 必须存在');

  const missingFields = cloneCollections();
  missingFields[0].fields = [];
  expectRejected(missingFields, 'Collection fields 必须存在且非空');

  const badSensitive = cloneCollections();
  badSensitive[0].sensitiveFields = [...badSensitive[0].sensitiveFields, 'not_exists'];
  expectRejected(badSensitive, 'sensitiveFields 中字段不存在');

  const badUnique = cloneCollections();
  badUnique[0].uniqueConstraints = [['not_exists']];
  expectRejected(badUnique, 'uniqueConstraints 中字段不存在');
});

test('缺少关键 Collections 会被拒绝', () => {
  for (const name of ['drivers', 'vehicles', 'lease_contracts', 'rent_daily_ledgers']) {
    const result = validateCriticalCollections(removeCollection(name));
    assert(!result.passed, `缺少 ${name} 应被拒绝。`);
    assert(result.errors.some((error) => error.includes(name)), `错误应包含 ${name}。`);
  }
});

test('缺少关键唯一约束会被拒绝', () => {
  const missingLedgerUnique = cloneCollections();
  missingLedgerUnique.find((collection) => collection.name === 'rent_daily_ledgers')!.uniqueConstraints = [];
  let result = validateCriticalUniqueConstraints(missingLedgerUnique);
  assert(!result.passed && result.errors.some((error) => error.includes('rent_daily_ledgers.contract_id + rent_date')), '台账唯一约束缺失应被拒绝。');

  const missingPlateNo = cloneCollections();
  missingPlateNo.find((collection) => collection.name === 'vehicles')!.uniqueConstraints = [['vehicle_no']];
  result = validateCriticalUniqueConstraints(missingPlateNo);
  assert(!result.passed && result.errors.some((error) => error.includes('vehicles.plate_no')), '车牌唯一约束缺失应被拒绝。');

  const missingImei = cloneCollections();
  missingImei.find((collection) => collection.name === 'gps_devices')!.uniqueConstraints = [];
  result = validateCriticalUniqueConstraints(missingImei);
  assert(!result.passed && result.errors.some((error) => error.includes('gps_devices.imei')), 'GPS IMEI 唯一约束缺失应被拒绝。');
});

test('禁止短租、司机登录、按车型出租和 GPS 参与租金计算', () => {
  expectRejected([...cloneCollections(), { ...collections[0], name: 'bookings', title: '短租预订' }], '短租对象');
  expectRejected([...cloneCollections(), { ...collections[0], name: 'reservations', title: '预约' }], '短租对象');
  expectRejected([{ ...collections[0], notes: ['driver_login'] }, ...cloneCollections().slice(1)], '司机登录');
  expectRejected([{ ...collections[0], notes: ['vehicle_category_rental'] }, ...cloneCollections().slice(1)], '按车型出租');
  expectRejected([{ ...collections[0], notes: ['GPS 参与租金计算'] }, ...cloneCollections().slice(1)], 'GPS 计划不得参与租金计算');
});
