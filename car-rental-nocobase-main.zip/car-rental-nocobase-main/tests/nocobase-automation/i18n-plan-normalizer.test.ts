import { assert, test } from '../testHarness';
import { contractDocumentsPluginRegistration } from '../../packages/plugins/plugin-contract-documents/src/server/pluginRegistration';
import { iopgpsPluginRegistration } from '../../packages/plugins/plugin-iopgps/src/server/pluginRegistration';
import { rentalCorePluginRegistration } from '../../packages/plugins/plugin-rental-core/src/server/pluginRegistration';
import { buildAutomatedRegistrationPlan, buildRuntimeRegistrationPlanFromAutomatedPlan, normalizeI18nPlans, validateRuntimeRegistrationPlan } from '../../packages/shared/nocobase-automation/src';

const runtimePlan = buildRuntimeRegistrationPlanFromAutomatedPlan(buildAutomatedRegistrationPlan([rentalCorePluginRegistration, contractDocumentsPluginRegistration, iopgpsPluginRegistration]));

test('能标准化 i18n 计划', () => {
  const i18n = normalizeI18nPlans(runtimePlan.i18n);
  assert(i18n.length === 3, '应包含三个插件的 i18n 计划。');
  assert(i18n.every((item) => ['zh-CN', 'en-US', 'fr-FR'].every((language) => item.languages.includes(language))), '必须包含三种语言。');
});

test('i18n 缺少 zh-CN、en-US 或 fr-FR 被拒绝', () => {
  for (const language of ['zh-CN', 'en-US', 'fr-FR']) {
    const broken = { ...runtimePlan, i18n: runtimePlan.i18n.map((item, index) => index === 0 ? { ...item, languages: item.languages.filter((itemLanguage) => itemLanguage !== language) } : item) };
    const result = validateRuntimeRegistrationPlan(broken);
    assert(!result.passed, `缺少 ${language} 应被拒绝。`);
    assert(result.errors.some((error) => error.includes(language)), `错误应提到 ${language}。`);
  }
});
