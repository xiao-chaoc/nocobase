import { assert, assertEqual, test } from '../testHarness';
import { rentalCorePluginRegistration } from '../../packages/plugins/plugin-rental-core/src/server/pluginRegistration';
import { buildAutomatedRegistrationPlan, UnconfiguredNocobaseRealAdapter } from '../../packages/shared/nocobase-automation/src';

const plan = buildAutomatedRegistrationPlan([rentalCorePluginRegistration]);

test('UnconfiguredNocobaseRealAdapter 不应报告 ready', () => {
  const adapter = new UnconfiguredNocobaseRealAdapter({ mode: 'real' });
  const environment = adapter.inspectEnvironment();
  assertEqual(environment.status, 'unavailable', '未配置 adapter 不能报告 ready。');
  assert(!adapter.connected, '未配置 adapter 不应建立连接。');
});

test('UnconfiguredNocobaseRealAdapter 所有能力 supported 都是 false', () => {
  const adapter = new UnconfiguredNocobaseRealAdapter({ mode: 'real' });
  const capabilities = adapter.getCapabilities();
  assert(capabilities.length >= 12, '应覆盖真实 adapter 能力矩阵。');
  assert(capabilities.every((capability) => !capability.supported), '所有能力都应报告不可用。');
});

test('UnconfiguredNocobaseRealAdapter registerCollections 不会成功', () => {
  const adapter = new UnconfiguredNocobaseRealAdapter({ mode: 'real' });
  const result = adapter.registerCollections(plan.collections.slice(0, 1));
  assert(!result.success, '未配置 adapter 不能成功注册 Collections。');
  assertEqual(result.summary.createdCount, 0, '未配置 adapter 不能创建 Collection。');
  assert(result.errors.some((error) => error.includes('当前没有真实 NocoBase app')), '错误应说明缺少真实 app。');
});

test('UnconfiguredNocobaseRealAdapter 不连接数据库', () => {
  const adapter = new UnconfiguredNocobaseRealAdapter({ mode: 'real' });
  const result = adapter.connect();
  assert(!result.success, 'connect 应返回受控失败。');
  assert(!adapter.connected, 'connect 不应改变为已连接状态。');
  assert(result.steps.some((step) => step.includes('未尝试连接数据库')), '步骤应说明未尝试连接数据库。');
});
