declare const require: any;

import { assert, test } from '../testHarness';
import { buildSeedDataImportPlan, dryRunImportSeedData, seedDataFileByEntity, summarizeSeedDataImportResult } from '../../packages/shared/nocobase-automation/src';

const fs = require('fs');
const path = require('path');

const recordsByEntity: Record<string, unknown[]> = {
  drivers: [{ driver_id: 'D1', driver_no: 'TEST-D1' }],
  vehicles: [{ vehicle_id: 'V1', vehicle_no: 'TEST-V1', plate_no: 'TEST-P1' }],
  gps_devices: [{ device_id: 'G1', imei: 'TEST-I1' }],
  lease_contracts: [{ contract_id: 'C1', contract_no: 'TEST-C1', driver_id: 'D1', vehicle_id: 'V1' }],
  contract_billing_weeks: [{ billing_week_id: 'B1', contract_id: 'C1' }],
  rent_daily_ledgers: [{ ledger_id: 'L1', contract_id: 'C1', driver_id: 'D1', vehicle_id: 'V1', rent_date: '2026-01-01', is_payable: true, due_amount: 100, paid_amount: 100, waived_amount: 0, balance_amount: 0 }],
  rent_payments: [{ payment_id: 'P1', payment_no: 'TEST-PAY1', paid_amount: 100, status: 'confirmed', payment_screenshot: 'TEST_SCREENSHOT' }],
  rent_payment_allocations: [{ allocation_id: 'A1', payment_id: 'P1', ledger_id: 'L1', allocated_amount: 100 }],
  deposit_records: [{ deposit_id: 'DEP1', contract_id: 'C1', required_amount: 1000, received_amount: 1000, deducted_amount: 0, refunded_amount: 0, waived_amount: 0, proof_file: 'TEST_PROOF' }],
  gps_location_snapshots: [{ snapshot_id: 'S1', device_id: 'G1', raw_response: { token: 'TEST_TOKEN' } }],
  gps_daily_mileages: [{ mileage_id: 'M1', device_id: 'G1', mileage_date: '2026-01-01', raw_response: { login_key: 'TEST_LOGIN_KEY' }, remark: 'GPS 不参与租金计算' }],
  contract_documents: [{ document_id: 'DOC1', document_no: 'TEST-DOC1', contract_id: 'C1', signed_scan_file: 'TEST_SCAN' }],
  operation_logs: [{ log_id: 'O1', action: 'TEST_ACTION' }],
};

const prepareSourceDir = (): string => {
  const dir = path.resolve('.test-dist/seed-data-import-executor');
  fs.mkdirSync(dir, { recursive: true });
  for (const [entityType, sourceFile] of Object.entries(seedDataFileByEntity)) {
    fs.writeFileSync(path.join(dir, sourceFile), JSON.stringify(recordsByEntity[entityType], null, 2));
  }
  return dir;
};

test('dryRunImportSeedData 返回中文步骤和 summary', () => {
  const sourceDir = prepareSourceDir();
  const result = dryRunImportSeedData({ importPlan: buildSeedDataImportPlan(Object.values(seedDataFileByEntity)), dryRun: true, sourceDir, targetEnvironment: 'test', importedBy: 'test', importedAt: '2026-06-03T00:00:00.000Z' });
  const summary = summarizeSeedDataImportResult(result);
  assert(result.success, result.errors.join('；'));
  assert(result.entityResults[0].steps.join('').includes('dry-run'), 'steps 应包含 dry-run。');
  assert(summary.includes('实体类型数量'), 'summary 应为中文摘要。');
});
