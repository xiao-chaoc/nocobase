import { assert, test } from '../testHarness';
import { buildRealSmokeTestPlan, inspectNocobaseEnvironment } from '../../packages/shared/nocobase-automation/src';
import type { RealSmokeTestContext } from '../../packages/shared/nocobase-automation/src';

const context = (mode: RealSmokeTestContext['mode'] = 'plan_only'): RealSmokeTestContext => ({
  mode,
  adapterEnvironment: inspectNocobaseEnvironment({ mode: 'dry_run' }),
  allowRealExecution: false,
  requireBackup: true,
  requireRollbackPlan: true,
  requireIsolatedDatabase: true,
  requireMockDataOnly: true,
  requireIopgpsDisabled: true,
  operator: 'test',
  notes: ['测试只生成草案。'],
});

const plan = () => buildRealSmokeTestPlan({ context: context() });

test('能生成真实 smoke test plan 草案且默认不是 real', () => {
  const result = plan();
  assert(result.steps.length > 0, '应生成步骤。');
  assert(result.mode !== 'real', '默认 mode 不能是 real。');
});

for (const stage of ['environment_check', 'collection_registration_check', 'runtime_registration_check', 'page_registration_check', 'seed_data_import_check', 'core_business_flow_check', 'permission_check', 'failure_isolation_check', 'rollback_check'] as const) {
  test(`plan 包含 ${stage}`, () => {
    const result = plan();
    assert(result.stages.includes(stage), `stages 应包含 ${stage}。`);
    assert(result.steps.some((step) => step.stage === stage), `steps 应包含 ${stage}。`);
  });
}

test('核心业务步骤包含单日不可超付、付款分配日期、未来应收不计入当前欠款', () => {
  const text = JSON.stringify(plan().businessChecks);
  assert(text.includes('单日不可超付'), '应包含单日不可超付。');
  assert(text.includes('付款必须分配到具体日期'), '应包含付款必须分配到具体日期。');
  assert(text.includes('未来应收不计入当前欠款'), '应包含未来应收不计入当前欠款。');
});

test('权限、GPS 和合同文件步骤覆盖敏感边界', () => {
  const text = JSON.stringify(plan().steps);
  assert(text.includes('operator 不能看付款截图'), 'operator 不能看付款截图。');
  assert(text.includes('gps_maintenance 不能看财务汇总'), 'gps_maintenance 不能看财务汇总。');
  assert(text.includes('IOPGPS 失败不影响租金') || text.includes('IOPGPS 同步失败不影响租金台账'), 'IOPGPS 失败不影响租金。');
  assert(text.includes('合同文件生成失败不影响付款和台账'), '合同文件生成失败不影响付款和台账。');
});
