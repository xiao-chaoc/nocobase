import { assert, test } from '../testHarness';
import { contractDocumentsPluginRegistration } from '../../packages/plugins/plugin-contract-documents/src/server/pluginRegistration';
import { iopgpsPluginRegistration } from '../../packages/plugins/plugin-iopgps/src/server/pluginRegistration';
import { rentalCorePluginRegistration } from '../../packages/plugins/plugin-rental-core/src/server/pluginRegistration';
import { buildAutomatedRegistrationPlan, buildPageInitializationPlan, validatePageForbiddenPatterns, validatePageInitializationPlan, validateSensitivePageFields } from '../../packages/shared/nocobase-automation/src';

const automatedPlan = buildAutomatedRegistrationPlan([rentalCorePluginRegistration, contractDocumentsPluginRegistration, iopgpsPluginRegistration]);
const pagePlan = buildPageInitializationPlan(automatedPlan);

test('页面初始化计划校验通过并包含必需页面', () => {
  const validation = validatePageInitializationPlan(pagePlan);
  assert(validation.passed, validation.errors.join('；'));
});

test('页面计划拒绝禁止对象', () => {
  for (const forbidden of ['booking', 'reservation', 'driver_login', 'vehicle_category_rental', 'gps_rent_calculation']) {
    const invalid = { ...pagePlan, notes: [...pagePlan.notes, forbidden] };
    const validation = validatePageForbiddenPatterns(invalid);
    assert(!validation.passed, `应拒绝：${forbidden}`);
  }
});

test('敏感字段必须被标记且角色边界正确', () => {
  const validation = validateSensitivePageFields(pagePlan);
  assert(validation.passed, validation.errors.join('；'));
  const paymentBlock = pagePlan.blocks.find((block) => block.name === 'payments-table');
  assert(paymentBlock && paymentBlock.hiddenFields.includes('screenshot_file'), '付款截图必须隐藏。');
  assert(paymentBlock && !paymentBlock.requiredRoles.includes('operator'), 'operator 默认不能看付款截图。');
  const financeBlock = pagePlan.blocks.find((block) => block.name === 'rent-calendar-summary');
  assert(financeBlock && !financeBlock.requiredRoles.includes('gps_maintenance'), 'gps_maintenance 默认不能看财务汇总。');
});
