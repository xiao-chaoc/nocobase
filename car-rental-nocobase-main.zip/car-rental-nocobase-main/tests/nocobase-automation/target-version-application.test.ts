import { assert, test } from '../testHarness';
declare const require: any;

const fs = require('fs');
const path = require('path');
const childProcess = require('child_process');

const read = (filePath: string): string => fs.readFileSync(filePath, 'utf8') as string;
const write = (filePath: string, content: string): void => fs.writeFileSync(filePath, content);

const validateInputScript = 'scripts/nocobase/validate-target-version-input.ts';
const applyScript = 'scripts/nocobase/apply-target-version-confirmation.ts';
const canStartScript = 'scripts/nocobase/validate-can-start-real-adapter.ts';
const workflowDoc = 'docs/nocobase-target-version-confirmation-workflow.md';
const decisionDoc = 'docs/nocobase-target-version-decision.md';
const tempDir = 'test-data/generated/test-target-version-application';

let scriptsBuilt = false;
const ensureScriptsBuilt = (): void => {
  if (scriptsBuilt) return;
  childProcess.execFileSync('npm', ['run', 'build:scripts', '--silent'], { stdio: 'ignore' });
  scriptsBuilt = true;
};

const runNode = (script: string, args: string[] = []): { ok: boolean; output: string } => {
  ensureScriptsBuilt();
  try {
    const output = childProcess.execFileSync('node', [script, ...args], {
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'pipe'],
    }) as string;
    return { ok: true, output };
  } catch (error) {
    const execError = error as { stdout?: string; stderr?: string };
    return { ok: false, output: `${execError.stdout ?? ''}${execError.stderr ?? ''}` };
  }
};

const validInput = (overrides: Record<string, unknown> = {}): Record<string, unknown> => ({
  decision_status: 'confirmed',
  target_version: 'manual-confirmed-test-version',
  source_type: 'tag',
  source_reference: 'manual-test-source-reference',
  package_manager: 'yarn',
  node_version: '20.x',
  database: 'postgresql',
  deployment_mode: 'source_host',
  plugin_development_mode: 'packages_plugins',
  plugin_install_mode: 'manual_test_install',
  iopgps_real_sync_allowed: false,
  mock_data_only: true,
  confirmed_by: 'manual-test-user',
  confirmed_at: '2026-06-06',
  ...overrides,
});

const writeInput = (name: string, data: Record<string, unknown>): string => {
  fs.mkdirSync(tempDir, { recursive: true });
  const filePath = path.join(tempDir, name);
  write(filePath, `${JSON.stringify(data, null, 2)}\n`);
  return filePath;
};

const runValidateInput = (filePath: string): { ok: boolean; output: string } => {
  return runNode('.test-dist/scripts/scripts/nocobase/validate-target-version-input.js', ['--file', filePath]);
};

test('validate-target-version-input.ts 存在', () => {
  assert(fs.existsSync(validateInputScript), '缺少输入校验脚本。');
});

test('apply-target-version-confirmation.ts 存在', () => {
  assert(fs.existsSync(applyScript), '缺少确认应用脚本。');
});

test('validate-can-start-real-adapter.ts 存在', () => {
  assert(fs.existsSync(canStartScript), '缺少真实 adapter 推进门禁脚本。');
});

test('package.json 包含目标版本确认应用脚本', () => {
  const packageJson = JSON.parse(read('package.json')) as { scripts?: Record<string, string> };
  assert(Boolean(packageJson.scripts?.['validate:target-version-input']), '缺少 validate:target-version-input。');
  assert(Boolean(packageJson.scripts?.['apply:target-version-confirmation']), '缺少 apply:target-version-confirmation。');
  assert(Boolean(packageJson.scripts?.['validate:can-start-real-adapter']), '缺少 validate:can-start-real-adapter。');
});

test('invalid JSON 路径会失败', () => {
  const result = runValidateInput('test-data/generated/not-exists-target-version.json');
  assert(!result.ok && result.output.includes('不存在'), '不存在的 JSON 路径应失败。');
});

test('decision_status 不是 confirmed 会失败', () => {
  const result = runValidateInput(writeInput('bad-status.json', validInput({ decision_status: 'pending_manual_confirmation' })));
  assert(!result.ok && result.output.includes('decision_status'), 'decision_status 非 confirmed 应失败。');
});

test('target_version = unset 会失败', () => {
  const result = runValidateInput(writeInput('unset-version.json', validInput({ target_version: 'unset' })));
  assert(!result.ok && result.output.includes('unset'), 'target_version 为 unset 应失败。');
});

test('target_version = latest-full 会失败', () => {
  const result = runValidateInput(writeInput('latest-full-version.json', validInput({ target_version: 'latest-full' })));
  assert(!result.ok && result.output.includes('latest-full'), 'target_version 为 latest-full 应失败。');
});

test('iopgps_real_sync_allowed = true 会失败', () => {
  const result = runValidateInput(writeInput('iopgps-true.json', validInput({ iopgps_real_sync_allowed: true })));
  assert(!result.ok && result.output.includes('iopgps_real_sync_allowed'), '允许真实 IOPGPS 应失败。');
});

test('mock_data_only = false 会失败', () => {
  const result = runValidateInput(writeInput('mock-false.json', validInput({ mock_data_only: false })));
  assert(!result.ok && result.output.includes('mock_data_only'), 'mock_data_only 为 false 应失败。');
});

test('包含 APP_KEY 会失败', () => {
  const result = runValidateInput(writeInput('app-key.json', validInput({ APP_KEY: 'secret' })));
  assert(!result.ok && result.output.includes('APP_KEY'), '包含 APP_KEY 应失败。');
});

test('包含 DB_PASSWORD 会失败', () => {
  const result = runValidateInput(writeInput('db-password.json', validInput({ DB_PASSWORD: 'secret' })));
  assert(!result.ok && result.output.includes('DB_PASSWORD'), '包含 DB_PASSWORD 应失败。');
});

test('包含 IOPGPS_LOGIN_KEY 会失败', () => {
  const result = runValidateInput(writeInput('iopgps-key.json', validInput({ IOPGPS_LOGIN_KEY: 'secret' })));
  assert(!result.ok && result.output.includes('IOPGPS_LOGIN_KEY'), '包含 IOPGPS_LOGIN_KEY 应失败。');
});

test('apply 脚本默认 dry-run 不修改 decision 文件', () => {
  const original = read(decisionDoc);
  const filePath = writeInput('valid-dry-run.json', validInput());
  const result = runNode('.test-dist/scripts/scripts/nocobase/apply-target-version-confirmation.js', ['--file', filePath]);
  assert(result.ok, 'dry-run 应通过。');
  assert(read(decisionDoc) === original, 'dry-run 不应修改决策文件。');
});

test('apply 脚本没有 --execute 不写文件', () => {
  const original = read(decisionDoc);
  const filePath = writeInput('valid-no-execute.json', validInput({ confirmed_by: 'another-manual-user' }));
  const result = runNode('.test-dist/scripts/scripts/nocobase/apply-target-version-confirmation.js', ['--file', filePath]);
  assert(result.ok && result.output.includes('不会写入'), '未传 --execute 应提示不会写入。');
  assert(read(decisionDoc) === original, '没有 --execute 不应修改决策文件。');
});

test('validate-can-start-real-adapter 在当前已确认状态下应通过', () => {
  const result = runNode('.test-dist/scripts/scripts/nocobase/validate-can-start-real-adapter.js');
  assert(result.ok && result.output.includes('允许进入真实 adapter 实现阶段的下一轮任务准备'), '已确认版本时真实 adapter 门禁应通过下一轮任务准备。');
});

test('脚本不读取 .env.test 且不连接 NocoBase', () => {
  const combined = `${read(validateInputScript)}\n${read(applyScript)}\n${read(canStartScript)}`;
  assert(!combined.includes("readFileSync('.env.test'") && !combined.includes('readFileSync(".env.test"'), '脚本不应读取 .env.test。');
  assert(!combined.includes('fetch(') && !combined.includes('axios') && !combined.includes('NocoBase('), '脚本不应连接 NocoBase 或外部网络。');
});

test('工作流文档存在并声明禁止 latest-full 与版本确认前真实 adapter', () => {
  assert(fs.existsSync(workflowDoc), '缺少工作流文档。');
  const content = read(workflowDoc);
  assert(content.includes('不把 `latest-full` 写成真实目标版本'), '工作流文档必须禁止 latest-full 作为真实目标版本。');
  assert(content.includes('目标版本未确认前不能继续真实 adapter'), '工作流文档必须说明版本确认前不能继续真实 adapter。');
});
