import { assert, test } from '../testHarness';
import { createDefaultRealRuntimeRegistrationContext, RealRuntimeRegistrationAdapter, validateRealRuntimeRegistrationSafety, validateRealRuntimeSchemaDraft } from '../../packages/shared/nocobase-automation/src';
import type { RuntimeRegistrationPlan } from '../../packages/shared/nocobase-automation/src';

const baseRuntimePlan: RuntimeRegistrationPlan = {
  services: [{ name: 'ledgerGenerationService.generateFixedTermDailyLedgers', sourcePlugin: 'plugin-rental-core', handlerName: 'generateFixedTermDailyLedgers', permissions: ['lease_contracts:update'], transactional: true, notes: ['GPS 数据不参与租金计算', '押金不计入租金'] }],
  actions: [{ name: 'approve_rent_waiver', title: '审批免除', sourcePlugin: 'plugin-rental-core', inputSchema: ['ledgerId'], outputSchema: 'waiver', requiredPermissions: ['rent_waivers:approve'], serviceName: 'waiverService.approveRentWaiver', notes: [] }],
  permissions: [
    { role: 'system_admin', collections: ['rent_payments', 'deposit_records'], actions: ['read', 'create', 'update', '审批免除'], fieldVisibility: { payment_screenshot: 'visible', total_paid_amount: 'visible', future_receivable_amount: 'visible', current_debt_amount: 'visible' }, sensitiveFields: ['payment_screenshot'], notes: ['审批'] },
    { role: 'manager', collections: ['rent_payments', 'deposit_records'], actions: ['read', '审批免除'], fieldVisibility: { payment_screenshot: 'masked', total_paid_amount: 'visible', future_receivable_amount: 'visible', current_debt_amount: 'visible' }, sensitiveFields: ['payment_screenshot'], notes: ['可审批免除'] },
    { role: 'accountant', collections: ['rent_payments', 'deposit_records'], actions: ['read', 'create'], fieldVisibility: { payment_screenshot: 'visible', total_paid_amount: 'visible', future_receivable_amount: 'visible', current_debt_amount: 'visible' }, sensitiveFields: ['payment_screenshot'], notes: [] },
    { role: 'operator', collections: ['drivers', 'vehicles'], actions: ['read'], fieldVisibility: { payment_screenshot: 'hidden', total_paid_amount: 'hidden', future_receivable_amount: 'hidden', current_debt_amount: 'hidden' }, sensitiveFields: ['payment_screenshot'], notes: [] },
    { role: 'gps_maintenance', collections: ['gps_devices'], actions: ['read'], fieldVisibility: { payment_screenshot: 'hidden', total_paid_amount: 'hidden', future_receivable_amount: 'hidden', current_debt_amount: 'hidden' }, sensitiveFields: ['payment_screenshot'], notes: [] },
    { role: 'readonly_auditor', collections: ['drivers'], actions: ['read'], fieldVisibility: { payment_screenshot: 'hidden', total_paid_amount: 'masked', future_receivable_amount: 'masked', current_debt_amount: 'masked' }, sensitiveFields: ['payment_screenshot'], notes: [] },
  ],
  schedules: [{ name: 'iopgps_sync_location', title: '同步定位', sourcePlugin: 'plugin-iopgps', cron: '*/30 * * * *', enabledByDefault: false, serviceName: 'iopgpsLocationService.syncLocation', notes: ['GPS 数据不参与租金计算'] }],
  i18n: [{ namespace: 'plugin-rental-core', sourcePlugin: 'plugin-rental-core', languages: ['zh-CN', 'en-US', 'fr-FR'], localeFiles: ['zh-CN.json', 'en-US.json', 'fr-FR.json'], notes: [] }],
  warnings: [],
  notes: ['GPS 数据不参与租金计算', '押金不计入租金'],
};

const buildPlan = (runtimePlan: RuntimeRegistrationPlan = baseRuntimePlan, mode: 'plan_only' | 'real' = 'plan_only') => new RealRuntimeRegistrationAdapter().buildRealRuntimeRegistrationPlan(runtimePlan, createDefaultRealRuntimeRegistrationContext(mode));

test('action 缺少 serviceName 被拒绝', () => {
  const plan = buildPlan({ ...baseRuntimePlan, actions: [{ ...baseRuntimePlan.actions[0], serviceName: '' }] });
  const result = validateRealRuntimeSchemaDraft(plan);
  assert(!result.passed && result.errors.some((error) => error.includes('serviceName')), '缺少 serviceName 应被拒绝。');
});

test('六个角色必须保留', () => {
  const plan = buildPlan({ ...baseRuntimePlan, permissions: baseRuntimePlan.permissions.slice(0, 5) });
  const result = validateRealRuntimeSchemaDraft(plan);
  assert(!result.passed && result.errors.some((error) => error.includes('readonly_auditor')), '缺少角色应被拒绝。');
});

test('operator 默认不能查看付款截图', () => {
  const plan = buildPlan();
  const operator = plan.permissions.find((permission) => permission.role === 'operator');
  assert(operator?.fieldVisibility.payment_screenshot === 'hidden', 'operator 付款截图应隐藏。');
});

test('gps_maintenance 默认不能查看财务汇总', () => {
  const plan = buildPlan();
  const gps = plan.permissions.find((permission) => permission.role === 'gps_maintenance');
  assert(gps?.fieldVisibility.total_paid_amount === 'hidden' && gps.fieldVisibility.future_receivable_amount === 'hidden', 'GPS 维护角色不能看财务汇总。');
});

test('manager 可审批免除', () => {
  const plan = buildPlan();
  const result = validateRealRuntimeSchemaDraft(plan);
  assert(result.passed, `manager 审批免除应通过：${result.errors.join('；')}`);
});

test('accountant 可访问付款和押金', () => {
  const plan = buildPlan();
  const accountant = plan.permissions.find((permission) => permission.role === 'accountant');
  assert(accountant?.collections.includes('rent_payments') && accountant.collections.includes('deposit_records'), 'accountant 应访问付款和押金。');
});

test('i18n 必须包含 zh-CN、en-US、fr-FR', () => {
  const plan = buildPlan({ ...baseRuntimePlan, i18n: [{ ...baseRuntimePlan.i18n[0], languages: ['zh-CN'] }] });
  const result = validateRealRuntimeSchemaDraft(plan);
  assert(!result.passed && result.errors.some((error) => error.includes('en-US')), '缺少三语言应被拒绝。');
});

test('mode 默认不是 real', () => {
  const plan = buildPlan();
  assert(plan.mode !== 'real', '默认模式不得为 real。');
});

test('mode = real 且 allowRealExecution = false 时拒绝', () => {
  const plan = buildPlan(baseRuntimePlan, 'real');
  assert(plan.errors.some((error) => error.includes('allowRealExecution') || error.includes('不允许 real')), 'real 且未允许应拒绝。');
});

test('mode = real 且无 backup 时拒绝', () => {
  const context = createDefaultRealRuntimeRegistrationContext('real');
  context.allowRealExecution = true;
  context.requireBackup = false;
  const plan = new RealRuntimeRegistrationAdapter().buildRealRuntimeRegistrationPlan(baseRuntimePlan, context);
  assert(plan.errors.some((error) => error.includes('requireBackup')), 'real 且无备份应拒绝。');
});

test('mode = real 且无 rollbackPlan 时拒绝', () => {
  const plan = buildPlan(baseRuntimePlan, 'real');
  plan.rollbackPlan = [];
  const result = validateRealRuntimeRegistrationSafety(plan, createDefaultRealRuntimeRegistrationContext('real'));
  assert(!result.passed && result.errors.some((error) => error.includes('rollbackPlan')), '无回滚计划应拒绝。');
});

test('当前仓库环境下不能执行 real', () => {
  const plan = buildPlan(baseRuntimePlan, 'real');
  assert(plan.errors.some((error) => error.includes('当前仓库') || error.includes('禁止执行 real')), '当前仓库不能执行 real。');
});

test('出现 booking 被拒绝', () => {
  const plan = buildPlan({ ...baseRuntimePlan, notes: ['booking'] });
  assert(!validateRealRuntimeSchemaDraft(plan).passed, 'booking 应被拒绝。');
});

test('出现 driver_login 被拒绝', () => {
  const plan = buildPlan({ ...baseRuntimePlan, notes: ['driver_login'] });
  assert(!validateRealRuntimeSchemaDraft(plan).passed, 'driver_login 应被拒绝。');
});

test('出现 vehicle_category_rental 被拒绝', () => {
  const plan = buildPlan({ ...baseRuntimePlan, notes: ['vehicle_category_rental'] });
  assert(!validateRealRuntimeSchemaDraft(plan).passed, 'vehicle_category_rental 应被拒绝。');
});

test('GPS 参与租金计算被拒绝', () => {
  const plan = buildPlan({ ...baseRuntimePlan, notes: ['GPS 参与租金计算'] });
  assert(!validateRealRuntimeSchemaDraft(plan).passed, 'GPS 参与租金计算应被拒绝。');
});

test('押金计入租金已付被拒绝', () => {
  const plan = buildPlan({ ...baseRuntimePlan, notes: ['押金计入租金已付'] });
  assert(!validateRealRuntimeSchemaDraft(plan).passed, '押金计入租金已付应被拒绝。');
});
