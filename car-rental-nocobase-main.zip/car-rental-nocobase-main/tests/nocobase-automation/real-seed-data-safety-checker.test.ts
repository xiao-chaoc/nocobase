import { assert, test } from '../testHarness';
import { buildSeedDataImportPlan, inspectNocobaseEnvironment, RealSeedDataImportAdapter, validateRealSeedDataImportSafety, validateRealSeedDataNoRealData, validateRealSeedDataSchemaDraft } from '../../packages/shared/nocobase-automation/src';
import type { RealSeedDataImportContext, RealSeedDataImportPlan } from '../../packages/shared/nocobase-automation/src';

const baseContext = (mode: RealSeedDataImportContext['mode'] = 'plan_only'): RealSeedDataImportContext => ({
  mode,
  adapterEnvironment: inspectNocobaseEnvironment({ mode: 'dry_run' }),
  allowRealExecution: false,
  requireBackup: true,
  requireRollbackPlan: true,
  requireTransaction: true,
  sourceDir: 'test-data/generated',
  operator: 'test',
  notes: ['测试上下文。'],
});

const basePlan = (): RealSeedDataImportPlan => new RealSeedDataImportAdapter().buildRealSeedDataImportPlan(buildSeedDataImportPlan(), baseContext());

const withExtraEntity = (entityType: string): RealSeedDataImportPlan => ({
  ...basePlan(),
  entities: [...basePlan().entities, { ...basePlan().entities[0], entityType, targetCollection: entityType }],
});

test('真实 Seed Data 安全检查接受 plan_only 草案并确认默认不是 real', () => {
  const plan = basePlan();
  const result = validateRealSeedDataSchemaDraft(plan);
  assert(plan.mode !== 'real', '默认模式不得为 real。');
  assert(result.passed, `schema draft 应通过：${result.errors.join('；')}`);
});

test('真实 Seed Data real 模式缺少执行授权、备份、回滚和事务时被拒绝', () => {
  const adapter = new RealSeedDataImportAdapter();
  const badContext = { ...baseContext('real'), allowRealExecution: false, requireBackup: false, requireRollbackPlan: false, requireTransaction: false };
  const plan = adapter.buildRealSeedDataImportPlan(buildSeedDataImportPlan(), badContext);
  const result = validateRealSeedDataImportSafety(plan, badContext);
  assert(!result.passed, 'real 模式应被拒绝。');
  assert(result.errors.some((error) => error.includes('allowRealExecution')), '应拒绝未授权 real。');
  assert(result.errors.some((error) => error.includes('备份')), '应要求备份。');
  assert(result.errors.some((error) => error.includes('回滚')), '应要求回滚。');
  assert(result.errors.some((error) => error.includes('事务')), '应要求事务。');
  assert(result.errors.some((error) => error.includes('当前仓库')), '当前仓库环境不能执行 real。');
});

test('真实 Seed Data schema draft 拒绝短租、司机登录和按车型出租实体', () => {
  for (const forbidden of ['booking', 'driver_login', 'vehicle_category_rental']) {
    const result = validateRealSeedDataSchemaDraft(withExtraEntity(forbidden));
    assert(!result.passed && result.errors.some((error) => error.includes(forbidden)), `${forbidden} 应被拒绝。`);
  }
});

test('真实 Seed Data schema draft 拒绝 GPS 参与租金计算和押金计入租金已付', () => {
  const gpsPlan = { ...basePlan(), notes: ['gps_rent_calculation'] };
  const depositPlan = { ...basePlan(), notes: ['deposit_as_rent_payment'] };
  assert(!validateRealSeedDataSchemaDraft(gpsPlan).passed, 'GPS 参与租金计算应被拒绝。');
  assert(!validateRealSeedDataSchemaDraft(depositPlan).passed, '押金计入租金已付应被拒绝。');
});

test('真实 Seed Data 禁止真实 access_token 和 login_key', () => {
  const plan = { ...basePlan(), notes: ['access_token=REAL_SECRET_VALUE', 'login_key=REAL_LOGIN_KEY'] };
  const result = validateRealSeedDataNoRealData(plan);
  assert(!result.passed, '真实 token 与 login_key 应被拒绝。');
  assert(result.errors.some((error) => error.includes('access_token')), '应拒绝 access_token。');
  assert(result.errors.some((error) => error.includes('login_key')), '应拒绝 login_key。');
});
