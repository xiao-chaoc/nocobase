import { assert, test } from '../testHarness';
import { contractDocumentsPluginRegistration } from '../../packages/plugins/plugin-contract-documents/src/server/pluginRegistration';
import { iopgpsPluginRegistration } from '../../packages/plugins/plugin-iopgps/src/server/pluginRegistration';
import { rentalCorePluginRegistration } from '../../packages/plugins/plugin-rental-core/src/server/pluginRegistration';
import { buildAutomatedRegistrationPlan, buildRuntimeRegistrationPlanFromAutomatedPlan, dryRunRegisterRuntime, summarizeRuntimeRegistrationResult } from '../../packages/shared/nocobase-automation/src';

const runtimePlan = buildRuntimeRegistrationPlanFromAutomatedPlan(buildAutomatedRegistrationPlan([rentalCorePluginRegistration, contractDocumentsPluginRegistration, iopgpsPluginRegistration]));

test('能从自动化计划构建 runtime 注册计划', () => {
  assert(runtimePlan.services.some((service) => service.handlerName === 'allocateRentPayment'), '应包含核心服务 allocateRentPayment。');
  assert(runtimePlan.actions.some((action) => action.name === 'confirm_rent_payment'), '应包含核心动作 confirm_rent_payment。');
  assert(runtimePlan.permissions.some((permission) => permission.role === 'system_admin'), '应包含 system_admin 权限。');
  assert(runtimePlan.i18n.length === 3, '应包含三个 i18n 命名空间。');
});

test('dryRunRegisterRuntime 返回中文步骤和 summary', () => {
  const result = dryRunRegisterRuntime(runtimePlan);
  assert(result.success, `runtime dry-run 应成功：${result.errors.join('；')}`);
  assert(result.serviceResults.some((item) => item.steps.some((step) => step.includes('dry-run'))), '服务结果应包含 dry-run 步骤。');
  assert(result.warnings.some((warning) => warning.includes('不连接真实 NocoBase')), '警告应说明不连接真实 NocoBase。');
  const summary = summarizeRuntimeRegistrationResult(result);
  assert(summary.includes('服务数量'), '摘要应包含服务数量。');
  assert(summary.includes('动作数量'), '摘要应包含动作数量。');
  assert(summary.includes('权限角色数量'), '摘要应包含权限角色数量。');
});
