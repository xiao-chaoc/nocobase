import { assert, test } from '../testHarness';
import { contractDocumentsPluginRegistration } from '../../packages/plugins/plugin-contract-documents/src/server/pluginRegistration';
import { iopgpsPluginRegistration } from '../../packages/plugins/plugin-iopgps/src/server/pluginRegistration';
import { rentalCorePluginRegistration } from '../../packages/plugins/plugin-rental-core/src/server/pluginRegistration';
import { buildAutomatedRegistrationPlan, buildRuntimeRegistrationPlanFromAutomatedPlan, normalizeActionPlan, validateRuntimeRegistrationPlan } from '../../packages/shared/nocobase-automation/src';

const runtimePlan = buildRuntimeRegistrationPlanFromAutomatedPlan(buildAutomatedRegistrationPlan([rentalCorePluginRegistration, contractDocumentsPluginRegistration, iopgpsPluginRegistration]));

test('能标准化动作计划', () => {
  const action = normalizeActionPlan(runtimePlan.actions.find((item) => item.name === 'confirm_rent_payment')!);
  assert(action.name === 'confirm_rent_payment', '动作名称应保留。');
  assert(action.serviceName.length > 0, '动作应保留 serviceName。');
  assert(action.notes.some((note) => note.includes('不真实注册按钮')), '动作说明应保持 dry-run 边界。');
});

test('动作缺少 serviceName 被拒绝', () => {
  const broken = { ...runtimePlan, actions: runtimePlan.actions.map((action) => action.name === 'confirm_rent_payment' ? { ...action, serviceName: '' } : action) };
  const result = validateRuntimeRegistrationPlan(broken);
  assert(!result.passed, '缺少 serviceName 应被拒绝。');
  assert(result.errors.some((error) => error.includes('serviceName')), '错误应提到 serviceName。');
});
