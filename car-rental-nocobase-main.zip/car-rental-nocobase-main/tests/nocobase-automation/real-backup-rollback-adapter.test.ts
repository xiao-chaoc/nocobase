import { assert, test } from '../testHarness';
import { inspectNocobaseEnvironment, RealBackupRollbackAdapter } from '../../packages/shared/nocobase-automation/src';
import { generateRealBackupRollbackPlan } from '../../scripts/nocobase/generate-real-backup-rollback-plan';
import { validateGeneratedRealBackupRollbackPlan } from '../../scripts/nocobase/validate-real-backup-rollback-plan';
import type { RealBackupRollbackContext } from '../../packages/shared/nocobase-automation/src';

const context = (mode: RealBackupRollbackContext['mode'] = 'plan_only'): RealBackupRollbackContext => ({
  mode,
  adapterEnvironment: inspectNocobaseEnvironment({ mode: 'dry_run' }),
  allowRealExecution: false,
  requireOperatorConfirmation: false,
  requireIsolatedDatabase: true,
  requireMockDataOnly: true,
  requireIopgpsDisabled: true,
  backupDirectory: 'backups-test/real-backup-rollback-draft',
  rollbackDirectory: 'backups-test/real-backup-rollback-draft/rollback',
  operator: 'test',
  notes: ['不调用真实 NocoBase API。'],
});

test('adapter 只生成计划，不执行备份', () => {
  const report = new RealBackupRollbackAdapter().generateBackupRollbackReport(context());
  assert(!report.executed, '报告不得标记为已执行。');
  assert(report.backupPlan.steps.every((step) => !step.executed && !step.canExecute), '备份步骤不得执行。');
});

test('adapter 不执行 pg_dump', () => {
  let called = false;
  const fake = { pgDump: () => { called = true; } };
  const report = new RealBackupRollbackAdapter().generateBackupRollbackReport(context());
  assert(fake && !called, 'adapter 不应调用 pg_dump。');
  assert(report.backupPlan.steps.some((step) => step.plannedCommand.includes('pg_dump')), '只应保留 pg_dump 草案说明。');
});

test('adapter 不执行 pg_restore', () => {
  let called = false;
  const fake = { pgRestore: () => { called = true; } };
  const report = new RealBackupRollbackAdapter().generateBackupRollbackReport(context());
  assert(fake && !called, 'adapter 不应调用 pg_restore。');
  assert(report.rollbackPlan.steps.some((step) => step.plannedAction.includes('pg_restore')), '只应保留 pg_restore 草案说明。');
});

test('adapter 不删除文件', () => {
  let called = false;
  const fake = { rm: () => { called = true; } };
  const report = new RealBackupRollbackAdapter().generateBackupRollbackReport(context());
  assert(fake && !called, 'adapter 不应删除文件。');
  assert(report.rollbackPlan.steps.every((step) => !step.executed), '回滚步骤不得执行。');
});

test('adapter 不调用真实 NocoBase API', () => {
  let called = false;
  const fakeApi = { app: { start: () => { called = true; } }, db: { query: () => { called = true; } }, storage: { snapshot: () => { called = true; } } };
  const report = new RealBackupRollbackAdapter().generateBackupRollbackReport(context());
  assert(fakeApi && !called, 'adapter 不应调用真实 NocoBase API。');
  assert(report.warnings.join(' ').includes('不连接 NocoBase'), '报告应说明不连接 NocoBase。');
});

test('adapter 的 real 模式返回错误并阻止执行', () => {
  const report = new RealBackupRollbackAdapter().generateBackupRollbackReport(context('real'));
  assert(!report.success, 'real 模式不得成功。');
  assert(report.errors.some((error) => error.includes('当前仓库') || error.includes('real')), '应说明当前仓库不允许真实执行。');
  assert(report.backupsExecutable === 0 && report.rollbacksExecutable === 0, 'real 模式下不得可执行。');
});

test('脚本能生成 real-backup-rollback-plan.generated.json', () => {
  const result = generateRealBackupRollbackPlan();
  assert(result.output.report.mode === 'plan_only', '生成脚本默认应使用 plan_only。');
  assert(result.output.report.backupPlan.steps.length > 0, '应生成 backup plan。');
  assert(result.output.report.rollbackPlan.steps.length > 0, '应生成 rollback plan。');
});

test('校验脚本能通过 plan_only 结果', () => {
  generateRealBackupRollbackPlan();
  const result = validateGeneratedRealBackupRollbackPlan();
  assert(result.passed, `校验脚本应通过：${result.errors.join('；')}`);
});
