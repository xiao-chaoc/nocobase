declare const require: any;

const fs = require('fs');
import { assert, test } from '../testHarness';

const read = (path: string): string => fs.readFileSync(path, 'utf8');

const issueTemplate = '.github/ISSUE_TEMPLATE/nocobase-target-version-confirmation.yml';
const prTemplate = '.github/pull_request_template.md';
const operatorChecklist = 'docs/nocobase-target-version-operator-checklist.md';
const commitPolicy = 'docs/nocobase-target-version-commit-policy.md';
const reviewChecklist = 'docs/nocobase-target-version-review-checklist.md';
const workflowDoc = 'docs/nocobase-target-version-confirmation-workflow.md';
const workflowScript = 'scripts/nocobase/validate-target-version-workflow-files.ts';

test('Issue 模板存在', () => {
  assert(fs.existsSync(issueTemplate), '缺少 Issue 模板。');
});

test('PR 模板存在', () => {
  assert(fs.existsSync(prTemplate), '缺少 PR 模板。');
});

test('operator checklist 存在', () => {
  assert(fs.existsSync(operatorChecklist), '缺少人工确认操作清单。');
});

test('commit policy 存在', () => {
  assert(fs.existsSync(commitPolicy), '缺少提交规范。');
});

test('review checklist 存在', () => {
  assert(fs.existsSync(reviewChecklist), '缺少 review checklist。');
});

test('validate-target-version-workflow-files.ts 存在', () => {
  assert(fs.existsSync(workflowScript), '缺少流程文件校验脚本。');
});

test('package.json 包含 validate:target-version-workflow-files', () => {
  const packageJson = JSON.parse(read('package.json')) as { scripts?: Record<string, string> };
  assert(Boolean(packageJson.scripts?.['validate:target-version-workflow-files']), '缺少 validate:target-version-workflow-files。');
});

test('Issue 模板不包含 APP_KEY', () => {
  assert(!read(issueTemplate).includes('APP_KEY'), 'Issue 模板不能包含 APP_KEY。');
});

test('Issue 模板不包含 DB_PASSWORD', () => {
  assert(!read(issueTemplate).includes('DB_PASSWORD'), 'Issue 模板不能包含 DB_PASSWORD。');
});

test('Issue 模板不包含 IOPGPS_LOGIN_KEY', () => {
  assert(!read(issueTemplate).includes('IOPGPS_LOGIN_KEY'), 'Issue 模板不能包含 IOPGPS_LOGIN_KEY。');
});

test('PR 模板包含 latest-full 检查', () => {
  assert(read(prTemplate).includes('latest-full'), 'PR 模板必须包含 latest-full 检查。');
});

test('PR 模板包含 .env 检查', () => {
  assert(read(prTemplate).includes('.env'), 'PR 模板必须包含 .env 检查。');
});

test('commit policy 禁止 filled.json', () => {
  assert(read(commitPolicy).includes('filled.json'), '提交规范必须禁止 filled.json。');
});

test('review checklist 包含 validate:can-start-real-adapter', () => {
  assert(read(reviewChecklist).includes('validate:can-start-real-adapter'), 'review checklist 必须包含 validate:can-start-real-adapter。');
});

test('workflow 文档说明版本未确认前不能继续真实 adapter', () => {
  assert(read(workflowDoc).includes('目标版本未确认前不能继续真实 adapter'), 'workflow 文档必须说明版本未确认前不能继续真实 adapter。');
});

test('流程文件校验脚本不连接 NocoBase', () => {
  const content = read(workflowScript);
  assert(!content.includes('fetch(') && !content.includes('axios') && !content.includes('NocoBase('), '流程文件校验脚本不应连接 NocoBase。');
});

test('流程文件校验脚本不读取 .env.test', () => {
  const content = read(workflowScript);
  assert(!content.includes("readFileSync('.env.test'") && !content.includes('readFileSync(".env.test"'), '流程文件校验脚本不应读取 .env.test。');
});
