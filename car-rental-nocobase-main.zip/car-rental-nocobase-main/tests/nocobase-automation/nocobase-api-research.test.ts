import { assert, test } from '../testHarness';
declare const require: any;

const fs = require('fs');

const read = (filePath: string): string => fs.readFileSync(filePath, 'utf8');

const targetVersionDoc = 'docs/nocobase-target-version-research.md';
const pluginApiDoc = 'docs/nocobase-plugin-api-research.md';
const adapterMappingDoc = 'docs/real-adapter-api-mapping.md';
const gapAnalysisDoc = 'docs/real-adapter-gap-analysis.md';
const backlogDoc = 'docs/real-adapter-implementation-backlog.md';
const validateScript = 'scripts/nocobase/validate-nocobase-api-research.ts';

test('目标版本调研文档存在', () => {
  assert(fs.existsSync(targetVersionDoc), '缺少目标版本调研文档。');
});

test('插件 API 调研文档存在', () => {
  assert(fs.existsSync(pluginApiDoc), '缺少插件 API 调研文档。');
});

test('Adapter API 映射文档存在', () => {
  assert(fs.existsSync(adapterMappingDoc), '缺少 Adapter API 映射文档。');
});

test('差距分析文档存在', () => {
  assert(fs.existsSync(gapAnalysisDoc), '缺少差距分析文档。');
});

test('Backlog 文档存在', () => {
  assert(fs.existsSync(backlogDoc), '缺少 Backlog 文档。');
});

test('validate-nocobase-api-research 脚本存在', () => {
  assert(fs.existsSync(validateScript), '缺少 API 调研校验脚本。');
});

test('package.json 包含 validate:nocobase-api-research', () => {
  const packageJson = JSON.parse(read('package.json')) as { scripts?: Record<string, string> };
  assert(Boolean(packageJson.scripts?.['validate:nocobase-api-research']), 'package.json 缺少 validate:nocobase-api-research。');
});

test('API 调研文档包含插件生命周期', () => {
  assert(read(pluginApiDoc).includes('插件生命周期'), 'API 调研文档缺少插件生命周期。');
});

test('API 调研文档包含 Collection 注册', () => {
  assert(read(pluginApiDoc).includes('Collection 注册'), 'API 调研文档缺少 Collection 注册。');
});

test('API 调研文档包含权限 ACL', () => {
  assert(read(pluginApiDoc).includes('权限 ACL'), 'API 调研文档缺少权限 ACL。');
});

test('API 调研文档包含 UI Schema', () => {
  assert(read(pluginApiDoc).includes('UI Schema'), 'API 调研文档缺少 UI Schema。');
});

test('API 调研文档包含 i18n', () => {
  assert(read(pluginApiDoc).includes('i18n'), 'API 调研文档缺少 i18n。');
});

test('API 调研文档包含定时任务', () => {
  assert(read(pluginApiDoc).includes('定时任务'), 'API 调研文档缺少定时任务。');
});

test('API 调研文档包含文件存储', () => {
  assert(read(pluginApiDoc).includes('文件存储'), 'API 调研文档缺少文件存储。');
});

test('API 调研文档包含模板打印', () => {
  assert(read(pluginApiDoc).includes('模板打印'), 'API 调研文档缺少模板打印。');
});

test('文档明确不得伪造 API', () => {
  const combined = [targetVersionDoc, pluginApiDoc, adapterMappingDoc, gapAnalysisDoc, backlogDoc].map(read).join('\n');
  assert(combined.includes('不得伪造 API'), '文档必须明确不得伪造 API。');
});

test('文档明确不得生产库调试', () => {
  const combined = [targetVersionDoc, pluginApiDoc, adapterMappingDoc, gapAnalysisDoc, backlogDoc].map(read).join('\n');
  assert(combined.includes('不得生产库调试'), '文档必须明确不得生产库调试。');
});

test('文档明确无法确认的 API 必须标记待验证', () => {
  const combined = [targetVersionDoc, pluginApiDoc, adapterMappingDoc, gapAnalysisDoc, backlogDoc].map(read).join('\n');
  assert(combined.includes('无法确认的 API 必须标记待验证') || combined.includes('无法确认') && combined.includes('待验证'), '文档必须明确无法确认的 API 必须标记待验证。');
});
