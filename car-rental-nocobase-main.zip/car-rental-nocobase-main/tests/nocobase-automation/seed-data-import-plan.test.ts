import { assert, test } from '../testHarness';
import { buildSeedDataDependencyPlan, buildSeedDataImportPlan, getDefaultSeedDataImportOrder } from '../../packages/shared/nocobase-automation/src';

test('能生成测试数据导入计划并保持顺序正确', () => {
  const plan = buildSeedDataImportPlan();
  const order = getDefaultSeedDataImportOrder();
  assert(plan.entities.length === order.length, '导入计划应包含所有核心实体。');
  assert(plan.importOrder.join(',') === order.join(','), '导入顺序应符合默认顺序。');
});

test('导入顺序满足核心依赖', () => {
  const order = getDefaultSeedDataImportOrder();
  const index = (name: string) => order.indexOf(name as any);
  assert(index('drivers') < index('lease_contracts'), 'drivers 必须早于 lease_contracts。');
  assert(index('vehicles') < index('lease_contracts'), 'vehicles 必须早于 lease_contracts。');
  assert(index('lease_contracts') < index('rent_daily_ledgers'), 'lease_contracts 必须早于 rent_daily_ledgers。');
  assert(index('rent_payments') < index('rent_payment_allocations'), 'rent_payments 必须早于 rent_payment_allocations。');
  assert(index('gps_devices') < index('gps_daily_mileages'), 'gps_devices 必须早于 gps_daily_mileages。');
});

test('依赖计划包含合同、付款、GPS 和合同文件引用', () => {
  const deps = buildSeedDataDependencyPlan();
  assert(deps.some((dep) => dep.entityType === 'lease_contracts' && dep.dependsOn === 'drivers'), '合同应依赖司机。');
  assert(deps.some((dep) => dep.entityType === 'rent_payment_allocations' && dep.dependsOn === 'rent_daily_ledgers'), '付款分配应依赖台账。');
  assert(deps.some((dep) => dep.entityType === 'gps_daily_mileages' && dep.dependsOn === 'gps_devices'), 'GPS 里程应依赖设备。');
});
