import { assert, test } from '../testHarness';
import { createDefaultRealCollectionRegistrationContext, RealCollectionRegistrationAdapter } from '../../packages/shared/nocobase-automation/src';
import { generateAutomatedRegistrationPlan } from '../../scripts/nocobase/generate-automated-registration-plan';
import { generateRealCollectionRegistrationPlan } from '../../scripts/nocobase/generate-real-collection-registration-plan';
import { validateGeneratedRealCollectionRegistrationPlan } from '../../scripts/nocobase/validate-real-collection-registration-plan';
import type { NocobaseCollectionPlan } from '../../packages/shared/nocobase-automation/src';

const collection: NocobaseCollectionPlan = {
  name: 'adapter_test_collections',
  title: 'Adapter 测试表',
  fields: ['name'],
  indexes: ['name'],
  uniqueConstraints: [['name']],
  sensitiveFields: [],
  relations: [],
  sourcePlugin: 'plugin-rental-core',
  notes: [],
};

test('adapter 只生成计划，不写数据库', () => {
  const adapter = new RealCollectionRegistrationAdapter();
  const plan = adapter.buildRealCollectionRegistrationPlan([collection], createDefaultRealCollectionRegistrationContext('plan_only'));
  const report = adapter.validateRealCollectionRegistrationPlan(plan);
  assert(plan.collections.length === 1, '应生成一个 Collection 草案。');
  assert(report.executed === false, '不得标记为已执行。');
});

test('adapter 不调用真实 NocoBase API', () => {
  const adapter = new RealCollectionRegistrationAdapter();
  const plan = adapter.buildRealCollectionRegistrationPlan([collection]);
  assert(plan.notes.some((note) => note.includes('未调用 app.collection')), '应声明未调用 app.collection。');
  assert(plan.notes.some((note) => note.includes('未调用 db.collection')), '应声明未调用 db.collection。');
});

test('real 模式返回错误', () => {
  const adapter = new RealCollectionRegistrationAdapter();
  const plan = adapter.buildRealCollectionRegistrationPlan([collection], createDefaultRealCollectionRegistrationContext('real'));
  assert(plan.errors.some((error) => error.includes('不允许真实执行') || error.includes('禁止')), 'real 模式应返回错误。');
});

test('脚本能生成 real-collection-registration-plan.generated.json', () => {
  generateAutomatedRegistrationPlan();
  const result = generateRealCollectionRegistrationPlan();
  assert(result.output.plan.mode === 'plan_only', '生成脚本默认应使用 plan_only。');
  assert(result.output.plan.collections.length > 0, '应生成 Collection schema draft。');
});

test('校验脚本能通过 plan_only 结果', () => {
  generateAutomatedRegistrationPlan();
  generateRealCollectionRegistrationPlan();
  const result = validateGeneratedRealCollectionRegistrationPlan();
  assert(result.passed, `校验脚本应通过：${result.errors.join('；')}`);
});
