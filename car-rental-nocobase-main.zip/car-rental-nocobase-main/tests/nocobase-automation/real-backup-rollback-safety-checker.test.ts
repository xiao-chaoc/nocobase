import { assert, test } from '../testHarness';
import { buildFailureRecoveryPlans, buildRealBackupPlan, buildRealRollbackPlan, inspectNocobaseEnvironment, validateFailureRecoveryPlans, validateRealBackupPlan, validateRealBackupRollbackSafety, validateRealRollbackPlan } from '../../packages/shared/nocobase-automation/src';
import type { RealBackupRollbackContext } from '../../packages/shared/nocobase-automation/src';

const context = (overrides: Partial<RealBackupRollbackContext> = {}): RealBackupRollbackContext => ({
  mode: 'plan_only',
  adapterEnvironment: inspectNocobaseEnvironment({ mode: 'dry_run' }),
  allowRealExecution: false,
  requireOperatorConfirmation: false,
  requireIsolatedDatabase: true,
  requireMockDataOnly: true,
  requireIopgpsDisabled: true,
  backupDirectory: 'backups-test/real-backup-rollback-draft',
  rollbackDirectory: 'backups-test/real-backup-rollback-draft/rollback',
  operator: 'test',
  notes: ['测试只生成草案。'],
  ...overrides,
});

test('mode 默认不是 real', () => {
  const plan = buildRealBackupPlan({});
  assert(plan.mode !== 'real', '默认模式不能是 real。');
});

test('mode = real 且 allowRealExecution = false 时拒绝', () => {
  const c = context({ mode: 'real', allowRealExecution: false });
  const result = validateRealBackupRollbackSafety(buildRealBackupPlan(c), c);
  assert(result.errors.some((error) => error.includes('allowRealExecution')), '应拒绝未授权 real。');
});

test('mode = real 且无 operator confirmation 时拒绝', () => {
  const c = context({ mode: 'real', allowRealExecution: true, requireOperatorConfirmation: false });
  const result = validateRealBackupRollbackSafety(buildRealBackupPlan(c), c);
  assert(result.errors.some((error) => error.includes('requireOperatorConfirmation')), '应拒绝无人工确认 real。');
});

test('mode = real 且非 isolated database 时拒绝', () => {
  const c = context({ mode: 'real', allowRealExecution: true, requireOperatorConfirmation: true, requireIsolatedDatabase: false });
  const result = validateRealBackupRollbackSafety(buildRealBackupPlan(c), c);
  assert(result.errors.some((error) => error.includes('requireIsolatedDatabase') || error.includes('隔离')), '应拒绝非隔离数据库 real。');
});

test('mode = real 且 IOPGPS 未禁用时拒绝', () => {
  const c = context({ mode: 'real', allowRealExecution: true, requireOperatorConfirmation: true, requireIopgpsDisabled: false });
  const result = validateRealBackupRollbackSafety(buildRealBackupPlan(c), c);
  assert(result.errors.some((error) => error.includes('Iopgps') || error.includes('IOPGPS')), '应拒绝 IOPGPS 未禁用。');
});

test('当前仓库环境下不能执行 real', () => {
  const c = context({ mode: 'real', allowRealExecution: true, requireOperatorConfirmation: true });
  const result = validateRealBackupRollbackSafety(buildRealBackupPlan(c), c);
  assert(result.errors.some((error) => error.includes('当前仓库')), '当前仓库必须阻断 real。');
});

test('校验 backup plan 目标和不可执行状态', () => {
  const result = validateRealBackupPlan(buildRealBackupPlan(context()));
  assert(result.passed, `backup plan 应通过：${result.errors.join('；')}`);
});

test('校验 rollback plan 目标和不可执行状态', () => {
  const result = validateRealRollbackPlan(buildRealRollbackPlan(context()));
  assert(result.passed, `rollback plan 应通过：${result.errors.join('；')}`);
});

test('校验 failure recovery plans 结构完整', () => {
  const result = validateFailureRecoveryPlans(buildFailureRecoveryPlans(context()));
  assert(result.passed, `failure recovery plans 应通过：${result.errors.join('；')}`);
});
