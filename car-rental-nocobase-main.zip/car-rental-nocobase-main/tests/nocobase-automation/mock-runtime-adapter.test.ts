import { assert, test } from '../testHarness';
import { contractDocumentsPluginRegistration } from '../../packages/plugins/plugin-contract-documents/src/server/pluginRegistration';
import { iopgpsPluginRegistration } from '../../packages/plugins/plugin-iopgps/src/server/pluginRegistration';
import { rentalCorePluginRegistration } from '../../packages/plugins/plugin-rental-core/src/server/pluginRegistration';
import { buildAutomatedRegistrationPlan, buildRuntimeRegistrationPlanFromAutomatedPlan, MockRuntimeAdapter } from '../../packages/shared/nocobase-automation/src';

const runtimePlan = buildRuntimeRegistrationPlanFromAutomatedPlan(buildAutomatedRegistrationPlan([rentalCorePluginRegistration, contractDocumentsPluginRegistration, iopgpsPluginRegistration]));

test('MockRuntimeAdapter 能 dry-run 注册服务和动作', () => {
  const adapter = new MockRuntimeAdapter();
  const serviceResult = adapter.registerServices([runtimePlan.services[0]])[0];
  const actionResult = adapter.registerActions([runtimePlan.actions[0]])[0];
  assert(serviceResult.success && serviceResult.registered, '服务 dry-run 注册应成功。');
  assert(actionResult.success && actionResult.registered, '动作 dry-run 注册应成功。');
  assert(serviceResult.steps.some((step) => step.includes('不连接真实 NocoBase')), '服务步骤应说明不连接真实 NocoBase。');
  assert(actionResult.steps.some((step) => step.includes('不注册真实按钮')), '动作步骤应说明不注册真实按钮。');
});

test('MockRuntimeAdapter 能 dry-run 注册权限、定时任务和 i18n', () => {
  const adapter = new MockRuntimeAdapter();
  const permissionResult = adapter.registerPermissions([runtimePlan.permissions[0]])[0];
  const scheduleResult = adapter.registerSchedules([runtimePlan.schedules[0]])[0];
  const i18nResult = adapter.registerI18n([runtimePlan.i18n[0]])[0];
  assert(permissionResult.success && permissionResult.registered, '权限 dry-run 注册应成功。');
  assert(scheduleResult.success && scheduleResult.registered, '定时任务 dry-run 注册应成功。');
  assert(i18nResult.success && i18nResult.registered, 'i18n dry-run 注册应成功。');
  assert(permissionResult.steps.some((step) => step.includes('不注册真实 ACL')), '权限步骤应说明不注册真实 ACL。');
  assert(scheduleResult.steps.some((step) => step.includes('不执行真实 scheduler')), '定时任务步骤应说明不执行真实 scheduler。');
});

test('MockRuntimeAdapter 重复注册会 skipped', () => {
  const adapter = new MockRuntimeAdapter();
  adapter.registerServices([runtimePlan.services[0]]);
  const duplicate = adapter.registerServices([runtimePlan.services[0]])[0];
  assert(duplicate.success && duplicate.skipped, '重复服务应跳过。');
});
