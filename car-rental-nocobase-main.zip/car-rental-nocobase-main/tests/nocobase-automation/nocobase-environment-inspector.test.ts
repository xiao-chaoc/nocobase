import { assert, test } from '../testHarness';
import { inspectNocobaseEnvironment, summarizeNocobaseEnvironment } from '../../packages/shared/nocobase-automation/src';

test('inspectNocobaseEnvironment 缺少 app 时输出错误', () => {
  const environment = inspectNocobaseEnvironment({ mode: 'real', db: {}, acl: {}, uiSchema: {}, pluginManager: {} });
  assert(environment.errors.some((error) => error.includes('真实 NocoBase app')), '应输出缺少 app 错误。');
});

test('inspectNocobaseEnvironment 缺少 acl 时输出错误', () => {
  const environment = inspectNocobaseEnvironment({ mode: 'real', app: {}, db: {}, uiSchema: {}, pluginManager: {} });
  assert(environment.errors.some((error) => error.includes('ACL')), '应输出缺少 ACL 的错误。');
});

test('summarizeNocobaseEnvironment 输出中文摘要', () => {
  const environment = inspectNocobaseEnvironment({ mode: 'disabled' });
  const summary = summarizeNocobaseEnvironment(environment);
  assert(summary.includes('当前模式'), '摘要应包含当前模式。');
  assert(summary.includes('缺失能力'), '摘要应包含缺失能力。');
  assert(summary.includes('是否可以真实注册 Collections'), '摘要应说明是否可真实注册 Collections。');
  assert(summary.includes('下一步需要接入'), '摘要应说明下一步需要接入内容。');
});
