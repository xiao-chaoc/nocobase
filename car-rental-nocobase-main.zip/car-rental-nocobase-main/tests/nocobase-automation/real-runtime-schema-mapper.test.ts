import { assert, test } from '../testHarness';
import {
  mapActionPlanToRealSchemaDraft,
  mapI18nPlanToRealSchemaDraft,
  mapPermissionPlanToRealSchemaDraft,
  mapSchedulePlanToRealSchemaDraft,
  mapServicePlanToRealSchemaDraft,
} from '../../packages/shared/nocobase-automation/src';
import type { NocobaseActionPlan, NocobaseI18nPlan, NocobasePermissionPlan, NocobaseSchedulePlan, NocobaseServicePlan } from '../../packages/shared/nocobase-automation/src';

const service: NocobaseServicePlan = { name: 'paymentAllocationService.allocateRentPayment', sourcePlugin: 'plugin-rental-core', handlerName: 'allocateRentPayment', permissions: ['rent_payments:create'], transactional: true, notes: [] };
const action: NocobaseActionPlan = { name: 'confirm_rent_payment', title: '确认付款', sourcePlugin: 'plugin-rental-core', inputSchema: ['paymentId'], outputSchema: 'paymentResult', requiredPermissions: ['rent_payments:create'], serviceName: 'paymentAllocationService.allocateRentPayment', notes: [] };
const permission: NocobasePermissionPlan = { role: 'operator', collections: ['drivers', 'vehicles'], actions: ['read'], fieldVisibility: { payment_screenshot: 'hidden', total_paid_amount: 'hidden' }, sensitiveFields: ['payment_screenshot'], notes: ['plugin-rental-core 权限草案'] };
const schedule: NocobaseSchedulePlan = { name: 'iopgps_sync_location', title: '同步 GPS 定位', sourcePlugin: 'plugin-iopgps', cron: '*/30 * * * *', enabledByDefault: true, serviceName: 'iopgpsLocationService.syncLocation', notes: ['GPS 数据不参与租金计算'] };
const i18n: NocobaseI18nPlan = { namespace: 'plugin-rental-core', sourcePlugin: 'plugin-rental-core', languages: ['zh-CN', 'en-US', 'fr-FR'], localeFiles: ['zh-CN.json', 'en-US.json', 'fr-FR.json'], notes: [] };

test('能将 service plan 映射为 service schema draft', () => {
  const draft = mapServicePlanToRealSchemaDraft(service);
  assert(draft.name === service.name, '服务名称应保留。');
  assert(draft.permissions.includes('rent_payments:create'), '权限要求不能删除。');
});

test('事务服务能被标记 transactional', () => {
  const draft = mapServicePlanToRealSchemaDraft(service);
  assert(draft.transactional, '事务标记应保留。');
  assert(draft.warnings.some((warning) => warning.includes('事务')), '事务服务应提示后续接入数据库事务。');
});

test('能将 action plan 映射为 action schema draft', () => {
  const draft = mapActionPlanToRealSchemaDraft(action);
  assert(draft.serviceName === action.serviceName, '动作应保留 serviceName。');
  assert(draft.confirmationRequired, '确认付款动作应要求确认。');
});

test('能将 permission plan 映射为 permission schema draft', () => {
  const draft = mapPermissionPlanToRealSchemaDraft(permission);
  assert(draft.role === 'operator', '角色应保留。');
  assert(draft.fieldVisibility.payment_screenshot === 'hidden', '付款截图字段可见性应保留。');
  assert(draft.aclNotes.some((note) => note.includes('不能只靠前端隐藏')), '应说明必须接入服务端 ACL。');
});

test('能将 schedule plan 映射为 schedule schema draft', () => {
  const draft = mapSchedulePlanToRealSchemaDraft(schedule);
  assert(draft.serviceName === schedule.serviceName, '定时任务应保留 serviceName。');
  assert(draft.schedulerNotes.some((note) => note.includes('失败隔离')), '定时任务应说明失败隔离。');
});

test('IOPGPS schedule 默认不能真实启用', () => {
  const draft = mapSchedulePlanToRealSchemaDraft(schedule);
  assert(draft.enabledByDefault === false, 'IOPGPS 定时任务应默认关闭。');
});

test('能将 i18n plan 映射为 i18n schema draft', () => {
  const draft = mapI18nPlanToRealSchemaDraft(i18n);
  assert(draft.namespace === 'plugin-rental-core', 'i18n namespace 应保留。');
  assert(draft.languages.includes('zh-CN') && draft.languages.includes('en-US') && draft.languages.includes('fr-FR'), '三语言应保留。');
});
