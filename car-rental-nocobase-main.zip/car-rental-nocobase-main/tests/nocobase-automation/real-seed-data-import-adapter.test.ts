import { assert, test } from '../testHarness';
import { buildSeedDataImportPlan, dryRunImportSeedData, inspectNocobaseEnvironment, RealSeedDataImportAdapter, summarizeSeedDataImportResult } from '../../packages/shared/nocobase-automation/src';
import { generateRealSeedDataImportPlan } from '../../scripts/nocobase/generate-real-seed-data-import-plan';
import { seedTestData } from '../../scripts/seed-test-data';
import { validateGeneratedRealSeedDataImportPlan } from '../../scripts/nocobase/validate-real-seed-data-import-plan';
import type { RealSeedDataImportContext } from '../../packages/shared/nocobase-automation/src';

declare const require: any;
const fs = require('fs');
const path = require('path');

const ensureSeedImportDryRun = () => {
  seedTestData();
  const sourceDir = path.resolve('test-data/generated');
  const manifest = fs.readdirSync(sourceDir).filter((fileName: string) => fileName.endsWith('.json')).sort();
  const importPlan = buildSeedDataImportPlan(manifest);
  const result = dryRunImportSeedData({
    importPlan,
    dryRun: true,
    sourceDir,
    targetEnvironment: 'dry-run-nocobase-test',
    importedBy: 'codex-test',
    importedAt: '2026-06-04T00:00:00.000Z',
  });
  const summary = summarizeSeedDataImportResult(result);
  fs.writeFileSync(path.join(sourceDir, 'seed-data-import-dry-run.generated.json'), JSON.stringify({ generated_at: '2026-06-04T00:00:00.000Z', dry_run_only: true, importPlan, result, summary }, null, 2));
};

const context = (mode: RealSeedDataImportContext['mode'] = 'plan_only'): RealSeedDataImportContext => ({
  mode,
  adapterEnvironment: inspectNocobaseEnvironment({ mode: 'dry_run' }),
  allowRealExecution: false,
  requireBackup: true,
  requireRollbackPlan: true,
  requireTransaction: true,
  sourceDir: 'test-data/generated',
  operator: 'test',
  notes: ['不调用真实 NocoBase API。'],
});

test('真实 Seed Data adapter 生成事务、回滚和后置验证计划', () => {
  const plan = new RealSeedDataImportAdapter().buildRealSeedDataImportPlan(buildSeedDataImportPlan(), context());
  assert(plan.transactionPlan.length > 0, '应生成 transactionPlan。');
  assert(plan.rollbackPlan.length > 0, '应生成 rollbackPlan。');
  assert(plan.postImportValidationPlan.length > 0, '应生成 postImportValidationPlan。');
  assert(plan.steps.length === plan.entities.length, '应为每个实体生成导入步骤。');
});

test('真实 Seed Data adapter 只生成计划，不写数据库也不调用真实 NocoBase API', () => {
  let called = false;
  const fakeApi = { repository: { create: () => { called = true; } }, db: { collection: { create: () => { called = true; } } }, storage: { upload: () => { called = true; } } };
  const plan = new RealSeedDataImportAdapter().buildRealSeedDataImportPlan(buildSeedDataImportPlan(), context());
  assert(fakeApi && !called, 'adapter 不应调用真实 repository/db/storage API。');
  assert(plan.notes.join(' ').includes('不调用真实 NocoBase') || plan.warnings.join(' ').includes('不连接 NocoBase'), '计划应说明未调用真实 NocoBase。');
});

test('真实 Seed Data adapter 的 real 模式在当前仓库返回错误', () => {
  const plan = new RealSeedDataImportAdapter().buildRealSeedDataImportPlan(buildSeedDataImportPlan(), context('real'));
  assert(plan.errors.some((error) => error.includes('当前仓库') || error.includes('real')), 'real 模式必须被阻断。');
  assert(plan.steps.every((step) => !step.canExecute), 'real 模式下步骤不得执行。');
});

test('脚本能生成 real-seed-data-import-plan.generated.json', () => {
  ensureSeedImportDryRun();
  const result = generateRealSeedDataImportPlan();
  assert(result.output.plan.mode === 'plan_only', '生成脚本默认应使用 plan_only。');
  assert(result.output.plan.entities.length > 0, '应生成 Seed Data schema draft。');
});

test('真实 Seed Data 校验脚本能通过 plan_only 结果', () => {
  ensureSeedImportDryRun();
  generateRealSeedDataImportPlan();
  const result = validateGeneratedRealSeedDataImportPlan();
  assert(result.passed, `校验脚本应通过：${result.errors.join('；')}`);
});
