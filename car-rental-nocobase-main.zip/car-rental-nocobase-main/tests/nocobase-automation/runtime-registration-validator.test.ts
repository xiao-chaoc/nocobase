import { assert, test } from '../testHarness';
import { contractDocumentsPluginRegistration } from '../../packages/plugins/plugin-contract-documents/src/server/pluginRegistration';
import { iopgpsPluginRegistration } from '../../packages/plugins/plugin-iopgps/src/server/pluginRegistration';
import { rentalCorePluginRegistration } from '../../packages/plugins/plugin-rental-core/src/server/pluginRegistration';
import { buildAutomatedRegistrationPlan, buildRuntimeRegistrationPlanFromAutomatedPlan, validateRuntimeForbiddenPatterns, validateRuntimeRegistrationPlan } from '../../packages/shared/nocobase-automation/src';
import type { RuntimeRegistrationPlan } from '../../packages/shared/nocobase-automation/src';

const runtimePlan = buildRuntimeRegistrationPlanFromAutomatedPlan(buildAutomatedRegistrationPlan([rentalCorePluginRegistration, contractDocumentsPluginRegistration, iopgpsPluginRegistration]));

const expectForbidden = (patch: Partial<RuntimeRegistrationPlan>, text: string) => {
  const result = validateRuntimeForbiddenPatterns({ ...runtimePlan, ...patch });
  assert(!result.passed, `应拒绝：${text}`);
  assert(result.errors.some((error) => error.includes(text) || error.includes('不允许') || error.includes('GPS') || error.includes('押金')), `错误应包含禁止说明：${result.errors.join('；')}`);
};

test('runtime 注册计划通过核心校验', () => {
  const result = validateRuntimeRegistrationPlan(runtimePlan);
  assert(result.passed, `runtime 计划应通过：${result.errors.join('；')}`);
});

test('runtime 校验能拒绝 booking、driver_login 和按车型出租', () => {
  expectForbidden({ notes: ['booking'] }, 'booking');
  expectForbidden({ notes: ['driver_login'] }, 'driver_login');
  expectForbidden({ notes: ['vehicle_category_rental'] }, 'vehicle_category_rental');
});

test('runtime 校验能拒绝 GPS 参与租金计算和押金计入租金已付', () => {
  expectForbidden({ notes: ['GPS 参与租金计算'] }, 'GPS');
  expectForbidden({ notes: ['deposit_as_rent_payment'] }, 'deposit_as_rent_payment');
});
