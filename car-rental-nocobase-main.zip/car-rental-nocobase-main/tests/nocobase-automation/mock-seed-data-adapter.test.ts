declare const require: any;

import { assert, test } from '../testHarness';
import { buildSeedDataImportPlan, MockSeedDataAdapter } from '../../packages/shared/nocobase-automation/src';

const fs = require('fs');
const path = require('path');

const makeRecords = () => ({
  drivers: [{ driver_id: 'D1', driver_no: 'TEST-D1' }],
  vehicles: [{ vehicle_id: 'V1', vehicle_no: 'TEST-V1', plate_no: 'TEST-P1' }],
  gps_devices: [{ device_id: 'G1', imei: 'TEST-I1' }],
  lease_contracts: [{ contract_id: 'C1', contract_no: 'TEST-C1', driver_id: 'D1', vehicle_id: 'V1' }],
  contract_billing_weeks: [{ billing_week_id: 'B1', contract_id: 'C1' }],
  rent_daily_ledgers: [{ ledger_id: 'L1', contract_id: 'C1', driver_id: 'D1', vehicle_id: 'V1', rent_date: '2026-01-01', is_payable: true, due_amount: 100, paid_amount: 100, waived_amount: 0, balance_amount: 0 }],
  rent_payments: [{ payment_id: 'P1', payment_no: 'TEST-PAY1', paid_amount: 100, status: 'confirmed', payment_screenshot: 'TEST_SCREENSHOT' }],
  rent_payment_allocations: [{ allocation_id: 'A1', payment_id: 'P1', ledger_id: 'L1', allocated_amount: 100 }],
  deposit_records: [{ deposit_id: 'DEP1', contract_id: 'C1', required_amount: 1000, received_amount: 1000, deducted_amount: 0, refunded_amount: 0, waived_amount: 0, proof_file: 'TEST_PROOF' }],
  gps_location_snapshots: [{ snapshot_id: 'S1', device_id: 'G1', raw_response: { token: 'TEST_TOKEN' } }],
  gps_daily_mileages: [{ mileage_id: 'M1', device_id: 'G1', mileage_date: '2026-01-01', raw_response: { login_key: 'TEST_LOGIN_KEY' }, remark: 'GPS 不参与租金计算' }],
  contract_documents: [{ document_id: 'DOC1', document_no: 'TEST-DOC1', contract_id: 'C1', signed_scan_file: 'TEST_SCAN' }],
  operation_logs: [{ log_id: 'O1', action: 'TEST_ACTION' }],
});

test('MockSeedDataAdapter 不写数据库并能 dry-run 导入', () => {
  const adapter = new MockSeedDataAdapter();
  const plan = buildSeedDataImportPlan();
  const data = makeRecords();
  const result = adapter.importEntities({ importPlan: plan, dryRun: true, sourceDir: '.test-dist/seed-data', targetEnvironment: 'test', importedBy: 'test', importedAt: '2026-06-03T00:00:00.000Z' }, data as any);
  assert(result.success, result.errors.join('；'));
  assert(result.entityResults[0].steps.join('').includes('不写入数据库'), 'steps 应说明不写数据库。');
});

test('MockSeedDataAdapter 重复唯一键会 skipped', () => {
  const adapter = new MockSeedDataAdapter();
  const entity = buildSeedDataImportPlan().entities.find((item) => item.entityType === 'drivers');
  assert(entity, '应存在 drivers 计划。');
  adapter.importEntity(entity!, [{ driver_no: 'TEST-D1' }]);
  const repeated = adapter.importEntity(entity!, [{ driver_no: 'TEST-D1' }]);
  assert(repeated.skippedRecords === 1, '重复唯一键应跳过。');
});
