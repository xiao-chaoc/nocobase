import { assert, test } from '../testHarness';
import { contractDocumentsPluginRegistration } from '../../packages/plugins/plugin-contract-documents/src/server/pluginRegistration';
import { iopgpsPluginRegistration } from '../../packages/plugins/plugin-iopgps/src/server/pluginRegistration';
import { rentalCorePluginRegistration } from '../../packages/plugins/plugin-rental-core/src/server/pluginRegistration';
import { buildAutomatedRegistrationPlan, buildPageInitializationPlan } from '../../packages/shared/nocobase-automation/src';

const automatedPlan = buildAutomatedRegistrationPlan([rentalCorePluginRegistration, contractDocumentsPluginRegistration, iopgpsPluginRegistration]);
const pagePlan = buildPageInitializationPlan(automatedPlan);
const pageNames = pagePlan.pages.map((page) => page.name);

test('能生成菜单计划', () => {
  assert(pagePlan.menus.length >= 10, '应生成至少十个菜单。');
  assert(pagePlan.menus.some((menu) => menu.title === '仪表盘'), '应包含仪表盘菜单。');
});

test('能生成核心页面计划', () => {
  for (const name of ['driver-list', 'vehicle-list', 'contract-list', 'active-contracts', 'rent-ledger-list', 'rent-calendar', 'payment-list', 'deposit-list', 'contract-documents', 'gps-devices', 'gps-status', 'operation-logs']) {
    assert(pageNames.includes(name), `应生成页面：${name}`);
  }
});

test('页面计划包含筛选器和动作', () => {
  assert(pagePlan.filters.length > 0, '页面计划应包含筛选器。');
  assert(pagePlan.actions.length > 0, '页面计划应包含动作。');
  assert(pagePlan.actions.some((action) => action.name === 'confirm_rent_payment'), '应包含确认付款动作。');
});
