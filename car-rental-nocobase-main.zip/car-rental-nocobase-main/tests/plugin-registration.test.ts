import { assert, assertEqual, test } from './testHarness';
import { contractDocumentsPluginRegistration } from '../packages/plugins/plugin-contract-documents/src/server/pluginRegistration';
import { iopgpsPluginRegistration } from '../packages/plugins/plugin-iopgps/src/server/pluginRegistration';
import { rentalCoreActionRegistry } from '../packages/plugins/plugin-rental-core/src/server/actions/actionRegistry';
import { rentalCorePermissionRegistry } from '../packages/plugins/plugin-rental-core/src/server/permissions/permissionRegistry';
import { rentalCorePluginRegistration } from '../packages/plugins/plugin-rental-core/src/server/pluginRegistration';
import { rentalCoreScheduleRegistry } from '../packages/plugins/plugin-rental-core/src/server/schedules/scheduleRegistry';
import { iopgpsScheduleRegistry } from '../packages/plugins/plugin-iopgps/src/server/schedules/scheduleRegistry';

test('三个插件都有 pluginRegistration 描述', () => {
  assertEqual(rentalCorePluginRegistration.pluginName, 'plugin-rental-core');
  assertEqual(iopgpsPluginRegistration.pluginName, 'plugin-iopgps');
  assertEqual(contractDocumentsPluginRegistration.pluginName, 'plugin-contract-documents');
});

test('插件依赖关系符合边界', () => {
  assertEqual(rentalCorePluginRegistration.dependencies.length, 0);
  assert(iopgpsPluginRegistration.dependencies.includes('plugin-rental-core'));
  assert(contractDocumentsPluginRegistration.dependencies.includes('plugin-rental-core'));
});

test('注册描述包含各插件核心 Collection', () => {
  const rentalCollections = rentalCorePluginRegistration.collections.map((collection) => (collection as { name: string }).name);
  assert(rentalCollections.includes('drivers'));
  assert(rentalCollections.includes('vehicles'));
  assert(rentalCollections.includes('lease_contracts'));
  assert(rentalCollections.includes('rent_daily_ledgers'));
  assert(rentalCollections.includes('rent_payments'));
  assert(rentalCollections.includes('deposit_records'));

  const gpsCollections = iopgpsPluginRegistration.collections.map((collection) => collection.name);
  assert(gpsCollections.includes('gps_devices'));
  assert(gpsCollections.includes('gps_device_bindings'));
  assert(gpsCollections.includes('gps_location_snapshots'));
  assert(gpsCollections.includes('gps_daily_mileages'));
  assert(gpsCollections.includes('gps_device_status_logs'));
  assert(gpsCollections.includes('iopgps_settings'));

  const documentCollections = contractDocumentsPluginRegistration.collections.map((collection) => collection.name);
  assert(documentCollections.includes('contract_templates'));
  assert(documentCollections.includes('contract_documents'));
});

test('rental-core 权限草案包含六个内部角色', () => {
  const roles = rentalCorePermissionRegistry.map((item) => item.role);
  for (const role of ['system_admin', 'manager', 'accountant', 'operator', 'gps_maintenance', 'readonly_auditor']) {
    assert(roles.includes(role as typeof roles[number]), `缺少角色：${role}`);
  }
});

test('定时任务草案不执行真实任务', () => {
  assert(rentalCoreScheduleRegistry.every((item) => item.sideEffects === 'none_in_skeleton'));
  assert(iopgpsScheduleRegistry.every((item) => item.callsRealApi === false && item.writesDatabase === false));
});

test('动作草案不执行真实数据库操作', () => {
  assert(rentalCoreActionRegistry.every((item) => item.sideEffects === 'none_in_skeleton'));
  assert(iopgpsPluginRegistration.actions.every((item) => item.callsRealApi === false && item.writesDatabase === false));
  assert(contractDocumentsPluginRegistration.actions.every((item) => item.writesDatabase === false && item.handlesRealFile === false));
});

test('GPS 和合同文件注册说明保持失败隔离', () => {
  assert(iopgpsPluginRegistration.notes.some((note) => note.includes('GPS 数据不参与租金计算')));
  assert(iopgpsPluginRegistration.notes.some((note) => note.includes('不能影响租金台账和付款')));
  assert(contractDocumentsPluginRegistration.notes.some((note) => note.includes('不处理租金')));
  assert(contractDocumentsPluginRegistration.notes.some((note) => note.includes('不处理付款')));
});
