# 合同文件插件测试 TODO

1. 支持 `zh-CN`、`en-US`、`fr-FR` 三种合同语言。
2. 非法语言报错。
3. 每种语言选择默认 `active` 模板。
4. 没有默认模板时选择同语言最新 `active` 模板。
5. 缺少某语言模板时进入 `missing_templates`。
6. 合同文件生成结果不真实生成 docx/pdf。
7. 文件名不包含司机证件号、手机号等敏感信息。
8. `generated` 状态可以标记为 `printed`。
9. `voided` 文件不能打印。
10. `printed` 状态可以标记为 `signed`。
11. `printed` 或 `signed` 状态可以上传 `signed_scan_file`。
12. `signed_scan_file` 缺失时报错。
13. `scanned` 状态可以由 `signed` 或 `printed` 转入。
14. `scanned` 后不能回退到 `printed`。
15. `voided` 后不能恢复。
16. 作废必须填写原因。
17. 根据合同文件列表推导合同签署状态。
18. `signed_scan_file` 为敏感字段。
19. `generated_docx_file` / `generated_pdf_file` 需要权限控制。
20. 本轮不调用真实 PDF 生成。
