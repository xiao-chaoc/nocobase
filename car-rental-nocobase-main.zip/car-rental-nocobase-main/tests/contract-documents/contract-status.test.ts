import { assertEqual, assertThrows, test } from '../testHarness';
import { canTransitionContractDocumentStatus, getContractSignatureStatusFromDocuments } from '../../packages/plugins/plugin-contract-documents/src/server/services/contractDocumentStatusService';
import { markContractPrinted } from '../../packages/plugins/plugin-contract-documents/src/server/services/contractPrintService';
import { markContractSigned, uploadSignedContractScan, voidContractDocument } from '../../packages/plugins/plugin-contract-documents/src/server/services/contractScanService';

function doc(status: any = 'generated') {
  return { document_id: 'doc1', document_no: 'DOC1', contract_id: 'c1', template_id: 'tpl1', language: 'zh-CN', status, created_at: '2026-06-01', updated_at: '2026-06-01' } as any;
}

test('合同文件允许的状态流转正确', () => {
  assertEqual(canTransitionContractDocumentStatus('draft', 'generated'), true);
  assertEqual(canTransitionContractDocumentStatus('generated', 'printed'), true);
  assertEqual(canTransitionContractDocumentStatus('printed', 'signed'), true);
  assertEqual(canTransitionContractDocumentStatus('printed', 'scanned'), true);
  assertEqual(canTransitionContractDocumentStatus('signed', 'scanned'), true);
  assertEqual(canTransitionContractDocumentStatus('generated', 'voided'), true);
  assertEqual(canTransitionContractDocumentStatus('voided', 'generated'), false);
  assertEqual(canTransitionContractDocumentStatus('scanned', 'printed'), false);
});

test('打印、签署、扫描件上传和作废校验符合状态规则', () => {
  const printed = markContractPrinted(doc('generated'), { document_id: 'doc1', printed_by: 'u1', printed_at: '2026-06-01T10:00:00Z' });
  assertEqual(printed.status, 'printed');
  const signed = markContractSigned(printed, '2026-06-01T11:00:00Z', 'u1');
  assertEqual(signed.status, 'signed');
  const scanned = uploadSignedContractScan(signed, { document_id: 'doc1', signed_scan_file: 'scan.pdf', signed_at: '2026-06-01T12:00:00Z', uploaded_by: 'u1' });
  assertEqual(scanned.status, 'scanned');
  assertThrows(() => markContractPrinted(scanned, { document_id: 'doc1', printed_by: 'u1', printed_at: '2026-06-01T13:00:00Z' }), 'contract_document_status_transition_invalid');
  assertThrows(() => voidContractDocument(doc('generated'), { document_id: 'doc1', reason: '', voided_by: 'u1', voided_at: '2026-06-01T13:00:00Z' }), 'contract_void_reason_required');
  const voided = voidContractDocument(doc('generated'), { document_id: 'doc1', reason: '作废', voided_by: 'u1', voided_at: '2026-06-01T13:00:00Z' });
  assertEqual(voided.status, 'voided');
});

test('根据合同文件列表推导合同签署状态', () => {
  assertEqual(getContractSignatureStatusFromDocuments([]), 'not_generated');
  assertEqual(getContractSignatureStatusFromDocuments([doc('generated')]), 'generated');
  assertEqual(getContractSignatureStatusFromDocuments([doc('printed')]), 'printed');
  assertEqual(getContractSignatureStatusFromDocuments([doc('signed')]), 'signed');
  assertEqual(getContractSignatureStatusFromDocuments([doc('scanned')]), 'scanned');
  assertEqual(getContractSignatureStatusFromDocuments([doc('voided')]), 'voided');
});
