import { assert, assertEqual, assertThrows, test } from '../testHarness';
import { buildContractDocumentFileName, generateContractDocuments, validateContractDocument } from '../../packages/plugins/plugin-contract-documents/src/server/services/contractDocumentService';
import { getContractTemplateByLanguage, selectTemplatesForLanguages, validateContractLanguage } from '../../packages/plugins/plugin-contract-documents/src/server/services/contractTemplateService';

function template(language: 'zh-CN' | 'en-US' | 'fr-FR', version: string, is_default = false) {
  return { template_id: `${language}-${version}`, template_no: `TPL-${language}-${version}`, name: `模板 ${language}`, language, version, template_file: `${language}.docx`, is_default, status: 'active', created_at: '2026-06-01', updated_at: '2026-06-01' } as any;
}
const templates = [template('zh-CN', '1.0.0', true), template('en-US', '1.0.0'), template('en-US', '2.0.0'), template('fr-FR', '1.0.0', true)];

test('支持三种合同语言并拒绝非法语言', () => {
  validateContractLanguage('zh-CN');
  validateContractLanguage('en-US');
  validateContractLanguage('fr-FR');
  assertThrows(() => validateContractLanguage('es-ES'), 'contract_language_invalid');
});

test('每种语言选择默认 active 模板；无默认时选择同语言最新 active 模板', () => {
  assertEqual(getContractTemplateByLanguage(templates, 'zh-CN')?.template_id, 'zh-CN-1.0.0');
  assertEqual(getContractTemplateByLanguage(templates, 'en-US')?.template_id, 'en-US-2.0.0');
  const selected = selectTemplatesForLanguages(templates, ['zh-CN', 'fr-FR']);
  assertEqual(selected.selected_templates.length, 2);
});

test('缺少模板进入 missing_templates，生成结果不真实生成 docx/pdf', () => {
  const result = generateContractDocuments({ contract_id: 'c1', languages: ['zh-CN', 'en-US', 'fr-FR'], contract_data: { contract: { contract_no: 'CTR202606010001' } }, requested_by: 'u1', requested_at: '2026-06-01T10:00:00Z' }, [templates[0], templates[1]]);
  assert(result.missing_templates.includes('fr-FR'));
  assertEqual(result.documents[0].status, 'generated');
  assertEqual(result.documents[0].generated_docx_file, undefined as any);
  assertEqual(result.documents[0].generated_pdf_file, undefined as any);
});

test('合同文件名不包含司机证件号、手机号等敏感信息，合同文件敏感字段需权限控制', () => {
  const filename = buildContractDocumentFileName({ contract_no: 'CTR202606010001', id_no: 'ID123', phone: '13800000000' } as any, 'zh-CN', 'pdf');
  assertEqual(filename, 'CTR202606010001.zh-CN.pdf');
  assert(!filename.includes('ID123'));
  assert(!filename.includes('13800000000'));
  const document: any = { document_id: 'doc1', document_no: 'DOC1', contract_id: 'c1', template_id: 'tpl1', language: 'zh-CN', status: 'scanned', signed_scan_file: 'scan.pdf', generated_docx_file: 'contract.docx', generated_pdf_file: 'contract.pdf', created_at: '2026-06-01', updated_at: '2026-06-01' };
  validateContractDocument(document);
  assert('signed_scan_file' in document);
  assert('generated_docx_file' in document);
  assert('generated_pdf_file' in document);
});
