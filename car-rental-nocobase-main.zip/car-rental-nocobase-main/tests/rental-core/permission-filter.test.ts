import { assert, assertEqual, test } from '../testHarness';
import { canViewCalendarField, filterCalendarSensitiveData, getCalendarFieldVisibility } from '../../packages/plugins/plugin-rental-core/src/server/services/permissionFilterService';

const data: any = {
  summary: { driver_id: 'd1', contract_ids: ['c1'], vehicle_ids: ['v1'], total_paid_amount: 100, current_debt_amount: 80, current_debt_days: 1, future_receivable_amount: 200, deposit_required_amount: 500, deposit_received_amount: 300, total_waived_amount: 0, payable_days_count: 1, paid_days_count: 0, unpaid_days_count: 1, waived_days_count: 0, non_payable_days_count: 0, dispute_amount: 0, dispute_days: 0 },
  days: [{ ledger_id: 'l1', contract_id: 'c1', driver_id: 'd1', vehicle_id: 'v1', rent_date: '2026-06-01', is_payable: true, due_amount: 100, paid_amount: 20, waived_amount: 0, balance_amount: 80, payment_status: 'partial', unpaid_reason: 'waiting_for_payment', shortfall_disposition: 'debt', calendar_status: 'partial_debt', payment_screenshot: 'pay.png', payment_method: 'cash', driver_id_no: 'ID123', driver_id_files: ['id.png'], driver_license_files: ['license.png'] }],
  hidden_fields: [],
  visible_fields: {},
};

test('不同角色的日历敏感字段可见性符合默认规则', () => {
  assertEqual(getCalendarFieldVisibility({ user_id: 'u1', roles: ['system_admin'] }).can_view_all_sensitive_fields, true);
  assertEqual(canViewCalendarField({ user_id: 'u2', roles: ['manager'] }, 'current_debt_amount'), true);
  assertEqual(canViewCalendarField({ user_id: 'u3', roles: ['accountant'] }, 'payment_screenshot'), true);
  assertEqual(canViewCalendarField({ user_id: 'u3', roles: ['accountant'] }, 'payment_method'), true);
  assertEqual(canViewCalendarField({ user_id: 'u4', roles: ['operator'] }, 'total_paid_amount'), false);
  assertEqual(canViewCalendarField({ user_id: 'u5', roles: ['gps_maintenance'] }, 'current_debt_amount'), false);
  assertEqual(canViewCalendarField({ user_id: 'u6', roles: ['readonly_auditor'] }, 'future_receivable_amount'), false);
});

test('无权限字段被置为 null，hidden_fields 记录隐藏字段，日历状态保留且证件字段不外泄', () => {
  const result = filterCalendarSensitiveData(data, { user_id: 'operator1', roles: ['operator'] }).data;
  assertEqual(result.summary.total_paid_amount, null as any);
  assertEqual(result.summary.future_receivable_amount, null as any);
  assertEqual(result.summary.deposit_required_amount, null as any);
  assertEqual(result.days[0].payment_screenshot, null as any);
  assertEqual(result.days[0].calendar_status, 'partial_debt');
  assert(result.hidden_fields.includes('total_paid_amount'));
  assert(result.hidden_fields.includes('payment_screenshot'));
  assertEqual((result.days[0] as any).driver_id_no, null);
  assertEqual((result.days[0] as any).driver_id_files, null);
  assertEqual((result.days[0] as any).driver_license_files, null);
});
