import { assertEqual, assertThrows, test } from '../testHarness';
import { createDepositRecord, deductDeposit, getDepositAvailableAmount, refundDeposit, waiveDeposit } from '../../packages/plugins/plugin-rental-core/src/server/services/depositService';
import { refreshContractFinancialSummary } from '../../packages/plugins/plugin-rental-core/src/server/services/summaryService';

function create(required_amount: number, received_amount: number) {
  return createDepositRecord({ contract_id: 'c1', driver_id: 'd1', vehicle_id: 'v1', required_amount, received_amount, method: 'cash', screenshot_file: 'deposit.png', received_at: '2026-06-01', received_by: 'u1' }).deposit;
}

test('创建未收、已收足、部分收取押金并校验金额边界', () => {
  assertEqual(create(500, 0).status, 'pending');
  assertEqual(create(500, 500).status, 'held');
  assertEqual(create(500, 300).status, 'collected');
  assertThrows(() => create(500, 600), 'deposit_received_exceeds_required');
  assertThrows(() => create(-1, 0), 'deposit_required_amount_invalid');
});

test('押金 available_amount、抵扣、退款和免除规则正确', () => {
  const dep = create(500, 500);
  assertEqual(getDepositAvailableAmount(dep), 500);
  assertThrows(() => deductDeposit(dep, { deposit_id: dep.deposit_id, amount: 600, reason: '超额', deducted_by: 'u1', deducted_at: '2026-06-02', target_type: 'damage' }), 'deposit_deduct_amount_exceeds_available');
  assertThrows(() => refundDeposit(dep, { deposit_id: dep.deposit_id, amount: 600, reason: '超额', refunded_by: 'u1', refunded_at: '2026-06-02', method: 'cash' }), 'deposit_refund_amount_exceeds_available');
  const deducted = deductDeposit(dep, { deposit_id: dep.deposit_id, amount: 100, reason: '维修', deducted_by: 'u1', deducted_at: '2026-06-02', target_type: 'repair' }).deposit;
  assertEqual(deducted.status, 'partially_deducted');
  const deductedAll = deductDeposit(dep, { deposit_id: dep.deposit_id, amount: 500, reason: '损伤', deducted_by: 'u1', deducted_at: '2026-06-02', target_type: 'damage' }).deposit;
  assertEqual(deductedAll.status, 'deducted');
  const refunded = refundDeposit(dep, { deposit_id: dep.deposit_id, amount: 100, reason: '退还', refunded_by: 'u1', refunded_at: '2026-06-03', method: 'cash', proof_file: 'refund.png' }).deposit;
  assertEqual(refunded.status, 'partially_refunded');
  const refundedAll = refundDeposit(dep, { deposit_id: dep.deposit_id, amount: 500, reason: '退还', refunded_by: 'u1', refunded_at: '2026-06-03', method: 'cash' }).deposit;
  assertEqual(refundedAll.status, 'refunded');
  assertThrows(() => deductDeposit(dep, { deposit_id: dep.deposit_id, amount: 1, reason: '', deducted_by: 'u1', deducted_at: '2026-06-02', target_type: 'other' }), 'deposit_reason_required');
  assertThrows(() => refundDeposit(dep, { deposit_id: dep.deposit_id, amount: 1, reason: '', refunded_by: 'u1', refunded_at: '2026-06-02' }), 'deposit_reason_required');
  assertThrows(() => waiveDeposit(dep, { deposit_id: dep.deposit_id, amount: 1, reason: '免除', approved_by: '', approved_at: '2026-06-02' }), 'deposit_approved_by_required');
});

test('押金敏感字段不计入租金 total_paid_amount 或每日租金收入', () => {
  const dep = create(500, 500);
  assertEqual(dep.screenshot_file, 'deposit.png' as any);
  const summary = refreshContractFinancialSummary({ contract_id: 'c1', driver_id: 'd1', vehicle_id: 'v1' }, [], [dep], '2026-06-01');
  assertEqual(summary.deposit_received_amount, 500);
  assertEqual(summary.total_paid_amount, 0);
  assertEqual(summary.total_due_amount, 0);
});
