import { assert, assertEqual, test } from '../testHarness';
import { getDriverCalendarData } from '../../packages/plugins/plugin-rental-core/src/server/services/calendarDataService';
import { refreshContractFinancialSummary, refreshDriverCalendarSummary } from '../../packages/plugins/plugin-rental-core/src/server/services/summaryService';

function ledger(overrides: Record<string, unknown> = {}) {
  return { ledger_id: 'l', contract_id: 'c1', driver_id: 'd1', vehicle_id: 'v1', rent_date: '2026-06-01', is_payable: true, due_amount: 100, paid_amount: 0, waived_amount: 0, balance_amount: 100, payment_status: 'unpaid', unpaid_reason: 'waiting_for_payment', shortfall_disposition: 'debt', calendar_status: 'unpaid_debt', status: 'active', ...overrides } as any;
}
const contract = { contract_id: 'c1', driver_id: 'd1', vehicle_id: 'v1' } as any;
const deposit = { deposit_id: 'dep1', deposit_no: 'DEP1', contract_id: 'c1', driver_id: 'd1', vehicle_id: 'v1', required_amount: 500, received_amount: 300, deducted_amount: 0, refunded_amount: 0, waived_amount: 0, available_amount: 300, status: 'held' } as any;

test('合同汇总区分当前欠款、未来应收、免租日、取消日、争议和押金', () => {
  const ledgers = [
    ledger({ ledger_id: 'current', rent_date: '2026-06-01', balance_amount: 100 }),
    ledger({ ledger_id: 'future', rent_date: '2026-06-10', balance_amount: 100, calendar_status: 'future_receivable' }),
    ledger({ ledger_id: 'free', rent_date: '2026-06-02', is_payable: false, due_amount: 0, balance_amount: 0, calendar_status: 'non_payable', payment_status: 'non_payable' }),
    ledger({ ledger_id: 'cancelled', status: 'cancelled', due_amount: 100, balance_amount: 100 }),
    ledger({ ledger_id: 'waived', rent_date: '2026-06-03', waived_amount: 100, balance_amount: 0, payment_status: 'waived', calendar_status: 'waived', shortfall_disposition: 'waived' }),
    ledger({ ledger_id: 'pending', rent_date: '2026-06-04', balance_amount: 80, shortfall_disposition: 'pending_waiver_approval', calendar_status: 'unpaid_debt' }),
    ledger({ ledger_id: 'dispute', rent_date: '2026-06-05', balance_amount: 70, shortfall_disposition: 'dispute', calendar_status: 'dispute' }),
    ledger({ ledger_id: 'paid', rent_date: '2026-06-06', paid_amount: 100, balance_amount: 0, payment_status: 'paid', calendar_status: 'paid' }),
  ];
  const summary = refreshContractFinancialSummary(contract, ledgers, [deposit], '2026-06-06');
  assertEqual(summary.current_debt_amount, 180);
  assertEqual(summary.current_debt_days, 2);
  assertEqual(summary.future_receivable_amount, 100);
  assertEqual(summary.dispute_amount, 70);
  assertEqual(summary.dispute_days, 1);
  assertEqual(summary.total_paid_amount, 100);
  assertEqual(summary.deposit_required_amount, 500);
  assertEqual(summary.deposit_received_amount, 300);
  assertEqual(summary.total_paid_amount, 100, '押金不能计入租金已付金额');
});

test('司机日历汇总和 debt_only 只返回指定司机截至当前日期的欠款', () => {
  const contracts = [contract, { contract_id: 'c2', driver_id: 'd2', vehicle_id: 'v2' } as any];
  const ledgers = [ledger({ ledger_id: 'd1old', rent_date: '2026-06-01' }), ledger({ ledger_id: 'd1future', rent_date: '2026-06-10', calendar_status: 'future_receivable' }), ledger({ ledger_id: 'd2old', driver_id: 'd2', contract_id: 'c2', vehicle_id: 'v2' })];
  const summary = refreshDriverCalendarSummary('d1', contracts, ledgers, [deposit], { fromDate: '2026-06-01', toDate: '2026-06-30' }, '2026-06-05');
  assertEqual(summary.current_debt_amount, 100);
  assertEqual(summary.future_receivable_amount, 100);
  const data = getDriverCalendarData({ driver_id: 'd1', contracts, ledgers, deposits: [deposit], date_range: { fromDate: '2026-06-01', toDate: '2026-06-30' }, current_user: { user_id: 'u1', roles: ['system_admin'] }, today: '2026-06-05', filters: { debt_only: true } });
  assertEqual(data.days.length, 1);
  assertEqual(data.days[0].ledger_id, 'd1old');
  assert(!data.days.some((day) => day.rent_date > '2026-06-05'), 'debt_only 不返回未来应收');
});
