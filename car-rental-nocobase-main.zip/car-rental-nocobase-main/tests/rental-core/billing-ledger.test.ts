import { assert, assertEqual, assertThrows, test } from '../testHarness';
import { validateDefaultFreeWeekdays, validateWeeklyPayableDays } from '../../packages/plugins/plugin-rental-core/src/server/services/billingRuleService';
import { calculateFixedTermEndDate } from '../../packages/plugins/plugin-rental-core/src/server/services/dateBillingUtils';
import { buildDailyLedgerForDate, generateFixedTermDailyLedgerPreview, generateOpenEndedDailyLedgerPreview, summarizeLedgerPreview } from '../../packages/plugins/plugin-rental-core/src/server/services/ledgerGenerationService';
import { refreshLedgerPaymentStatus } from '../../packages/plugins/plugin-rental-core/src/server/services/ledgerStatusService';

function contract(overrides: Record<string, unknown> = {}) {
  return {
    contract_id: 'c1',
    driver_id: 'd1',
    vehicle_id: 'v1',
    contract_type: 'fixed_term',
    start_date: '2026-06-01',
    term_months: 6,
    weekly_payable_days: 5,
    default_free_weekdays: ['sat', 'sun'],
    daily_rent_amount: 100,
    week_start_day: 'monday',
    ...overrides,
  } as any;
}

test('周付天数与默认免租日规则符合业务约束', () => {
  validateWeeklyPayableDays(5);
  validateDefaultFreeWeekdays(5, ['sat', 'sun']);
  validateDefaultFreeWeekdays(7, []);
  validateDefaultFreeWeekdays(3, ['mon', 'tue', 'wed', 'thu']);
  assertThrows(() => validateDefaultFreeWeekdays(5, ['sun']), 'default_free_weekdays_invalid');
  assertThrows(() => validateDefaultFreeWeekdays(5, ['sun', 'sun']), 'default_free_weekdays_invalid');
  assertThrows(() => validateDefaultFreeWeekdays(5, ['sun', 'bad']), 'default_free_weekdays_invalid');
});

test('时限合同 6 个月按自然月计算结束日期并一次性生成完整台账', () => {
  assertEqual(calculateFixedTermEndDate('2026-06-01', 6), '2026-11-30');
  assertEqual(calculateFixedTermEndDate('2026-01-15', 6), '2026-07-14');
  const preview = generateFixedTermDailyLedgerPreview(contract(), '2026-06-02');
  assertEqual(preview.ledgers[0].rent_date, '2026-06-01');
  assertEqual(preview.ledgers.at(-1)?.rent_date, '2026-11-30');
  assert(preview.ledgers.length > 180, '6 个月合同应一次性生成完整周期台账');
});

test('应收日、免租日、未来应收和到期欠款状态正确', () => {
  const payable = buildDailyLedgerForDate(contract(), '2026-06-01', '2026-06-02');
  const free = buildDailyLedgerForDate(contract(), '2026-06-07', '2026-06-02');
  const future = buildDailyLedgerForDate(contract(), '2026-06-08', '2026-06-02');
  assertEqual(payable.due_amount, 100);
  assertEqual(payable.calendar_status, 'unpaid_debt');
  assertEqual(free.due_amount, 0);
  assertEqual(free.calendar_status, 'non_payable');
  assertEqual(future.calendar_status, 'future_receivable');
  const refreshed = refreshLedgerPaymentStatus(payable, '2026-06-02');
  assertEqual(refreshed.calendar_status, 'unpaid_debt');
});

test('长租合同按 horizonDays 生成未来台账且不超过终止日', () => {
  const open = contract({ contract_type: 'open_ended', term_months: undefined, start_date: '2026-06-01', termination_date: '2026-06-05' });
  const preview = generateOpenEndedDailyLedgerPreview(open, '2026-06-01', 30, '2026-06-01');
  assertEqual(preview.ledgers.at(-1)?.rent_date, '2026-06-05');
  assert(!preview.ledgers.some((ledger) => ledger.rent_date > '2026-06-05'), '不应生成终止日之后台账');
});

test('未来应收和免租日不计入当前欠款，也不生成短租订单字段', () => {
  const ledgers = [
    buildDailyLedgerForDate(contract(), '2026-06-01', '2026-06-02'),
    buildDailyLedgerForDate(contract(), '2026-06-07', '2026-06-02'),
    buildDailyLedgerForDate(contract(), '2026-06-08', '2026-06-02'),
  ];
  const summary = summarizeLedgerPreview(ledgers, '2026-06-02');
  assertEqual(summary.current_debt_amount, 100);
  assertEqual(summary.current_debt_days, 1);
  assertEqual(summary.future_receivable_amount, 100);
  assertEqual(summary.non_payable_days_count, 1);
  assert(!('booking_id' in ledgers[0]), '每日台账不应包含短租订单或预订逻辑');
});
