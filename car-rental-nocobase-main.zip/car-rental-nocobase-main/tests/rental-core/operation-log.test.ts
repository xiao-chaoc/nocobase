import { assert, assertEqual, assertThrows, test } from '../testHarness';
import { buildOperationLogForChange, maskSensitiveLogValue, recordOperationLog } from '../../packages/plugins/plugin-rental-core/src/server/services/operationLogService';

test('operation log 必须包含 operator、action、target 和必要原因', () => {
  assertThrows(() => recordOperationLog({ operator_id: '', action: 'deposit_deducted', target_collection: 'deposit_records', target_id: 'd1', reason: '抵扣' } as any), 'operation_operator_required');
  assertThrows(() => recordOperationLog({ operator_id: 'u1', action: 'deposit_deducted', target_collection: '', target_id: 'd1', reason: '抵扣' } as any), 'operation_target_required');
  assertThrows(() => recordOperationLog({ operator_id: 'u1', action: 'deposit_deducted', target_collection: 'deposit_records', target_id: 'd1', before_value: { amount: 1 } } as any), 'operation_reason_required');
  const log = recordOperationLog({ operator_id: 'u1', action: 'payment_reversed', target_collection: 'rent_payments', target_id: 'p1', reason: '录入错误' });
  assertEqual(log.operator_id, 'u1');
  assertEqual(log.action, 'payment_reversed');
});

test('operation log 对证件、截图、token、login_key 等敏感字段递归脱敏', () => {
  const masked = maskSensitiveLogValue({ id_no: '完整证件号', screenshot_file: 'https://real-file', access_token: 'token', login_key_encrypted: 'login_key', nested: { proof_file: 'refund.png' } }) as any;
  assertEqual(masked.id_no, '[已隐藏]');
  assertEqual(masked.screenshot_file, '[已隐藏]');
  assertEqual(masked.access_token, '[已隐藏]');
  assertEqual(masked.login_key_encrypted, '[已隐藏]');
  assertEqual(masked.nested.proof_file, '[已隐藏]');
});

test('关键动作可记录且变更日志不记录敏感原文', () => {
  for (const action of ['payment_reversed', 'waiver_approved', 'deposit_deducted', 'deposit_refunded'] as const) {
    const log = buildOperationLogForChange({ operator_id: 'u1', action, target_collection: 'target', target_id: action, before_value: { screenshot_file: 'secret.png' }, after_value: { id_no: 'ID' }, reason: '测试原因' });
    assertEqual((log.before_value as any).screenshot_file, '[已隐藏]');
    assertEqual((log.after_value as any).id_no, '[已隐藏]');
    assert(log.log_no.includes(action.toUpperCase()));
  }
});
