# 敏感字段权限过滤测试 TODO

1. `system_admin` 可见所有敏感字段。
2. `manager` 可见财务汇总、欠款、未来应收、押金和付款截图。
3. `accountant` 可见付款截图和付款方式。
4. `operator` 默认看不到总已付、未来应收、押金、付款截图、付款方式和日级金额字段。
5. `gps_maintenance` 看不到财务汇总、付款截图和付款方式。
6. `readonly_auditor` 默认隐藏敏感财务字段。
7. `current_user.permissions` 可以显式开放或拒绝敏感字段。
8. 无权限字段被置为 `null`，并记录到 `hidden_fields`。
9. `calendar_status` 保留可见，方便运营判断每日状态。
10. 司机证件号、证件照片、驾照照片不应出现在日历输出；若上游误传也必须置空。
