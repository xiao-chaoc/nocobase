import { assert, assertEqual, assertThrows, test } from '../testHarness';
import { allocateRentPayment, createRentPaymentDraft, validateNoOverpayment, validatePaymentAllocations } from '../../packages/plugins/plugin-rental-core/src/server/services/paymentAllocationService';
import { markShortfallAsDebt, markShortfallAsDispute, markShortfallAsPendingWaiver } from '../../packages/plugins/plugin-rental-core/src/server/services/shortfallService';
import { markUnpaidReason } from '../../packages/plugins/plugin-rental-core/src/server/services/unpaidReasonService';
import { approveRentWaiver, rejectRentWaiver, requestRentWaiver } from '../../packages/plugins/plugin-rental-core/src/server/services/waiverService';
import { reverseRentPayment } from '../../packages/plugins/plugin-rental-core/src/server/services/paymentReversalService';

function ledger(overrides: Record<string, unknown> = {}) {
  return {
    ledger_id: 'l1', contract_id: 'c1', driver_id: 'd1', vehicle_id: 'v1', rent_date: '2026-06-01',
    is_payable: true, due_amount: 100, paid_amount: 0, waived_amount: 0, balance_amount: 100,
    payment_status: 'unpaid', unpaid_reason: 'waiting_for_payment', shortfall_disposition: 'none', calendar_status: 'unpaid_debt', status: 'active',
    ...overrides,
  } as any;
}
function payment(amount: number, allocations: any[] = [{ ledger_id: 'l1', allocated_amount: amount }]) {
  return createRentPaymentDraft({ driver_id: 'd1', contract_id: 'c1', vehicle_id: 'v1', payment_date: '2026-06-01', paid_at: '2026-06-01T10:00:00Z', amount, method: 'cash', received_by: 'u1', allocations });
}

test('付款草稿要求金额大于 0 且 allocations 不能为空', () => {
  assertEqual(payment(100).status, 'draft');
  assertThrows(() => payment(0, [{ ledger_id: 'l1', allocated_amount: 1 }]), 'payment_amount_invalid');
  assertThrows(() => payment(100, []), 'payment_allocations_required');
});

test('一笔付款可支付一个或多个日期，金额必须等于分配合计', () => {
  const ledgers = [ledger(), ledger({ ledger_id: 'l2', rent_date: '2026-06-02' })];
  const one = allocateRentPayment(payment(100), ledgers, [{ ledger_id: 'l1', allocated_amount: 100 }], '2026-06-02');
  assertEqual(one.payment.status, 'confirmed');
  assertEqual(one.ledgers[0].paid_amount, 100);
  const multiPayment = payment(150, [{ ledger_id: 'l1', allocated_amount: 100 }, { ledger_id: 'l2', allocated_amount: 50 }]);
  const multi = allocateRentPayment(multiPayment, ledgers, [{ ledger_id: 'l1', allocated_amount: 100 }, { ledger_id: 'l2', allocated_amount: 50 }], '2026-06-02');
  assertEqual(multi.allocations.length, 2);
  assertThrows(() => validatePaymentAllocations(payment(100), ledgers, [{ ledger_id: 'l1', allocated_amount: 50 }]), 'payment_allocation_amount_mismatch');
});

test('付款分配拒绝非法金额、免租日、取消日期和合同/司机/车辆不匹配', () => {
  assertThrows(() => validatePaymentAllocations(payment(100), [ledger()], [{ ledger_id: 'l1', allocated_amount: 0 }]), 'payment_allocation_amount_invalid');
  assertThrows(() => validatePaymentAllocations(payment(100), [ledger()], [{ ledger_id: 'l1', allocated_amount: -1 }]), 'payment_allocation_amount_invalid');
  assertThrows(() => validatePaymentAllocations(payment(100), [ledger({ is_payable: false, due_amount: 0, balance_amount: 0 })], [{ ledger_id: 'l1', allocated_amount: 100 }]), 'payment_ledger_not_payable');
  assertThrows(() => validatePaymentAllocations(payment(100), [ledger({ status: 'cancelled' })], [{ ledger_id: 'l1', allocated_amount: 100 }]), 'payment_ledger_cancelled');
  assertThrows(() => validatePaymentAllocations(payment(100), [ledger({ contract_id: 'c2' })], [{ ledger_id: 'l1', allocated_amount: 100 }]), 'payment_contract_mismatch');
  assertThrows(() => validatePaymentAllocations(payment(100), [ledger({ driver_id: 'd2' })], [{ ledger_id: 'l1', allocated_amount: 100 }]), 'payment_driver_mismatch');
  assertThrows(() => validatePaymentAllocations(payment(100), [ledger({ vehicle_id: 'v2' })], [{ ledger_id: 'l1', allocated_amount: 100 }]), 'payment_vehicle_mismatch');
});

test('单日不可超付，已付金额和免除金额会减少可收金额且不生成预收款', () => {
  assertEqual(validateNoOverpayment(ledger({ paid_amount: 40, waived_amount: 10 }), 50).remaining_collectable_amount, 50);
  assertThrows(() => validateNoOverpayment(ledger(), 101), 'ledger_overpaid');
  assertThrows(() => validateNoOverpayment(ledger({ paid_amount: 100, balance_amount: 0 }), 1), 'ledger_overpaid');
  const ledgers = [ledger(), ledger({ ledger_id: 'l2', rent_date: '2026-06-02' })];
  assertThrows(() => allocateRentPayment(payment(150, [{ ledger_id: 'l1', allocated_amount: 150 }]), ledgers, [{ ledger_id: 'l1', allocated_amount: 150 }], '2026-06-02'), 'ledger_overpaid');
  assertEqual(ledgers[0].paid_amount, 0);
});

test('部分付款后可标记欠款、争议、待免除审批和未付原因', () => {
  const result = allocateRentPayment(payment(40), [ledger()], [{ ledger_id: 'l1', allocated_amount: 40 }], '2026-06-02');
  const partial = result.ledgers[0];
  const debt = markShortfallAsDebt(partial, '承诺补缴', '2026-06-02');
  assertEqual(debt.calendar_status, 'partial_debt');
  assertEqual(markShortfallAsDispute(partial, '金额争议', '2026-06-02').calendar_status, 'dispute');
  assertEqual(markShortfallAsPendingWaiver(partial, '申请免除', '2026-06-02').shortfall_disposition, 'pending_waiver_approval');
  assertThrows(() => markUnpaidReason(partial, 'none'), 'unpaid_reason_required');
  assertEqual(markUnpaidReason(partial, 'dispute').shortfall_disposition, 'dispute');
});

test('免除申请、审批、拒绝与冲正规则正确', () => {
  const base = ledger({ paid_amount: 40, balance_amount: 60, payment_status: 'partial' });
  const requested = requestRentWaiver(base, 60, '经理审批', 'u1');
  assertEqual(requested.ledger.waived_amount, 0);
  const approved = approveRentWaiver(requested.ledger, requested.waiverRequest, 'manager1', '2026-06-02');
  assertEqual(approved.ledger.waived_amount, 60);
  assertEqual(approved.ledger.balance_amount, 0);
  assertThrows(() => requestRentWaiver(base, 61, '过大', 'u1'), 'waiver_amount_exceeds_balance');
  assertEqual(rejectRentWaiver(base, requestRentWaiver(base, 10, '申请', 'u1').waiverRequest, 'manager1', '拒绝').waiverRequest.status, 'rejected');

  const paid = allocateRentPayment(payment(100), [ledger()], [{ ledger_id: 'l1', allocated_amount: 100 }], '2026-06-02');
  const reversed = reverseRentPayment(paid.payment, paid.ledgers, paid.allocations, '录入错误', '2026-06-03');
  assertEqual(reversed.payment.status, 'reversed');
  assertEqual(reversed.ledgers[0].paid_amount, 0);
  assertThrows(() => reverseRentPayment(paid.payment, [ledger({ paid_amount: 0 })], paid.allocations, '录入错误', '2026-06-03'), 'payment_reversal_paid_amount_negative');
});
