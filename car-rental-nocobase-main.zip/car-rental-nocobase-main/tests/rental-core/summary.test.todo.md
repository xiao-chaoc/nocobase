# 合同财务汇总与司机日历汇总测试 TODO

1. 当前欠款只统计 `rent_date <= today`。
2. 未来应收不计入当前欠款。
3. 免租日不计入应收。
4. 已取消台账不计入汇总。
5. 已免除金额不计入欠款。
6. `pending_waiver_approval` 默认仍计入当前欠款。
7. `dispute` 默认单独统计，不计入当前欠款。
8. `total_paid_amount` 正确汇总 `paid_amount`。
9. `future_receivable_amount` 正确汇总未来应收。
10. `current_debt_days` 正确统计截至当前日期的欠款天数。
11. `deposit_required_amount` 和 `deposit_received_amount` 从押金记录汇总。
12. 押金不计入租金收入。
13. 司机日历只返回指定司机数据。
14. `debt_only` 只返回截至当前日期的欠款日期。
15. `debt_only` 不返回未来应收。
