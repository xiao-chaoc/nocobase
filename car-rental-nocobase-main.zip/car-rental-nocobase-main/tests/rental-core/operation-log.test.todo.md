# 操作日志服务测试 TODO

1. operation log 必须包含 operator、action、target。
2. operation log 的 action 必须来自允许枚举。
3. 付款冲正、免除审批、押金抵扣、押金退款等关键动作必须填写原因。
4. operation log 对敏感字段脱敏。
5. operation log 不记录完整证件号、截图 URL、退款凭据、合同扫描件、密钥或 token。
6. `maskSensitiveLogValue` 能递归处理对象。
7. `maskSensitiveLogValue` 能递归处理数组。
8. `buildOperationLogForChange` 自动对 before/after 值脱敏。
9. GPS 同步异常日志不能影响租金台账和付款逻辑。
10. 后续真实落库时，业务变更和日志写入必须处于同一服务端事务。
