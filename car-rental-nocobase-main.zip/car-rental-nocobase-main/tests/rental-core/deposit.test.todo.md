# 押金服务测试 TODO

1. 创建未收押金记录。
2. 创建已收足押金记录。
3. 创建部分收取押金记录。
4. `received_amount` 不能大于 `required_amount`。
5. `required_amount` 不能为负数。
6. 押金 `available_amount` 计算正确。
7. 押金抵扣金额不能超过 `available_amount`。
8. 押金退款金额不能超过 `available_amount`。
9. 押金抵扣后状态变为 `partially_deducted` 或 `deducted`。
10. 押金退款后状态变为 `partially_refunded` 或 `refunded`。
11. 押金不能计入 `total_paid_amount`。
12. 押金不能计入每日租金收入。
13. 押金截图和退款凭据为敏感字段。
14. 押金抵扣需要原因。
15. 押金退款需要原因。
16. 押金免除需要审批人。
