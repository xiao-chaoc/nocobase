import { assertEqual, test } from '../testHarness';
import { buildIopgpsErrorLog, maskIopgpsSensitiveValue, safeIopgpsSyncWrapper } from '../../packages/plugins/plugin-iopgps/src/server/services/iopgpsErrorLogService';

test('错误日志会脱敏 token 和 login_key', () => {
  const masked = maskIopgpsSensitiveValue({ token: 'real-token', login_key: 'real-key', nested: { access_token: 'secret' } }) as any;
  assertEqual(masked.token, '[已隐藏]');
  assertEqual(masked.login_key, '[已隐藏]');
  assertEqual(masked.nested.access_token, '[已隐藏]');
  const log = buildIopgpsErrorLog({ action: 'sync_location', error_message: '失败', raw_response: { access_token: 'secret', login_key: 'key' } } as any);
  assertEqual((log.raw_response as any).access_token, '[已隐藏]');
});

test('safeIopgpsSyncWrapper 捕获错误并返回 failed，不抛出影响租金业务的异常', async () => {
  const result = await safeIopgpsSyncWrapper('sync_daily_mileage', () => { throw new Error('网络失败'); }) as any;
  assertEqual(result.status, 'failed');
  assertEqual(result.error_log.action, 'sync_daily_mileage');
});
