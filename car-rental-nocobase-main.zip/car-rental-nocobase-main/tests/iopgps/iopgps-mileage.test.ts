import { assert, assertEqual, assertThrows, test } from '../testHarness';
import { buildGpsLocationSnapshot, buildVehicleLocationPatch } from '../../packages/plugins/plugin-iopgps/src/server/services/iopgpsLocationService';
import { buildGpsDailyMileage, buildMileageSyncKey } from '../../packages/plugins/plugin-iopgps/src/server/services/iopgpsMileageService';

const context = { vehicle_id: 'v1', device_id: 'dev1', created_at: '2026-06-01T10:00:00Z' } as any;

test('定位快照对象和车辆位置 patch 构建正确', () => {
  const snapshot = buildGpsLocationSnapshot({ imei: 'imei1', lat: '1.23', lng: '4.56', address: '测试地址', speed: '0', acc_status: 'off', position_type: 'gps', gps_time: '2026-06-01T09:59:00Z' } as any, context);
  assertEqual(snapshot.imei, 'imei1');
  assertEqual(snapshot.lat, 1.23);
  const patch = buildVehicleLocationPatch(snapshot);
  assertEqual(patch.last_gps_lat, 1.23 as any);
  assertEqual(patch.last_gps_address, '测试地址' as any);
});

test('每日里程拒绝负数并生成 device_id + mileage_date 幂等键', () => {
  assertThrows(() => buildGpsDailyMileage({ imei: 'imei1', mileage_date: '2026-06-01', mileage_km: -1, runtime_seconds: 0 } as any, context), 'iopgps_mileage_invalid');
  assertThrows(() => buildGpsDailyMileage({ imei: 'imei1', mileage_date: '2026-06-01', mileage_km: 1, runtime_seconds: -1 } as any, context), 'iopgps_mileage_invalid');
  assertEqual(buildMileageSyncKey('dev1', '2026-06-01'), 'dev1:2026-06-01');
  const mileage = buildGpsDailyMileage({ imei: 'imei1', mileage_date: '2026-06-01', mileage_km: 12.5, runtime_seconds: 3600, start_time: '2026-06-01T00:00:00Z', end_time: '2026-06-01T23:59:59Z' } as any, context);
  assertEqual(mileage.mileage_km, 12.5);
  assert(!('rent_amount' in mileage), 'GPS 里程不参与租金计算');
});
