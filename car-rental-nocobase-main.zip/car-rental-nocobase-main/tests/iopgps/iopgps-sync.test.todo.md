# IOPGPS 同步纯函数测试 TODO

1. token 为空时视为过期。
2. `token_expires_at` 为空时视为过期。
3. token 即将过期时 `shouldRefreshToken` 返回 `true`。
4. `rawStatus` 为空时归一化为 `unknown` / `api_error`。
5. 缺少 `imei` 时归一化为 `unknown` / `api_error`。
6. `gps_time` 超过离线阈值时归一化为 `offline`。
7. `speed > 0` 时归一化为 `moving`。
8. `speed = 0` 且在线时归一化为 `static`。
9. 原始状态含低电时归一化为 `low_power`。
10. 原始状态含断电时归一化为 `power_cut`。
11. 原始状态含故障时归一化为 `fault`。
12. GPS 状态映射到车辆 `gps_status` 正确。
13. 定位快照对象构建正确。
14. 车辆位置 patch 构建正确。
15. 每日里程 `mileage_km` 不能为负数。
16. 每日里程 `runtime_seconds` 不能为负数。
17. 每日里程唯一键 `device_id + mileage_date` 正确。
18. 错误日志会脱敏 token、login_key。
19. `safeIopgpsSyncWrapper` 捕获错误并返回 `failed`。
20. IOPGPS 失败不抛出影响租金台账的异常。
21. GPS 里程不参与租金计算。
