import { assert, assertEqual, test } from '../testHarness';
import { buildTokenState, isTokenExpired, shouldRefreshToken } from '../../packages/plugins/plugin-iopgps/src/server/services/iopgpsTokenService';

function settings(overrides: Record<string, unknown> = {}) {
  return { base_url: 'https://mock-iopgps.example', appid: 'mock-app', login_key_encrypted: 'encrypted', access_token: 'token', token_expires_at: '2026-06-01T10:30:00Z', sync_enabled: true, location_sync_interval_minutes: 5, mileage_sync_interval_hours: 24, offline_threshold_minutes: 30, status: 'active', ...overrides } as any;
}

test('token 为空或 token_expires_at 为空时视为过期', () => {
  assertEqual(isTokenExpired(settings({ access_token: '' }), '2026-06-01T10:00:00Z'), true);
  assertEqual(isTokenExpired(settings({ token_expires_at: undefined }), '2026-06-01T10:00:00Z'), true);
});

test('token 即将过期时应提前刷新，buildTokenState 不暴露 login_key_encrypted', () => {
  assertEqual(shouldRefreshToken(settings(), '2026-06-01T10:25:00Z', 10), true);
  const state = buildTokenState(settings(), '2026-06-01T10:00:00Z') as any;
  assertEqual(state.is_expired, false);
  assert(!('login_key_encrypted' in state), 'token 状态不应暴露 login_key_encrypted');
});
