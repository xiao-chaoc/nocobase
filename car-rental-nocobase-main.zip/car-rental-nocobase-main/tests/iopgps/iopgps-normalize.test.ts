import { assertEqual, test } from '../testHarness';
import { mapNormalizedStatusToVehicleGpsStatus, normalizeIopgpsStatus } from '../../packages/plugins/plugin-iopgps/src/server/services/iopgpsNormalizeService';

test('rawStatus 为空或缺少 imei 时归一化为 unknown / api_error', () => {
  assertEqual(normalizeIopgpsStatus(null).normalized_status, 'unknown');
  assertEqual(normalizeIopgpsStatus(null).vehicle_gps_status, 'api_error');
  assertEqual(normalizeIopgpsStatus({ speed: 0 } as any).vehicle_gps_status, 'api_error');
});

test('gps_time 超过离线阈值时归一化为 offline', () => {
  const result = normalizeIopgpsStatus({ imei: 'imei1', speed: 0, gps_time: '2026-06-01T09:00:00Z', status_text: 'online' }, { now: '2026-06-01T10:00:00Z', offlineThresholdMinutes: 30 });
  assertEqual(result.normalized_status, 'offline');
  assertEqual(result.vehicle_gps_status, 'offline');
});

test('速度和原始状态文本映射为 moving/static/low_power/power_cut/fault', () => {
  assertEqual(normalizeIopgpsStatus({ imei: 'imei1', speed: 10, gps_time: '2026-06-01T09:55:00Z' }, { now: '2026-06-01T10:00:00Z' }).normalized_status, 'moving');
  assertEqual(normalizeIopgpsStatus({ imei: 'imei1', speed: 0, gps_time: '2026-06-01T09:55:00Z', status_text: 'online' }, { now: '2026-06-01T10:00:00Z' }).normalized_status, 'static');
  assertEqual(normalizeIopgpsStatus({ imei: 'imei1', status_text: 'low_battery', gps_time: '2026-06-01T09:55:00Z' }, { now: '2026-06-01T10:00:00Z' }).normalized_status, 'low_power');
  assertEqual(normalizeIopgpsStatus({ imei: 'imei1', status_text: 'power_cut', gps_time: '2026-06-01T09:55:00Z' }, { now: '2026-06-01T10:00:00Z' }).normalized_status, 'power_cut');
  assertEqual(normalizeIopgpsStatus({ imei: 'imei1', status_text: 'fault', gps_time: '2026-06-01T09:55:00Z' }, { now: '2026-06-01T10:00:00Z' }).normalized_status, 'fault');
});

test('GPS 设备状态正确映射车辆 gps_status', () => {
  assertEqual(mapNormalizedStatusToVehicleGpsStatus('moving'), 'normal');
  assertEqual(mapNormalizedStatusToVehicleGpsStatus('offline'), 'offline');
  assertEqual(mapNormalizedStatusToVehicleGpsStatus('low_power'), 'fault');
  assertEqual(mapNormalizedStatusToVehicleGpsStatus('unknown'), 'unknown');
});
