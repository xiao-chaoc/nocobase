type TestFn = () => void | Promise<void>;

const pending: Promise<{ name: string; error?: unknown }>[] = [];

export function test(name: string, fn: TestFn): void {
  const run = Promise.resolve()
    .then(fn)
    .then(() => ({ name }))
    .catch((error) => ({ name, error }));
  pending.push(run);
}

export function assert(condition: unknown, message = '断言失败'): void {
  if (!condition) throw new Error(message);
}

export function assertEqual<T>(actual: T, expected: T, message?: string): void {
  if (actual !== expected) {
    throw new Error(message ?? `期望 ${String(expected)}，实际 ${String(actual)}`);
  }
}

export function assertDeepEqual(actual: unknown, expected: unknown, message?: string): void {
  const actualJson = JSON.stringify(actual);
  const expectedJson = JSON.stringify(expected);
  if (actualJson !== expectedJson) {
    throw new Error(message ?? `期望 ${expectedJson}，实际 ${actualJson}`);
  }
}

export function assertThrows(fn: () => unknown, expectedCode?: string): void {
  try {
    fn();
  } catch (error) {
    if (!expectedCode) return;
    const code = (error as { code?: string }).code;
    const message = (error as Error).message;
    if (code === expectedCode || message.includes(expectedCode)) return;
    throw new Error(`期望错误 ${expectedCode}，实际 ${code ?? message}`);
  }
  throw new Error('期望函数抛出错误，但没有抛出。');
}

export async function report(): Promise<void> {
  const results = await Promise.all(pending);
  const failed = results.filter((item) => item.error);
  for (const item of results) {
    if (item.error) {
      console.error(`✗ ${item.name}`);
      console.error(item.error);
    } else {
      console.log(`✓ ${item.name}`);
    }
  }
  if (failed.length > 0) {
    throw new Error(`测试失败：${failed.length}/${results.length}`);
  }
  console.log(`全部纯函数测试通过：${results.length}`);
}
