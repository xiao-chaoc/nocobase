declare const require: any;

import { assert, test } from '../testHarness';
import { validateNasTestDocs } from '../../scripts/validate-nas-test-docs';

const fs = require('fs');

const requiredFiles = [
  'docker-compose.test.yml',
  '.env.test.example',
  'docs/deployment-nas-test.md',
  'docs/plugin-install-test.md',
  'scripts/backup-test-db.sh',
  'scripts/restore-test-db.sh',
  'scripts/check-nas-test-env.sh',
  'scripts/clean-nas-test-runtime.sh',
];

test('NAS 测试部署关键文件均存在', () => {
  for (const file of requiredFiles) {
    assert(fs.existsSync(file), `缺少文件：${file}`);
  }
});

test('NAS 测试 Compose 使用分离挂载且不直接挂载插件目录', () => {
  const compose = fs.readFileSync('docker-compose.test.yml', 'utf8');
  assert(compose.includes('nocobase/nocobase:latest-full'), 'Compose 应使用测试 NocoBase 镜像。');
  assert(compose.includes('postgres:16'), 'Compose 应使用 postgres:16。');
  assert(compose.includes('13000:80'), 'Compose 应暴露测试端口。');
  assert(compose.includes('storage-test/nocobase'), 'Compose 应挂载 storage-test/nocobase。');
  assert(compose.includes('storage-test/postgres'), 'Compose 应挂载 storage-test/postgres。');
  assert(!compose.includes('./storage-test:/app/nocobase/storage'), 'Compose 不应继续整体挂载 storage-test。');
  assert(!compose.includes('- ./packages/plugins') && !compose.includes('- packages/plugins'), 'Compose 不应直接挂载 packages/plugins。');
  assert(compose.includes('./templates:/app/nocobase/templates:ro'), '模板目录应只读挂载。');
});

test('NAS 测试 env 模板不包含真实密码或真实密钥', () => {
  const envExample = fs.readFileSync('.env.test.example', 'utf8');
  assert(!/sk_live|ghp_|AKIA|BEGIN PRIVATE KEY/i.test(envExample), '不得包含真实密钥格式。');
  assert(envExample.includes('IOPGPS_SYNC_ENABLED=false'), 'IOPGPS 同步默认必须关闭。');
  assert(envExample.includes('TEST_'), 'env 模板必须使用测试占位值。');
  assert(envExample.includes('DB_HOST=postgres'), 'DB_HOST 应指向测试 compose 服务 postgres。');
  assert(envExample.includes('DB_PORT=5432'), 'DB_PORT 应为 PostgreSQL 默认测试端口。');
});

test('NAS 测试文档说明分离目录、Raw 获取和生产边界', () => {
  const deploymentDoc = fs.readFileSync('docs/deployment-nas-test.md', 'utf8');
  const installDoc = fs.readFileSync('docs/plugin-install-test.md', 'utf8');
  assert(deploymentDoc.includes('storage-test/nocobase'), '部署文档必须说明 NocoBase storage 分离目录。');
  assert(deploymentDoc.includes('storage-test/postgres'), '部署文档必须说明 PostgreSQL 分离目录。');
  assert(deploymentDoc.includes('不能用于生产'), '部署文档必须明确不能用于生产。');
  assert(deploymentDoc.includes('GitHub HTML 页面'), '部署文档必须提醒不要保存 GitHub HTML 页面。');
  assert(deploymentDoc.includes('Raw') || deploymentDoc.includes('git clone'), '部署文档必须提醒使用 Raw 或 git clone。');
  assert(installDoc.includes('不是完整 NocoBase 源码工程'), '插件接入文档必须说明当前仓库状态。');
});

test('validate:nas-test-docs 结构校验通过', () => {
  const result = validateNasTestDocs();
  assert(result.passed, result.errors.join('\n'));
});
