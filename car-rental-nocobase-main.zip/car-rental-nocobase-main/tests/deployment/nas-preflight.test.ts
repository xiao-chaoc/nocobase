declare const require: any;

import { assert, test } from '../testHarness';
import { preflightNasTest } from '../../scripts/preflight-nas-test';

const fs = require('fs');
const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));

test('NAS 测试前自检脚本和清单文档存在', () => {
  for (const file of [
    'scripts/preflight-nas-test.ts',
    'docs/nas-smoke-test-checklist.md',
    'docs/nas-test-runbook.md',
    'docs/plugin-package-test.md',
  ]) {
    assert(fs.existsSync(file), `缺少文件：${file}`);
  }
});

test('package.json 包含 preflight:nas-test 脚本', () => {
  assert(Boolean(packageJson.scripts['preflight:nas-test']), '缺少 preflight:nas-test。');
});

test('NAS 测试准备文件不包含真实密码或真实密钥格式', () => {
  const compose = fs.readFileSync('docker-compose.test.yml', 'utf8');
  const envExample = fs.readFileSync('.env.test.example', 'utf8');
  assert(!/sk_live|ghp_|AKIA|BEGIN PRIVATE KEY/i.test(`${compose}\n${envExample}`), '不得包含真实密钥格式。');
  assert(envExample.includes('IOPGPS_SYNC_ENABLED=false'), 'IOPGPS 同步默认必须关闭。');
});

test('NAS 测试文档明确当前不是生产部署', () => {
  const smoke = fs.readFileSync('docs/nas-smoke-test-checklist.md', 'utf8');
  const runbook = fs.readFileSync('docs/nas-test-runbook.md', 'utf8');
  assert(smoke.includes('不要在生产环境继续试错'), 'Smoke Test 清单必须说明生产边界。');
  assert(runbook.includes('当前不做生产上线'), 'Runbook 必须明确当前不做生产上线。');
});



test('NAS runbook 和 smoke 清单说明分离挂载', () => {
  const smoke = fs.readFileSync('docs/nas-smoke-test-checklist.md', 'utf8');
  const runbook = fs.readFileSync('docs/nas-test-runbook.md', 'utf8');
  assert(smoke.includes('storage-test/nocobase'), 'Smoke Test 清单必须检查 NocoBase storage 分离目录。');
  assert(smoke.includes('storage-test/postgres'), 'Smoke Test 清单必须检查 PostgreSQL 分离目录。');
  assert(smoke.includes('packages/plugins'), 'Smoke Test 清单必须检查不直接挂载插件目录。');
  assert(runbook.includes('GitHub HTML 页面'), 'Runbook 必须说明避免保存 GitHub HTML 页面。');
  assert(runbook.includes('./storage-test:/app/nocobase/storage'), 'Runbook 必须说明旧整体挂载是数据混放问题。');
});

test('preflight:nas-test 自检通过且未发现风险路径', () => {
  const result = preflightNasTest();
  assert(result.passed, result.errors.join('\n'));
});
