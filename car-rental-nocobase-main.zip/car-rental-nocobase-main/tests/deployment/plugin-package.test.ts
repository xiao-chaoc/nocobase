declare const require: any;

import { assert, test } from '../testHarness';
import { checkPluginRegistration } from '../../scripts/check-plugin-registration';
import { checkPluginStructure } from '../../scripts/check-plugin-structure';

const fs = require('fs');

const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));

test('插件打包测试草案文件和脚本存在', () => {
  for (const file of [
    'docs/plugin-package-test.md',
    'scripts/check-plugin-structure.ts',
    'scripts/check-plugin-registration.ts',
  ]) {
    assert(fs.existsSync(file), `缺少文件：${file}`);
  }
});

test('package.json 包含插件结构和注册描述检查脚本', () => {
  assert(Boolean(packageJson.scripts['check:plugin-structure']), '缺少 check:plugin-structure。');
  assert(Boolean(packageJson.scripts['check:plugin-registration']), '缺少 check:plugin-registration。');
});

test('插件结构检查脚本可通过', () => {
  const result = checkPluginStructure();
  assert(result.passed, result.errors.join('\n'));
});

test('插件注册描述检查脚本可通过', () => {
  const result = checkPluginRegistration();
  assert(result.passed, result.errors.join('\n'));
});
