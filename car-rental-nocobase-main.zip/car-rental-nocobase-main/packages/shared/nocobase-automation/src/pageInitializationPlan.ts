import type {
  AutomatedGoLiveRegistrationPlan,
  NocobaseBlockPlan,
  NocobaseFilterPlan,
  NocobaseMenuPlan,
  NocobasePageActionPlan,
  NocobasePagePlan,
  PageInitializationPlan,
} from './types';

const allInternalRoles = ['system_admin', 'manager', 'accountant', 'operator'];
const financeRoles = ['system_admin', 'manager', 'accountant'];
const gpsRoles = ['system_admin', 'manager', 'gps_maintenance'];

const menu = (name: string, title: string, path: string, order: number, sourcePlugin = 'plugin-rental-core', icon = 'appstore', requiredRoles = allInternalRoles): NocobaseMenuPlan => ({
  name,
  title,
  path,
  icon,
  order,
  parentName: '',
  requiredRoles,
  sourcePlugin,
  notes: ['dry-run 菜单计划，不真实创建 NocoBase 菜单。'],
});

const page = (input: {
  name: string;
  title: string;
  route: string;
  menuName: string;
  menuPath: string;
  sourcePlugin: string;
  collection: string;
  collections?: string[];
  layout?: string;
  blocks: string[];
  filters?: string[];
  actions?: string[];
  requiredRoles: string[];
  notes: string[];
}): NocobasePagePlan => ({
  name: input.name,
  title: input.title,
  route: input.route,
  menuName: input.menuName,
  menuPath: input.menuPath,
  sourcePlugin: input.sourcePlugin,
  collection: input.collection,
  collections: input.collections ?? [input.collection],
  layout: input.layout ?? 'internal-business-page',
  blocks: input.blocks,
  filters: input.filters ?? [],
  actions: input.actions ?? [],
  requiredRoles: input.requiredRoles,
  notes: input.notes.concat('本轮只输出页面初始化计划，不真实创建 UI。'),
});

const block = (input: Omit<NocobaseBlockPlan, 'notes'> & { notes?: string[] }): NocobaseBlockPlan => ({
  ...input,
  notes: (input.notes ?? []).concat('dry-run 区块计划，不真实创建区块。'),
});

const filter = (name: string, title: string, collection: string, field: string, sourcePlugin = 'plugin-rental-core', requiredRoles = allInternalRoles, operator = 'eq', defaultValue?: unknown): NocobaseFilterPlan => ({
  name,
  title,
  collection,
  field,
  operator,
  defaultValue,
  requiredRoles,
  sourcePlugin,
  notes: ['dry-run 筛选器计划，不真实创建筛选器。'],
});

const action = (input: Omit<NocobasePageActionPlan, 'notes'> & { notes?: string[] }): NocobasePageActionPlan => ({
  ...input,
  notes: (input.notes ?? []).concat('dry-run 页面按钮动作计划，不真实注册按钮。'),
});

export const buildDashboardPagePlan = (): { pages: NocobasePagePlan[]; blocks: NocobaseBlockPlan[]; filters: NocobaseFilterPlan[]; actions: NocobasePageActionPlan[] } => ({
  pages: [page({
    name: 'dashboard',
    title: '仪表盘',
    route: '/rental/dashboard',
    menuName: 'dashboard',
    menuPath: '仪表盘',
    sourcePlugin: 'plugin-rental-core',
    collection: 'rent_daily_ledgers',
    collections: ['vehicles', 'lease_contracts', 'rent_daily_ledgers', 'gps_devices'],
    blocks: ['dashboard-summary-cards', 'dashboard-risk-panel'],
    filters: ['dashboard-current-month'],
    actions: [],
    requiredRoles: allInternalRoles,
    notes: ['包含当前出租车辆数、生效合同数、截至今日总欠款金额、截至今日总欠款天数、今日应收、未来应收、GPS 异常车辆数、待处理免除审批、待处理付款冲正、即将到期时限合同。敏感金额需要权限控制。'],
  })],
  blocks: [
    block({ name: 'dashboard-summary-cards', title: '仪表盘汇总卡片', blockType: 'chart', collection: 'rent_daily_ledgers', fields: ['active_vehicle_count', 'active_contract_count', 'total_arrears_amount', 'total_arrears_days', 'today_due_amount', 'future_receivable_amount', 'gps_abnormal_vehicle_count', 'pending_waiver_count', 'pending_reversal_count', 'expiring_fixed_term_contract_count'], filters: ['dashboard-current-month'], actions: [], visibleFields: ['active_vehicle_count', 'active_contract_count', 'gps_abnormal_vehicle_count', 'pending_waiver_count', 'pending_reversal_count', 'expiring_fixed_term_contract_count'], hiddenFields: ['total_arrears_amount', 'today_due_amount', 'future_receivable_amount', 'total_paid_amount'], requiredRoles: financeRoles, sourcePlugin: 'plugin-rental-core', notes: ['operator 和 gps_maintenance 默认不能查看敏感财务汇总。'] }),
    block({ name: 'dashboard-risk-panel', title: '待处理风险', blockType: 'table', collection: 'rent_daily_ledgers', fields: ['unpaid_reason', 'shortfall_disposition', 'calendar_status'], filters: [], actions: [], visibleFields: ['unpaid_reason', 'shortfall_disposition', 'calendar_status'], hiddenFields: [], requiredRoles: ['system_admin', 'manager', 'accountant', 'operator'], sourcePlugin: 'plugin-rental-core' }),
  ],
  filters: [filter('dashboard-current-month', '当前月份', 'rent_daily_ledgers', 'rent_date', 'plugin-rental-core', allInternalRoles, 'month')],
  actions: [],
});

export const buildDriverManagementPagePlan = () => {
  const hiddenFields = ['id_no', 'id_front_file', 'id_back_file', 'license_front_file', 'license_back_file'];
  return {
    pages: [page({ name: 'driver-list', title: '司机列表', route: '/rental/drivers', menuName: 'driver-management', menuPath: '司机管理/司机列表', sourcePlugin: 'plugin-rental-core', collection: 'drivers', collections: ['drivers', 'lease_contracts', 'rent_daily_ledgers', 'rent_payments'], blocks: ['drivers-table', 'driver-detail', 'driver-contracts-relation', 'driver-ledgers-relation', 'driver-payments-relation'], filters: ['driver-status-filter'], actions: ['create_driver'], requiredRoles: allInternalRoles, notes: ['司机不登录系统；敏感证件字段默认仅 system_admin、manager、accountant 可见。'] })],
    blocks: [
      block({ name: 'drivers-table', title: '司机表格', blockType: 'table', collection: 'drivers', fields: ['driver_no', 'name', 'phone', ...hiddenFields], filters: ['driver-status-filter'], actions: ['create_driver'], visibleFields: ['driver_no', 'name', 'phone'], hiddenFields, requiredRoles: financeRoles, sourcePlugin: 'plugin-rental-core' }),
      block({ name: 'driver-detail', title: '司机详情', blockType: 'details', collection: 'drivers', fields: ['driver_no', 'name', 'phone', ...hiddenFields], filters: [], actions: [], visibleFields: ['driver_no', 'name', 'phone'], hiddenFields, requiredRoles: financeRoles, sourcePlugin: 'plugin-rental-core' }),
      block({ name: 'driver-contracts-relation', title: '司机合同关联', blockType: 'relation', collection: 'lease_contracts', fields: ['contract_no', 'status', 'vehicle_id'], filters: [], actions: [], visibleFields: ['contract_no', 'status', 'vehicle_id'], hiddenFields: [], requiredRoles: allInternalRoles, sourcePlugin: 'plugin-rental-core' }),
      block({ name: 'driver-ledgers-relation', title: '司机每日台账关联', blockType: 'relation', collection: 'rent_daily_ledgers', fields: ['rent_date', 'due_amount', 'paid_amount', 'balance_amount'], filters: [], actions: [], visibleFields: ['rent_date'], hiddenFields: ['due_amount', 'paid_amount', 'balance_amount'], requiredRoles: financeRoles, sourcePlugin: 'plugin-rental-core' }),
      block({ name: 'driver-payments-relation', title: '司机付款关联', blockType: 'relation', collection: 'rent_payments', fields: ['payment_no', 'amount', 'method', 'screenshot_file'], filters: [], actions: [], visibleFields: ['payment_no'], hiddenFields: ['amount', 'method', 'screenshot_file'], requiredRoles: financeRoles, sourcePlugin: 'plugin-rental-core' }),
    ],
    filters: [filter('driver-status-filter', '司机状态', 'drivers', 'status')],
    actions: [action({ name: 'create_driver', title: '创建司机', actionType: 'create', serviceName: 'createDriverDraft', collection: 'drivers', requiredRoles: ['system_admin', 'manager', 'operator'], confirmationRequired: false, danger: false, sourcePlugin: 'plugin-rental-core' })],
  };
};

export const buildVehicleManagementPagePlan = () => ({
  pages: [page({ name: 'vehicle-list', title: '车辆列表', route: '/rental/vehicles', menuName: 'vehicle-management', menuPath: '车辆管理/车辆列表', sourcePlugin: 'plugin-rental-core', collection: 'vehicles', collections: ['vehicles', 'lease_contracts', 'gps_devices', 'gps_location_snapshots', 'gps_device_status_logs'], blocks: ['vehicles-table', 'vehicle-current-contract', 'vehicle-gps-device', 'vehicle-gps-status', 'vehicle-gps-location', 'vehicle-maintenance-placeholder'], filters: ['vehicle-status-filter'], actions: ['create_vehicle'], requiredRoles: allInternalRoles, notes: ['必须绑定具体车牌，不创建车型预订页面。'] })],
  blocks: [
    block({ name: 'vehicles-table', title: '车辆表格', blockType: 'table', collection: 'vehicles', fields: ['vehicle_no', 'plate_no', 'status'], filters: ['vehicle-status-filter'], actions: ['create_vehicle'], visibleFields: ['vehicle_no', 'plate_no', 'status'], hiddenFields: [], requiredRoles: allInternalRoles, sourcePlugin: 'plugin-rental-core' }),
    block({ name: 'vehicle-current-contract', title: '当前合同关联', blockType: 'relation', collection: 'lease_contracts', fields: ['contract_no', 'status', 'driver_id'], filters: [], actions: [], visibleFields: ['contract_no', 'status', 'driver_id'], hiddenFields: [], requiredRoles: allInternalRoles, sourcePlugin: 'plugin-rental-core' }),
    block({ name: 'vehicle-gps-device', title: 'GPS 设备关联', blockType: 'relation', collection: 'gps_devices', fields: ['imei', 'status'], filters: [], actions: [], visibleFields: ['imei', 'status'], hiddenFields: [], requiredRoles: gpsRoles, sourcePlugin: 'plugin-iopgps' }),
    block({ name: 'vehicle-gps-status', title: 'GPS 最近状态', blockType: 'details', collection: 'gps_device_status_logs', fields: ['normalized_status', 'reported_at'], filters: [], actions: [], visibleFields: ['normalized_status', 'reported_at'], hiddenFields: [], requiredRoles: gpsRoles, sourcePlugin: 'plugin-iopgps' }),
    block({ name: 'vehicle-gps-location', title: 'GPS 最近位置', blockType: 'details', collection: 'gps_location_snapshots', fields: ['lat', 'lng', 'reported_at'], filters: [], actions: [], visibleFields: ['lat', 'lng', 'reported_at'], hiddenFields: [], requiredRoles: gpsRoles, sourcePlugin: 'plugin-iopgps' }),
    block({ name: 'vehicle-maintenance-placeholder', title: '维修异常状态占位', blockType: 'markdown', collection: 'vehicles', fields: ['status'], filters: [], actions: [], visibleFields: ['status'], hiddenFields: [], requiredRoles: allInternalRoles, sourcePlugin: 'plugin-rental-core' }),
  ],
  filters: [filter('vehicle-status-filter', '车辆状态', 'vehicles', 'status')],
  actions: [action({ name: 'create_vehicle', title: '创建车辆', actionType: 'create', serviceName: 'createVehicleDraft', collection: 'vehicles', requiredRoles: ['system_admin', 'manager', 'operator'], confirmationRequired: false, danger: false, sourcePlugin: 'plugin-rental-core' })],
});

export const buildContractManagementPagePlan = () => ({
  pages: [
    page({ name: 'contract-list', title: '合同列表', route: '/rental/contracts', menuName: 'contract-management', menuPath: '合同管理/合同列表', sourcePlugin: 'plugin-rental-core', collection: 'lease_contracts', collections: ['lease_contracts', 'rent_daily_ledgers', 'rent_payments', 'deposit_records', 'contract_documents'], blocks: ['contracts-table', 'contract-detail', 'contract-ledgers-relation', 'contract-payments-relation', 'contract-deposits-relation', 'contract-documents-relation'], filters: ['contract-status-filter'], actions: ['create_contract', 'activate_contract', 'generate_fixed_term_ledgers', 'ensure_open_ended_ledgers', 'terminate_contract_placeholder', 'view_financial_summary'], requiredRoles: allInternalRoles, notes: ['合同分为时限合同和长租合同。'] }),
    page({ name: 'active-contracts', title: '生效中合同', route: '/rental/contracts/active', menuName: 'contract-management', menuPath: '合同管理/生效中合同', sourcePlugin: 'plugin-rental-core', collection: 'lease_contracts', blocks: ['contracts-table'], filters: ['active-contract-filter'], actions: ['ensure_open_ended_ledgers'], requiredRoles: allInternalRoles, notes: ['仅展示生效中合同计划。'] }),
  ],
  blocks: [
    block({ name: 'contracts-table', title: '合同表格', blockType: 'table', collection: 'lease_contracts', fields: ['contract_no', 'driver_id', 'vehicle_id', 'status', 'total_paid_amount', 'total_arrears_amount', 'future_receivable_amount'], filters: ['contract-status-filter'], actions: ['activate_contract'], visibleFields: ['contract_no', 'driver_id', 'vehicle_id', 'status'], hiddenFields: ['total_paid_amount', 'total_arrears_amount', 'future_receivable_amount'], requiredRoles: financeRoles, sourcePlugin: 'plugin-rental-core' }),
    block({ name: 'contract-detail', title: '合同详情', blockType: 'details', collection: 'lease_contracts', fields: ['contract_no', 'contract_type', 'start_date', 'end_date'], filters: [], actions: [], visibleFields: ['contract_no', 'contract_type', 'start_date', 'end_date'], hiddenFields: [], requiredRoles: allInternalRoles, sourcePlugin: 'plugin-rental-core' }),
    block({ name: 'contract-ledgers-relation', title: '每日台账关联', blockType: 'relation', collection: 'rent_daily_ledgers', fields: ['rent_date', 'due_amount', 'paid_amount', 'balance_amount'], filters: [], actions: [], visibleFields: ['rent_date'], hiddenFields: ['due_amount', 'paid_amount', 'balance_amount'], requiredRoles: financeRoles, sourcePlugin: 'plugin-rental-core' }),
    block({ name: 'contract-payments-relation', title: '付款记录关联', blockType: 'relation', collection: 'rent_payments', fields: ['payment_no', 'amount', 'method', 'screenshot_file'], filters: [], actions: [], visibleFields: ['payment_no'], hiddenFields: ['amount', 'method', 'screenshot_file'], requiredRoles: financeRoles, sourcePlugin: 'plugin-rental-core' }),
    block({ name: 'contract-deposits-relation', title: '押金记录关联', blockType: 'relation', collection: 'deposit_records', fields: ['deposit_no', 'required_amount', 'received_amount', 'screenshot_file'], filters: [], actions: [], visibleFields: ['deposit_no'], hiddenFields: ['required_amount', 'received_amount', 'screenshot_file'], requiredRoles: financeRoles, sourcePlugin: 'plugin-rental-core' }),
    block({ name: 'contract-documents-relation', title: '合同文件关联', blockType: 'relation', collection: 'contract_documents', fields: ['document_no', 'status', 'signed_scan_file'], filters: [], actions: [], visibleFields: ['document_no', 'status'], hiddenFields: ['signed_scan_file'], requiredRoles: ['system_admin', 'manager', 'operator'], sourcePlugin: 'plugin-contract-documents' }),
  ],
  filters: [filter('contract-status-filter', '合同状态', 'lease_contracts', 'status'), filter('active-contract-filter', '生效中', 'lease_contracts', 'status', 'plugin-rental-core', allInternalRoles, 'eq', 'active')],
  actions: [
    action({ name: 'create_contract', title: '创建合同', actionType: 'create', serviceName: 'createLeaseContractDraft', collection: 'lease_contracts', requiredRoles: ['system_admin', 'manager', 'operator'], confirmationRequired: false, danger: false, sourcePlugin: 'plugin-rental-core' }),
    action({ name: 'activate_contract', title: '激活合同', actionType: 'submit', serviceName: 'activateLeaseContract', collection: 'lease_contracts', requiredRoles: ['system_admin', 'manager'], confirmationRequired: true, danger: false, sourcePlugin: 'plugin-rental-core' }),
    action({ name: 'generate_fixed_term_ledgers', title: '生成时限合同台账', actionType: 'generate', serviceName: 'generateFixedTermDailyLedgers', collection: 'rent_daily_ledgers', requiredRoles: ['system_admin', 'manager'], confirmationRequired: true, danger: false, sourcePlugin: 'plugin-rental-core' }),
    action({ name: 'ensure_open_ended_ledgers', title: '补生成长租合同台账', actionType: 'generate', serviceName: 'ensureOpenEndedDailyLedgers', collection: 'rent_daily_ledgers', requiredRoles: ['system_admin', 'manager'], confirmationRequired: true, danger: false, sourcePlugin: 'plugin-rental-core' }),
    action({ name: 'terminate_contract_placeholder', title: '终止合同占位', actionType: 'custom', serviceName: 'terminateLeaseContractPlaceholder', collection: 'lease_contracts', requiredRoles: ['system_admin', 'manager'], confirmationRequired: true, danger: true, sourcePlugin: 'plugin-rental-core' }),
    action({ name: 'view_financial_summary', title: '查看财务汇总', actionType: 'view', serviceName: 'refreshContractFinancialSummary', collection: 'lease_contracts', requiredRoles: financeRoles, confirmationRequired: false, danger: false, sourcePlugin: 'plugin-rental-core' }),
  ],
});

export const buildRentLedgerPagePlan = () => ({
  pages: [page({ name: 'rent-ledger-list', title: '每日租金台账', route: '/rental/ledgers', menuName: 'rent-management', menuPath: '收租管理/每日租金台账', sourcePlugin: 'plugin-rental-core', collection: 'rent_daily_ledgers', blocks: ['rent-ledgers-table'], filters: ['ledger-driver-filter', 'ledger-vehicle-filter', 'ledger-contract-filter', 'ledger-date-range-filter', 'ledger-payment-status-filter', 'ledger-calendar-status-filter', 'ledger-debt-only-filter'], actions: ['mark_unpaid_reason', 'request_rent_waiver', 'approve_rent_waiver'], requiredRoles: allInternalRoles, notes: ['每日租金台账是应收、已付、欠款和日历显示的唯一事实来源。'] })],
  blocks: [block({ name: 'rent-ledgers-table', title: '每日租金台账表格', blockType: 'table', collection: 'rent_daily_ledgers', fields: ['rent_date', 'driver_id', 'vehicle_id', 'contract_id', 'due_amount', 'paid_amount', 'waived_amount', 'balance_amount', 'payment_status', 'unpaid_reason', 'shortfall_disposition', 'calendar_status'], filters: ['ledger-driver-filter', 'ledger-vehicle-filter', 'ledger-contract-filter', 'ledger-date-range-filter', 'ledger-payment-status-filter', 'ledger-calendar-status-filter', 'ledger-debt-only-filter'], actions: ['mark_unpaid_reason', 'request_rent_waiver', 'approve_rent_waiver'], visibleFields: ['rent_date', 'driver_id', 'vehicle_id', 'contract_id', 'payment_status', 'unpaid_reason', 'shortfall_disposition', 'calendar_status'], hiddenFields: ['due_amount', 'paid_amount', 'waived_amount', 'balance_amount', 'total_paid_amount', 'future_receivable_amount'], requiredRoles: financeRoles, sourcePlugin: 'plugin-rental-core' })],
  filters: [
    filter('ledger-driver-filter', '司机', 'rent_daily_ledgers', 'driver_id'),
    filter('ledger-vehicle-filter', '车辆', 'rent_daily_ledgers', 'vehicle_id'),
    filter('ledger-contract-filter', '合同', 'rent_daily_ledgers', 'contract_id'),
    filter('ledger-date-range-filter', '日期范围', 'rent_daily_ledgers', 'rent_date', 'plugin-rental-core', allInternalRoles, 'between'),
    filter('ledger-payment-status-filter', '付款状态', 'rent_daily_ledgers', 'payment_status'),
    filter('ledger-calendar-status-filter', '日历状态', 'rent_daily_ledgers', 'calendar_status'),
    filter('ledger-debt-only-filter', '只看欠款', 'rent_daily_ledgers', 'balance_amount', 'plugin-rental-core', financeRoles, 'gt', 0),
  ],
  actions: [
    action({ name: 'mark_unpaid_reason', title: '标记未付原因', actionType: 'update', serviceName: 'markUnpaidReason', collection: 'rent_daily_ledgers', requiredRoles: ['system_admin', 'manager', 'accountant', 'operator'], confirmationRequired: false, danger: false, sourcePlugin: 'plugin-rental-core' }),
    action({ name: 'request_rent_waiver', title: '申请租金免除', actionType: 'submit', serviceName: 'requestRentWaiver', collection: 'rent_daily_ledgers', requiredRoles: ['system_admin', 'manager', 'accountant', 'operator'], confirmationRequired: true, danger: false, sourcePlugin: 'plugin-rental-core' }),
    action({ name: 'approve_rent_waiver', title: '审批租金免除', actionType: 'approve', serviceName: 'approveRentWaiver', collection: 'rent_daily_ledgers', requiredRoles: ['system_admin', 'manager'], confirmationRequired: true, danger: false, sourcePlugin: 'plugin-rental-core' }),
  ],
});

export const buildRentCalendarPagePlan = () => ({
  pages: [page({ name: 'rent-calendar', title: '收租日历', route: '/rental/calendar', menuName: 'rent-management', menuPath: '收租管理/收租日历', sourcePlugin: 'plugin-rental-core', collection: 'rent_daily_ledgers', blocks: ['rent-calendar-placeholder', 'rent-calendar-summary'], filters: ['calendar-driver-filter', 'calendar-vehicle-filter', 'calendar-contract-filter', 'calendar-month-filter', 'calendar-debt-only-filter', 'calendar-status-filter'], actions: [], requiredRoles: allInternalRoles, notes: ['收租日历本轮只生成计划，不实现真实 UI；GPS 维护人员不能看财务汇总。'] })],
  blocks: [
    block({ name: 'rent-calendar-placeholder', title: '收租日历格占位', blockType: 'calendar', collection: 'rent_daily_ledgers', fields: ['rent_date', 'vehicle_id', 'calendar_status', 'due_amount', 'paid_amount', 'balance_amount', 'waived_amount'], filters: ['calendar-driver-filter', 'calendar-vehicle-filter', 'calendar-contract-filter', 'calendar-month-filter', 'calendar-debt-only-filter', 'calendar-status-filter'], actions: [], visibleFields: ['rent_date', 'vehicle_id', 'calendar_status'], hiddenFields: ['due_amount', 'paid_amount', 'balance_amount', 'waived_amount'], requiredRoles: financeRoles, sourcePlugin: 'plugin-rental-core' }),
    block({ name: 'rent-calendar-summary', title: '收租日历汇总', blockType: 'chart', collection: 'rent_daily_ledgers', fields: ['total_arrears_days', 'total_arrears_amount', 'total_paid_amount', 'future_receivable_amount'], filters: [], actions: [], visibleFields: ['total_arrears_days'], hiddenFields: ['total_arrears_amount', 'total_paid_amount', 'future_receivable_amount'], requiredRoles: financeRoles, sourcePlugin: 'plugin-rental-core', notes: ['operator 默认不能看总已付、未来应收、押金、付款截图；gps_maintenance 不能看财务汇总。'] }),
  ],
  filters: [
    filter('calendar-driver-filter', '司机', 'rent_daily_ledgers', 'driver_id'),
    filter('calendar-vehicle-filter', '车辆', 'rent_daily_ledgers', 'vehicle_id'),
    filter('calendar-contract-filter', '合同', 'rent_daily_ledgers', 'contract_id'),
    filter('calendar-month-filter', '月份', 'rent_daily_ledgers', 'rent_date', 'plugin-rental-core', allInternalRoles, 'month'),
    filter('calendar-debt-only-filter', '只看欠款', 'rent_daily_ledgers', 'balance_amount', 'plugin-rental-core', financeRoles, 'gt', 0),
    filter('calendar-status-filter', '日历状态', 'rent_daily_ledgers', 'calendar_status'),
  ],
  actions: [],
});

export const buildPaymentPagePlan = () => ({
  pages: [page({ name: 'payment-list', title: '付款记录', route: '/rental/payments', menuName: 'rent-management', menuPath: '收租管理/付款记录', sourcePlugin: 'plugin-rental-core', collection: 'rent_payments', collections: ['rent_payments', 'rent_payment_allocations'], blocks: ['payments-table', 'payment-allocations-relation'], filters: ['payment-date-filter'], actions: ['create_rent_payment', 'confirm_rent_payment', 'reverse_rent_payment'], requiredRoles: financeRoles, notes: ['付款必须分配到具体日期，单日不可超付，超付整个操作失败，不允许预收款。'] })],
  blocks: [
    block({ name: 'payments-table', title: '付款记录表格', blockType: 'table', collection: 'rent_payments', fields: ['payment_no', 'amount', 'method', 'screenshot_file', 'paid_at'], filters: ['payment-date-filter'], actions: ['create_rent_payment', 'confirm_rent_payment', 'reverse_rent_payment'], visibleFields: ['payment_no', 'paid_at'], hiddenFields: ['amount', 'method', 'screenshot_file'], requiredRoles: financeRoles, sourcePlugin: 'plugin-rental-core' }),
    block({ name: 'payment-allocations-relation', title: '付款分配关联', blockType: 'relation', collection: 'rent_payment_allocations', fields: ['ledger_id', 'allocated_amount'], filters: [], actions: [], visibleFields: ['ledger_id'], hiddenFields: ['allocated_amount'], requiredRoles: financeRoles, sourcePlugin: 'plugin-rental-core' }),
  ],
  filters: [filter('payment-date-filter', '付款日期', 'rent_payments', 'paid_at', 'plugin-rental-core', financeRoles, 'between')],
  actions: [
    action({ name: 'create_rent_payment', title: '创建付款', actionType: 'create', serviceName: 'createRentPayment', collection: 'rent_payments', requiredRoles: financeRoles, confirmationRequired: false, danger: false, sourcePlugin: 'plugin-rental-core' }),
    action({ name: 'confirm_rent_payment', title: '确认付款', actionType: 'submit', serviceName: 'allocateRentPayment', collection: 'rent_payments', requiredRoles: financeRoles, confirmationRequired: true, danger: false, sourcePlugin: 'plugin-rental-core' }),
    action({ name: 'reverse_rent_payment', title: '冲正付款', actionType: 'reverse', serviceName: 'reverseRentPayment', collection: 'rent_payments', requiredRoles: ['system_admin', 'manager', 'accountant'], confirmationRequired: true, danger: true, sourcePlugin: 'plugin-rental-core' }),
  ],
});

export const buildDepositPagePlan = () => ({
  pages: [page({ name: 'deposit-list', title: '押金记录', route: '/rental/deposits', menuName: 'deposit-management', menuPath: '押金管理/押金记录', sourcePlugin: 'plugin-rental-core', collection: 'deposit_records', blocks: ['deposits-table'], filters: ['deposit-status-filter'], actions: ['create_deposit', 'deduct_deposit', 'refund_deposit', 'waive_deposit'], requiredRoles: financeRoles, notes: ['押金不计入租金收入，不计入 total_paid_amount。'] })],
  blocks: [block({ name: 'deposits-table', title: '押金记录表格', blockType: 'table', collection: 'deposit_records', fields: ['deposit_no', 'required_amount', 'received_amount', 'screenshot_file', 'status'], filters: ['deposit-status-filter'], actions: ['create_deposit', 'deduct_deposit', 'refund_deposit', 'waive_deposit'], visibleFields: ['deposit_no', 'status'], hiddenFields: ['required_amount', 'received_amount', 'screenshot_file'], requiredRoles: financeRoles, sourcePlugin: 'plugin-rental-core' })],
  filters: [filter('deposit-status-filter', '押金状态', 'deposit_records', 'status', 'plugin-rental-core', financeRoles)],
  actions: [
    action({ name: 'create_deposit', title: '创建押金', actionType: 'create', serviceName: 'createDepositRecord', collection: 'deposit_records', requiredRoles: financeRoles, confirmationRequired: false, danger: false, sourcePlugin: 'plugin-rental-core' }),
    action({ name: 'deduct_deposit', title: '押金抵扣', actionType: 'submit', serviceName: 'deductDeposit', collection: 'deposit_records', requiredRoles: financeRoles, confirmationRequired: true, danger: false, sourcePlugin: 'plugin-rental-core' }),
    action({ name: 'refund_deposit', title: '押金退款', actionType: 'submit', serviceName: 'refundDeposit', collection: 'deposit_records', requiredRoles: financeRoles, confirmationRequired: true, danger: false, sourcePlugin: 'plugin-rental-core' }),
    action({ name: 'waive_deposit', title: '押金免除', actionType: 'approve', serviceName: 'waiveDepositPlaceholder', collection: 'deposit_records', requiredRoles: ['system_admin', 'manager'], confirmationRequired: true, danger: true, sourcePlugin: 'plugin-rental-core' }),
  ],
});

export const buildContractDocumentsPagePlan = () => ({
  pages: [page({ name: 'contract-documents', title: '合同文件', route: '/rental/contract-documents', menuName: 'contract-documents', menuPath: '合同文件/合同文件', sourcePlugin: 'plugin-contract-documents', collection: 'contract_documents', collections: ['contract_templates', 'contract_documents'], blocks: ['contract-templates-table', 'contract-documents-table'], filters: ['contract-document-status-filter', 'contract-template-language-filter'], actions: ['generate_contract_documents', 'mark_contract_printed', 'upload_signed_contract_scan', 'void_contract_document'], requiredRoles: ['system_admin', 'manager', 'operator'], notes: ['支持 zh-CN、en-US、fr-FR；本轮不真实生成 PDF；signed_scan_file 敏感。'] })],
  blocks: [
    block({ name: 'contract-templates-table', title: '合同模板表格', blockType: 'table', collection: 'contract_templates', fields: ['template_no', 'language', 'status'], filters: ['contract-template-language-filter'], actions: [], visibleFields: ['template_no', 'language', 'status'], hiddenFields: [], requiredRoles: ['system_admin', 'manager', 'operator'], sourcePlugin: 'plugin-contract-documents' }),
    block({ name: 'contract-documents-table', title: '合同文件表格', blockType: 'table', collection: 'contract_documents', fields: ['document_no', 'language', 'status', 'signed_scan_file', 'generated_docx_file', 'generated_pdf_file'], filters: ['contract-document-status-filter'], actions: ['generate_contract_documents', 'mark_contract_printed', 'upload_signed_contract_scan', 'void_contract_document'], visibleFields: ['document_no', 'language', 'status'], hiddenFields: ['signed_scan_file', 'generated_docx_file', 'generated_pdf_file'], requiredRoles: ['system_admin', 'manager', 'operator'], sourcePlugin: 'plugin-contract-documents' }),
  ],
  filters: [filter('contract-document-status-filter', '合同文件状态', 'contract_documents', 'status', 'plugin-contract-documents', ['system_admin', 'manager', 'operator']), filter('contract-template-language-filter', '合同语言', 'contract_templates', 'language', 'plugin-contract-documents', ['system_admin', 'manager', 'operator'])],
  actions: [
    action({ name: 'generate_contract_documents', title: '生成合同文件', actionType: 'generate', serviceName: 'generateContractDocuments', collection: 'contract_documents', requiredRoles: ['system_admin', 'manager', 'operator'], confirmationRequired: true, danger: false, sourcePlugin: 'plugin-contract-documents' }),
    action({ name: 'mark_contract_printed', title: '标记已打印', actionType: 'update', serviceName: 'markContractPrinted', collection: 'contract_documents', requiredRoles: ['system_admin', 'manager', 'operator'], confirmationRequired: true, danger: false, sourcePlugin: 'plugin-contract-documents' }),
    action({ name: 'upload_signed_contract_scan', title: '上传签署扫描件', actionType: 'submit', serviceName: 'uploadSignedContractScan', collection: 'contract_documents', requiredRoles: ['system_admin', 'manager', 'operator'], confirmationRequired: true, danger: false, sourcePlugin: 'plugin-contract-documents' }),
    action({ name: 'void_contract_document', title: '作废合同文件', actionType: 'delete', serviceName: 'voidContractDocument', collection: 'contract_documents', requiredRoles: ['system_admin', 'manager'], confirmationRequired: true, danger: true, sourcePlugin: 'plugin-contract-documents' }),
  ],
});

export const buildGpsPagePlan = () => ({
  pages: [
    page({ name: 'gps-devices', title: 'GPS 设备', route: '/rental/gps/devices', menuName: 'gps-management', menuPath: 'GPS 管理/GPS 设备', sourcePlugin: 'plugin-iopgps', collection: 'gps_devices', blocks: ['gps-devices-table'], filters: ['gps-device-status-filter'], actions: ['sync_device_status'], requiredRoles: gpsRoles, notes: ['IOPGPS_SYNC_ENABLED=false 时不真实同步。'] }),
    page({ name: 'gps-status', title: 'GPS 状态', route: '/rental/gps/status', menuName: 'gps-management', menuPath: 'GPS 管理/GPS 状态', sourcePlugin: 'plugin-iopgps', collection: 'gps_device_status_logs', collections: ['gps_location_snapshots', 'gps_daily_mileages', 'gps_device_status_logs'], blocks: ['gps-location-table', 'gps-mileage-table', 'gps-status-log-table'], filters: ['gps-status-filter'], actions: ['sync_location', 'sync_daily_mileage'], requiredRoles: gpsRoles, notes: ['GPS 不参与租金计算；GPS 失败不影响租金台账和付款。'] }),
  ],
  blocks: [
    block({ name: 'gps-devices-table', title: 'GPS 设备表格', blockType: 'table', collection: 'gps_devices', fields: ['imei', 'status', 'vehicle_id'], filters: ['gps-device-status-filter'], actions: ['sync_device_status'], visibleFields: ['imei', 'status', 'vehicle_id'], hiddenFields: [], requiredRoles: gpsRoles, sourcePlugin: 'plugin-iopgps' }),
    block({ name: 'gps-location-table', title: 'GPS 位置快照', blockType: 'table', collection: 'gps_location_snapshots', fields: ['device_id', 'lat', 'lng', 'reported_at'], filters: [], actions: ['sync_location'], visibleFields: ['device_id', 'lat', 'lng', 'reported_at'], hiddenFields: [], requiredRoles: gpsRoles, sourcePlugin: 'plugin-iopgps' }),
    block({ name: 'gps-mileage-table', title: 'GPS 每日里程', blockType: 'table', collection: 'gps_daily_mileages', fields: ['device_id', 'mileage_date', 'mileage'], filters: [], actions: ['sync_daily_mileage'], visibleFields: ['device_id', 'mileage_date', 'mileage'], hiddenFields: [], requiredRoles: gpsRoles, sourcePlugin: 'plugin-iopgps' }),
    block({ name: 'gps-status-log-table', title: 'GPS 状态日志', blockType: 'table', collection: 'gps_device_status_logs', fields: ['device_id', 'normalized_status', 'reported_at'], filters: ['gps-status-filter'], actions: [], visibleFields: ['device_id', 'normalized_status', 'reported_at'], hiddenFields: [], requiredRoles: gpsRoles, sourcePlugin: 'plugin-iopgps' }),
  ],
  filters: [filter('gps-device-status-filter', 'GPS 设备状态', 'gps_devices', 'status', 'plugin-iopgps', gpsRoles), filter('gps-status-filter', 'GPS 归一状态', 'gps_device_status_logs', 'normalized_status', 'plugin-iopgps', gpsRoles)],
  actions: [
    action({ name: 'sync_device_status', title: '手动同步设备状态', actionType: 'sync', serviceName: 'syncIopgpsDeviceStatus', collection: 'gps_devices', requiredRoles: gpsRoles, confirmationRequired: true, danger: false, sourcePlugin: 'plugin-iopgps', notes: ['占位动作；不调用真实 IOPGPS。'] }),
    action({ name: 'sync_location', title: '手动同步位置', actionType: 'sync', serviceName: 'syncIopgpsLocation', collection: 'gps_location_snapshots', requiredRoles: gpsRoles, confirmationRequired: true, danger: false, sourcePlugin: 'plugin-iopgps', notes: ['占位动作；不调用真实 IOPGPS。'] }),
    action({ name: 'sync_daily_mileage', title: '手动同步里程', actionType: 'sync', serviceName: 'syncIopgpsDailyMileage', collection: 'gps_daily_mileages', requiredRoles: gpsRoles, confirmationRequired: true, danger: false, sourcePlugin: 'plugin-iopgps', notes: ['占位动作；不调用真实 IOPGPS。'] }),
  ],
});

const buildOperationLogPagePlan = () => ({
  pages: [page({ name: 'operation-logs', title: '操作日志', route: '/rental/operation-logs', menuName: 'system-logs', menuPath: '系统日志/操作日志', sourcePlugin: 'plugin-rental-core', collection: 'operation_logs', blocks: ['operation-logs-table'], filters: ['operation-log-action-filter'], actions: [], requiredRoles: ['system_admin', 'manager', 'readonly_auditor'], notes: ['操作日志必须脱敏。'] })],
  blocks: [block({ name: 'operation-logs-table', title: '操作日志表格', blockType: 'table', collection: 'operation_logs', fields: ['actor_id', 'action', 'target', 'created_at'], filters: ['operation-log-action-filter'], actions: [], visibleFields: ['actor_id', 'action', 'target', 'created_at'], hiddenFields: [], requiredRoles: ['system_admin', 'manager', 'readonly_auditor'], sourcePlugin: 'plugin-rental-core' })],
  filters: [filter('operation-log-action-filter', '操作类型', 'operation_logs', 'action', 'plugin-rental-core', ['system_admin', 'manager', 'readonly_auditor'])],
  actions: [],
});

export const buildPageInitializationPlan = (automatedPlan: AutomatedGoLiveRegistrationPlan): PageInitializationPlan => {
  const parts = [
    buildDashboardPagePlan(),
    buildDriverManagementPagePlan(),
    buildVehicleManagementPagePlan(),
    buildContractManagementPagePlan(),
    buildRentLedgerPagePlan(),
    buildRentCalendarPagePlan(),
    buildPaymentPagePlan(),
    buildDepositPagePlan(),
    buildContractDocumentsPagePlan(),
    buildGpsPagePlan(),
    buildOperationLogPagePlan(),
  ];

  return {
    menus: [
      menu('dashboard', '仪表盘', '/rental/dashboard', 10),
      menu('driver-management', '司机管理', '/rental/drivers', 20),
      menu('vehicle-management', '车辆管理', '/rental/vehicles', 30),
      menu('contract-management', '合同管理', '/rental/contracts', 40),
      menu('rent-management', '收租管理', '/rental/ledgers', 50),
      menu('deposit-management', '押金管理', '/rental/deposits', 60),
      menu('contract-documents', '合同文件', '/rental/contract-documents', 70, 'plugin-contract-documents'),
      menu('gps-management', 'GPS 管理', '/rental/gps', 80, 'plugin-iopgps', 'environment', gpsRoles),
      menu('system-logs', '系统日志', '/rental/operation-logs', 90, 'plugin-rental-core', 'audit', ['system_admin', 'manager', 'readonly_auditor']),
      menu('system-settings', '系统设置', '/rental/settings', 100, 'plugin-rental-core', 'setting', ['system_admin']),
    ],
    pages: parts.flatMap((part) => part.pages),
    blocks: parts.flatMap((part) => part.blocks),
    filters: parts.flatMap((part) => part.filters),
    actions: parts.flatMap((part) => part.actions),
    warnings: [
      ...automatedPlan.warnings,
      '页面初始化仅为 dry-run，不连接真实 NocoBase，不创建真实页面、菜单、区块或按钮。',
    ],
    notes: [
      '页面初始化后续必须自动化完成，不要求用户手动建页面。',
      '收租日历页面仅为计划，不实现真实 UI。',
      'GPS 页面不调用真实 IOPGPS，GPS 数据不参与租金计算。',
      '合同文件页面不真实生成 PDF，不上传真实扫描件。',
    ],
  };
};
