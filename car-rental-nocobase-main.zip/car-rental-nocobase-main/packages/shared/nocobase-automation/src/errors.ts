export class NocobaseAutomationPlanError extends Error {
  code: string;
  details: string[];

  constructor(code: string, message: string, details: string[] = []) {
    super(message);
    this.name = 'NocobaseAutomationPlanError';
    this.code = code;
    this.details = details;
  }
}
