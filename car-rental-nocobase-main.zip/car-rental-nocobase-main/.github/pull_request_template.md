## 变更说明

请说明本 PR 是否用于目标 NocoBase 版本确认流程，以及是否仅包含文档、模板、脚本或人工确认产生的 decision 变更。

## 目标版本确认信息

- target_version：
- source_type：
- source_reference：
- package_manager：
- node_version：
- database：
- deployment_mode：
- plugin_development_mode：
- plugin_install_mode：
- iopgps_real_sync_allowed = false：
- mock_data_only = true：
- confirmed_by：
- confirmed_at：

## 安全检查

- [ ] 没有提交 `.env`。
- [ ] 没有提交 `.env.test`。
- [ ] 没有提交真实密钥。
- [ ] 没有提交真实司机文件。
- [ ] 没有提交真实付款截图。
- [ ] 没有提交真实合同扫描件。
- [ ] 没有把 `latest-full` 作为真实目标版本。
- [ ] 没有把 IOPGPS 真实同步设置为 `true`。
- [ ] `mock_data_only = true`。

## 目标版本字段检查

- [ ] `target_version` 非空且不是 `unset`。
- [ ] `source_reference` 已填写。
- [ ] `confirmed_by` 已填写。
- [ ] `confirmed_at` 已填写。

## 门禁命令

- [ ] 已执行 `npm run validate:target-version-input -- --file test-data/generated/nocobase-target-version-confirmation.filled.json`。
- [ ] 已执行 `npm run validate:target-version-confirmation`。
- [ ] 已执行 `npm run validate:can-start-real-adapter`。

## 阶段边界

- [ ] 已明确当前仍不能 `production_ready`。
- [ ] 未实现真实 adapter。
- [ ] 未连接 NocoBase。
- [ ] 未写数据库。
