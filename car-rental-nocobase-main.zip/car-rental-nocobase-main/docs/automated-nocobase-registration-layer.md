# NocoBase 自动化接入适配层说明

## 1. 为什么需要自动化接入适配层

用户不希望手动在 NocoBase UI 中创建 Collections、页面、菜单、权限和测试数据。当前仓库也不是完整 NocoBase 源码工程，因此需要先建立一个抽象适配层，把后续要自动执行的事项转成可验证的注册计划，再在真实 NocoBase 工程中逐步替换为真实 adapter。

## 2. 当前不会真实执行的内容

当前 `packages/shared/nocobase-automation` 只提供接口、计划生成、计划校验和 dry-run 执行器：

- 不真实连接 NocoBase。
- 不真实安装插件。
- 不真实创建数据库表。
- 不真实创建页面、菜单或权限。
- 不真实导入测试数据。
- 不调用真实 IOPGPS API。
- 不生成真实合同文件。
- 不上传真实文件。

## 3. 当前只生成 dry-run 注册计划

本轮新增的自动化注册计划会把三个插件的 `pluginRegistration` 描述合并为统一计划，包含：

- 插件顺序。
- Collection 注册计划。
- 服务注册计划。
- 权限注册计划。
- i18n 注册计划。
- 动作注册计划。
- 定时任务注册计划。
- 页面初始化计划。
- mock 数据导入计划。
- smoke test 计划。

生成命令：

```bash
npm run generate:registration-plan
npm run validate:registration-plan
```

输出文件为 `test-data/generated/automated-registration-plan.generated.json`。该文件是测试计划产物，不代表已经写入 NocoBase。

## 4. 后续如何替换为真实 NocoBase adapter

后续进入完整 NocoBase 工程后，应实现 `NocobaseAutomationAdapter` 接口，并把 dry-run 步骤逐步替换为真实实现：

1. 使用真实 Collection/migration API 注册 Collections。
2. 使用真实服务注册机制注册服务方法。
3. 使用真实服务端 ACL 初始化角色和字段权限。
4. 使用真实 i18n 机制注册多语言资源。
5. 使用真实动作或工作流机制注册动作。
6. 使用真实 scheduler/workflow 注册定时任务。
7. 使用真实页面配置或导入机制初始化页面和菜单。
8. 使用测试导入脚本导入 mock 数据。
9. 使用自动化 smoke test 验证核心业务。

真实 adapter 必须在目标 NocoBase 版本中验证，不能伪造不确定 API。

## 5. 用户不需要手动搭建

用户不需要手动创建：

- Collections。
- 页面。
- 菜单。
- 权限。
- 测试司机、车辆、合同、付款、押金、GPS 或合同文件数据。

用户只需要合并 PR、创建 `.env.test`、启动测试环境、运行自动化命令并查看报告。

## 6. 当前仍不能正式上线测试

当前只是 dry-run 适配层和注册计划。插件尚未在真实 NocoBase 中安装启用，Collections、页面、权限和测试数据也尚未真实初始化，因此仍不能进入正式上线测试，更不能生产上线。

## 7. 进入下一阶段的条件

进入下一阶段前至少需要：

- `npm run typecheck` 通过。
- `npm run test` 通过。
- `npm run generate:registration-plan` 通过。
- `npm run validate:registration-plan` 通过。
- dry-run 计划无阻塞错误。
- 明确目标 NocoBase 版本和插件真实接入方式。

## 8. Collection 自动注册 dry-run 补充

本轮新增 Collection 自动注册 dry-run 适配内容：

- `collectionPlanNormalizer.ts`：将插件 Collection 草案标准化为统一 Collection 注册计划。
- `collectionRegistrationValidator.ts`：校验关键 Collections、唯一约束、敏感字段和业务边界。
- `mockCollectionAdapter.ts`：使用内存对象模拟 Collection 注册，不连接真实 NocoBase、不写数据库、不执行 migration。
- `collectionRegistrationExecutor.ts`：从自动化注册计划提取 Collections，并执行 dry-run 注册。
- `scripts/nocobase/dry-run-register-collections.ts`：生成 Collection dry-run 注册结果。
- `scripts/nocobase/validate-collection-registration.ts`：校验 Collection dry-run 注册结果。

该补充只推进 Collection 注册适配层草案，不创建真实表，不实现页面、权限、数据导入、GPS 同步或合同生成。用户仍不需要手动创建 Collections；后续真实 adapter 必须在完整 NocoBase 工程中替换 mock adapter。

## 9. Runtime 自动注册 dry-run 补充

本轮新增服务方法、动作、权限、定时任务和 i18n 的 runtime dry-run 适配内容：

- `servicePlanNormalizer.ts`：标准化服务方法注册计划并标记事务服务。
- `actionPlanNormalizer.ts`：标准化动作注册计划，校验服务绑定和 requiredPermissions。
- `permissionPlanNormalizer.ts`：标准化角色权限计划并输出敏感字段覆盖。
- `schedulePlanNormalizer.ts`：标准化定时任务计划，IOPGPS 同步任务 dry-run 默认关闭。
- `i18nPlanNormalizer.ts`：验证 zh-CN、en-US、fr-FR 三语言计划。
- `runtimeRegistrationValidator.ts`：校验核心服务、动作、角色权限、i18n 和禁止业务模式。
- `mockRuntimeAdapter.ts`：用内存对象模拟注册服务、动作、权限、定时任务和 i18n。
- `runtimeRegistrationExecutor.ts`：从自动化注册计划提取 runtime plans 并执行 dry-run。

该补充不连接真实 NocoBase，不注册真实 API、按钮、ACL、定时任务或 i18n。后续仍必须在完整 NocoBase 工程中用真实 adapter 替换 mock adapter。

## 页面初始化 dry-run 补充

在 Collection 注册 dry-run 和 runtime 注册 dry-run 之后，新增页面、菜单、区块、筛选器和按钮动作初始化 dry-run。该阶段仍不连接真实 NocoBase，不创建真实页面，不注册真实按钮，只验证页面初始化计划是否覆盖司机、车辆、合同、每日租金台账、收租日历、付款、押金、合同文件、GPS 和操作日志等内部业务页面。

真实页面 adapter 仍需等待接入完整 NocoBase 工程后实现，且必须使用目标 NocoBase 版本确认可用的页面配置或导入机制，不能伪造不确定的 UI API。

## 测试数据导入 dry-run 补充

在页面初始化 dry-run 之后，新增 mock 测试数据导入 dry-run。该阶段根据 `test-data/generated` 生成导入计划，校验导入顺序、引用完整性、唯一键、敏感真实数据、每日台账、付款分配、押金和 GPS mock 业务边界。该阶段不连接真实 NocoBase、不写数据库、不上传文件，只为后续真实 seed data adapter 提供可验证输入。

## Smoke Test dry-run 编排层补充

自动化接入层新增 smoke test dry-run 编排器，用于按固定顺序调用注册计划生成、Collection dry-run、Runtime dry-run、页面初始化 dry-run、mock 测试数据导入 dry-run 与 NAS 文件预检。该编排器只执行本地脚本和 mock adapter，不调用真实 NocoBase API，不写数据库，不创建页面、权限或按钮。未来接入真实 NocoBase 工程后，仍应先通过该编排层验证计划完整性，再替换真实 adapter。

## 真实 adapter 最小接口边界补充

本轮新增真实 NocoBase adapter 的最小接口落地内容：

- 定义 `NocobaseRealAdapter`，组合现有 Collection、Runtime、Page、Seed Data adapter 边界。
- 定义 adapter 模式、状态、能力矩阵、环境检测结果和通用操作结果类型。
- 新增 `UnconfiguredNocobaseRealAdapter`，用于在当前仓库没有真实 NocoBase app 时返回受控失败。
- 新增 adapter factory、模式检测和 ready 断言，避免未配置状态静默继续。
- 新增环境检测器和中文摘要，用于说明缺少哪些 NocoBase 能力。

该补充仍不连接真实 NocoBase，不写数据库，不安装插件，不伪造官方 API。当前仓库仍没有真实可用 adapter，不能进入真实插件接入测试。下一轮应先实现 Collection 注册 adapter 草案，并在完整 NocoBase 工程内验证目标版本官方能力。
