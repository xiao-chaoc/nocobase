# 真实 Adapter API 映射

## 本轮结论

本轮只把当前草案 adapter 方法映射到可能的 NocoBase 官方能力方向或标记为待验证，不实现真实 adapter，不连接 NocoBase，不写数据库，不创建页面。

映射来源标记只使用：`official_docs`、`official_source`、`local_project`、`unknown`。凡是没有固定目标版本源码和完整工程验证的调用，均标记为待验证。

不得伪造 API。不得生产库调试。未知 API 必须标记为待验证。

## Collection Adapter 映射

| 草案方法 | 目标真实能力 | 可能的 NocoBase API | 官方来源 | 验证状态 | 替代方案 | 风险 | 下一步 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `registerCollections` | 将草案能力落到真实 NocoBase 隔离工程。 | defineCollection / extendCollection / db.collection / Migration / queryInterface；具体以固定版本源码为准 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `checkCollectionExists` | 将草案能力落到真实 NocoBase 隔离工程。 | defineCollection / extendCollection / db.collection / Migration / queryInterface；具体以固定版本源码为准 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `ensureIndexes` | 将草案能力落到真实 NocoBase 隔离工程。 | defineCollection / extendCollection / db.collection / Migration / queryInterface；具体以固定版本源码为准 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `ensureUniqueConstraints` | 将草案能力落到真实 NocoBase 隔离工程。 | defineCollection / extendCollection / db.collection / Migration / queryInterface；具体以固定版本源码为准 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `ensureRelations` | 将草案能力落到真实 NocoBase 隔离工程。 | defineCollection / extendCollection / db.collection / Migration / queryInterface；具体以固定版本源码为准 | official_docs + unknown | 部分 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `markSensitiveFields` | 将草案能力落到真实 NocoBase 隔离工程。 | defineCollection / extendCollection / db.collection / Migration / queryInterface；具体以固定版本源码为准 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `rollbackCollectionRegistration` | 将草案能力落到真实 NocoBase 隔离工程。 | defineCollection / extendCollection / db.collection / Migration / queryInterface；具体以固定版本源码为准 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |

## Runtime Adapter 映射

| 草案方法 | 目标真实能力 | 可能的 NocoBase API | 官方来源 | 验证状态 | 替代方案 | 风险 | 下一步 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `registerServices` | 将草案能力落到真实 NocoBase 隔离工程。 | resourceManager.registerActionHandlers / resourceManager.define / i18n / ACL / workflow；ACL 和 scheduler 待验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `registerActions` | 将草案能力落到真实 NocoBase 隔离工程。 | resourceManager.registerActionHandlers / resourceManager.define / i18n / ACL / workflow；ACL 和 scheduler 待验证 | official_docs + unknown | 部分 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `registerPermissions` | 将草案能力落到真实 NocoBase 隔离工程。 | resourceManager.registerActionHandlers / resourceManager.define / i18n / ACL / workflow；ACL 和 scheduler 待验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `registerI18n` | 将草案能力落到真实 NocoBase 隔离工程。 | resourceManager.registerActionHandlers / resourceManager.define / i18n / ACL / workflow；ACL 和 scheduler 待验证 | official_docs | 部分 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `registerSchedules` | 将草案能力落到真实 NocoBase 隔离工程。 | resourceManager.registerActionHandlers / resourceManager.define / i18n / ACL / workflow；ACL 和 scheduler 待验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `validateRuntimeRegistration` | 将草案能力落到真实 NocoBase 隔离工程。 | resourceManager.registerActionHandlers / resourceManager.define / i18n / ACL / workflow；ACL 和 scheduler 待验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `rollbackRuntimeRegistration` | 将草案能力落到真实 NocoBase 隔离工程。 | resourceManager.registerActionHandlers / resourceManager.define / i18n / ACL / workflow；ACL 和 scheduler 待验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |

## Page Adapter 映射

| 草案方法 | 目标真实能力 | 可能的 NocoBase API | 官方来源 | 验证状态 | 替代方案 | 风险 | 下一步 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `registerMenus` | 将草案能力落到真实 NocoBase 隔离工程。 | client router / pluginSettingsManager / UI Schema；业务页面 schema API 待验证 | official_docs + unknown | 部分 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `registerPages` | 将草案能力落到真实 NocoBase 隔离工程。 | client router / pluginSettingsManager / UI Schema；业务页面 schema API 待验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `registerBlocks` | 将草案能力落到真实 NocoBase 隔离工程。 | client router / pluginSettingsManager / UI Schema；业务页面 schema API 待验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `registerFilters` | 将草案能力落到真实 NocoBase 隔离工程。 | client router / pluginSettingsManager / UI Schema；业务页面 schema API 待验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `registerPageActions` | 将草案能力落到真实 NocoBase 隔离工程。 | client router / pluginSettingsManager / UI Schema；业务页面 schema API 待验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `validatePageRegistration` | 将草案能力落到真实 NocoBase 隔离工程。 | client router / pluginSettingsManager / UI Schema；业务页面 schema API 待验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `rollbackPageRegistration` | 将草案能力落到真实 NocoBase 隔离工程。 | client router / pluginSettingsManager / UI Schema；业务页面 schema API 待验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |

## Seed Data Adapter 映射

| 草案方法 | 目标真实能力 | 可能的 NocoBase API | 官方来源 | 验证状态 | 替代方案 | 风险 | 下一步 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `importEntity` | 将草案能力落到真实 NocoBase 隔离工程。 | repository CRUD / resource action / transaction；依赖和唯一键检查待验证 | local_project + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `importEntities` | 将草案能力落到真实 NocoBase 隔离工程。 | repository CRUD / resource action / transaction；依赖和唯一键检查待验证 | local_project + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `checkDependencies` | 将草案能力落到真实 NocoBase 隔离工程。 | repository CRUD / resource action / transaction；依赖和唯一键检查待验证 | local_project + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `checkUniqueKeys` | 将草案能力落到真实 NocoBase 隔离工程。 | repository CRUD / resource action / transaction；依赖和唯一键检查待验证 | local_project + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `rollbackImport` | 将草案能力落到真实 NocoBase 隔离工程。 | repository CRUD / resource action / transaction；依赖和唯一键检查待验证 | local_project + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `validateImportResult` | 将草案能力落到真实 NocoBase 隔离工程。 | repository CRUD / resource action / transaction；依赖和唯一键检查待验证 | local_project + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |

## Smoke Test Adapter 映射

| 草案方法 | 目标真实能力 | 可能的 NocoBase API | 官方来源 | 验证状态 | 替代方案 | 风险 | 下一步 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `runEnvironmentSmokeTest` | 将草案能力落到真实 NocoBase 隔离工程。 | 插件加载、资源动作、权限、页面、文件、workflow、回滚 smoke；大多待完整工程验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `runPluginLoadSmokeTest` | 将草案能力落到真实 NocoBase 隔离工程。 | 插件加载、资源动作、权限、页面、文件、workflow、回滚 smoke；大多待完整工程验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `runCoreBusinessSmokeTest` | 将草案能力落到真实 NocoBase 隔离工程。 | 插件加载、资源动作、权限、页面、文件、workflow、回滚 smoke；大多待完整工程验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `runPermissionSmokeTest` | 将草案能力落到真实 NocoBase 隔离工程。 | 插件加载、资源动作、权限、页面、文件、workflow、回滚 smoke；大多待完整工程验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `runGpsMockSmokeTest` | 将草案能力落到真实 NocoBase 隔离工程。 | 插件加载、资源动作、权限、页面、文件、workflow、回滚 smoke；大多待完整工程验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `runContractDocumentSmokeTest` | 将草案能力落到真实 NocoBase 隔离工程。 | 插件加载、资源动作、权限、页面、文件、workflow、回滚 smoke；大多待完整工程验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `runRollbackSmokeTest` | 将草案能力落到真实 NocoBase 隔离工程。 | 插件加载、资源动作、权限、页面、文件、workflow、回滚 smoke；大多待完整工程验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |

## Backup / Rollback Adapter 映射

| 草案方法 | 目标真实能力 | 可能的 NocoBase API | 官方来源 | 验证状态 | 替代方案 | 风险 | 下一步 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `backupDatabase` | 将草案能力落到真实 NocoBase 隔离工程。 | pg_dump/pg_restore、storage snapshot、CLI plugin disable、Migration；官方备份 API 待验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `backupStorage` | 将草案能力落到真实 NocoBase 隔离工程。 | pg_dump/pg_restore、storage snapshot、CLI plugin disable、Migration；官方备份 API 待验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `backupPluginStorage` | 将草案能力落到真实 NocoBase 隔离工程。 | pg_dump/pg_restore、storage snapshot、CLI plugin disable、Migration；官方备份 API 待验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `snapshotSchema` | 将草案能力落到真实 NocoBase 隔离工程。 | pg_dump/pg_restore、storage snapshot、CLI plugin disable、Migration；官方备份 API 待验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `restoreDatabase` | 将草案能力落到真实 NocoBase 隔离工程。 | pg_dump/pg_restore、storage snapshot、CLI plugin disable、Migration；官方备份 API 待验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `restoreStorage` | 将草案能力落到真实 NocoBase 隔离工程。 | pg_dump/pg_restore、storage snapshot、CLI plugin disable、Migration；官方备份 API 待验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `disablePlugin` | 将草案能力落到真实 NocoBase 隔离工程。 | pg_dump/pg_restore、storage snapshot、CLI plugin disable、Migration；官方备份 API 待验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `cleanupSeedData` | 将草案能力落到真实 NocoBase 隔离工程。 | pg_dump/pg_restore、storage snapshot、CLI plugin disable、Migration；官方备份 API 待验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |
| `preserveLogs` | 将草案能力落到真实 NocoBase 隔离工程。 | pg_dump/pg_restore、storage snapshot、CLI plugin disable、Migration；官方备份 API 待验证 | official_docs + unknown | 待验证 | 保持 dry-run 或在完整工程中用 mock/fixture 验证。 | 若误认为已验证会造成伪造 API 或污染数据库。 | 固定目标版本后读取源码、写最小 adapter、只在隔离库验证。 |

## 最小可行真实 adapter 范围

下一阶段最小可行范围不是一次性实现全部 adapter，而是：

1. 锁定目标版本和源码 tag。
2. 创建完整 NocoBase 源码测试工程。
3. 只接入 `plugin-rental-core` 的最小 Collection 与一个只读 smoke action。
4. 验证插件加载、Collection 同步、资源动作、权限读取、i18n、日志和回滚边界。
5. 通过后再扩展到合同文件、IOPGPS mock、页面、Seed Data 和备份/回滚。
