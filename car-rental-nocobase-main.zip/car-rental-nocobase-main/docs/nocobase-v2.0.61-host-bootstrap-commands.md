# NocoBase v2.0.61 宿主工程准备命令清单草案

## 使用边界

- 本文命令全部为“人工执行”草案。
- 本轮不要执行这些命令。
- 命令仅作为后续人工或 Codex in host 工程任务参考。
- target_version = v2.0.61。
- package_manager = yarn。
- database = postgresql。
- deployment_mode = source_host。
- plugin_development_mode = packages_plugins。
- plugin_install_mode = packages_plugins。
- iopgps_real_sync_allowed = false。
- mock_data_only = true。
- 禁止在当前仓库 clone NocoBase 源码；不 clone NocoBase 源码到当前仓库。
- 禁止提交完整 NocoBase 源码，不提交完整 NocoBase 源码。
- 禁止不使用隔离库验证；不使用生产库，不在生产库验证。
- 禁止复制 `.env`、`.env.test`、`filled.json`、`*confirmed*.json`。
- 当前不能 production_ready，当前仍不能正式上线测试，当前仍不能生产部署。

## 命令草案

| 步骤 | 命令草案 | 是否自动执行 | 是否需要人工确认 | 是否禁止在当前仓库执行 |
| --- | --- | --- | --- | --- |
| 创建项目目录 | `mkdir -p /volume1/projects /volume1/docker/nocobase-car-lease-test/storage-test/nocobase /volume1/docker/nocobase-car-lease-test/storage-test/postgres /volume1/docker/nocobase-car-lease-test/backups-test /volume1/docker/nocobase-car-lease-test/logs-test` | false | true | true |
| 获取 NocoBase v2.0.61 源码 | `git clone --branch v2.0.61 --depth 1 https://github.com/nocobase/nocobase.git /volume1/projects/nocobase-host-v2.0.61` | false | true | true |
| 切换到 v2.0.61 | `cd /volume1/projects/nocobase-host-v2.0.61 && git checkout v2.0.61` | false | true | true |
| 检查 package manager | `cd /volume1/projects/nocobase-host-v2.0.61 && corepack enable && yarn --version` | false | true | true |
| 安装依赖 | `cd /volume1/projects/nocobase-host-v2.0.61 && yarn install --ignore-scripts` | false | true | true |
| 准备测试数据库 | `cd /volume1/docker/nocobase-car-lease-test && docker compose up -d postgres` | false | true | true |
| 准备 storage | `mkdir -p /volume1/docker/nocobase-car-lease-test/storage-test/nocobase /volume1/docker/nocobase-car-lease-test/storage-test/postgres` | false | true | true |
| 禁用真实 IOPGPS | `printf 'IOPGPS_SYNC_ENABLED=false\nIOPGPS_REAL_SYNC_ALLOWED=false\n' >> /volume1/projects/nocobase-host-v2.0.61/.env.test` | false | true | true |
| 创建集成分支 | `cd /volume1/projects/nocobase-host-v2.0.61 && git checkout -b car-rental-v2.0.61-integration` | false | true | true |
| 复制插件 | `rsync -a --exclude '.env' --exclude '.env.test' --exclude 'storage-test' --exclude 'backups-test' --exclude 'logs-test' --exclude 'node_modules' --exclude 'test-runtime' --exclude 'filled.json' --exclude '*confirmed*.json' /volume1/projects/car-rental-nocobase/packages/plugins/plugin-rental-core/ /volume1/projects/nocobase-host-v2.0.61/packages/plugins/plugin-rental-core/` | false | true | true |
| 复制合同插件 | `rsync -a --exclude '.env' --exclude '.env.test' --exclude 'storage-test' --exclude 'backups-test' --exclude 'logs-test' --exclude 'node_modules' --exclude 'test-runtime' --exclude 'filled.json' --exclude '*confirmed*.json' /volume1/projects/car-rental-nocobase/packages/plugins/plugin-contract-documents/ /volume1/projects/nocobase-host-v2.0.61/packages/plugins/plugin-contract-documents/` | false | true | true |
| 复制 IOPGPS 插件 | `rsync -a --exclude '.env' --exclude '.env.test' --exclude 'storage-test' --exclude 'backups-test' --exclude 'logs-test' --exclude 'node_modules' --exclude 'test-runtime' --exclude 'filled.json' --exclude '*confirmed*.json' /volume1/projects/car-rental-nocobase/packages/plugins/plugin-iopgps/ /volume1/projects/nocobase-host-v2.0.61/packages/plugins/plugin-iopgps/` | false | true | true |
| 复制 shared automation | `rsync -a --exclude '.env' --exclude '.env.test' --exclude 'storage-test' --exclude 'backups-test' --exclude 'logs-test' --exclude 'node_modules' --exclude 'test-runtime' --exclude 'filled.json' --exclude '*confirmed*.json' /volume1/projects/car-rental-nocobase/packages/shared/nocobase-automation/ /volume1/projects/nocobase-host-v2.0.61/packages/shared/nocobase-automation/` | false | true | true |
| 运行类型检查 | `cd /volume1/projects/nocobase-host-v2.0.61 && yarn typecheck` | false | true | true |
| 运行 NocoBase 开发环境 | `cd /volume1/projects/nocobase-host-v2.0.61 && yarn dev` | false | true | true |

## 执行前复核

- 人工确认宿主工程目录不在当前项目仓库内。
- 人工确认 `.env.test` 只在宿主工程或 Docker runtime 中创建，且不进入 Git。
- 人工确认 IOPGPS 真实同步禁用。
- 人工确认使用隔离 postgresql 测试库，不使用生产库。
- 人工确认当前项目不变更为 production_ready。
