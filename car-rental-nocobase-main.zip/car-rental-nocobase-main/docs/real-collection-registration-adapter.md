# 真实 Collection 注册 Adapter 草案

## 1. 本轮范围

本轮实现的是“真实 Collection 注册 adapter 草案”，用于把现有 Collection plan 转换为真实 NocoBase Collection schema draft，并生成注册步骤、回滚计划、后置验证计划和安全检查报告。

当前实现仍然只属于计划层：

- 不连接真实 NocoBase。
- 不创建真实 Collections。
- 不执行 migration。
- 不写数据库。
- 不调用 `app.collection`。
- 不调用 `db.collection`。
- 不伪造真实 NocoBase API 成功。

## 2. 当前产物

- `realCollectionSchemaMapper.ts`：把 Collection plan 映射为 schema draft。
- `realCollectionSafetyChecker.ts`：校验真实注册前的安全边界和业务禁用项。
- `realCollectionRegistrationAdapter.ts`：生成真实注册草案计划、步骤、回滚计划和后置验证计划。
- `generate-real-collection-registration-plan.ts`：读取自动化注册计划并输出草案文件。
- `validate-real-collection-registration-plan.ts`：校验草案文件仍处于安全的 `plan_only` 边界。

输出文件为：`test-data/generated/real-collection-registration-plan.generated.json`。

## 3. 字段类型映射策略

字段映射只生成草案，不作为真实 NocoBase API 请求体：

| 计划字段类型 | schema draft 类型 | 说明 |
| --- | --- | --- |
| `text` / `string` | `text` | 文本草案。 |
| `integer` | `integer` | 整数字段草案。 |
| `number` / `decimal` | `decimal` | 金额、里程等数值字段暂按 decimal 草案处理，真实精度后续确认。 |
| `boolean` | `boolean` | 布尔字段草案。 |
| `date` | `date` | 日期字段草案。 |
| `datetime` | `datetime` | 日期时间字段草案。 |
| `enum` | `select` | 枚举暂映射为 select/enum 草案，真实选项结构后续确认。 |
| `json` | `json` | 结构化数据草案。 |
| `file` / `fileList` | `file` | 文件/附件草案，真实存储、权限和脱敏后续确认。 |
| `relation` | `relation` | 关系草案，本轮不注册真实关系。 |
| `password` / `encrypted` | `password` / `encrypted` | 标记为需要真实 NocoBase 安全字段能力验证。 |

无法确认的字段类型会写入 `unsupportedFeatures` 和字段级 `unsupportedReason`，不得硬写成确定 API。

## 4. relation 映射策略

关系映射保留以下信息：

- `sourceCollection`
- `sourceField`
- `targetCollection`
- `relationType`
- `foreignKey`
- `targetKey`

`belongsTo`、`hasMany`、`hasOne`、`belongsToMany` 与跨插件引用都只作为计划保存。本轮不真实注册 relation，也不创建外键。

## 5. 唯一约束映射策略

唯一约束从 `uniqueConstraints` 和唯一索引计划中提取并保留。草案 adapter 只校验约束是否仍在计划内，不执行数据库唯一索引创建。

## 6. 敏感字段映射策略

`sensitiveFields` 必须完整保留。字段草案中的 `sensitive=true` 会附加权限提示。未来真实 adapter 必须接入字段级权限、脱敏、导出限制和文件访问控制。

## 7. 安全检查要求

安全检查包括：

- 默认模式不能是 `real`。
- `mode=real` 必须显式 `allowRealExecution=true`。
- `mode=real` 必须要求备份。
- `mode=real` 必须要求回滚方案。
- adapter 环境必须 `ready` 才可能进入真实执行评审。
- 当前仓库环境禁止执行 `real`。
- 禁止真实数据库写入。
- 禁止缺少回滚计划。
- 禁止在当前仓库执行生产环境真实注册。
- 禁止短租、预订、司机登录、客户门户和按车型出租 Collection。
- 禁止 GPS 数据参与租金计算。
- 禁止押金计入租金已付。

## 8. 为什么当前不能执行 real 模式

当前仓库没有真实 NocoBase app、db、collection manager、migration、transaction、备份和回滚运行时，也没有生产审批与人工恢复流程。因此即使 schema draft 校验通过，也不能在当前仓库执行真实 Collection 注册。

## 9. 未来真实 adapter 替换路径

下一阶段如要进入真实接入设计，必须先完成：

1. 接入真实 NocoBase app。
2. 接入真实 db。
3. 接入 collection manager。
4. 接入 migration / transaction。
5. 接入备份与回滚方案。
6. 接入真实执行前审批开关。
7. 接入后置 schema 对账和失败恢复流程。

## 10. 进入下一阶段的条件

- 草案 schema、字段映射、关系、唯一约束和敏感字段通过评审。
- 真实 NocoBase 测试环境可用，并具备可恢复备份。
- 明确 collection manager 与 migration API 的真实调用方式。
- 明确事务和失败回滚策略。
- 明确禁止业务边界仍被自动校验。
- 明确本项目仍不是短租预订、司机自助登录或按车型出租系统。
