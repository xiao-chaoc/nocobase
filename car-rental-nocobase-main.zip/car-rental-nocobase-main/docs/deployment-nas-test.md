# Synology NAS 测试部署方案

## 测试部署目标

本方案只用于后续 NAS 测试环境准备，目标是验证：

- NocoBase 容器能够启动。
- PostgreSQL 容器能够启动。
- `storage-test/nocobase` 作为 NocoBase storage 测试目录挂载正常。
- `storage-test/postgres` 作为 PostgreSQL 测试数据库目录挂载正常。
- `templates` 模板目录以测试模板目录形式挂载正常。
- 后续插件接入测试具备基础运行环境。

当前不能验证：

- 完整插件启用。
- 完整业务页面。
- 收租日历 UI。
- 真实 IOPGPS 同步。
- 真实合同 PDF 生成。
- 真实权限配置。
- 真实业务上线。

## 推荐 NAS 目录结构

建议把源码目录和 Docker 运行目录分开：

```bash
/volume1/projects/car-rental-nocobase
/volume1/docker/nocobase-car-lease-test
```

- `/volume1/projects` 用于 GitHub 项目源码。
- `/volume1/docker` 用于 NocoBase 测试运行环境。
- 两者不要混在一起。
- 不要把 Git 仓库目录当作 NocoBase storage。
- 不要把真实数据、真实上传文件或真实数据库文件放进 Git 仓库。

## GitHub 项目拉取步骤

```bash
mkdir -p /volume1/projects
cd /volume1/projects
git clone <你的仓库地址> car-rental-nocobase
```

私有仓库需要使用 SSH key 或 GitHub token。不要把 token 写进项目文件，不要提交任何凭据。

## 文件获取注意事项

- 推荐直接在 NAS 上通过 `git clone` 获取仓库。
- 不要使用浏览器“另存为页面”保存 GitHub 文件；这样容易得到 HTML 页面而不是 YAML、env 或脚本原始内容。
- 如果必须手动下载文件，应点击 GitHub 的 Raw 原始文件内容后再保存。
- 复制到测试运行目录的 `docker-compose.test.yml`、`.env.test.example`、`templates/` 必须来自仓库原始文件内容，不应复制 GitHub HTML 页面。

## 测试运行目录准备步骤

```bash
mkdir -p /volume1/docker/nocobase-car-lease-test
cd /volume1/docker/nocobase-car-lease-test
mkdir -p storage-test/nocobase
mkdir -p storage-test/postgres
mkdir -p backups-test
mkdir -p logs-test
mkdir -p templates
```

目录用途：

- `storage-test/nocobase`：NocoBase storage 测试目录。
- `storage-test/postgres`：PostgreSQL 测试数据库目录。
- `backups-test`：测试备份目录。
- `logs-test`：测试日志目录。
- `templates`：合同模板测试挂载目录。

请保持边界清晰：不要把 PostgreSQL 数据目录放在 NocoBase storage 根目录下，不要继续使用 `./storage-test:/app/nocobase/storage` 这种混合挂载，也不要把真实业务文件放进测试运行目录后再提交到 Git。

## 拷贝文件步骤

从 Git 仓库原始文件复制以下内容到测试运行目录：

```bash
cp /volume1/projects/car-rental-nocobase/docker-compose.test.yml .
cp /volume1/projects/car-rental-nocobase/.env.test.example .
cp -R /volume1/projects/car-rental-nocobase/templates .
cp .env.test.example .env.test
```

请修改 `.env.test` 中的 `APP_KEY`、`DB_PASSWORD`、`INIT_ROOT_PASSWORD` 等测试专用值。`.env.test` 不进入 Git。`APP_KEY` 在测试环境创建后不要随意修改，否则可能导致已有测试数据无法解密或登录异常。

## 启动命令

```bash
docker compose -f docker-compose.test.yml --env-file .env.test pull
docker compose -f docker-compose.test.yml --env-file .env.test up -d
docker compose -f docker-compose.test.yml --env-file .env.test logs -f nocobase
```

## 访问地址

```text
http://NAS_IP:13000
```

## Synology Container Manager 使用说明

- 可以在 Container Manager 中创建 Project。
- Project 使用 `docker-compose.test.yml`。
- 环境变量使用 `.env.test`。
- 注意区分项目源码目录和测试运行目录。
- 不要把 Git 仓库目录当作 `storage` 数据目录。
- 不要把真实业务文件放入测试运行目录后再提交到 Git。
- 确认 `storage-test/nocobase` 和 `storage-test/postgres` 均存在且 NAS 当前用户有读写权限。

## 停止和清理命令

停止测试环境：

```bash
docker compose -f docker-compose.test.yml --env-file .env.test down
```

清理 `storage-test/nocobase` 会删除 NocoBase 测试 storage，清理 `storage-test/postgres` 会删除 PostgreSQL 测试数据库文件。执行前必须确认不包含真实数据。可以参考 `scripts/clean-nas-test-runtime.sh`，但该脚本仍然只是测试环境草案，不用于生产。

## 测试边界

- 当前只是基础环境测试。
- 插件还未真实启用。
- 不能用于生产。
- 不能放真实司机数据。
- 不能放真实付款截图。
- 不能放真实合同扫描件。
- 不能配置真实 IOPGPS 密钥。
- 当前不能验证完整业务页面、收租日历 UI、真实权限配置、真实合同 PDF 生成或真实 IOPGPS 同步。
- 不要在本测试 Compose 中声称三个插件已经自动可用；插件仍需真实 NocoBase 工程适配、构建和安装验证。
- 本测试 Compose 不直接挂载 `packages/plugins`。

## 测试前最终自检

真正复制到 NAS 测试目录前，建议先在仓库根目录运行：

```bash
npm run check:plugin-structure
npm run check:plugin-registration
npm run preflight:nas-test
```

这些命令只做插件结构、注册描述和测试准备文件检查，不会连接数据库，不会调用 NocoBase，不会调用 IOPGPS，也不会生成真实合同文件。Smoke Test 清单见 `docs/nas-smoke-test-checklist.md`，完整执行顺序见 `docs/nas-test-runbook.md`。

## 自动化正式上线测试说明

当前 NAS 测试环境能启动官方 NocoBase + PostgreSQL，但登录后为空应用是正常状态。用户不需要手动在 NocoBase UI 中创建 Collections、页面、菜单、权限或测试数据；后续正式上线测试必须等待 Codex 自动化完成插件安装、Collection 注册、页面初始化、权限初始化、mock 数据导入和 smoke test。

在这些自动化能力完成前，本测试环境只用于基础环境验证，不能用于正式上线测试，更不能用于生产上线。

## 2026-06-05 补充：NAS 测试中的 Backup / Rollback 草案

NAS 测试部署进入真实 NocoBase 验证前，必须先生成并评审 `test-data/generated/real-backup-rollback-plan.generated.json`。当前脚本只生成草案，不调用 `scripts/backup-test-db.sh`、不调用 `scripts/restore-test-db.sh`、不删除 NAS storage、不读取 `.env.test` 真实值。

在未来隔离 NAS 测试目录中允许真实演练前，必须确认：

- 测试数据库只包含 mock 数据。
- `.env.test` 不进入 Git，且不在报告中输出真实值。
- `backups-test/`、`storage-test/`、`logs-test/` 不进入 Git。
- IOPGPS 真实同步禁用。
- 操作人手工确认备份和恢复步骤。

## 2026-06-05 复核补充：NAS 备份回滚草案边界

NAS 测试部署文档中的 Backup / Rollback 内容仅用于计划评审。当前仓库生成的草案不得在 NAS 上直接执行真实 `pg_dump`、`pg_restore`、storage 删除或插件回滚；进入 NAS 隔离测试前必须先确认测试库、mock 数据、备份目录、回滚目录和 IOPGPS 禁用状态。
