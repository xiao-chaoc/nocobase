# NAS 测试执行顺序

## 1. 测试目标

验证 NAS 上 NocoBase + PostgreSQL 基础测试环境、测试数据、插件接入准备文件和安全边界是否满足后续插件集成测试要求。

## 2. 测试边界

- 不做生产上线。
- 不启用真实业务数据。
- 不连接真实 IOPGPS。
- 不生成真实合同文件。
- 不上传真实文件。
- 不声称当前插件已经生产可用。

## 3. 测试人员需要准备的内容

- NAS 上可用的 Docker / Container Manager。
- GitHub 仓库访问权限。
- 测试专用 `.env.test`。
- 测试专用 `APP_KEY` 和测试密码。
- 独立测试目录，不与 Git 仓库源码目录混用。

## 4. 从 GitHub 拉取仓库

```bash
mkdir -p /volume1/projects
cd /volume1/projects
git clone <你的仓库地址> car-rental-nocobase
cd car-rental-nocobase
```

私有仓库使用 SSH key 或 GitHub token，凭据不得写入项目文件。

## 4.1 文件获取注意事项

- 推荐通过 `git clone` 获取项目源码。
- 不要从 GitHub 页面直接“另存为”文件，否则可能保存为 HTML 页面。
- 手动下载时必须点击 Raw 获取原始文件内容。
- 复制到 NAS 的 `docker-compose.test.yml` 必须是 YAML 原始内容，不是 GitHub HTML 页面。


## 5. 运行本地检查

```bash
npm run typecheck
npm run test
npm run seed:test-data
npm run validate:test-data
npm run check:plugin-structure
npm run check:plugin-registration
npm run preflight:nas-test
```

## 6. 复制测试文件到 NAS 测试目录

```bash
mkdir -p /volume1/docker/nocobase-car-lease-test
cd /volume1/docker/nocobase-car-lease-test
cp /volume1/projects/car-rental-nocobase/docker-compose.test.yml .
cp /volume1/projects/car-rental-nocobase/.env.test.example .
cp -R /volume1/projects/car-rental-nocobase/templates .
mkdir -p storage-test/nocobase
mkdir -p storage-test/postgres
mkdir -p backups-test
mkdir -p logs-test
mkdir -p templates
```

`docker-compose.test.yml` 中的挂载边界必须保持清晰：

- NocoBase storage 对应 `storage-test/nocobase`。
- PostgreSQL 数据对应 `storage-test/postgres`。
- 两者不要混放，不要继续使用 `./storage-test:/app/nocobase/storage`。
- 当前测试 Compose 不直接挂载 `packages/plugins`，插件接入仍需后续真实 NocoBase 插件流程。


## 7. 创建 `.env.test`

```bash
cp .env.test.example .env.test
```

修改测试密码和 `APP_KEY`。测试环境创建后不要随意修改 `APP_KEY`。

## 8. 启动 NocoBase + PostgreSQL

```bash
docker compose -f docker-compose.test.yml --env-file .env.test pull
docker compose -f docker-compose.test.yml --env-file .env.test up -d
```

## 9. 浏览器访问

访问：

```text
http://NAS_IP:13000
```

## 10. 记录测试结果

记录以下内容：

- 启动时间。
- 容器状态。
- 访问地址。
- 初始化账号是否成功。
- 日志中是否有严重错误。
- `storage-test/nocobase` 是否作为 NocoBase storage 挂载成功。
- `storage-test/postgres` 是否作为 PostgreSQL 数据目录挂载成功。
- `templates` 是否以测试模板目录挂载成功。

## 11. 停止环境

```bash
docker compose -f docker-compose.test.yml --env-file .env.test down
```

## 12. 备份和恢复

备份测试库可参考：

```bash
scripts/backup-test-db.sh
```

恢复测试库可参考：

```bash
scripts/restore-test-db.sh backups-test/<dump文件>
```

这两个脚本只用于测试环境，不是生产备份或恢复方案。

## 13. 清理测试数据

清理运行目录可参考：

```bash
scripts/clean-nas-test-runtime.sh /volume1/docker/nocobase-car-lease-test
```

执行前必须确认目录中没有真实数据。

## 14. 常见问题


### docker compose 报 YAML 解析错误

检查是否误保存了 GitHub HTML 页面。应使用 `git clone` 获取仓库，或在 GitHub 点击 Raw 保存原始 YAML。

### 容器启动但找不到 `.env.test`

检查是否已经从 `.env.test.example` 复制为 `.env.test`，并确认 Compose 命令指定了 `--env-file .env.test`。

### 数据混放问题

检查是否仍使用 `./storage-test:/app/nocobase/storage`。正确结构应为 NocoBase 使用 `storage-test/nocobase`，PostgreSQL 使用 `storage-test/postgres`。

### 端口 13000 被占用

更换测试端口或停止占用端口的测试服务，不要直接占用生产端口。

### PostgreSQL 启动失败

检查 `.env.test` 中数据库用户名、密码、数据库名和 `storage-test/postgres` 权限。

### APP_KEY 修改导致登录异常

测试环境创建后不要随意修改 `APP_KEY`。如果已经修改，可能需要清理测试环境并重新初始化。

### storage 权限问题

检查 NAS 文件夹权限，确认容器可以读写 `storage-test/nocobase` 和 `storage-test/postgres`。

### Container Manager 项目路径错误

确认 Project 指向测试运行目录，而不是 Git 仓库源码目录。

### 忘记创建 `.env.test`

从 `.env.test.example` 复制并填写测试占位值，`.env.test` 不得提交。

## 15. 当前不做生产上线

本 runbook 只用于测试前准备和基础 Smoke Test，不是生产部署手册。

## 2026-06-05 补充：Backup / Rollback 草案运行步骤

当前运行手册只允许执行草案生成与校验：

1. 执行 `npm run generate:real-backup-rollback-plan` 生成备份、回滚和失败恢复草案。
2. 执行 `npm run validate:real-backup-rollback-plan` 校验草案未进入 `real` 模式、未标记已执行、未包含真实密钥或 `.env.test` 真实值。
3. 将生成报告作为进入真实 NocoBase 隔离测试前的评审材料。

当前不得在本仓库通过该 adapter 执行真实 `pg_dump`、`pg_restore`、文件删除、storage 恢复、插件禁用或 NocoBase schema 修改。

## 2026-06-05 复核补充：Backup / Rollback 草案校验

运行 `npm run generate:real-backup-rollback-plan` 与 `npm run validate:real-backup-rollback-plan` 只能证明草案结构、安全边界和敏感信息检查通过。它不代表已完成真实数据库备份、文件存储 snapshot、插件状态恢复或 smoke test 失败回滚演练。

## 2026-06-06 NAS 测试前真实接入补充

NAS 测试环境不应作为源码插件的第一调试地点。推荐先在完整 NocoBase 源码工程中完成真实 adapter 验证，再构建 `plugin-rental-core`、`plugin-contract-documents`、`plugin-iopgps` 插件包，并在 NAS 测试环境中安装和启用。

当前所有真实 Adapter 草案已经覆盖 Collection、Runtime、Page、Seed Data、Smoke Test、Backup / Rollback，但这些仍是草案和计划层能力。下一阶段不是继续新增草案，而是在完整 NocoBase 工程中实现真实 adapter。当前仓库仍不能正式上线测试，也不能生产部署。

NAS 测试前必须确认：隔离数据库、隔离 storage、测试专用 APP_KEY、测试管理员账号、权限测试账号、mock 数据、备份目录、日志目录、文件上传测试目录和回滚演练均已准备完成，并且 `IOPGPS_SYNC_ENABLED=false`。
