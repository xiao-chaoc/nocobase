# 核心服务方法和业务流程设计（第一版）

## 设计原则

- 本文只描述服务端业务方法和流程，不包含 TypeScript 实现代码、插件实现代码或前端页面设计。
- 所有关键校验必须在服务端执行，不能只依赖前端页面隐藏、禁用按钮或表单校验。
- 司机不登录系统，不设计司机账号、司机端流程或司机自助操作。
- 系统不做短租预订，不按车型出租；合同必须绑定 `vehicles` 中的具体车辆和车牌。
- GPS 和 IOPGPS 数据只用于车辆位置、里程、设备状态和运营核查，不参与租金计算、欠款计算、免租日判断或付款状态判断。
- 每日租金台账 `rent_daily_ledgers` 是应收、已付、欠款、免除、未来应收、日历显示和司机对账的唯一事实来源。
- 付款必须通过 `rent_payment_allocations` 分配到具体租金日期；单日不可超付，任一日期超付时整次付款操作失败并回滚。
- 当前欠款只统计截至当前日期的未结清应收日期，未来应收必须单独统计，不得计入当前欠款。
- 未付日期必须有未付原因；部分付款或未结清余额必须有差额处理方式。
- 敏感字段必须经过服务端权限过滤，普通运营角色不能看到全部敏感财务数据。

## 通用返回结构建议

- 成功结果：`success = true`、`data`、`warnings`。
- 失败结果：`success = false`、`error_code`、`message`、`details`。
- 批量或事务方法必须返回整体成功或整体失败，不允许在超付、权限不足、合同冲突等关键场景中部分成功。

## 一、编号生成服务

### 1. `generateBusinessNo(prefix)`

- 方法名称：`generateBusinessNo(prefix)`
- 业务目的：为司机、车辆、合同、每日租金台账、付款、押金、合同文件、GPS 记录、操作日志等对象生成可读且唯一的业务编号。
- 输入参数：
  - `prefix`：对象前缀，例如 `DRV`、`VEH`、`CON`、`LED`、`PAY`、`DEP`、`DOC`、`GPS`、`LOG`。
- 输出结果：
  - `business_no`：生成的业务编号。
  - `sequence_date`：编号使用的日期段。
  - `sequence_value`：当日递增序号。
- 前置校验：
  - `prefix` 必须在允许清单内。
  - 调用方必须具备创建目标对象的权限。
- 处理步骤：
  1. 按对象前缀区分编号空间。
  2. 建议编号格式为 `{prefix}-{yyyyMMdd}-{六位递增序号}`，例如 `CON-20260601-000001`。
  3. 按日期生成序号，每个前缀每天从 `000001` 递增。
  4. 使用数据库事务、行级锁或独立序列表避免并发重复。
  5. 写入目标 Collection 时仍依赖数据库唯一约束兜底。
- 状态变更：
  - 更新编号序列表的当前值。
  - 不直接改变业务对象状态。
- 关联 Collection：
  - 所有包含 `*_no` 的业务 Collection。
  - 可选内部序列 Collection，后续实现时再确认名称。
- 权限要求：
  - 只能由服务端内部调用；普通用户不能直接指定序号。
- 失败场景：
  - 前缀非法。
  - 序列表加锁失败或事务冲突。
  - 写入目标对象时触发唯一约束冲突。
  - 数据库不可用。
- 操作日志要求：
  - 普通编号生成不单独写业务日志；若连续失败或出现唯一冲突，应写入 `operation_logs` 或系统异常日志。
- 验收测试点：
  - 同一前缀同一天并发生成编号不重复。
  - 不同前缀同一天序号互不影响。
  - 写入目标表时唯一约束能兜底拦截重复编号。

## 二、车辆和合同可用性服务

### 2. `checkVehicleContractAvailability(vehicle_id, start_date, end_date_or_null, exclude_contract_id)`

- 方法名称：`checkVehicleContractAvailability(vehicle_id, start_date, end_date_or_null, exclude_contract_id)`
- 业务目的：检查某个具体车牌在目标日期范围内是否已有占用车辆的合同，防止同一车辆存在冲突有效合同。
- 输入参数：
  - `vehicle_id`：车辆标识。
  - `start_date`：目标开始日期。
  - `end_date_or_null`：目标结束日期；长租合同可为空。
  - `exclude_contract_id`：编辑现有合同时排除当前合同，可为空。
- 输出结果：
  - `available`：是否可用。
  - `conflict_contracts`：冲突合同摘要。
  - `checked_range`：检查范围。
- 前置校验：
  - `vehicle_id` 必须存在且未出售、未停用。
  - `start_date` 必须有效。
  - 若 `end_date_or_null` 有值，必须不早于 `start_date`。
- 处理步骤：
  1. 查询同一 `vehicle_id` 的合同。
  2. 排除 `exclude_contract_id` 指定合同。
  3. 草稿 `draft` 默认不占用车辆。
  4. `pending_signature`、`pending_deposit`、`pending_handover` 视为已进入履约准备，应占用车辆。
  5. `active`、`overdue`、`defaulted`、`terminating` 占用车辆。
  6. `completed`、`cancelled` 不占用车辆。
  7. 对时限合同使用 `[start_date, calculated_end_date]` 作为合同范围。
  8. 对长租合同：如有 `termination_date`，使用 `[start_date, termination_date]`；如无 `termination_date`，视为 `[start_date, 无限未来]`。
  9. 日期重叠判断：目标开始日期小于等于既有结束日期，且既有开始日期小于等于目标结束日期；任一结束日期为空时按无限未来处理。
- 状态变更：
  - 无状态变更，只返回检查结果。
- 关联 Collection：
  - `vehicles`
  - `lease_contracts`
- 权限要求：
  - 创建或激活合同的服务端流程可调用。
  - 运营、经理、系统管理员可触发检查；结果中的敏感财务字段不得返回。
- 失败场景：
  - 车辆不存在。
  - 日期非法。
  - 存在冲突合同。
  - 数据库查询失败。
- 操作日志要求：
  - 单纯检查不写日志。
  - 因冲突阻止合同激活时，应在合同激活失败记录中保留原因摘要。
- 验收测试点：
  - 时限合同范围重叠时返回不可用。
  - 未终止长租合同从开始日期起占用无限未来。
  - 已终止长租合同只占用至 `termination_date`。
  - 编辑合同时排除当前合同后不与自身冲突。
  - `completed`、`cancelled` 不占用车辆。

## 三、合同日期计算服务

### 3. `calculateFixedTermEndDate(start_date, term_months)`

- 方法名称：`calculateFixedTermEndDate(start_date, term_months)`
- 业务目的：根据开始日期和自然月租期计算时限合同结束日期。
- 输入参数：
  - `start_date`：合同开始日期。
  - `term_months`：自然月租期。
- 输出结果：
  - `calculated_end_date`：计算出的结束日期。
- 前置校验：
  - `start_date` 必须为有效日期。
  - `term_months` 必须为整数且大于等于 6。
- 处理步骤：
  1. 将 `start_date` 加 `term_months` 个自然月。
  2. 如目标月份没有开始日期对应的日，例如 1 月 31 日加 1 个月遇到 2 月，则先落到目标月份最后一天。
  3. 再减 1 天作为合同结束日期。
  4. 示例：1 月 31 日开始，6 个月目标月为 7 月 31 日，再减 1 天，结束日期为 7 月 30 日；如目标月份没有对应日期，则先按目标月最后一天再减 1 天。
- 状态变更：
  - 无状态变更。
- 关联 Collection：
  - `lease_contracts`
- 权限要求：
  - 创建或编辑合同的服务端流程可调用。
- 失败场景：
  - `term_months < 6`。
  - 日期非法。
- 操作日志要求：
  - 单纯计算不写日志；合同保存时记录计算结果。
- 验收测试点：
  - `term_months = 5` 必须报错。
  - 正常日期按自然月加租期再减一天。
  - 月底日期遇到目标月份天数不足时按目标月份最后一天处理。

## 四、合同创建与激活服务

### 4. `createLeaseContractDraft(input)`

- 方法名称：`createLeaseContractDraft(input)`
- 业务目的：创建合同草稿，保存司机、车辆、合同类型和计费规则，但不立即生成台账。
- 输入参数：
  - `driver_id`、`vehicle_id`、`contract_type`、`start_date`、`term_months`、`weekly_payable_days`、`default_free_weekdays`、`daily_rent_amount`、`deposit_required_amount`、`week_start_day`、`remark`。
- 输出结果：
  - 新建的合同草稿摘要。
- 前置校验：
  - 司机存在，且不是系统登录用户。
  - 司机 `risk_status` 不能为 `blacklisted`。
  - 车辆存在，必须是具体车牌，不允许只传车型。
  - 合同类型只能为 `open_ended` 或 `fixed_term`。
  - 时限合同 `term_months >= 6`。
  - 周付天数只能为 3、4、5、6、7。
  - 默认免租日通过 `validateDefaultFreeWeekdays`。
  - 押金金额必须大于等于 0。
  - 日租金必须大于 0。
- 处理步骤：
  1. 生成 `contract_no`。
  2. 时限合同调用 `calculateFixedTermEndDate`。
  3. 保存合同草稿，状态为 `draft`。
  4. 草稿合同不占用车辆。
  5. 草稿阶段不生成自然周账期和每日租金台账。
  6. 写入操作日志。
- 状态变更：
  - 新增 `lease_contracts`，`status = draft`。
- 关联 Collection：
  - `drivers`、`vehicles`、`lease_contracts`、`operation_logs`
- 权限要求：
  - 运营、经理、系统管理员可创建草稿。
  - 创建时不返回敏感财务汇总给无权限角色。
- 失败场景：
  - 司机黑名单。
  - 车辆不存在或不是可管理状态。
  - 合同类型、租期、周付天数、免租日、金额非法。
  - 编号生成失败。
- 操作日志要求：
  - 记录 `contract_created`，包含合同号、司机、车辆、合同类型、开始日期，不记录敏感文件。
- 验收测试点：
  - 草稿合同不生成台账。
  - 草稿合同不占用车辆。
  - 黑名单司机不能创建草稿或至少不能保存为可激活草稿；本设计选择阻止创建。
  - 默认免租日数量不匹配时报错。

### 5. `activateLeaseContract(contract_id)`

- 方法名称：`activateLeaseContract(contract_id)`
- 业务目的：将合同从待签署、待押金或待交车状态激活，并生成对应每日租金台账。
- 输入参数：
  - `contract_id`：合同标识。
- 输出结果：
  - 激活后的合同摘要。
  - 台账生成结果摘要。
- 前置校验：
  - 合同存在且未取消、未完成。
  - 司机不是黑名单。
  - 驾照未过期。
  - 合同已签署或符合线下签署要求。
  - 押金已收或已批准豁免。
  - 调用 `checkVehicleContractAvailability` 校验车辆无冲突合同。
  - 车辆状态允许出租，不能为 `maintenance`、`repair`、`blocked`、`sold`。
  - 合同计费规则完整：日租金、周付天数、默认免租日、周起始日均有效。
  - 默认免租日符合周付天数。
- 处理步骤：
  1. 开启事务。
  2. 锁定合同和车辆记录，防止并发激活冲突。
  3. 校验全部前置条件。
  4. 将合同状态改为 `active`。
  5. 将车辆 `availability_status` 改为 `rented`。
  6. 时限合同调用 `generateFixedTermDailyLedgers`。
  7. 长租合同调用 `ensureOpenEndedDailyLedgers`，使用系统配置的未来天数，例如 90 天。
  8. 刷新合同财务汇总。
  9. 写入操作日志。
  10. 提交事务。
- 状态变更：
  - `lease_contracts.status = active`。
  - `vehicles.availability_status = rented`。
  - 新增 `contract_billing_weeks` 与 `rent_daily_ledgers`。
- 关联 Collection：
  - `drivers`、`vehicles`、`lease_contracts`、`contract_billing_weeks`、`rent_daily_ledgers`、`deposit_records`、`contract_documents`、`operation_logs`
- 权限要求：
  - 经理、系统管理员或授权运营可激活。
  - 押金豁免涉及财务或经理审批权限。
- 失败场景：
  - 司机黑名单或驾照过期。
  - 合同未签署且不符合线下签署要求。
  - 押金未收且无豁免。
  - 车辆冲突或状态不可出租。
  - 台账生成违反唯一约束。
- 操作日志要求：
  - 成功记录 `contract_activated` 与 `ledger_generated`。
  - 失败记录激活失败原因摘要，不记录敏感附件。
- 验收测试点：
  - 激活时生成完整台账。
  - 车辆冲突时激活失败且不生成部分台账。
  - 驾照过期时激活失败。
  - 激活后车辆状态变为已出租。

## 五、自然周账期服务

### 6. `getNaturalWeekRange(date, week_start_day)`

- 方法名称：`getNaturalWeekRange(date, week_start_day)`
- 业务目的：根据指定日期和自然周起始日计算所属自然周范围。
- 输入参数：
  - `date`：目标日期。
  - `week_start_day`：周起始日，默认 `monday`。
- 输出结果：
  - `natural_week_start_date`。
  - `natural_week_end_date`。
- 前置校验：
  - 日期有效。
  - `week_start_day` 为允许枚举。
- 处理步骤：
  1. 以 `week_start_day` 为自然周第一天。
  2. 向前回溯至本周起始日。
  3. 起始日加 6 天得到结束日。
- 状态变更：无。
- 关联 Collection：
  - `lease_contracts`、`contract_billing_weeks`、`rent_daily_ledgers`
- 权限要求：服务端内部方法。
- 失败场景：日期或周起始日非法。
- 操作日志要求：单纯计算不写日志。
- 验收测试点：
  - 默认周一到周日。
  - 配置周日为起始日时范围正确变化。

### 7. `generateContractBillingWeeks(contract_id, from_date, to_date)`

- 方法名称：`generateContractBillingWeeks(contract_id, from_date, to_date)`
- 业务目的：为合同生成指定日期范围内的自然周账期。
- 输入参数：
  - `contract_id`、`from_date`、`to_date`。
- 输出结果：
  - 新增或已存在的自然周账期清单。
- 前置校验：
  - 合同存在。
  - 日期范围有效且在合同有效期内。
  - 合同计费规则完整。
- 处理步骤：
  1. 从 `from_date` 到 `to_date` 逐周计算自然周范围。
  2. 按 `contract_id + natural_week_start_date` 检查是否已存在。
  3. 不存在时创建 `contract_billing_weeks`。
  4. 保存 `week_start_day`、`weekly_payable_days`、`default_free_weekdays_snapshot`。
  5. 周汇总初始为 0，后续由每日台账和付款刷新。
- 状态变更：
  - 新增 `contract_billing_weeks`。
- 关联 Collection：
  - `lease_contracts`、`contract_billing_weeks`、`rent_daily_ledgers`
- 权限要求：合同激活、台账生成服务端流程调用。
- 失败场景：
  - 合同不存在。
  - 日期越界。
  - 唯一约束冲突。
- 操作日志要求：
  - 合同激活或台账生成总日志中记录账期生成数量。
- 验收测试点：
  - 同一合同同一自然周不会重复生成。
  - 账期保存默认免租日快照。

## 六、每日租金台账生成服务

### 8. `generateFixedTermDailyLedgers(contract_id)`

- 方法名称：`generateFixedTermDailyLedgers(contract_id)`
- 业务目的：为时限合同一次性生成整个合同周期每日租金台账。
- 输入参数：
  - `contract_id`。
- 输出结果：
  - 生成日期范围、生成台账数量、跳过已有数量。
- 前置校验：
  - 合同存在且 `contract_type = fixed_term`。
  - `start_date` 与 `calculated_end_date` 有效。
  - 计费规则完整且已锁定。
- 处理步骤：
  1. 开启事务。
  2. 生成合同周期内自然周账期。
  3. 从 `start_date` 到 `calculated_end_date` 逐日调用 `buildDailyLedgerForDate`。
  4. 按 `contract_id + rent_date` 检查是否已存在。
  5. 已存在且有付款、免除或手动调整时不得覆盖。
  6. 不存在时创建 `rent_daily_ledgers`。
  7. 默认免租日生成 `is_payable = false`、`payment_status = non_payable`。
  8. 应收日使用合同固定 `daily_rent_amount`。
  9. 刷新合同财务汇总。
  10. 写入操作日志。
- 状态变更：
  - 新增 `contract_billing_weeks`、`rent_daily_ledgers`。
  - 更新 `lease_contracts.total_due_amount`、`future_receivable_amount` 等汇总。
- 关联 Collection：
  - `lease_contracts`、`contract_billing_weeks`、`rent_daily_ledgers`、`operation_logs`
- 权限要求：合同激活服务或系统管理员触发；不能由普通前端直接绕过。
- 失败场景：
  - 合同不是时限合同。
  - 已有台账存在冲突且不能覆盖。
  - 唯一约束冲突。
- 操作日志要求：
  - 记录 `ledger_generated`，包含合同号、日期范围、生成数量。
- 验收测试点：
  - 时限合同激活时生成完整周期台账。
  - 再次调用不会重复生成。
  - 已付款或手动调整日期不会被覆盖。

### 9. `ensureOpenEndedDailyLedgers(contract_id, horizon_days)`

- 方法名称：`ensureOpenEndedDailyLedgers(contract_id, horizon_days)`
- 业务目的：为长租合同按配置持续向未来生成每日租金台账。
- 输入参数：
  - `contract_id`。
  - `horizon_days`：未来保障天数，例如 90。
- 输出结果：
  - 生成至日期、生成数量、跳过数量。
- 前置校验：
  - 合同存在且 `contract_type = open_ended`。
  - 长租合同没有固定 `calculated_end_date`。
  - `horizon_days` 大于 0。
- 处理步骤：
  1. 计算目标生成截止日：当前日期加 `horizon_days`。
  2. 如合同有 `termination_date`，目标截止日不得晚于 `termination_date`。
  3. 从合同 `start_date` 或 `ledger_generate_until + 1` 开始补齐缺失日期。
  4. 生成所需自然周账期。
  5. 对缺失日期调用 `buildDailyLedgerForDate`。
  6. 已生成日期不得重复生成。
  7. 不得覆盖已有付款、免除、手动调整日期。
  8. 更新 `ledger_generate_until`。
  9. 刷新合同汇总并写日志。
- 状态变更：
  - 新增未来 `rent_daily_ledgers`。
  - 更新 `lease_contracts.ledger_generate_until`。
- 关联 Collection：
  - `lease_contracts`、`contract_billing_weeks`、`rent_daily_ledgers`、`operation_logs`
- 权限要求：系统定时任务、合同激活服务、系统管理员可触发。
- 失败场景：
  - 合同不是长租合同。
  - 合同已终止且目标日期全部超过终止日期。
  - 唯一约束冲突。
- 操作日志要求：
  - 记录生成范围和数量。
- 验收测试点：
  - 长租合同始终保证未来指定天数台账。
  - 终止后不生成终止日期之后应收台账。

### 10. `buildDailyLedgerForDate(contract_id, rent_date)`

- 方法名称：`buildDailyLedgerForDate(contract_id, rent_date)`
- 业务目的：根据合同固定计费规则生成某一天的台账对象。
- 输入参数：
  - `contract_id`、`rent_date`。
- 输出结果：
  - 未保存或待保存的单日台账对象。
- 前置校验：
  - 合同存在。
  - `rent_date` 在合同有效范围内。
  - 合同计费规则完整。
- 处理步骤：
  1. 读取合同类型、开始日期、结束日期或终止日期。
  2. 调用 `getNaturalWeekRange` 计算自然周。
  3. 计算星期。
  4. 判断星期是否在 `default_free_weekdays` 中。
  5. 默认免租日生成不应收台账，`due_amount = 0`。
  6. 应收日生成应收台账，`due_amount = daily_rent_amount`。
  7. 初始 `paid_amount = 0`、`waived_amount = 0`、`balance_amount = due_amount`。
  8. 根据日期设置初始日历状态：未来应收或到期未付。
- 状态变更：
  - 方法本身不保存，保存由生成服务处理。
- 关联 Collection：
  - `lease_contracts`、`contract_billing_weeks`、`rent_daily_ledgers`
- 权限要求：服务端内部方法。
- 失败场景：
  - 日期不在合同范围内。
  - 免租日配置非法。
- 操作日志要求：单日构建不写日志，批量生成写日志。
- 验收测试点：
  - 默认免租日生成 `non_payable`。
  - 应收日金额等于合同固定日租金。
  - GPS 里程不影响金额。

## 七、默认免租日服务

### 11. `validateDefaultFreeWeekdays(weekly_payable_days, default_free_weekdays)`

- 方法名称：`validateDefaultFreeWeekdays(weekly_payable_days, default_free_weekdays)`
- 业务目的：校验合同默认免租日是否与周付天数匹配。
- 输入参数：
  - `weekly_payable_days`。
  - `default_free_weekdays`。
- 输出结果：
  - 校验通过结果或错误详情。
- 前置校验：
  - 输入不能为空，周付天数必须可解析。
- 处理步骤：
  1. 校验周付天数只能为 3、4、5、6、7。
  2. 计算免租天数 `7 - weekly_payable_days`。
  3. 校验默认免租日数量必须等于免租天数。
  4. 周付 7 天时，默认免租日必须为空。
  5. 校验不能重复选择同一个星期。
  6. 免租日只能是 `mon`、`tue`、`wed`、`thu`、`fri`、`sat`、`sun`。
  7. 不允许系统默认写死周六周日，必须来自合同配置。
- 状态变更：无。
- 关联 Collection：
  - `lease_contracts`、`rent_daily_ledgers`
- 权限要求：服务端内部方法。
- 失败场景：
  - 周付天数非法。
  - 免租日数量不匹配。
  - 免租日重复或枚举非法。
- 操作日志要求：单纯校验不写日志。
- 验收测试点：
  - 周付 5 天必须正好 2 个免租日。
  - 周付 7 天免租日为空。
  - 重复星期报错。

### 12. `applyDefaultFreeDays(contract_id)`

- 方法名称：`applyDefaultFreeDays(contract_id)`
- 业务目的：根据合同默认免租日生成或刷新尚未发生业务变更的台账状态。
- 输入参数：
  - `contract_id`。
- 输出结果：
  - 应用数量、跳过数量、跳过原因。
- 前置校验：
  - 合同存在且计费规则完整。
  - 默认免租日通过校验。
- 处理步骤：
  1. 仅允许在合同激活前台账生成阶段，或无付款、无免除、无手动调整的日期上应用。
  2. 遍历合同台账日期。
  3. 对尚未付款、未免除、未手动调整的日期，根据默认免租日刷新 `is_payable`、`due_amount`、`payment_status`、`calendar_status`。
  4. 已付款日期不允许自动改成免租日。
  5. 已手动调整日期不允许覆盖。
  6. 刷新合同汇总。
  7. 写入操作日志。
- 状态变更：
  - 更新符合条件的 `rent_daily_ledgers`。
  - 更新合同汇总。
- 关联 Collection：
  - `lease_contracts`、`rent_daily_ledgers`、`rent_adjustments`、`operation_logs`
- 权限要求：经理、系统管理员或授权运营；合同激活流程可内部调用。
- 失败场景：
  - 合同不存在。
  - 默认免租日非法。
  - 试图覆盖已付款或手动调整日期。
- 操作日志要求：
  - 记录 `free_day_changed` 或台账生成摘要，包含跳过原因。
- 验收测试点：
  - 已付款日期不会被改成免租日。
  - 手动调整日期不会被覆盖。

## 八、手动调整租金日期服务

### 13. `manuallyAdjustRentDate(ledger_id, adjustment_type, reason)`

- 方法名称：`manuallyAdjustRentDate(ledger_id, adjustment_type, reason)`
- 业务目的：对具体租金日期进行人工调整，并保留调整记录与操作日志。
- 输入参数：
  - `ledger_id`。
  - `adjustment_type`：`change_to_free_day`、`change_to_payable_day`、`change_unpaid_reason`、`mark_debt`、`request_waiver`、`mark_dispute`、`cancel_ledger`、`correction`。
  - `reason`：调整原因。
- 输出结果：
  - 调整记录。
  - 更新后的台账摘要。
- 前置校验：
  - 台账存在。
  - `reason` 必填。
  - 调用人具备对应调整权限。
  - 已取消台账不得再次进行普通调整。
  - 已付款日期改免租必须先处理付款冲正或明确差额处理。
- 处理步骤：
  1. 读取台账、合同、司机、车辆。
  2. 按调整类型进行校验。
  3. 需要审批的免除类调整写入 `rent_adjustments`，状态为 `pending_approval`，不直接修改 `waived_amount`。
  4. 不需审批的状态调整写入 `rent_adjustments` 并更新台账。
  5. 调用 `refreshLedgerPaymentStatus`。
  6. 调用 `refreshContractFinancialSummary`。
  7. 写入 `operation_logs`。
- 状态变更：
  - 新增 `rent_adjustments`。
  - 可能更新 `rent_daily_ledgers` 的应收、未付原因、差额处理、日历状态、取消状态。
  - 可能更新合同汇总。
- 关联 Collection：
  - `rent_daily_ledgers`、`rent_adjustments`、`lease_contracts`、`drivers`、`vehicles`、`operation_logs`
- 权限要求：
  - 运营可发起非财务状态调整申请。
  - 财务可修改未付原因、标记欠款、发起金额修正。
  - 经理或授权角色审批免除。
  - 只读审计不可调整。
- 失败场景：
  - 原因为空。
  - 权限不足。
  - 已付款日期直接改免租导致超付或余额异常。
  - 试图绕过免除审批。
- 操作日志要求：
  - 记录免租日调整、应收日调整、未付原因修改、欠款标记、免除申请、争议标记、取消台账、错误修正。
- 验收测试点：
  - 免除申请不直接修改免除金额。
  - 已付款日期改免租受限制。
  - 每次调整都有 `rent_adjustments` 和 `operation_logs`。

## 九、付款创建和分配服务

### 14. `createRentPayment(input)`

- 方法名称：`createRentPayment(input)`
- 业务目的：创建内部员工手工录入的租金付款记录，并可在同一事务中确认分配。
- 输入参数：
  - `driver_id`、`contract_id`、`vehicle_id`、`payment_date`、`paid_at`、`amount`、`method`、`screenshot_file`、`allocations`、`confirm_now`、`remark`。
- 输出结果：
  - 付款记录。
  - 如确认，返回分配结果和更新后的台账摘要。
- 前置校验：
  - 调用人具备财务付款权限。
  - 金额大于 0。
  - 合同、司机、车辆一致。
  - 付款必须提供分配明细，不能只保存总付款。
- 处理步骤：
  1. 生成 `payment_no`。
  2. 创建 `rent_payments`。
  3. 初始状态选择逻辑：如 `confirm_now = false`，保存为 `draft` 但仍必须带分配草案；如 `confirm_now = true`，立即调用 `allocateRentPayment` 并转为 `confirmed`。
  4. 上传付款截图时按敏感文件处理。
  5. 写入操作日志。
- 状态变更：
  - 新增 `rent_payments`。
  - 可能新增 `rent_payment_allocations` 并更新台账。
- 关联 Collection：
  - `rent_payments`、`rent_payment_allocations`、`rent_daily_ledgers`、`lease_contracts`、`drivers`、`vehicles`、`operation_logs`
- 权限要求：
  - 财务、系统管理员可创建。
  - 运营不可创建付款。
- 失败场景：
  - 金额小于等于 0。
  - 无分配明细。
  - 权限不足。
  - 截图上传失败。
- 操作日志要求：
  - 记录 `payment_created`；确认时另记录 `payment_confirmed`。
- 验收测试点：
  - 不能只保存总付款。
  - 无权限角色不能创建付款。

### 15. `validatePaymentAllocations(payment, allocations)`

- 方法名称：`validatePaymentAllocations(payment, allocations)`
- 业务目的：校验付款分配明细是否满足业务规则。
- 输入参数：
  - `payment`：付款记录或付款输入。
  - `allocations`：分配明细数组。
- 输出结果：
  - 校验通过或错误清单。
- 前置校验：
  - 付款金额大于 0。
  - 分配数组存在。
- 处理步骤：
  1. 校验 `allocations` 不能为空。
  2. 校验每条分配有 `ledger_id` 和正数金额。
  3. 校验分配金额合计等于付款金额。
  4. 查询每条每日租金台账。
  5. 只能分配到应收日期。
  6. 不能分配到免租日。
  7. 不能分配到已取消日期。
  8. 所有分配必须属于同一合同，且与付款合同一致。
  9. 对每条调用 `validateNoOverpayment`。
  10. 任一失败则整个校验失败。
- 状态变更：无。
- 关联 Collection：
  - `rent_payments`、`rent_payment_allocations`、`rent_daily_ledgers`、`lease_contracts`
- 权限要求：财务或服务端内部调用。
- 失败场景：
  - 分配为空。
  - 合计金额不等于付款金额。
  - 台账不存在、免租、取消、合同不一致。
  - 单日超付。
- 操作日志要求：校验不写日志；失败原因返回给调用方。
- 验收测试点：
  - 任何一条超付导致整笔失败。
  - 免租日不能分配付款。

### 16. `validateNoOverpayment(ledger_id, allocation_amount)`

- 方法名称：`validateNoOverpayment(ledger_id, allocation_amount)`
- 业务目的：校验指定日期新增分配后是否超付。
- 输入参数：
  - `ledger_id`。
  - `allocation_amount`。
- 输出结果：
  - `receivable_remaining`：可收金额。
  - 校验是否通过。
- 前置校验：
  - 台账存在。
  - 分配金额大于 0。
- 处理步骤：
  1. 锁定台账行，防止并发付款导致超付。
  2. 已付金额以 `rent_daily_ledgers.paid_amount` 为准，并可由 `active` 分配记录复核。
  3. 免除金额以 `waived_amount` 为准。
  4. 计算可收金额：`due_amount - paid_amount - waived_amount`。
  5. 如 `allocation_amount > 可收金额`，返回超付错误。
  6. 部分付款允许，但剩余金额必须后续通过差额处理方式明确性质。
  7. 不允许生成预收款。
  8. 不允许自动转移到其他日期。
- 状态变更：无。
- 关联 Collection：
  - `rent_daily_ledgers`、`rent_payment_allocations`
- 权限要求：服务端内部方法。
- 失败场景：
  - 台账已取消或免租。
  - 可收金额不足。
  - 并发更新冲突。
- 操作日志要求：超付校验失败可在付款失败日志中记录摘要。
- 验收测试点：
  - 应收 100、已付 80、免除 0 时最多再收 20。
  - 分配 21 时整笔付款失败。

### 17. `allocateRentPayment(payment_id, allocations)`

- 方法名称：`allocateRentPayment(payment_id, allocations)`
- 业务目的：确认付款并将付款分配到具体每日租金台账。
- 输入参数：
  - `payment_id`。
  - `allocations`。
- 输出结果：
  - 已确认付款。
  - 分配记录清单。
  - 受影响台账摘要。
- 前置校验：
  - 付款存在且状态为 `draft`。
  - 调用人具备财务确认权限。
  - 调用 `validatePaymentAllocations` 通过。
- 处理步骤：
  1. 开启事务。
  2. 锁定付款和受影响台账。
  3. 校验付款状态。
  4. 校验分配和单日不可超付。
  5. 创建 `rent_payment_allocations`。
  6. 更新每条 `rent_daily_ledgers.paid_amount`。
  7. 调用 `refreshLedgerPaymentStatus`。
  8. 调用 `refreshContractFinancialSummary`。
  9. 调用 `refreshDriverCalendarSummary`。
  10. 将付款状态改为 `confirmed`。
  11. 写入操作日志。
  12. 提交事务。
- 状态变更：
  - `rent_payments.status = confirmed`。
  - 新增 `rent_payment_allocations`。
  - 更新台账、合同汇总和日历汇总。
- 关联 Collection：
  - `rent_payments`、`rent_payment_allocations`、`rent_daily_ledgers`、`lease_contracts`、`operation_logs`
- 权限要求：财务、系统管理员。
- 失败场景：
  - 付款不是草稿。
  - 分配非法。
  - 任意日期超付。
  - 并发付款导致余额变化。
- 操作日志要求：
  - 成功记录 `payment_confirmed`。
  - 失败返回明确错误，不得部分成功。
- 验收测试点：
  - 任一日期超付时所有分配都不写入。
  - 确认成功后台账已付金额正确增加。

## 十、未付原因和差额处理服务

### 18. `markUnpaidReason(ledger_id, unpaid_reason, remark)`

- 方法名称：`markUnpaidReason(ledger_id, unpaid_reason, remark)`
- 业务目的：为到期未付的应收日期记录未付原因。
- 输入参数：
  - `ledger_id`、`unpaid_reason`、`remark`。
- 输出结果：更新后的台账。
- 前置校验：
  - 台账存在。
  - 台账为应收日期。
  - 未付原因在系统枚举内。
- 处理步骤：
  1. 校验 `rent_date <= 当前日期`。
  2. 免租日不要求未付原因。
  3. 未结清应收日期必须填写未付原因。
  4. 更新 `unpaid_reason` 和备注。
  5. 刷新台账状态。
  6. 写入操作日志。
- 状态变更：
  - 更新 `rent_daily_ledgers.unpaid_reason`。
- 关联 Collection：
  - `rent_daily_ledgers`、`operation_logs`
- 权限要求：财务、经理、授权运营可按职责修改；只读审计不可修改。
- 失败场景：
  - 原因为空或非法。
  - 台账为免租日。
  - 权限不足。
- 操作日志要求：记录 `unpaid_reason_changed`。
- 验收测试点：
  - 到期未付无原因时保存失败。
  - 修改原因后有操作日志。

### 19. `markShortfallDisposition(ledger_id, disposition, reason)`

- 方法名称：`markShortfallDisposition(ledger_id, disposition, reason)`
- 业务目的：为部分付款或未全额结清余额明确差额性质。
- 输入参数：
  - `ledger_id`。
  - `disposition`：`debt`、`waived`、`pending_waiver_approval`、`dispute`。
  - `reason`。
- 输出结果：更新后的台账。
- 前置校验：
  - 台账存在且为应收日期。
  - 存在未结清余额。
  - 原因必填。
- 处理步骤：
  1. 计算余额。
  2. 校验余额大于 0。
  3. `debt` 计入当前欠款，影响 `unpaid_debt` 或 `partial_debt`。
  4. `waived` 必须已完成审批，不能绕过 `requestRentWaiver` 与 `approveRentWaiver`。
  5. `pending_waiver_approval` 不作为最终免除，通常不计入最终免除金额。
  6. `dispute` 显示为争议；本设计中争议金额暂计入风险欠款汇总，但可在报表中单独列示。
  7. 刷新台账状态、合同汇总和日历汇总。
  8. 写入操作日志。
- 状态变更：
  - 更新 `rent_daily_ledgers.shortfall_disposition`、`calendar_status`。
  - 可能更新合同汇总。
- 关联 Collection：
  - `rent_daily_ledgers`、`lease_contracts`、`operation_logs`
- 权限要求：财务、经理；运营可按授权提交原因但不审批免除。
- 失败场景：
  - 没有余额却标记差额。
  - 试图未审批直接标记最终免除。
  - 权限不足。
- 操作日志要求：记录欠款标记、争议标记或待审批免除状态变化。
- 验收测试点：
  - 部分付款不能只显示 `partial` 而无差额处理。
  - 待审批免除不会直接减少免除金额。

## 十一、免除租金服务

### 20. `requestRentWaiver(ledger_id, amount, reason)`

- 方法名称：`requestRentWaiver(ledger_id, amount, reason)`
- 业务目的：申请免除某日租金或某日剩余欠款。
- 输入参数：
  - `ledger_id`、`amount`、`reason`。
- 输出结果：
  - 新增的 `rent_adjustments` 申请记录。
- 前置校验：
  - 台账存在且为应收日期。
  - `amount > 0`。
  - `amount <= balance_amount`。
  - 原因必填。
- 处理步骤：
  1. 计算当前余额。
  2. 创建 `rent_adjustments`，`adjustment_type = waive`，`status = pending_approval`。
  3. 更新台账差额处理为 `pending_waiver_approval`。
  4. 不直接修改 `waived_amount`。
  5. 写入操作日志。
- 状态变更：
  - 新增待审批调整。
  - 台账显示待免除审批。
- 关联 Collection：
  - `rent_daily_ledgers`、`rent_adjustments`、`operation_logs`
- 权限要求：财务、经理、授权运营可申请。
- 失败场景：
  - 免租日申请免除。
  - 金额超过余额。
  - 原因为空。
- 操作日志要求：记录 `waiver_requested`。
- 验收测试点：
  - 申请后 `waived_amount` 不变化。
  - 申请记录状态为待审批。

### 21. `approveRentWaiver(adjustment_id)`

- 方法名称：`approveRentWaiver(adjustment_id)`
- 业务目的：审批通过租金免除申请并更新台账和汇总。
- 输入参数：
  - `adjustment_id`。
- 输出结果：
  - 已审批调整记录。
  - 更新后的台账和合同汇总。
- 前置校验：
  - 调整记录存在且为待审批免除。
  - 审批人具备经理或授权审批权限。
  - 台账仍有足够余额。
- 处理步骤：
  1. 开启事务。
  2. 锁定调整和台账。
  3. 将调整状态改为 `approved` 或 `applied`。
  4. 增加 `rent_daily_ledgers.waived_amount`。
  5. 重新计算 `balance_amount`。
  6. 刷新台账状态。
  7. 刷新合同财务汇总和司机日历汇总。
  8. 写入操作日志。
- 状态变更：
  - `rent_adjustments.status` 更新。
  - `rent_daily_ledgers.waived_amount` 更新。
- 关联 Collection：
  - `rent_adjustments`、`rent_daily_ledgers`、`lease_contracts`、`operation_logs`
- 权限要求：经理、系统管理员或授权审批角色。
- 失败场景：
  - 权限不足。
  - 调整不是待审批状态。
  - 台账余额不足。
- 操作日志要求：记录 `waiver_approved`。
- 验收测试点：
  - 审批后免除金额增加。
  - 合同欠款汇总同步减少。

### 22. `rejectRentWaiver(adjustment_id, reason)`

- 方法名称：`rejectRentWaiver(adjustment_id, reason)`
- 业务目的：拒绝租金免除申请，并保留原欠款或争议状态。
- 输入参数：
  - `adjustment_id`、`reason`。
- 输出结果：
  - 已拒绝调整记录。
- 前置校验：
  - 调整记录存在且待审批。
  - 拒绝原因必填。
  - 调用人具备审批权限。
- 处理步骤：
  1. 将调整状态改为 `rejected`。
  2. 不修改 `waived_amount`。
  3. 台账保留欠款或争议状态。
  4. 刷新台账状态。
  5. 写入操作日志。
- 状态变更：
  - `rent_adjustments.status = rejected`。
- 关联 Collection：
  - `rent_adjustments`、`rent_daily_ledgers`、`operation_logs`
- 权限要求：经理、系统管理员或授权审批角色。
- 失败场景：
  - 权限不足。
  - 原因为空。
  - 调整状态不允许拒绝。
- 操作日志要求：记录免除拒绝原因摘要。
- 验收测试点：
  - 拒绝后免除金额不变。
  - 拒绝原因可审计。

## 十二、付款冲正服务

### 23. `reverseRentPayment(payment_id, reason)`

- 方法名称：`reverseRentPayment(payment_id, reason)`
- 业务目的：对已确认付款进行冲正，替代直接删除。
- 输入参数：
  - `payment_id`、`reason`。
- 输出结果：
  - 已冲正付款。
  - 受影响分配和台账摘要。
- 前置校验：
  - 付款存在且状态为 `confirmed`。
  - 冲正原因必填。
  - 调用人具备财务冲正权限。
- 处理步骤：
  1. 开启事务。
  2. 锁定付款、分配和受影响台账。
  3. 将 `rent_payments.status` 改为 `reversed`。
  4. 将关联 `rent_payment_allocations.status` 改为 `reversed`，写入 `reversed_at` 与 `reversed_reason`。
  5. 从对应每日台账 `paid_amount` 扣回 `allocated_amount`。
  6. 校验不允许扣成负数。
  7. 每个受影响台账调用 `refreshLedgerPaymentStatus`。
  8. 刷新合同汇总和司机日历汇总。
  9. 写入操作日志。
- 状态变更：
  - 付款与分配变为已冲正。
  - 台账已付金额减少。
- 关联 Collection：
  - `rent_payments`、`rent_payment_allocations`、`rent_daily_ledgers`、`lease_contracts`、`operation_logs`
- 权限要求：财务主管、经理、系统管理员或授权财务角色。
- 失败场景：
  - 付款未确认。
  - 原因为空。
  - 扣回后已付金额为负。
  - 权限不足。
- 操作日志要求：记录 `payment_reversed`。
- 验收测试点：
  - 已确认付款不能删除，只能冲正。
  - 冲正后台账状态和合同汇总正确刷新。

## 十三、每日台账状态刷新服务

### 24. `refreshLedgerPaymentStatus(ledger_id)`

- 方法名称：`refreshLedgerPaymentStatus(ledger_id)`
- 业务目的：根据应收、已付、免除、余额、日期和差额处理方式刷新单日台账付款状态与日历状态。
- 输入参数：
  - `ledger_id`。
- 输出结果：
  - 更新后的台账。
- 前置校验：
  - 台账存在。
- 处理步骤：
  1. 计算 `balance_amount = due_amount - paid_amount - waived_amount`。
  2. 如 `balance_amount < 0`，报错并阻止保存。
  3. `status = cancelled` 时，`calendar_status = cancelled`。
  4. `is_payable = false` 时，`payment_status = non_payable`，`calendar_status = non_payable`。
  5. 未来日期未付款时，`calendar_status = future_receivable`。
  6. 到期未付时，`calendar_status = unpaid_debt`，且必须有未付原因。
  7. 部分付款且剩余为欠款时，`calendar_status = partial_debt`。
  8. 全额付款时，`calendar_status = paid`。
  9. 全额免除时，`calendar_status = waived`。
  10. 部分付款加部分免除后结清时，`calendar_status = partial_waived`。
  11. 差额为争议时，`calendar_status = dispute`。
- 状态变更：
  - 更新 `rent_daily_ledgers.payment_status`、`calendar_status`、`balance_amount`。
- 关联 Collection：
  - `rent_daily_ledgers`
- 权限要求：服务端内部方法；不能只靠前端计算。
- 失败场景：
  - 余额为负。
  - 到期未付缺少未付原因。
  - 部分付款缺少差额处理方式。
- 操作日志要求：
  - 被付款、调整、冲正等上游方法调用时，由上游方法记录日志。
- 验收测试点：
  - 未来应收不显示为当前欠款。
  - 余额为负时报错。
  - 争议显示为争议状态。

## 十四、合同汇总刷新服务

### 25. `refreshContractFinancialSummary(contract_id)`

- 方法名称：`refreshContractFinancialSummary(contract_id)`
- 业务目的：从每日租金台账、付款、免除和押金记录刷新合同财务汇总。
- 输入参数：
  - `contract_id`。
- 输出结果：
  - 更新后的合同汇总。
- 前置校验：
  - 合同存在。
- 处理步骤：
  1. 从 `rent_daily_ledgers` 汇总 `total_due_amount`，免租日不计应收。
  2. 汇总 `total_paid_amount`。
  3. 汇总 `total_waived_amount`。
  4. 当前欠款只统计 `rent_date <= 当前日期` 的未结清应收日期。
  5. 未来应收只统计 `rent_date > 当前日期` 的应收余额。
  6. 已免除金额不算欠款。
  7. 争议金额本设计中暂计入当前欠款风险汇总，同时可通过争议状态单独筛选；如后续业务要排除争议，应先更新文档确认。
  8. 从 `deposit_records` 汇总押金应收、已收和状态。
  9. 更新 `lease_contracts` 汇总字段。
- 状态变更：
  - 更新 `lease_contracts.total_due_amount`、`total_paid_amount`、`total_waived_amount`、`current_debt_amount`、`current_debt_days`、`future_receivable_amount`、押金摘要。
- 关联 Collection：
  - `lease_contracts`、`rent_daily_ledgers`、`deposit_records`
- 权限要求：服务端内部方法；敏感汇总输出需权限过滤。
- 失败场景：
  - 合同不存在。
  - 台账金额出现负余额。
- 操作日志要求：
  - 上游业务操作记录日志；定时汇总异常需记录。
- 验收测试点：
  - 未来应收不计入当前欠款。
  - 免租日不计应收。
  - 已免除金额不计欠款。

## 十五、司机日历汇总服务

### 26. `refreshDriverCalendarSummary(driver_id, date_range)`

- 方法名称：`refreshDriverCalendarSummary(driver_id, date_range)`
- 业务目的：刷新或计算司机日历汇总，用于日历展示和对账。
- 输入参数：
  - `driver_id`。
  - `date_range`：查询范围，可按月份、合同、车辆筛选。
- 输出结果：
  - 截至当前日期总欠款天数。
  - 截至当前日期总欠款金额。
  - 总已付金额。
  - 未来应收金额。
  - 押金金额。
  - 当前合同。
  - 当前车牌。
- 前置校验：
  - 司机存在。
  - 日期范围有效。
- 处理步骤：
  1. 查询司机相关每日台账。
  2. 当前欠款只统计截至当前日期。
  3. 未来应收单独统计。
  4. 总已付从台账或有效分配聚合。
  5. 押金从 `deposit_records` 聚合。
  6. 当前合同和车牌从有效合同读取。
  7. 支持按司机、车辆、合同、月份筛选。
- 状态变更：
  - 可只计算返回；如后续建立缓存表，再更新缓存。
- 关联 Collection：
  - `drivers`、`lease_contracts`、`vehicles`、`rent_daily_ledgers`、`deposit_records`
- 权限要求：
  - 汇总输出必须后续经 `filterCalendarSensitiveData` 过滤。
- 失败场景：
  - 司机不存在。
  - 日期范围非法。
- 操作日志要求：
  - 普通查询不写日志；导出或敏感查看可记录访问日志。
- 验收测试点：
  - 未来应收单独统计。
  - 支持按车辆、合同、月份筛选。

## 十六、权限过滤服务

### 27. `getDriverCalendarData(driver_id, date_range, current_user)`

- 方法名称：`getDriverCalendarData(driver_id, date_range, current_user)`
- 业务目的：返回司机日历每日台账、汇总数据和当前用户可见字段。
- 输入参数：
  - `driver_id`、`date_range`、`current_user`。
- 输出结果：
  - `daily_ledgers`。
  - `summary`。
  - `visible_fields`。
- 前置校验：
  - 用户已登录且为内部用户。
  - 用户有查看该司机日历的资源权限。
- 处理步骤：
  1. 查询每日台账。
  2. 调用 `refreshDriverCalendarSummary` 或计算汇总。
  3. 组装付款截图入口、付款方式等敏感信息的引用。
  4. 调用 `filterCalendarSensitiveData`。
  5. 返回过滤后的数据。
- 状态变更：无。
- 关联 Collection：
  - `drivers`、`rent_daily_ledgers`、`rent_payments`、`rent_payment_allocations`、`deposit_records`
- 权限要求：按角色和字段级权限控制。
- 失败场景：
  - 用户无权查看。
  - 司机不存在。
- 操作日志要求：
  - 普通查看可不写；导出、查看付款截图、查看证件应记录敏感访问日志。
- 验收测试点：
  - 运营看不到全部敏感财务字段。
  - GPS 维护人员看不到付款截图和司机证件。

### 28. `filterCalendarSensitiveData(data, current_user)`

- 方法名称：`filterCalendarSensitiveData(data, current_user)`
- 业务目的：对日历和汇总数据进行服务端敏感字段过滤。
- 输入参数：
  - `data`：待返回数据。
  - `current_user`：当前内部用户及角色。
- 输出结果：
  - 过滤后的数据。
  - `visible_fields` 与被隐藏字段列表。
- 前置校验：
  - 用户角色有效。
- 处理步骤：
  1. 识别敏感字段：总已付金额、总欠款金额、未来应收金额、押金金额、付款截图、付款方式、司机证件号、司机证件照片、司机驾照照片。
  2. 系统管理员可管理全部数据。
  3. 经理可查看财务汇总并审批免除。
  4. 财务可查看付款、欠款、押金、付款截图和付款方式。
  5. 运营可查看司机、车辆、合同和非敏感日历状态，不默认查看全部敏感财务汇总和付款截图。
  6. GPS 维护人员只看 GPS 相关，不看付款截图、付款方式、司机敏感证件和敏感财务汇总。
  7. 只读审计按授权查看，不能修改。
  8. 对无权字段返回空、脱敏值或完全移除，具体由前端展示策略决定，但服务端不得返回原始敏感值。
- 状态变更：无。
- 关联 Collection：
  - `drivers`、`lease_contracts`、`rent_daily_ledgers`、`rent_payments`、`deposit_records`、`contract_documents`
- 权限要求：服务端强制执行，不能只靠前端隐藏。
- 失败场景：
  - 角色无效。
  - 用户无资源权限。
- 操作日志要求：
  - 敏感文件预览、下载、导出应写日志。
- 验收测试点：
  - 普通运营无法通过接口获取总已付、押金、付款截图。
  - GPS 维护人员无法获取司机证件照片。

## 十七、押金服务

### 29. `createDepositRecord(input)`

- 方法名称：`createDepositRecord(input)`
- 业务目的：创建或记录合同押金，独立于租金付款。
- 输入参数：
  - `contract_id`、`driver_id`、`vehicle_id`、`required_amount`、`received_amount`、`method`、`received_at`、`screenshot_file`、`remark`。
- 输出结果：
  - 押金记录。
- 前置校验：
  - 合同、司机、车辆一致。
  - 金额不为负。
  - 调用人具备押金管理权限。
- 处理步骤：
  1. 生成 `deposit_no`。
  2. 创建 `deposit_records`。
  3. 押金截图按敏感文件处理。
  4. 不更新 `rent_daily_ledgers.paid_amount`。
  5. 刷新合同押金摘要。
  6. 写入操作日志。
- 状态变更：
  - 新增押金记录。
  - 更新合同押金摘要。
- 关联 Collection：
  - `deposit_records`、`lease_contracts`、`operation_logs`
- 权限要求：财务、经理、系统管理员。
- 失败场景：
  - 金额为负。
  - 权限不足。
  - 合同关系不一致。
- 操作日志要求：记录押金收取或创建。
- 验收测试点：
  - 押金不计入每日租金已付。
  - 无权限角色看不到押金截图。

### 30. `deductDeposit(contract_id, amount, reason)`

- 方法名称：`deductDeposit(contract_id, amount, reason)`
- 业务目的：记录押金抵扣欠款、损伤、违章或其他费用。
- 输入参数：
  - `contract_id`、`amount`、`reason`。
- 输出结果：
  - 更新后的押金记录。
- 前置校验：
  - 合同存在。
  - 金额大于 0。
  - 原因必填。
  - 可用押金余额足够。
- 处理步骤：
  1. 锁定押金记录。
  2. 校验可抵扣金额。
  3. 增加 `deducted_amount`。
  4. 更新押金状态。
  5. 刷新合同押金摘要。
  6. 写入操作日志。
- 状态变更：
  - 更新 `deposit_records.deducted_amount` 与状态。
- 关联 Collection：
  - `deposit_records`、`lease_contracts`、`operation_logs`
- 权限要求：财务、经理、系统管理员。
- 失败场景：
  - 金额超过可抵扣余额。
  - 原因为空。
- 操作日志要求：记录押金抵扣。
- 验收测试点：
  - 抵扣必须有原因。
  - 抵扣不直接生成每日租金付款，除非后续另行确认押金抵扣欠款流程。

### 31. `refundDeposit(contract_id, amount, proof_file)`

- 方法名称：`refundDeposit(contract_id, amount, proof_file)`
- 业务目的：记录押金退还及退还凭据。
- 输入参数：
  - `contract_id`、`amount`、`proof_file`。
- 输出结果：
  - 更新后的押金记录。
- 前置校验：
  - 金额大于 0。
  - 不得超过可退金额。
  - 退还凭据按业务要求提供。
- 处理步骤：
  1. 锁定押金记录。
  2. 计算可退金额：已收金额减已抵扣金额减已退还金额。
  3. 校验本次退还不超过可退金额。
  4. 增加 `refunded_amount`。
  5. 更新押金状态为部分退还或已退还。
  6. 保存凭据文件引用。
  7. 写入操作日志。
- 状态变更：
  - 更新押金退还金额和状态。
- 关联 Collection：
  - `deposit_records`、`lease_contracts`、`operation_logs`
- 权限要求：财务、经理、系统管理员。
- 失败场景：
  - 超过可退金额。
  - 权限不足。
  - 凭据上传失败。
- 操作日志要求：记录押金退还。
- 验收测试点：
  - 退还金额不能超过可退金额。
  - 退还凭据受权限控制。

## 十八、合同文件服务

### 32. `generateContractDocuments(contract_id, languages)`

- 方法名称：`generateContractDocuments(contract_id, languages)`
- 业务目的：根据合同模板生成中文、英文、法文合同文件，并支持后续打印、线下签署和扫描件上传状态流转。
- 输入参数：
  - `contract_id`。
  - `languages`：`zh-CN`、`en-US`、`fr-FR` 的数组。
- 输出结果：
  - 生成的 `contract_documents` 清单。
- 前置校验：
  - 合同存在且绑定具体车辆和车牌。
  - 语言枚举有效。
  - 每种语言存在启用模板。
- 处理步骤：
  1. 查询合同和模板。
  2. 生成合同文件记录，状态为 `generated`。
  3. 后续打印后状态变为 `printed`。
  4. 线下签署后记录 `signed_at` 并变为 `signed`。
  5. 上传扫描件后状态变为 `scanned`。
  6. 合同文件生成不得改变台账和计费规则。
  7. 写入操作日志。
- 状态变更：
  - 新增 `contract_documents`。
  - 可能更新 `lease_contracts.signature_status`。
- 关联 Collection：
  - `contract_templates`、`contract_documents`、`lease_contracts`、`operation_logs`
- 权限要求：运营可按授权生成和打印；扫描件上传、下载和预览需敏感文件权限。
- 失败场景：
  - 缺少模板。
  - 合同未绑定具体车牌。
  - 语言非法。
- 操作日志要求：记录合同文件生成、打印、签署、扫描件上传。
- 验收测试点：
  - 支持三种语言。
  - 合同文件生成不改变台账。

## 十九、IOPGPS 服务

### 33. `getIopgpsAccessToken()`

- 方法名称：`getIopgpsAccessToken()`
- 业务目的：获取或刷新 IOPGPS 访问令牌。
- 输入参数：无显式业务参数。
- 输出结果：
  - 可用于服务端请求的访问令牌；不得返回给无权限前端。
- 前置校验：
  - IOPGPS 配置存在且启用。
  - `login_key_encrypted` 可解密或环境变量可读取。
- 处理步骤：
  1. 从 `iopgps_settings` 或部署环境读取配置。
  2. 不写死密钥。
  3. 若 `access_token` 未过期，服务端内部使用。
  4. 若过期，调用 IOPGPS 刷新。
  5. 加密保存新令牌和过期时间。
  6. 失败写日志。
- 状态变更：
  - 可能更新 `iopgps_settings.access_token`、`token_expires_at`、`status`。
- 关联 Collection：
  - `iopgps_settings`、`operation_logs`
- 权限要求：系统定时任务或 GPS 管理服务；普通用户不能查看令牌。
- 失败场景：
  - 配置缺失。
  - 密钥解密失败。
  - IOPGPS API 失败。
- 操作日志要求：
  - 失败记录 `gps_sync_error`，不得记录密钥或令牌。
- 验收测试点：
  - 令牌为敏感字段。
  - 获取失败不影响租金台账和付款。

### 34. `syncIopgpsDeviceStatus()`

- 方法名称：`syncIopgpsDeviceStatus()`
- 业务目的：同步 GPS 设备在线、离线、故障等状态。
- 输入参数：无，或后续支持指定设备范围。
- 输出结果：
  - 同步成功数量、失败数量、错误摘要。
- 前置校验：
  - IOPGPS 同步启用。
  - 可获取访问令牌。
- 处理步骤：
  1. 获取访问令牌。
  2. 调用 IOPGPS 设备状态接口。
  3. 标准化设备状态。
  4. 更新 `gps_devices.device_status`。
  5. 更新 `vehicles.gps_status`。
  6. 写入 `gps_device_status_logs`。
  7. 失败只记录日志，不影响租金台账和付款逻辑。
- 状态变更：
  - 更新 GPS 设备与车辆 GPS 状态。
- 关联 Collection：
  - `gps_devices`、`vehicles`、`gps_device_status_logs`、`iopgps_settings`、`operation_logs`
- 权限要求：系统任务、GPS 维护人员或管理员。
- 失败场景：
  - API 失败。
  - 单个设备映射失败。
  - 令牌失效。
- 操作日志要求：
  - 异常记录 `gps_sync_error`。
- 验收测试点：
  - 同步失败不阻止付款确认。
  - 状态更新不改变任何租金金额。

### 35. `syncIopgpsLocation()`

- 方法名称：`syncIopgpsLocation()`
- 业务目的：同步并保存 GPS 定位快照，更新车辆最近位置。
- 输入参数：无，或后续支持指定设备范围。
- 输出结果：
  - 定位快照保存数量、失败数量。
- 前置校验：
  - 同步启用。
  - 可获取访问令牌。
- 处理步骤：
  1. 调用 IOPGPS 定位接口。
  2. 保存 `gps_location_snapshots`。
  3. 更新 `vehicles.last_gps_*` 与 `gps_devices.last_*` 摘要。
  4. 原始响应不得包含密钥。
  5. 失败记录日志但不影响租金台账和付款。
- 状态变更：
  - 新增定位快照。
  - 更新车辆和设备最近位置。
- 关联 Collection：
  - `gps_location_snapshots`、`gps_devices`、`vehicles`、`operation_logs`
- 权限要求：系统任务、GPS 维护人员或管理员。
- 失败场景：
  - API 失败。
  - 坐标缺失。
  - 设备未绑定车辆。
- 操作日志要求：异常记录 `gps_sync_error`。
- 验收测试点：
  - 定位同步失败不影响台账生成。
  - 定位变化不改变应收金额。

### 36. `syncIopgpsDailyMileage()`

- 方法名称：`syncIopgpsDailyMileage()`
- 业务目的：同步 GPS 每日里程，用于运营核查。
- 输入参数：无，或后续支持指定日期、车辆、设备。
- 输出结果：
  - 每日里程保存数量、更新数量、失败数量。
- 前置校验：
  - 同步启用。
  - 可获取访问令牌。
- 处理步骤：
  1. 调用 IOPGPS 里程接口。
  2. 按 `device_id + mileage_date` 唯一约束保存或更新 `gps_daily_mileages`。
  3. 可关联当日有效合同和司机，仅用于运营核查。
  4. 记录 `sync_status` 和 `error_message`。
  5. 不参与租金计算。
- 状态变更：
  - 新增或更新 `gps_daily_mileages`。
- 关联 Collection：
  - `gps_daily_mileages`、`gps_devices`、`vehicles`、`lease_contracts`、`drivers`、`operation_logs`
- 权限要求：系统任务、GPS 维护人员或管理员。
- 失败场景：
  - API 失败。
  - 唯一约束冲突。
  - 设备未绑定。
- 操作日志要求：同步异常记录 `gps_sync_error`。
- 验收测试点：
  - 里程只用于运营核查。
  - 里程变化不影响租金台账。

## 二十、操作日志服务

### 37. `recordOperationLog(input)`

- 方法名称：`recordOperationLog(input)`
- 业务目的：统一记录关键业务操作审计日志。
- 输入参数：
  - `operator_id`、`action`、`target_collection`、`target_id`、`before_value`、`after_value`、`reason`、`ip_address`。
- 输出结果：
  - 新增的操作日志记录。
- 前置校验：
  - `action` 在允许枚举内。
  - `target_collection` 和 `target_id` 必填。
  - 敏感字段已脱敏。
- 处理步骤：
  1. 生成 `log_no`。
  2. 对 `before_value`、`after_value` 进行摘要化和脱敏。
  3. 写入 `operation_logs`。
  4. 日志写入失败时，关键业务操作应按严重程度决定是否回滚；付款确认、冲正、免除审批等高风险操作建议日志失败即回滚。
- 状态变更：
  - 新增 `operation_logs`。
- 关联 Collection：
  - `operation_logs` 及全部关键业务 Collection。
- 权限要求：服务端内部方法；用户不能伪造操作人。
- 失败场景：
  - 编号生成失败。
  - 敏感值未脱敏。
  - 数据库写入失败。
- 操作日志要求：
  - 本方法自身不再递归记录日志。
  - 必须覆盖合同创建、合同激活、台账生成、免租日调整、应收日调整、付款创建、付款确认、付款冲正、未付原因修改、欠款标记、免除申请、免除审批、押金收取、押金抵扣、押金退还、GPS 同步异常。
- 验收测试点：
  - 高风险操作都有日志。
  - 日志不包含真实密钥、完整证件照片、完整付款截图内容或访问令牌。

## 必须服务端实现的关键控制

以下方法或校验必须在服务端实现，不能只靠前端页面控制：

- 编号唯一性与并发控制：`generateBusinessNo`。
- 车辆合同冲突检查：`checkVehicleContractAvailability`。
- 合同租期、默认免租日、日租金、押金校验：`calculateFixedTermEndDate`、`validateDefaultFreeWeekdays`、`createLeaseContractDraft`、`activateLeaseContract`。
- 台账生成唯一性和不可覆盖规则：`generateFixedTermDailyLedgers`、`ensureOpenEndedDailyLedgers`、`buildDailyLedgerForDate`。
- 单日不可超付和付款事务回滚：`validatePaymentAllocations`、`validateNoOverpayment`、`allocateRentPayment`。
- 未付原因必填和差额处理必填：`markUnpaidReason`、`markShortfallDisposition`、`refreshLedgerPaymentStatus`。
- 免除审批与冲正：`requestRentWaiver`、`approveRentWaiver`、`rejectRentWaiver`、`reverseRentPayment`。
- 当前欠款、未来应收和敏感汇总计算：`refreshContractFinancialSummary`、`refreshDriverCalendarSummary`。
- 敏感字段过滤：`getDriverCalendarData`、`filterCalendarSensitiveData`。
- IOPGPS 密钥保护和同步失败隔离：`getIopgpsAccessToken`、`syncIopgpsDeviceStatus`、`syncIopgpsLocation`、`syncIopgpsDailyMileage`。
- 关键审计日志：`recordOperationLog`。

## 文档冲突检查

- 本轮未发现 `SPEC.md`、`docs/data-model.md`、`docs/billing-rules.md`、`docs/payment-rules.md`、`docs/permissions.md`、`docs/workflows.md`、`docs/acceptance-tests.md` 之间存在业务规则冲突。
- 本文对未付原因使用 `waiting_for_payment`、`driver_promised_to_pay` 等更贴近服务方法的枚举名称；第一版文档中相近枚举如 `waiting_payment`、`driver_promised` 语义一致。后续实现前建议统一枚举编码，但不改变“未付必须有原因”的业务规则。
- 本文明确争议金额暂计入当前欠款风险汇总并可单独筛选；如后续业务希望争议金额不计入当前欠款，应先更新文档确认后再实现。

## 本轮实现状态补充

- `getNaturalWeekRange`、`eachDateBetween`、`getWeekday`、`addMonthsClamped`、`calculateFixedTermEndDate` 已在 `plugin-rental-core` 中实现为纯日期函数，不依赖本地时区隐式转换。
- `validateWeeklyPayableDays`、`validateDefaultFreeWeekdays`、`isDefaultFreeWeekday` 已实现为纯计费规则函数，校验失败会抛出带中文信息的 `BusinessError`。
- `buildDailyLedgerForDate`、`generateFixedTermDailyLedgerPreview`、`generateOpenEndedDailyLedgerPreview`、`summarizeLedgerPreview` 已实现为纯台账预览函数，只生成对象，不写数据库，不处理付款分配和免除审批。
- `refreshLedgerPaymentStatus` 已实现为纯状态刷新函数，只刷新单日台账对象，不做合同汇总落库和权限过滤。
- 数据库落库版 `generateFixedTermDailyLedgers`、`ensureOpenEndedDailyLedgers`、`applyDefaultFreeDays` 仍保留 TODO，后续接入 NocoBase Collection、唯一约束和服务端事务后再实现。
- 本轮没有实现付款分配、付款截图上传、收租日历 UI、权限过滤、IOPGPS、合同打印、NocoBase 页面配置、真实数据库迁移或 Docker 部署。

## 本轮付款与差额处理实现状态补充

- `createRentPaymentDraft`、`validatePaymentAllocations`、`validateNoOverpayment`、`confirmRentPayment`、`allocateRentPayment` 已实现为纯业务函数，只操作内存对象，不写数据库。
- `markUnpaidReason` 与 `validateUnpaidReason` 已实现未付原因校验和同步争议、待免除审批差额处理。
- `markShortfallAsDebt`、`markShortfallAsDispute`、`markShortfallAsPendingWaiver` 已实现欠款、争议、待免除审批的纯函数状态处理。
- `requestRentWaiver`、`approveRentWaiver`、`rejectRentWaiver` 已实现免除申请、审批通过和拒绝的纯对象流程；审批权限和操作日志仍需后续接入真实服务端权限系统。
- `reverseRentPayment` 已实现已确认付款的纯函数冲正流程，会扣回台账已付金额并刷新台账状态。
- 本轮没有实现真实数据库事务、付款截图上传、权限过滤、收租日历 UI、IOPGPS、合同打印、NocoBase 页面配置、真实数据库迁移或 Docker 部署。

## 本轮纯函数实现补充：合同汇总、司机日历汇总与权限过滤

- `refreshContractFinancialSummary(contract, ledgers, deposits, today)` 已按纯函数方式计算合同财务汇总：当前欠款只统计 `rent_date <= today` 的未结清应收日期，未来应收单独计入 `future_receivable_amount`，免租日和已取消台账不计入应收，争议金额默认进入 `dispute_amount` 而不混入当前欠款。
- `refreshDriverCalendarSummary(driverId, contracts, ledgers, deposits, dateRange, today)` 已按司机和日期范围汇总每日台账与押金，押金仍与租金分开管理，不计入租金收入或 `total_paid_amount`。
- `getDriverCalendarData(input)` 已作为司机日历数据纯函数入口：支持按司机、日期范围、合同、车辆、付款状态、日历状态和 `debt_only` 过滤；`debt_only` 默认不返回未来应收，也不把争议混入欠款列表。
- `filterCalendarSensitiveData(data, currentUser)` 已对总已付、当前欠款、未来应收、押金、付款截图、付款方式及日级金额字段进行角色过滤；无权字段统一置为 `null` 并记录在 `hidden_fields`。
- 本轮不写数据库、不实现页面、不接入 NocoBase ACL。后续落库刷新合同汇总字段、司机日历 API 和权限配置时，必须在服务端事务与 ACL 中复用同等规则。

## 本轮纯函数实现补充：押金服务与操作日志服务

- `createDepositRecord(input)` 已实现押金记录创建校验：应收和实收金额不能为负，实收不能大于应收，押金不会生成租金付款，也不会计入租金 `total_paid_amount`。
- `refreshDepositStatus(deposit)`、`getDepositAvailableAmount(deposit)` 已实现押金可用金额和状态刷新；`waived`、`cancelled` 为本轮不自动覆盖的终态。
- `deductDeposit(deposit, input)`、`refundDeposit(deposit, input)`、`waiveDeposit(deposit, input)` 已实现抵扣、退款、免除的纯对象流程，均会返回预生成的脱敏操作日志对象。
- `recordOperationLog(input)`、`buildOperationLogForChange(params)` 与 `maskSensitiveLogValue(value)` 已实现操作日志纯函数，关键操作要求填写原因，敏感字段递归替换为 `[已隐藏]`。
- 本轮不写数据库、不实现真实文件上传、不实现在线支付接口；后续接入 NocoBase 时，押金变更和日志写入必须放入同一服务端事务。

## 本轮纯函数实现补充：IOPGPS 配置、状态、定位、里程与错误日志

- `isTokenExpired`、`shouldRefreshToken`、`buildTokenState` 已实现 token 状态判断；`getIopgpsAccessToken` 仍为真实 HTTP 接入预留入口，不调用真实 API。
- `normalizeIopgpsStatus` 和 `mapNormalizedStatusToVehicleGpsStatus` 已实现可测试的 GPS 状态归一化和车辆 GPS 状态映射。
- `buildGpsDeviceStatusLog`、`buildVehicleGpsStatusPatch`、`buildGpsLocationSnapshot`、`buildVehicleLocationPatch`、`buildGpsDailyMileage` 和 `buildMileageSyncKey` 已实现纯对象构建逻辑，不写数据库。
- `buildIopgpsErrorLog`、`maskIopgpsSensitiveValue`、`safeIopgpsSyncWrapper` 已实现错误日志构建、敏感字段脱敏和同步失败隔离；IOPGPS 失败不得影响租金台账和付款逻辑。

## 本轮纯函数实现补充：合同模板、合同文件状态、打印与扫描件

- `validateContractLanguage`、`getContractTemplateByLanguage`、`validateContractTemplate`、`selectTemplatesForLanguages` 已实现合同模板选择与校验纯函数。
- `buildContractRenderContext`、`buildContractDocumentDraft`、`generateContractDocuments`、`buildContractDocumentFileName`、`validateContractDocument` 已实现合同数据映射和合同文件记录构建，不真实生成 Word/PDF。
- `markContractPrinted`、`validatePrintableDocument`、`buildPrintRecordPatch` 已实现打印状态管理，不调用打印机。
- `markContractSigned`、`uploadSignedContractScan`、`validateSignedScanUpload`、`voidContractDocument` 已实现线下签署、扫描件引用登记和作废状态管理，不处理真实上传。
- `canTransitionContractDocumentStatus`、`assertContractDocumentStatusTransition`、`getContractSignatureStatusFromDocuments` 已实现状态流转校验与合同签署状态推导。
