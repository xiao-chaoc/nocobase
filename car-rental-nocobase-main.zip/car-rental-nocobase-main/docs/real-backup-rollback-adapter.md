# 真实 Backup / Rollback Adapter 草案

## 本轮范围

本轮实现的是真实 Backup / Rollback adapter 草案，用于在进入完整 NocoBase 测试工程前明确备份、回滚、失败隔离和后置验证的接口边界。

当前草案只生成计划，不执行任何真实操作：

- 不连接真实 NocoBase。
- 不执行真实备份。
- 不执行真实回滚。
- 不读取 `.env.test` 真实值。
- 不删除文件。
- 不修改 storage。
- 不禁用真实插件。
- 不修改真实数据库、Collection、Runtime、Page / UI Schema 或 Seed Data。

## 当前生成内容

草案 adapter 只生成以下内容：

1. 备份计划草案。
2. 回滚计划草案。
3. 失败恢复计划草案。
4. 回滚后验证计划草案。
5. 执行前安全检查结果。
6. 面向下一阶段的阻塞项和后续动作。

## 备份策略草案

备份计划覆盖以下目标：

- 数据库备份计划：只生成 `pg_dump` 草案说明，不执行命令。
- 文件存储备份计划：只生成 storage snapshot 草案说明，不复制文件。
- 插件安装状态备份计划：只记录 `storage/plugins` snapshot 草案，不读取或修改插件目录。
- Collection 注册前后 schema snapshot 草案。
- Runtime 注册前后状态 snapshot 草案。
- Page / UI Schema 注册前后 snapshot 草案。
- Seed Data 导入前后 snapshot 草案。
- 日志保留计划草案。
- 环境配置存在性记录草案：只记录 `.env.test` 需要存在，不读取具体值。

## 回滚策略草案

回滚计划覆盖以下目标：

- 数据库恢复草案。
- 文件存储恢复草案。
- 插件禁用或恢复测试前状态草案。
- Collection schema 恢复草案。
- Runtime registry 恢复草案。
- Page / UI Schema 恢复草案。
- Seed Data cleanup 草案。
- 生成产物 cleanup 草案。
- 日志保留草案。
- 环境配置恢复草案。

所有回滚步骤当前均为不可执行计划，不删除文件、不写数据库、不禁用插件、不恢复 storage。

## 失败恢复策略草案

失败恢复计划覆盖以下失败类型：

- Collection 注册失败。
- Runtime 注册失败。
- Page / UI Schema 注册失败。
- Seed Data 导入失败。
- Smoke Test 失败。
- 权限验证失败。
- IOPGPS 意外启用。
- 合同文件生成失败。
- 单日超付规则失败。
- 敏感数据暴露检测失败。

每个失败类型均包含检测方式、隔离步骤、回滚步骤、验证步骤和升级处理步骤。

## 日志保留策略

日志只作为排查证据保留计划，不在当前仓库读取真实日志、不上传日志、不删除日志。未来进入隔离测试环境后，需要确保失败前后的 NocoBase 日志、PostgreSQL 日志、脚本输出和操作审计均保留在测试日志目录中，并且不得进入 Git。

## 安全检查策略

安全检查必须阻止当前仓库执行 `real` 模式，原因包括：

- 当前仓库不是完整 NocoBase 工程。
- 缺少真实 `app`、`db`、storage、插件管理器、ACL、UI Schema、调度器和工作流上下文。
- 没有经过人工确认的隔离测试数据库。
- 本轮禁止真实 `pg_dump`、`pg_restore`、storage 修改、插件回滚和数据库写入。
- 不能读取或输出 `.env.test` 真实值。
- 不能让备份文件进入 Git。
- 不能对生产环境执行任何操作。

## 未来真实 adapter 替换方向

进入下一阶段后，真实 adapter 需要在完整 NocoBase 测试工程中逐步替换草案步骤：

1. 接入真实 `pg_dump` / `pg_restore` 或 NocoBase 官方备份能力。
2. 接入真实文件存储 snapshot。
3. 接入真实 `storage/plugins` 备份。
4. 接入真实 Collection schema snapshot。
5. 接入真实 Runtime registry snapshot。
6. 接入真实 Page / UI Schema snapshot。
7. 接入真实 Seed Data 前后状态 snapshot。
8. 接入真实回滚执行。
9. 接入真实日志保留与审计。

## 为什么当前不能执行 real 模式

当前仓库只能验证类型、计划转换和安全边界。它不具备完整 NocoBase runtime，也没有隔离测试库连接、插件管理器和 storage runtime。若在当前仓库允许 real 模式，会造成伪造成功、误删文件、误恢复数据库或泄露环境配置的风险。因此 `real` 模式必须被安全检查器和草案 adapter 明确拒绝。

## 进入下一阶段的条件

进入真实备份/回滚验证前必须满足：

1. 在完整 NocoBase 测试工程中锁定目标版本。
2. 准备隔离测试数据库，并确认只包含 mock 数据。
3. 准备隔离 storage 与 `storage/plugins`。
4. 明确 `.env.test` 只包含测试占位值，且不输出真实值。
5. 明确 IOPGPS 真实同步禁用。
6. 完成操作人确认机制。
7. 完成备份文件不进入 Git 的保护。
8. 完成本轮草案脚本、测试和 readiness 校验。

## 2026-06-05 本轮复核补充

本轮在仓库全盘扫描后复核草案边界，确认后置验证计划也接收 Backup / Rollback 上下文，仅归档操作人草案提示，不读取或输出真实密钥。`real` 模式仍必须在当前仓库被拒绝，所有备份、回滚、日志和 storage 步骤仍保持 `executed=false` 与 `canExecute=false`。
