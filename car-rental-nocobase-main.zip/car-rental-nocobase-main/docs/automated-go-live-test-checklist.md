# 自动化上线测试检查表

## 1. 代码检查

- [ ] `npm run typecheck` 通过。
- [ ] `npm run test` 通过。
- [ ] `npm run validate:test-data` 通过。
- [ ] `npm run check:plugin-structure` 通过。
- [ ] `npm run check:plugin-registration` 通过。
- [ ] `npm run preflight:nas-test` 通过。

## 2. 插件检查

- [ ] `plugin-rental-core` 可构建。
- [ ] `plugin-contract-documents` 可构建。
- [ ] `plugin-iopgps` 可构建。
- [ ] 三个插件可安装。
- [ ] 三个插件可启用。
- [ ] 三个插件可回滚。
- [ ] 插件顺序为 `plugin-rental-core` → `plugin-contract-documents` → `plugin-iopgps`。

## 3. 数据检查

- [ ] 只使用 mock 数据。
- [ ] 无真实证件。
- [ ] 无真实付款截图。
- [ ] 无真实合同扫描件。
- [ ] 无真实 IOPGPS 密钥。
- [ ] GPS 数据不参与租金计算。
- [ ] 没有短租、司机登录、按车型出租数据模型。

## 4. 环境检查

- [ ] `.env.test` 已人工创建。
- [ ] `.env.test` 未提交 Git。
- [ ] `APP_KEY` 已设置且不再随意改。
- [ ] `DB_PASSWORD` 已设置测试强密码。
- [ ] `INIT_ROOT_PASSWORD` 已设置测试强密码。
- [ ] `IOPGPS_SYNC_ENABLED=false`。
- [ ] NocoBase 端口可访问。
- [ ] PostgreSQL 数据目录与 NocoBase storage 分离。
- [ ] `storage-test/postgres` 用于 PostgreSQL。
- [ ] `storage-test/nocobase` 用于 NocoBase storage。

## 5. 功能检查

- [ ] Collections 自动创建。
- [ ] 页面自动创建。
- [ ] 菜单自动创建。
- [ ] 权限自动初始化。
- [ ] 测试数据自动导入。
- [ ] 核心流程可跑通。
- [ ] smoke test 通过。
- [ ] UAT 报告无阻塞项。

## 6. 风险检查

- [ ] 当前不接真实支付。
- [ ] 当前不接真实 IOPGPS。
- [ ] 当前不使用真实合同扫描件。
- [ ] 当前不使用真实司机资料。
- [ ] 当前不是生产上线。
- [ ] 没有要求用户手动在 NocoBase UI 中搭建业务系统。
- [ ] 正式上线测试前已固定 NocoBase 镜像版本，不再以 `latest-full` 作为正式测试基准。
