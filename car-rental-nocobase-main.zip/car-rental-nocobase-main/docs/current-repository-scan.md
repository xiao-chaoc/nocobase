# 当前仓库扫描记录

## 扫描时间

- UTC 时间：`2026-06-03T17:16:20Z`

## 扫描命令

```bash
find . -maxdepth 6 -type f \( -path './node_modules/*' -o -path './.git/*' -o -path './.test-dist/*' -o -path './storage-test/*' -o -path './backups-test/*' -o -path './logs-test/*' -o -path './test-runtime/*' \) -prune -o -type f -print | sort
```

## 当前仓库关键文件清单

本轮扫描已按要求排除 `node_modules`、`.git`、`.test-dist`、`storage-test`、`backups-test`、`logs-test`、`test-runtime`。关键文件清单覆盖根目录配置、核心文档、共享自动化层、NocoBase 脚本、插件目录、测试目录和测试数据目录；完整命令输出已在任务终端中展示。

## 关键文件与目录检查

- `AGENTS.md`：存在（文件）
- `SPEC.md`：存在（文件）
- `README.md`：存在（文件）
- `package.json`：存在（文件）
- `tsconfig.json`：存在（文件）
- `tsconfig.test.json`：存在（文件）
- `tsconfig.scripts.json`：存在（文件）
- `docker-compose.test.yml`：存在（文件）
- `.env.test.example`：存在（文件）
- `.gitignore`：存在（文件）
- `docs/automated-go-live-test-roadmap.md`：存在（文件）
- `docs/automated-nocobase-build-plan.md`：存在（文件）
- `docs/automated-plugin-install-plan.md`：存在（文件）
- `docs/automated-uat-test-plan.md`：存在（文件）
- `docs/automated-go-live-test-checklist.md`：存在（文件）
- `docs/automated-nocobase-registration-layer.md`：存在（文件）
- `docs/automated-collection-registration.md`：存在（文件）
- `docs/automated-runtime-registration.md`：存在（文件）
- `docs/automated-page-initialization.md`：存在（文件）
- `docs/automated-seed-data-import.md`：存在（文件）
- `docs/automated-smoke-test-dry-run.md`：存在（文件）
- `docs/deployment-nas-test.md`：存在（文件）
- `docs/nas-test-runbook.md`：存在（文件）
- `docs/nas-smoke-test-checklist.md`：存在（文件）
- `docs/plugin-install-test.md`：存在（文件）
- `docs/plugin-integration-checklist.md`：存在（文件）
- `docs/test-data.md`：存在（文件）
- `docs/test-environment-plan.md`：存在（文件）
- `docs/go-live-readiness-report.md`：存在（文件）
- `packages/shared/nocobase-automation/src/types.ts`：存在（文件）
- `packages/shared/nocobase-automation/src/registrationPlan.ts`：存在（文件）
- `packages/shared/nocobase-automation/src/registrationValidator.ts`：存在（文件）
- `packages/shared/nocobase-automation/src/dryRunExecutor.ts`：存在（文件）
- `packages/shared/nocobase-automation/src/collectionRegistrationExecutor.ts`：存在（文件）
- `packages/shared/nocobase-automation/src/runtimeRegistrationExecutor.ts`：存在（文件）
- `packages/shared/nocobase-automation/src/pageInitializationExecutor.ts`：存在（文件）
- `packages/shared/nocobase-automation/src/seedDataImportExecutor.ts`：存在（文件）
- `packages/shared/nocobase-automation/src/smokeTestOrchestrator.ts`：存在（文件）
- `packages/shared/nocobase-automation/src/goLiveReadinessEvaluator.ts`：存在（文件）
- `scripts/nocobase/generate-automated-registration-plan.ts`：存在（文件）
- `scripts/nocobase/validate-automated-registration-plan.ts`：存在（文件）
- `scripts/nocobase/dry-run-register-collections.ts`：存在（文件）
- `scripts/nocobase/validate-collection-registration.ts`：存在（文件）
- `scripts/nocobase/dry-run-register-runtime.ts`：存在（文件）
- `scripts/nocobase/validate-runtime-registration.ts`：存在（文件）
- `scripts/nocobase/dry-run-initialize-pages.ts`：存在（文件）
- `scripts/nocobase/validate-page-initialization.ts`：存在（文件）
- `scripts/nocobase/dry-run-import-test-data.ts`：存在（文件）
- `scripts/nocobase/validate-seed-data-import.ts`：存在（文件）
- `scripts/nocobase/run-automated-smoke-dry-run.ts`：存在（文件）
- `scripts/nocobase/validate-smoke-test-report.ts`：存在（文件）
- `scripts/nocobase/generate-go-live-readiness-report.ts`：存在（文件）
- `scripts/nocobase/validate-go-live-readiness-report.ts`：存在（文件）
- `packages/plugins/plugin-rental-core/`：存在（目录）
- `packages/plugins/plugin-iopgps/`：存在（目录）
- `packages/plugins/plugin-contract-documents/`：存在（目录）
- `tests/`：存在（目录）
- `tests/nocobase-automation/`：存在（目录）
- `tests/rental-core/`：存在（目录）
- `tests/iopgps/`：存在（目录）
- `tests/contract-documents/`：存在（目录）
- `tests/deployment/`：存在（目录）
- `tests/test-data/`：存在（目录）
- `test-data/fixtures/`：存在（目录）
- `test-data/generated/`：存在（目录）

## 缺失项

- 无。

## 本轮是否可以继续

可以继续本轮正式上线测试前 readiness 报告任务。

## 风险说明

- 本次扫描只检查当前 Codex Web 任务启动时检出的本地仓库内容，不检查 `git remote`，不检查 `origin/main`，不执行 `git pull` 或 `git fetch`。
- 当前仓库仍是 NocoBase 自动化接入 dry-run 骨架，不是完整真实 NocoBase 源码工程；后续接入真实 NocoBase 工程时仍需要实现并验证真实 adapter。
- 本轮只能基于仓库文件、dry-run 产物和本地报告做 readiness 评估，不连接真实 NocoBase，不部署 NAS，不安装真实插件，不写数据库。
- 即使 readiness 报告显示 dry-run 与 NAS 基础文件满足条件，也不能将当前项目误判为 `production_ready`。

## 与上一阶段预期是否一致

与上一阶段预期一致：上一阶段已生成 smoke dry-run 编排、报告脚本与测试数据 dry-run 产物，本次扫描确认这些关键路径均存在，并确认本轮 readiness 报告脚本、校验脚本、评估器、文档和生成报告路径也存在。

## 2026-06-04 真实 NocoBase Adapter 最小接口落地前扫描

### 扫描命令

```bash
find . -maxdepth 6 -type f \( -path './node_modules/*' -o -path './.git/*' -o -path './.test-dist/*' -o -path './storage-test/*' -o -path './backups-test/*' -o -path './logs-test/*' -o -path './test-runtime/*' \) -prune -o -type f -print | sort
```

### 本轮关键文件核对结果

本轮已在实现真实 NocoBase adapter 最小接口前完成全盘扫描，并按要求排除 `node_modules`、`.git`、`.test-dist`、`storage-test`、`backups-test`、`logs-test`、`test-runtime`。终端扫描输出确认根目录配置、readiness 与 dry-run 文档、共享自动化层源码、NocoBase 脚本、三个插件目录和 `tests/nocobase-automation/` 均存在。

#### 根目录

- `AGENTS.md`：存在。
- `SPEC.md`：存在。
- `README.md`：存在。
- `package.json`：存在。
- `tsconfig.json`：存在。
- `tsconfig.test.json`：存在。
- `tsconfig.scripts.json`：存在。
- `docker-compose.test.yml`：存在。
- `.env.test.example`：存在。

#### readiness 与 dry-run 文档

- `docs/current-repository-scan.md`：存在。
- `docs/automated-go-live-test-roadmap.md`：存在。
- `docs/automated-nocobase-registration-layer.md`：存在。
- `docs/automated-collection-registration.md`：存在。
- `docs/automated-runtime-registration.md`：存在。
- `docs/automated-page-initialization.md`：存在。
- `docs/automated-seed-data-import.md`：存在。
- `docs/automated-smoke-test-dry-run.md`：存在。
- `docs/go-live-readiness-report.md`：存在。
- `docs/deployment-nas-test.md`：存在。
- `docs/nas-test-runbook.md`：存在。

#### 共享自动化层

- `packages/shared/nocobase-automation/src/types.ts`：存在。
- `packages/shared/nocobase-automation/src/registrationPlan.ts`：存在。
- `packages/shared/nocobase-automation/src/collectionRegistrationExecutor.ts`：存在。
- `packages/shared/nocobase-automation/src/runtimeRegistrationExecutor.ts`：存在。
- `packages/shared/nocobase-automation/src/pageInitializationExecutor.ts`：存在。
- `packages/shared/nocobase-automation/src/seedDataImportExecutor.ts`：存在。
- `packages/shared/nocobase-automation/src/smokeTestOrchestrator.ts`：存在。
- `packages/shared/nocobase-automation/src/goLiveReadinessEvaluator.ts`：存在。

#### 脚本

- `scripts/nocobase/generate-go-live-readiness-report.ts`：存在。
- `scripts/nocobase/validate-go-live-readiness-report.ts`：存在。
- `scripts/nocobase/run-automated-smoke-dry-run.ts`：存在。

#### 插件目录

- `packages/plugins/plugin-rental-core/`：存在。
- `packages/plugins/plugin-iopgps/`：存在。
- `packages/plugins/plugin-contract-documents/`：存在。

### 缺失项与风险

- 本轮要求核对的关键文件和目录无缺失。
- 当前仓库仍不是完整 NocoBase 工程，缺少真实 `app`、`db`、ACL、UI Schema、插件管理器、调度器、工作流和文件存储上下文，因此本轮只能定义真实 adapter 的接口边界、占位实现、能力矩阵、环境检测和测试，不能执行真实注册。

### 本轮结论

可以继续进行“真实 NocoBase Adapter 实现计划与最小接口落地”。本轮禁止真实连接 NocoBase、真实写数据库、真实安装插件或伪造 NocoBase API。

## 2026-06-04 本轮真实 Collection 注册 Adapter 草案前仓库扫描

### 扫描命令

- 已执行：`find . -maxdepth 6 -type f \( -path './node_modules/*' -o -path './.git/*' -o -path './.test-dist/*' -o -path './storage-test/*' -o -path './backups-test/*' -o -path './logs-test/*' -o -path './test-runtime/*' \) -prune -o -type f -print | sort`
- 已执行关键路径存在性逐项检查，未检查 `git remote`、未检查 `origin/main`、未执行 `git pull` 或 `git fetch`。

### 当前仓库关键文件清单摘要

- 根目录文件：`AGENTS.md`、`SPEC.md`、`README.md`、`package.json`、`tsconfig.json`、`docker-compose.test.yml`、`.env.test.example` 均存在。
- 真实 adapter 基础文件：`nocobaseRealAdapter.ts`、`unconfiguredRealAdapter.ts`、`nocobaseAdapterFactory.ts`、`nocobaseEnvironmentInspector.ts`、`adapterErrors.ts` 与 `docs/nocobase-real-adapter-plan.md` 均存在。
- Collection dry-run 基础文件：`types.ts`、`collectionPlanNormalizer.ts`、`collectionRegistrationValidator.ts`、`mockCollectionAdapter.ts`、`collectionRegistrationExecutor.ts`、`dry-run-register-collections.ts`、`validate-collection-registration.ts` 与 `docs/automated-collection-registration.md` 均存在。
- 插件 Collection 草案目录：`packages/plugins/plugin-rental-core/src/server/collections/`、`packages/plugins/plugin-iopgps/src/server/collections/`、`packages/plugins/plugin-contract-documents/src/server/collections/` 均存在。
- 已生成测试数据目录中存在 `test-data/generated/automated-registration-plan.generated.json`，可作为本轮真实 Collection 注册草案计划的输入。

### 关键路径存在性对比

| 路径 | 状态 |
| --- | --- |
| `AGENTS.md` | 存在 |
| `SPEC.md` | 存在 |
| `README.md` | 存在 |
| `package.json` | 存在 |
| `tsconfig.json` | 存在 |
| `docker-compose.test.yml` | 存在 |
| `.env.test.example` | 存在 |
| `packages/shared/nocobase-automation/src/nocobaseRealAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/unconfiguredRealAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/nocobaseAdapterFactory.ts` | 存在 |
| `packages/shared/nocobase-automation/src/nocobaseEnvironmentInspector.ts` | 存在 |
| `packages/shared/nocobase-automation/src/adapterErrors.ts` | 存在 |
| `docs/nocobase-real-adapter-plan.md` | 存在 |
| `packages/shared/nocobase-automation/src/types.ts` | 存在 |
| `packages/shared/nocobase-automation/src/collectionPlanNormalizer.ts` | 存在 |
| `packages/shared/nocobase-automation/src/collectionRegistrationValidator.ts` | 存在 |
| `packages/shared/nocobase-automation/src/mockCollectionAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/collectionRegistrationExecutor.ts` | 存在 |
| `scripts/nocobase/dry-run-register-collections.ts` | 存在 |
| `scripts/nocobase/validate-collection-registration.ts` | 存在 |
| `docs/automated-collection-registration.md` | 存在 |
| `packages/plugins/plugin-rental-core/src/server/collections/` | 存在 |
| `packages/plugins/plugin-iopgps/src/server/collections/` | 存在 |
| `packages/plugins/plugin-contract-documents/src/server/collections/` | 存在 |

### 缺失项与风险

- 本轮要求的前置关键文件和目录未发现缺失。
- 当前真实 NocoBase adapter 仍处于接口和未配置边界阶段，仓库内没有可安全执行真实 Collection 创建、migration 或数据库写入的运行环境；本轮必须继续停留在计划、校验、转换器和草案 adapter 层。

## 2026-06-04 本轮真实 Runtime 注册 Adapter 草案前仓库扫描

### 扫描命令

- 已执行：`find . -maxdepth 6 -type f \( -path './node_modules/*' -o -path './.git/*' -o -path './.test-dist/*' -o -path './storage-test/*' -o -path './backups-test/*' -o -path './logs-test/*' -o -path './test-runtime/*' \) -prune -o -type f -print | sort`
- 已执行关键路径存在性逐项检查，未检查 `git remote`、未检查 `origin/main`、未执行 `git pull` 或 `git fetch`。

### 当前仓库关键文件清单摘要

- 根目录文件：`AGENTS.md`、`SPEC.md`、`README.md`、`package.json`、`tsconfig.json`、`docker-compose.test.yml`、`.env.test.example` 均存在。
- 真实 adapter 基础文件：`nocobaseRealAdapter.ts`、`unconfiguredRealAdapter.ts`、`nocobaseAdapterFactory.ts`、`nocobaseEnvironmentInspector.ts`、`adapterErrors.ts` 与 `docs/nocobase-real-adapter-plan.md` 均存在。
- 真实 Collection 草案文件：`realCollectionSchemaMapper.ts`、`realCollectionSafetyChecker.ts`、`realCollectionRegistrationAdapter.ts`、`generate-real-collection-registration-plan.ts`、`validate-real-collection-registration-plan.ts` 与 `docs/real-collection-registration-adapter.md` 均存在。
- Runtime dry-run 文件：`servicePlanNormalizer.ts`、`actionPlanNormalizer.ts`、`permissionPlanNormalizer.ts`、`schedulePlanNormalizer.ts`、`i18nPlanNormalizer.ts`、`runtimeRegistrationValidator.ts`、`mockRuntimeAdapter.ts`、`runtimeRegistrationExecutor.ts`、`dry-run-register-runtime.ts`、`validate-runtime-registration.ts` 与 `docs/automated-runtime-registration.md` 均存在。
- 插件 runtime 草案目录：`plugin-rental-core`、`plugin-iopgps`、`plugin-contract-documents` 的 `actions`、`permissions`、`schedules`、`locale` 相关目录均已核对；本轮要求的路径均存在。

### 关键路径存在性对比

| 路径 | 状态 |
| --- | --- |
| `AGENTS.md` | 存在 |
| `SPEC.md` | 存在 |
| `README.md` | 存在 |
| `package.json` | 存在 |
| `tsconfig.json` | 存在 |
| `docker-compose.test.yml` | 存在 |
| `.env.test.example` | 存在 |
| `packages/shared/nocobase-automation/src/nocobaseRealAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/unconfiguredRealAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/nocobaseAdapterFactory.ts` | 存在 |
| `packages/shared/nocobase-automation/src/nocobaseEnvironmentInspector.ts` | 存在 |
| `packages/shared/nocobase-automation/src/adapterErrors.ts` | 存在 |
| `docs/nocobase-real-adapter-plan.md` | 存在 |
| `packages/shared/nocobase-automation/src/realCollectionSchemaMapper.ts` | 存在 |
| `packages/shared/nocobase-automation/src/realCollectionSafetyChecker.ts` | 存在 |
| `packages/shared/nocobase-automation/src/realCollectionRegistrationAdapter.ts` | 存在 |
| `scripts/nocobase/generate-real-collection-registration-plan.ts` | 存在 |
| `scripts/nocobase/validate-real-collection-registration-plan.ts` | 存在 |
| `docs/real-collection-registration-adapter.md` | 存在 |
| `packages/shared/nocobase-automation/src/servicePlanNormalizer.ts` | 存在 |
| `packages/shared/nocobase-automation/src/actionPlanNormalizer.ts` | 存在 |
| `packages/shared/nocobase-automation/src/permissionPlanNormalizer.ts` | 存在 |
| `packages/shared/nocobase-automation/src/schedulePlanNormalizer.ts` | 存在 |
| `packages/shared/nocobase-automation/src/i18nPlanNormalizer.ts` | 存在 |
| `packages/shared/nocobase-automation/src/runtimeRegistrationValidator.ts` | 存在 |
| `packages/shared/nocobase-automation/src/mockRuntimeAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/runtimeRegistrationExecutor.ts` | 存在 |
| `scripts/nocobase/dry-run-register-runtime.ts` | 存在 |
| `scripts/nocobase/validate-runtime-registration.ts` | 存在 |
| `docs/automated-runtime-registration.md` | 存在 |
| `packages/plugins/plugin-rental-core/src/server/actions/` | 存在 |
| `packages/plugins/plugin-rental-core/src/server/permissions/` | 存在 |
| `packages/plugins/plugin-rental-core/src/server/schedules/` | 存在 |
| `packages/plugins/plugin-iopgps/src/server/actions/` | 存在 |
| `packages/plugins/plugin-iopgps/src/server/schedules/` | 存在 |
| `packages/plugins/plugin-contract-documents/src/server/actions/` | 存在 |
| `packages/plugins/plugin-rental-core/src/locale/` | 存在 |
| `packages/plugins/plugin-iopgps/src/locale/` | 存在 |
| `packages/plugins/plugin-contract-documents/src/locale/` | 存在 |

### 缺失项与风险

- 本轮要求核对的关键文件和目录未发现缺失。
- 当前仓库仍不是完整 NocoBase 工程，缺少真实 `app`、`db`、ACL、action/route/command、i18n loader、scheduler、workflow、插件生命周期和生产环境隔离控制，因此本轮只能实现真实 Runtime 注册 adapter 草案，不能执行或声称完成真实 Runtime 注册。

### 本轮结论

可以继续进行“真实 Runtime 注册 Adapter 草案”。本轮仅允许生成服务、动作、权限、i18n、定时任务的 schema draft、步骤、回滚计划、后置验证计划和安全检查；禁止真实连接 NocoBase、禁止真实注册 runtime 能力、禁止伪造 NocoBase API 成功。

## 真实 Seed Data Import Adapter 草案阶段扫描（2026-06-04）

### 扫描命令

```bash
find . -maxdepth 6 -type f \( -path './node_modules/*' -o -path './.git/*' -o -path './.test-dist/*' -o -path './storage-test/*' -o -path './backups-test/*' -o -path './logs-test/*' -o -path './test-runtime/*' \) -prune -o -type f -print | sort
```

### 本轮关键文件存在性

本轮已完成仓库全盘扫描，并按要求排除 `node_modules`、`.git`、`.test-dist`、`storage-test`、`backups-test`、`logs-test`、`test-runtime`。扫描确认以下路径均存在：

- 根目录：`AGENTS.md`、`SPEC.md`、`README.md`、`package.json`、`tsconfig.json`、`docker-compose.test.yml`、`.env.test.example`。
- 真实 adapter：`nocobaseRealAdapter.ts`、`unconfiguredRealAdapter.ts`、`nocobaseAdapterFactory.ts`、`nocobaseEnvironmentInspector.ts`、`adapterErrors.ts`、`docs/nocobase-real-adapter-plan.md`。
- 真实 Collection 草案：`realCollectionSchemaMapper.ts`、`realCollectionSafetyChecker.ts`、`realCollectionRegistrationAdapter.ts`、生成与校验脚本、`docs/real-collection-registration-adapter.md`。
- 真实 Runtime 草案：`realRuntimeSchemaMapper.ts`、`realRuntimeSafetyChecker.ts`、`realRuntimeRegistrationAdapter.ts`、生成与校验脚本、`docs/real-runtime-registration-adapter.md`。
- 真实 Page 草案：`realPageSchemaMapper.ts`、`realPageSafetyChecker.ts`、`realPageRegistrationAdapter.ts`、生成与校验脚本、`docs/real-page-registration-adapter.md`。
- Seed Data dry-run：`seedDataImportPlan.ts`、`seedDataImportValidator.ts`、`mockSeedDataAdapter.ts`、`seedDataImportExecutor.ts`、dry-run 与校验脚本、`docs/automated-seed-data-import.md`、`docs/test-data.md`。
- 测试数据目录：`test-data/fixtures/`、`test-data/generated/`。

### 缺失项与风险

- 本轮要求对比的关键路径未发现缺失项。
- 当前仓库仍不是完整真实 NocoBase 工程，本轮只能继续设计真实 Seed Data Import adapter 草案；不得连接真实 NocoBase、写数据库、上传文件、创建记录或执行真实事务。
- `test-data/generated/seed-data-import-dry-run.generated.json` 已存在，可作为生成真实 Seed Data Import 草案计划的输入，但该产物仍为 dry-run 测试数据计划，不代表真实导入已经发生。

### 本轮结论

可以继续实现真实 Seed Data Import adapter 草案，范围限定为接口边界、schema draft 转换、计划校验、事务与回滚计划、后置验证计划、脚本、测试和文档。

## 2026-06-04 真实 Smoke Test Adapter 草案前仓库扫描

本轮任务开始时已执行仓库全盘扫描命令：

```bash
find . -maxdepth 6 -type f \( -path './node_modules/*' -o -path './.git/*' -o -path './.test-dist/*' -o -path './storage-test/*' -o -path './backups-test/*' -o -path './logs-test/*' -o -path './test-runtime/*' \) -prune -o -type f -print | sort
```

扫描排除了 `node_modules`、`.git`、`.test-dist`、`storage-test`、`backups-test`、`logs-test`、`test-runtime`。关键文件核对结果如下：

### 根目录

- 存在：`AGENTS.md`
- 存在：`SPEC.md`
- 存在：`README.md`
- 存在：`package.json`
- 存在：`tsconfig.json`
- 存在：`docker-compose.test.yml`
- 存在：`.env.test.example`

### 真实 adapter 基础

- 存在：`packages/shared/nocobase-automation/src/nocobaseRealAdapter.ts`
- 存在：`packages/shared/nocobase-automation/src/unconfiguredRealAdapter.ts`
- 存在：`packages/shared/nocobase-automation/src/nocobaseAdapterFactory.ts`
- 存在：`packages/shared/nocobase-automation/src/nocobaseEnvironmentInspector.ts`
- 存在：`packages/shared/nocobase-automation/src/adapterErrors.ts`
- 存在：`docs/nocobase-real-adapter-plan.md`

### 真实 Collection 草案

- 存在：`packages/shared/nocobase-automation/src/realCollectionSchemaMapper.ts`
- 存在：`packages/shared/nocobase-automation/src/realCollectionSafetyChecker.ts`
- 存在：`packages/shared/nocobase-automation/src/realCollectionRegistrationAdapter.ts`
- 存在：`scripts/nocobase/generate-real-collection-registration-plan.ts`
- 存在：`scripts/nocobase/validate-real-collection-registration-plan.ts`
- 存在：`docs/real-collection-registration-adapter.md`

### 真实 Runtime 草案

- 存在：`packages/shared/nocobase-automation/src/realRuntimeSchemaMapper.ts`
- 存在：`packages/shared/nocobase-automation/src/realRuntimeSafetyChecker.ts`
- 存在：`packages/shared/nocobase-automation/src/realRuntimeRegistrationAdapter.ts`
- 存在：`scripts/nocobase/generate-real-runtime-registration-plan.ts`
- 存在：`scripts/nocobase/validate-real-runtime-registration-plan.ts`
- 存在：`docs/real-runtime-registration-adapter.md`

### 真实 Page 草案

- 存在：`packages/shared/nocobase-automation/src/realPageSchemaMapper.ts`
- 存在：`packages/shared/nocobase-automation/src/realPageSafetyChecker.ts`
- 存在：`packages/shared/nocobase-automation/src/realPageRegistrationAdapter.ts`
- 存在：`scripts/nocobase/generate-real-page-registration-plan.ts`
- 存在：`scripts/nocobase/validate-real-page-registration-plan.ts`
- 存在：`docs/real-page-registration-adapter.md`

### 真实 Seed Data 草案

- 存在：`packages/shared/nocobase-automation/src/realSeedDataSchemaMapper.ts`
- 存在：`packages/shared/nocobase-automation/src/realSeedDataSafetyChecker.ts`
- 存在：`packages/shared/nocobase-automation/src/realSeedDataImportAdapter.ts`
- 存在：`scripts/nocobase/generate-real-seed-data-import-plan.ts`
- 存在：`scripts/nocobase/validate-real-seed-data-import-plan.ts`
- 存在：`docs/real-seed-data-import-adapter.md`

### Smoke dry-run 相关

- 存在：`packages/shared/nocobase-automation/src/smokeTestOrchestrator.ts`
- 存在：`scripts/nocobase/run-automated-smoke-dry-run.ts`
- 存在：`scripts/nocobase/validate-smoke-test-report.ts`
- 存在：`docs/automated-smoke-test-dry-run.md`

### 风险结论

本轮要求核对的关键文件均存在，未发现缺失项。真实 Smoke Test Adapter 草案仍必须保持计划级边界，不得连接真实 NocoBase、不得写数据库、不得真实调用 IOPGPS、不得真实生成合同文件、不得将当前仓库标记为生产就绪。

## 2026-06-05 本轮真实 Backup / Rollback Adapter 草案前仓库扫描

### 扫描命令

- 已执行：`find . -maxdepth 6 -type f \( -path './node_modules/*' -o -path './.git/*' -o -path './.test-dist/*' -o -path './storage-test/*' -o -path './backups-test/*' -o -path './logs-test/*' -o -path './test-runtime/*' \) -prune -o -type f -print | sort`
- 已执行关键路径逐项存在性检查。
- 未检查 `git remote`，未检查 `origin/main`，未执行 `git pull`，未执行 `git fetch`。

### 当前仓库关键文件清单摘要

- 根目录：`AGENTS.md`、`SPEC.md`、`README.md`、`package.json`、`tsconfig.json`、`docker-compose.test.yml`、`.env.test.example` 均存在。
- 真实 adapter 基础：`nocobaseRealAdapter.ts`、`unconfiguredRealAdapter.ts`、`nocobaseAdapterFactory.ts`、`nocobaseEnvironmentInspector.ts`、`adapterErrors.ts` 与 `docs/nocobase-real-adapter-plan.md` 均存在。
- 已有真实草案 adapter：`realCollectionRegistrationAdapter.ts`、`realRuntimeRegistrationAdapter.ts`、`realPageRegistrationAdapter.ts`、`realSeedDataImportAdapter.ts`、`realSmokeTestAdapter.ts` 均存在。
- 已有生成脚本：真实 Collection、Runtime、Page、Seed Data、Smoke Test 计划生成脚本均存在。
- 现有测试环境脚本：`backup-test-db.sh`、`restore-test-db.sh`、`check-nas-test-env.sh`、`clean-nas-test-runtime.sh` 均存在。
- 文档：真实 Collection、Runtime、Page、Seed Data、Smoke Test 草案文档，以及 NAS 测试部署、运行手册、smoke checklist 均存在。

### 关键路径存在性对比

| 路径 | 状态 |
| --- | --- |
| `AGENTS.md` | 存在 |
| `SPEC.md` | 存在 |
| `README.md` | 存在 |
| `package.json` | 存在 |
| `tsconfig.json` | 存在 |
| `docker-compose.test.yml` | 存在 |
| `.env.test.example` | 存在 |
| `packages/shared/nocobase-automation/src/nocobaseRealAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/unconfiguredRealAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/nocobaseAdapterFactory.ts` | 存在 |
| `packages/shared/nocobase-automation/src/nocobaseEnvironmentInspector.ts` | 存在 |
| `packages/shared/nocobase-automation/src/adapterErrors.ts` | 存在 |
| `docs/nocobase-real-adapter-plan.md` | 存在 |
| `packages/shared/nocobase-automation/src/realCollectionRegistrationAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/realRuntimeRegistrationAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/realPageRegistrationAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/realSeedDataImportAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/realSmokeTestAdapter.ts` | 存在 |
| `scripts/nocobase/generate-real-collection-registration-plan.ts` | 存在 |
| `scripts/nocobase/generate-real-runtime-registration-plan.ts` | 存在 |
| `scripts/nocobase/generate-real-page-registration-plan.ts` | 存在 |
| `scripts/nocobase/generate-real-seed-data-import-plan.ts` | 存在 |
| `scripts/nocobase/generate-real-smoke-test-plan.ts` | 存在 |
| `scripts/backup-test-db.sh` | 存在 |
| `scripts/restore-test-db.sh` | 存在 |
| `scripts/check-nas-test-env.sh` | 存在 |
| `scripts/clean-nas-test-runtime.sh` | 存在 |
| `docs/real-collection-registration-adapter.md` | 存在 |
| `docs/real-runtime-registration-adapter.md` | 存在 |
| `docs/real-page-registration-adapter.md` | 存在 |
| `docs/real-seed-data-import-adapter.md` | 存在 |
| `docs/real-smoke-test-adapter.md` | 存在 |
| `docs/deployment-nas-test.md` | 存在 |
| `docs/nas-test-runbook.md` | 存在 |
| `docs/nas-smoke-test-checklist.md` | 存在 |

### 缺失项与风险

- 本轮要求核对的关键文件均存在，未发现缺失项。
- 当前仓库仍不是完整 NocoBase 工程，不能连接真实 `app`、`db`、storage、插件管理器、ACL 或 UI Schema。
- 现有 `scripts/backup-test-db.sh` 与 `scripts/restore-test-db.sh` 是测试环境脚本草案；本轮真实 Backup / Rollback adapter 仍不得调用这些脚本，不得执行 `pg_dump`、`pg_restore`、文件删除、storage 修改或插件回滚。
- `.env.test.example` 存在，但本轮只允许记录 `.env.test` 存在性要求，不允许读取或输出 `.env.test` 真实值。

### 本轮结论

可以继续进行“真实 Backup / Rollback Adapter 草案”阶段。本轮只实现接口边界、计划生成器、安全校验器、草案 adapter、脚本、测试和文档；不执行真实备份、真实回滚、真实 NocoBase API 或任何生产部署动作。

## 2026-06-05 本轮真实 Backup / Rollback Adapter 草案前仓库扫描

### 扫描命令

- 已执行：`find . -maxdepth 6 -type f \( -path './node_modules/*' -o -path './.git/*' -o -path './.test-dist/*' -o -path './storage-test/*' -o -path './backups-test/*' -o -path './logs-test/*' -o -path './test-runtime/*' \) -prune -o -type f -print | sort | sed 's#^./##'`
- 已执行关键路径存在性逐项检查。
- 本轮未检查 `git remote`，未检查 `origin/main`，未执行 `git pull` 或 `git fetch`。

### 当前仓库关键文件清单摘要

- 根目录关键文件：`AGENTS.md`、`SPEC.md`、`README.md`、`package.json`、`tsconfig.json`、`docker-compose.test.yml`、`.env.test.example` 均存在。
- 真实 adapter 基础：`nocobaseRealAdapter.ts`、`unconfiguredRealAdapter.ts`、`nocobaseAdapterFactory.ts`、`nocobaseEnvironmentInspector.ts`、`adapterErrors.ts` 与 `docs/nocobase-real-adapter-plan.md` 均存在。
- 真实草案前置 adapter：Collection、Runtime、Page、Seed Data、Smoke Test 草案 adapter 均存在。
- 生成脚本：真实 Collection、Runtime、Page、Seed Data、Smoke Test 计划生成脚本均存在。
- 测试环境脚本：`backup-test-db.sh`、`restore-test-db.sh`、`check-nas-test-env.sh`、`clean-nas-test-runtime.sh` 均存在。
- 文档：真实 Collection、Runtime、Page、Seed Data、Smoke Test adapter 文档、NAS 测试部署文档、NAS runbook 与 smoke test checklist 均存在。

### 关键路径存在性对比

| 路径 | 状态 |
| --- | --- |
| `AGENTS.md` | 存在 |
| `SPEC.md` | 存在 |
| `README.md` | 存在 |
| `package.json` | 存在 |
| `tsconfig.json` | 存在 |
| `docker-compose.test.yml` | 存在 |
| `.env.test.example` | 存在 |
| `packages/shared/nocobase-automation/src/nocobaseRealAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/unconfiguredRealAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/nocobaseAdapterFactory.ts` | 存在 |
| `packages/shared/nocobase-automation/src/nocobaseEnvironmentInspector.ts` | 存在 |
| `packages/shared/nocobase-automation/src/adapterErrors.ts` | 存在 |
| `docs/nocobase-real-adapter-plan.md` | 存在 |
| `packages/shared/nocobase-automation/src/realCollectionRegistrationAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/realRuntimeRegistrationAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/realPageRegistrationAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/realSeedDataImportAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/realSmokeTestAdapter.ts` | 存在 |
| `scripts/nocobase/generate-real-collection-registration-plan.ts` | 存在 |
| `scripts/nocobase/generate-real-runtime-registration-plan.ts` | 存在 |
| `scripts/nocobase/generate-real-page-registration-plan.ts` | 存在 |
| `scripts/nocobase/generate-real-seed-data-import-plan.ts` | 存在 |
| `scripts/nocobase/generate-real-smoke-test-plan.ts` | 存在 |
| `scripts/backup-test-db.sh` | 存在 |
| `scripts/restore-test-db.sh` | 存在 |
| `scripts/check-nas-test-env.sh` | 存在 |
| `scripts/clean-nas-test-runtime.sh` | 存在 |
| `docs/real-collection-registration-adapter.md` | 存在 |
| `docs/real-runtime-registration-adapter.md` | 存在 |
| `docs/real-page-registration-adapter.md` | 存在 |
| `docs/real-seed-data-import-adapter.md` | 存在 |
| `docs/real-smoke-test-adapter.md` | 存在 |
| `docs/deployment-nas-test.md` | 存在 |
| `docs/nas-test-runbook.md` | 存在 |
| `docs/nas-smoke-test-checklist.md` | 存在 |

### 缺失项与风险

- 本轮要求核对的关键路径未发现缺失。
- 当前仓库仍不是完整 NocoBase 工程，不能真实连接 NocoBase，不能真实执行 `pg_dump`、`pg_restore`、文件存储 snapshot、插件回滚、schema 恢复或 storage 修改。
- Backup / Rollback 本轮只能设计接口边界、计划转换器、校验器、草案 adapter、脚本、测试和文档，不能声称真实备份或真实回滚已经成功。

### 本轮结论

可以继续进行“真实 Backup / Rollback Adapter 草案”阶段。本轮必须保持 `plan_only`、`validate_only`、`dry_run` 边界，当前仓库环境下必须拒绝 `real` 模式。

## 2026-06-06 全盘扫描

本轮已按要求基于当前 Codex Web 任务启动时检出的仓库内容执行仓库全盘扫描，未检查 `git remote`，未检查 `origin/main`，未执行 `git pull` 或 `git fetch`。

### 扫描命令

```bash
find . -maxdepth 6 -type f \( -path './node_modules/*' -o -path './.git/*' -o -path './.test-dist/*' -o -path './storage-test/*' -o -path './backups-test/*' -o -path './logs-test/*' -o -path './test-runtime/*' \) -prune -o -type f -print | sort
```

### 扫描范围

- 最大深度：6。
- 已排除目录：`node_modules`、`.git`、`.test-dist`、`storage-test`、`backups-test`、`logs-test`、`test-runtime`。
- 扫描到的文件总数：282。

### 当前仓库关键文件清单

#### 根目录

| 路径 | 状态 |
| --- | --- |
| `AGENTS.md` | 存在 |
| `SPEC.md` | 存在 |
| `README.md` | 存在 |
| `package.json` | 存在 |
| `tsconfig.json` | 存在 |
| `docker-compose.test.yml` | 存在 |
| `.env.test.example` | 存在 |

#### 真实 Adapter 基础

| 路径 | 状态 |
| --- | --- |
| `packages/shared/nocobase-automation/src/nocobaseRealAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/unconfiguredRealAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/nocobaseAdapterFactory.ts` | 存在 |
| `packages/shared/nocobase-automation/src/nocobaseEnvironmentInspector.ts` | 存在 |
| `packages/shared/nocobase-automation/src/adapterErrors.ts` | 存在 |
| `docs/nocobase-real-adapter-plan.md` | 存在 |

#### 真实 Adapter 草案

| 路径 | 状态 |
| --- | --- |
| `packages/shared/nocobase-automation/src/realCollectionRegistrationAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/realRuntimeRegistrationAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/realPageRegistrationAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/realSeedDataImportAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/realSmokeTestAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/realBackupRollbackAdapter.ts` | 存在 |

#### 真实 Adapter 文档

| 路径 | 状态 |
| --- | --- |
| `docs/real-collection-registration-adapter.md` | 存在 |
| `docs/real-runtime-registration-adapter.md` | 存在 |
| `docs/real-page-registration-adapter.md` | 存在 |
| `docs/real-seed-data-import-adapter.md` | 存在 |
| `docs/real-smoke-test-adapter.md` | 存在 |
| `docs/real-backup-rollback-adapter.md` | 存在 |

#### 真实草案生成脚本

| 路径 | 状态 |
| --- | --- |
| `scripts/nocobase/generate-real-collection-registration-plan.ts` | 存在 |
| `scripts/nocobase/validate-real-collection-registration-plan.ts` | 存在 |
| `scripts/nocobase/generate-real-runtime-registration-plan.ts` | 存在 |
| `scripts/nocobase/validate-real-runtime-registration-plan.ts` | 存在 |
| `scripts/nocobase/generate-real-page-registration-plan.ts` | 存在 |
| `scripts/nocobase/validate-real-page-registration-plan.ts` | 存在 |
| `scripts/nocobase/generate-real-seed-data-import-plan.ts` | 存在 |
| `scripts/nocobase/validate-real-seed-data-import-plan.ts` | 存在 |
| `scripts/nocobase/generate-real-smoke-test-plan.ts` | 存在 |
| `scripts/nocobase/validate-real-smoke-test-plan.ts` | 存在 |
| `scripts/nocobase/generate-real-backup-rollback-plan.ts` | 存在 |
| `scripts/nocobase/validate-real-backup-rollback-plan.ts` | 存在 |

#### 测试与产物

| 路径 | 状态 |
| --- | --- |
| `tests/nocobase-automation/` | 存在 |
| `test-data/generated/` | 存在 |

### 扫描结论

- 本轮要求对比的关键文件与目录均存在。
- 当前仓库具备继续编写真实 NocoBase 工程接入 Runbook、实施顺序、宿主工程要求、风险清单和 readiness 检查脚本的文档基础。
- 当前仓库仍只是插件骨架、dry-run 自动化层和真实 Adapter 草案仓库，不是完整 NocoBase 应用，不应直接正式上线测试或生产部署。

### 缺失项与风险

无本轮关键路径缺失项。

仍需注意的阶段性风险：

1. 当前仓库没有完整 NocoBase 源码工程上下文，不能验证真实 NocoBase API 调用。
2. dry-run 和真实 Adapter 草案通过不代表真实 Collection、权限、页面、数据导入、备份或回滚已经在 NocoBase 中成功执行。
3. 下一阶段必须在隔离的完整 NocoBase 工程、隔离 PostgreSQL 测试库和隔离 storage 中实施真实 adapter。

## 2026-06-06 全盘扫描结果

本轮已按任务要求执行仓库全盘扫描，命令如下：

```bash
find . -maxdepth 6 -type f \
  \( -path './node_modules/*' -o -path './.git/*' -o -path './.test-dist/*' -o -path './storage-test/*' -o -path './backups-test/*' -o -path './logs-test/*' -o -path './test-runtime/*' \) -prune \
  -o -type f -print | sort
```

扫描排除了 `node_modules`、`.git`、`.test-dist`、`storage-test`、`backups-test`、`logs-test`、`test-runtime`。

### 当前仓库关键文件清单

- 根目录：`AGENTS.md`、`SPEC.md`、`README.md`、`package.json`、`tsconfig.json`、`docker-compose.test.yml`、`.env.test.example`。
- 真实 NocoBase 接入文档：`docs/real-nocobase-integration-runbook.md`、`docs/real-adapter-implementation-sequence.md`、`docs/real-nocobase-host-requirements.md`、`docs/real-integration-risk-register.md`、`docs/nocobase-real-adapter-plan.md`、`docs/go-live-readiness-report.md`。
- 真实 Adapter 草案文档：`docs/real-collection-registration-adapter.md`、`docs/real-runtime-registration-adapter.md`、`docs/real-page-registration-adapter.md`、`docs/real-seed-data-import-adapter.md`、`docs/real-smoke-test-adapter.md`、`docs/real-backup-rollback-adapter.md`。
- 真实 Adapter 草案代码：`packages/shared/nocobase-automation/src/nocobaseRealAdapter.ts`、`packages/shared/nocobase-automation/src/unconfiguredRealAdapter.ts`、`packages/shared/nocobase-automation/src/nocobaseAdapterFactory.ts`、`packages/shared/nocobase-automation/src/nocobaseEnvironmentInspector.ts`、`packages/shared/nocobase-automation/src/realCollectionRegistrationAdapter.ts`、`packages/shared/nocobase-automation/src/realRuntimeRegistrationAdapter.ts`、`packages/shared/nocobase-automation/src/realPageRegistrationAdapter.ts`、`packages/shared/nocobase-automation/src/realSeedDataImportAdapter.ts`、`packages/shared/nocobase-automation/src/realSmokeTestAdapter.ts`、`packages/shared/nocobase-automation/src/realBackupRollbackAdapter.ts`。
- 插件骨架：`packages/plugins/plugin-rental-core`、`packages/plugins/plugin-contract-documents`、`packages/plugins/plugin-iopgps`。
- 校验与生成脚本：`scripts/nocobase/*`。
- 测试：`tests/nocobase-automation/*`、`tests/rental-core/*`、`tests/iopgps/*`、`tests/contract-documents/*`、`tests/deployment/*`。

### 任务要求关键路径对比

| 分类 | 路径 | 状态 |
| --- | --- | --- |
| 根目录 | `AGENTS.md` | 存在 |
| 根目录 | `SPEC.md` | 存在 |
| 根目录 | `README.md` | 存在 |
| 根目录 | `package.json` | 存在 |
| 根目录 | `tsconfig.json` | 存在 |
| 根目录 | `docker-compose.test.yml` | 存在 |
| 根目录 | `.env.test.example` | 存在 |
| 真实接入文档 | `docs/real-nocobase-integration-runbook.md` | 存在 |
| 真实接入文档 | `docs/real-adapter-implementation-sequence.md` | 存在 |
| 真实接入文档 | `docs/real-nocobase-host-requirements.md` | 存在 |
| 真实接入文档 | `docs/real-integration-risk-register.md` | 存在 |
| 真实接入文档 | `docs/nocobase-real-adapter-plan.md` | 存在 |
| 真实接入文档 | `docs/go-live-readiness-report.md` | 存在 |
| 草案文档 | `docs/real-collection-registration-adapter.md` | 存在 |
| 草案文档 | `docs/real-runtime-registration-adapter.md` | 存在 |
| 草案文档 | `docs/real-page-registration-adapter.md` | 存在 |
| 草案文档 | `docs/real-seed-data-import-adapter.md` | 存在 |
| 草案文档 | `docs/real-smoke-test-adapter.md` | 存在 |
| 草案文档 | `docs/real-backup-rollback-adapter.md` | 存在 |
| 草案代码 | `packages/shared/nocobase-automation/src/nocobaseRealAdapter.ts` | 存在 |
| 草案代码 | `packages/shared/nocobase-automation/src/unconfiguredRealAdapter.ts` | 存在 |
| 草案代码 | `packages/shared/nocobase-automation/src/nocobaseAdapterFactory.ts` | 存在 |
| 草案代码 | `packages/shared/nocobase-automation/src/nocobaseEnvironmentInspector.ts` | 存在 |
| 草案代码 | `packages/shared/nocobase-automation/src/realCollectionRegistrationAdapter.ts` | 存在 |
| 草案代码 | `packages/shared/nocobase-automation/src/realRuntimeRegistrationAdapter.ts` | 存在 |
| 草案代码 | `packages/shared/nocobase-automation/src/realPageRegistrationAdapter.ts` | 存在 |
| 草案代码 | `packages/shared/nocobase-automation/src/realSeedDataImportAdapter.ts` | 存在 |
| 草案代码 | `packages/shared/nocobase-automation/src/realSmokeTestAdapter.ts` | 存在 |
| 草案代码 | `packages/shared/nocobase-automation/src/realBackupRollbackAdapter.ts` | 存在 |

### 缺失项与风险

本轮要求对比的关键文件未发现缺失项。

仍需注意：当前仓库不是完整 NocoBase 工程，扫描结果只能证明文档、草案、脚本和测试文件齐备，不能证明真实 NocoBase 插件 API 已验证，也不能作为正式上线测试或生产部署依据。

## 2026-06-06 本轮宿主工程接入准备扫描

### 扫描命令

```bash
find . -maxdepth 6 -type f \( -path './node_modules/*' -o -path './.git/*' -o -path './.test-dist/*' -o -path './storage-test/*' -o -path './backups-test/*' -o -path './logs-test/*' -o -path './test-runtime/*' \) -prune -o -type f -print | sort
```

### 关键文件清单

本轮扫描确认当前仓库包含以下关键文件与目录：

#### 根目录

| 路径 | 状态 |
| --- | --- |
| `AGENTS.md` | 存在 |
| `SPEC.md` | 存在 |
| `README.md` | 存在 |
| `package.json` | 存在 |
| `tsconfig.json` | 存在 |
| `docker-compose.test.yml` | 存在 |
| `.env.test.example` | 存在 |

#### NocoBase 目标版本与 API 调研

| 路径 | 状态 |
| --- | --- |
| `docs/nocobase-target-version-research.md` | 存在 |
| `docs/nocobase-plugin-api-research.md` | 存在 |
| `docs/real-adapter-api-mapping.md` | 存在 |
| `docs/real-adapter-gap-analysis.md` | 存在 |
| `docs/real-adapter-implementation-backlog.md` | 存在 |
| `scripts/nocobase/validate-nocobase-api-research.ts` | 存在 |

#### 真实接入 Runbook

| 路径 | 状态 |
| --- | --- |
| `docs/real-nocobase-integration-runbook.md` | 存在 |
| `docs/real-adapter-implementation-sequence.md` | 存在 |
| `docs/real-nocobase-host-requirements.md` | 存在 |
| `docs/real-integration-risk-register.md` | 存在 |

#### 真实 Adapter 草案

| 路径 | 状态 |
| --- | --- |
| `docs/real-collection-registration-adapter.md` | 存在 |
| `docs/real-runtime-registration-adapter.md` | 存在 |
| `docs/real-page-registration-adapter.md` | 存在 |
| `docs/real-seed-data-import-adapter.md` | 存在 |
| `docs/real-smoke-test-adapter.md` | 存在 |
| `docs/real-backup-rollback-adapter.md` | 存在 |

#### 真实 Adapter 草案代码

| 路径 | 状态 |
| --- | --- |
| `packages/shared/nocobase-automation/src/nocobaseRealAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/unconfiguredRealAdapter.ts` | 存在 |
| `packages/shared/nocobase-automation/src/nocobaseAdapterFactory.ts` | 存在 |
| `packages/shared/nocobase-automation/src/nocobaseEnvironmentInspector.ts` | 存在 |
| `packages/shared/nocobase-automation/src/adapterErrors.ts` | 存在 |

#### 插件目录

| 路径 | 状态 |
| --- | --- |
| `packages/plugins/plugin-rental-core/` | 存在 |
| `packages/plugins/plugin-iopgps/` | 存在 |
| `packages/plugins/plugin-contract-documents/` | 存在 |

### 扫描结论

本轮要求对比的关键路径均存在，未发现必须阻断宿主工程接入准备文档创建的缺失项。本轮继续创建目标版本决策记录、宿主工程准备方案、dry-run 引导脚本草案与校验脚本。

### 风险提示

- 当前仓库仍不是完整 NocoBase 宿主工程，不能把 dry-run 成功视为真实接入成功。
- 当前扫描未拉取完整 NocoBase 源码，未验证真实插件 API。
- 目标 NocoBase 版本尚未人工锁定，真实 adapter 不应进入实现阶段。

## 2026-06-06 本轮全盘扫描结果

### 扫描命令

```bash
find . -maxdepth 6 -type f \( -path './node_modules/*' -o -path './.git/*' -o -path './.test-dist/*' -o -path './storage-test/*' -o -path './backups-test/*' -o -path './logs-test/*' -o -path './test-runtime/*' \) -prune -o -type f -print | sort
```

### 扫描结论

本轮已完成仓库全盘文件扫描，并按要求排除 `node_modules`、`.git`、`.test-dist`、`storage-test`、`backups-test`、`logs-test`、`test-runtime`。当前关键文件均存在，未发现本轮列出的关键路径缺失项。

### 根目录关键文件

- `AGENTS.md`：存在。
- `SPEC.md`：存在。
- `README.md`：存在。
- `package.json`：存在。
- `tsconfig.json`：存在。
- `docker-compose.test.yml`：存在。
- `.env.test.example`：存在。

### 目标版本与 API 调研

- `docs/nocobase-target-version-research.md`：存在。
- `docs/nocobase-target-version-decision.md`：存在。
- `docs/nocobase-plugin-api-research.md`：存在。
- `docs/real-adapter-api-mapping.md`：存在。
- `docs/real-adapter-gap-analysis.md`：存在。
- `docs/real-adapter-implementation-backlog.md`：存在。
- `scripts/nocobase/validate-nocobase-api-research.ts`：存在。

### 宿主工程准备

- `docs/nocobase-host-bootstrap-runbook.md`：存在。
- `docs/nocobase-host-integration-branch-plan.md`：存在。
- `docs/nocobase-source-api-verification-plan.md`：存在。
- `docs/real-nocobase-host-requirements.md`：存在。
- `docs/real-nocobase-integration-runbook.md`：存在。
- `docs/real-adapter-implementation-sequence.md`：存在。
- `scripts/host/prepare-nocobase-host-workspace.sh`：存在。
- `scripts/host/check-host-prerequisites.ts`：存在。
- `scripts/host/copy-project-plugins-to-host.ts`：存在。
- `scripts/host/validate-host-workspace.ts`：存在。
- `scripts/nocobase/validate-host-bootstrap-docs.ts`：存在。

### Readiness 与风险

- `docs/go-live-readiness-report.md`：存在。
- `docs/real-integration-risk-register.md`：存在。
- `docs/current-repository-scan.md`：存在。
- `scripts/nocobase/validate-real-integration-readiness.ts`：存在。

### 本轮风险记录

- 当前目标 NocoBase 版本仍未人工确认，`decision_status` 必须保持 `pending_manual_confirmation`。
- `target_version` 仍为 `unset`，不得把 `latest-full` 作为真实 adapter 接入目标版本。
- 版本冻结前不得实现真实 adapter、不得创建完整宿主工程、不得在 NAS 上安装插件、不得进入 UAT。
- 当前仍不能正式上线测试，仍不能生产部署。

## 2026-06-06 本轮目标版本确认门禁扫描补充

本轮已在实现任何代码前执行仓库全盘扫描，命令为：

```bash
find . -maxdepth 6 -type f \
  \( -path './node_modules/*' -o -path './.git/*' -o -path './.test-dist/*' -o -path './storage-test/*' -o -path './backups-test/*' -o -path './logs-test/*' -o -path './test-runtime/*' \) -prune \
  -o -type f -print | sort
```

扫描排除了 `node_modules`、`.git`、`.test-dist`、`storage-test`、`backups-test`、`logs-test`、`test-runtime`。本轮扫描只读取仓库文件，不读取 `.env`，不读取 `.env.test`，不连接 NocoBase，不访问外部网络，不写数据库。

### 本轮关键路径对比结果

| 分组 | 路径 | 状态 |
| --- | --- | --- |
| 根目录 | `AGENTS.md` | 存在 |
| 根目录 | `SPEC.md` | 存在 |
| 根目录 | `README.md` | 存在 |
| 根目录 | `package.json` | 存在 |
| 根目录 | `tsconfig.json` | 存在 |
| 根目录 | `docker-compose.test.yml` | 存在 |
| 根目录 | `.env.test.example` | 存在 |
| 目标版本确认 | `docs/nocobase-target-version-decision.md` | 存在 |
| 目标版本确认 | `docs/nocobase-target-version-manual-confirmation.md` | 存在 |
| 目标版本确认 | `docs/nocobase-target-version-freeze-template.md` | 存在 |
| 目标版本确认 | `docs/nocobase-target-version-input-schema.md` | 存在 |
| 目标版本确认 | `docs/nocobase-target-version-research.md` | 存在 |
| 目标版本确认 | `scripts/nocobase/validate-target-version-confirmation.ts` | 存在 |
| 目标版本确认 | `scripts/nocobase/generate-target-version-confirmation-template.ts` | 存在 |
| 宿主工程准备 | `docs/nocobase-host-bootstrap-runbook.md` | 存在 |
| 宿主工程准备 | `docs/nocobase-host-integration-branch-plan.md` | 存在 |
| 宿主工程准备 | `docs/nocobase-source-api-verification-plan.md` | 存在 |
| 宿主工程准备 | `docs/real-nocobase-host-requirements.md` | 存在 |
| 宿主工程准备 | `docs/real-nocobase-integration-runbook.md` | 存在 |
| 宿主工程准备 | `docs/real-adapter-implementation-sequence.md` | 存在 |
| Readiness | `docs/go-live-readiness-report.md` | 存在 |
| Readiness | `docs/current-repository-scan.md` | 存在 |
| Readiness | `scripts/nocobase/validate-real-integration-readiness.ts` | 存在 |
| Readiness | `scripts/nocobase/validate-host-bootstrap-docs.ts` | 存在 |
| Readiness | `scripts/nocobase/validate-nocobase-api-research.ts` | 存在 |

### 本轮扫描结论

- 本轮指定必须对比的关键路径均存在，未发现缺失项。
- 当前目标 NocoBase 版本仍为 `pending_manual_confirmation` / `target_version = unset`。
- 因目标版本未确认，不能继续真实 adapter、宿主工程接入、NocoBase 连接、数据库写入或生产部署。
- 本轮可以继续创建目标版本确认输入校验、应用脚本、工作流文档和防误推进门禁。

### 本轮新增门禁风险记录

- 用户填写的 `test-data/generated/nocobase-target-version-confirmation.filled.json` 可能包含敏感字段，因此必须通过输入校验脚本拒绝 `APP_KEY`、`DB_PASSWORD`、`INIT_ROOT_PASSWORD`、`IOPGPS_LOGIN_KEY`、`access_token`、`login_key` 和任何密码字段。
- 在 `validate:target-version-confirmation` 未通过前，`validate:can-start-real-adapter` 必须失败，防止把未确认版本或 `latest-full` 当作真实接入目标。
- 当前仍不能正式上线测试，仍不能生产部署。

## 2026-06-06 本轮仓库全盘扫描：目标版本确认 GitHub 审查流程

### 执行的扫描命令

```bash
find . -maxdepth 6 -type f \
  \( -path './node_modules/*' -o -path './.git/*' -o -path './.test-dist/*' -o -path './storage-test/*' -o -path './backups-test/*' -o -path './logs-test/*' -o -path './test-runtime/*' \) -prune \
  -o -type f -print | sort
```

### 关键文件清单对比

根目录关键文件均存在：`AGENTS.md`、`SPEC.md`、`README.md`、`package.json`、`tsconfig.json`、`docker-compose.test.yml`、`.env.test.example`、`.gitignore`。

目标版本确认相关关键文件均存在：`docs/nocobase-target-version-decision.md`、`docs/nocobase-target-version-manual-confirmation.md`、`docs/nocobase-target-version-freeze-template.md`、`docs/nocobase-target-version-input-schema.md`、`docs/nocobase-target-version-confirmation-workflow.md`、`scripts/nocobase/validate-target-version-input.ts`、`scripts/nocobase/apply-target-version-confirmation.ts`、`scripts/nocobase/validate-target-version-confirmation.ts`、`scripts/nocobase/validate-can-start-real-adapter.ts`、`scripts/nocobase/generate-target-version-confirmation-template.ts`。

宿主工程准备相关关键文件均存在：`docs/nocobase-host-bootstrap-runbook.md`、`docs/nocobase-host-integration-branch-plan.md`、`docs/nocobase-source-api-verification-plan.md`、`docs/real-nocobase-host-requirements.md`、`docs/real-nocobase-integration-runbook.md`、`docs/real-adapter-implementation-sequence.md`。

Readiness 相关关键文件均存在：`docs/go-live-readiness-report.md`、`docs/current-repository-scan.md`、`scripts/nocobase/validate-real-integration-readiness.ts`、`scripts/nocobase/validate-host-bootstrap-docs.ts`、`scripts/nocobase/validate-nocobase-api-research.ts`。

### 缺失项与风险

本轮指定关键路径未发现缺失项。风险仍是目标 NocoBase 版本尚未人工确认，`decision_status` 仍为 `pending_manual_confirmation`，`target_version` 仍为 `unset`，因此不得进入真实 adapter、不得创建完整宿主工程真实接入、不得连接 NocoBase、不得写数据库、不得正式上线测试、不得生产部署。

### 本轮新增流程扫描项

本轮将新增 GitHub Issue 模板、PR 模板、人工确认操作清单、提交规范、review checklist、流程文件校验脚本和测试，用于让目标版本人工确认通过 Issue + filled.json + apply 脚本 + PR 审查完成。

## 2026-06-06 本轮 NocoBase v2.0.61 宿主工程接入任务包前仓库扫描

### 扫描命令

- 已执行：`find . -maxdepth 6 -type f \( -path './node_modules/*' -o -path './.git/*' -o -path './.test-dist/*' -o -path './storage-test/*' -o -path './backups-test/*' -o -path './logs-test/*' -o -path './test-runtime/*' \) -prune -o -type f -print | sort`
- 已执行关键路径存在性逐项检查。
- 本轮未检查 `git remote`，未检查 `origin/main`，未执行 `git pull`，未执行 `git fetch`。

### 当前仓库关键文件清单摘要

- 根目录关键文件：`AGENTS.md`、`SPEC.md`、`README.md`、`package.json`、`tsconfig.json`、`docker-compose.test.yml`、`.env.test.example`、`.gitignore` 均存在。
- 目标版本确认相关文档与脚本：`docs/nocobase-target-version-decision.md`、`docs/nocobase-target-version-confirmation-workflow.md`、`docs/nocobase-target-version-input-schema.md`、`scripts/nocobase/validate-target-version-confirmation.ts`、`scripts/nocobase/validate-can-start-real-adapter.ts`、`scripts/nocobase/validate-target-version-input.ts`、`scripts/nocobase/apply-target-version-confirmation.ts` 均存在。
- 宿主工程准备相关文档：`docs/nocobase-host-bootstrap-runbook.md`、`docs/nocobase-host-integration-branch-plan.md`、`docs/nocobase-source-api-verification-plan.md`、`docs/real-nocobase-host-requirements.md`、`docs/real-nocobase-integration-runbook.md`、`docs/real-adapter-implementation-sequence.md`、`docs/real-adapter-implementation-backlog.md`、`docs/real-integration-risk-register.md` 均存在。
- 真实 adapter 草案相关文档与源码：`docs/real-collection-registration-adapter.md`、`docs/real-runtime-registration-adapter.md`、`docs/real-page-registration-adapter.md`、`docs/real-seed-data-import-adapter.md`、`docs/real-smoke-test-adapter.md`、`docs/real-backup-rollback-adapter.md`、`packages/shared/nocobase-automation/src/nocobaseRealAdapter.ts`、`packages/shared/nocobase-automation/src/unconfiguredRealAdapter.ts`、`packages/shared/nocobase-automation/src/nocobaseAdapterFactory.ts`、`packages/shared/nocobase-automation/src/nocobaseEnvironmentInspector.ts` 均存在。
- 插件目录：`packages/plugins/plugin-rental-core/`、`packages/plugins/plugin-contract-documents/`、`packages/plugins/plugin-iopgps/`、`packages/shared/nocobase-automation/` 均存在。

### 关键路径存在性对比

| 分类 | 路径 | 状态 |
| --- | --- | --- |
| 根目录 | `AGENTS.md` | 存在 |
| 根目录 | `SPEC.md` | 存在 |
| 根目录 | `README.md` | 存在 |
| 根目录 | `package.json` | 存在 |
| 根目录 | `tsconfig.json` | 存在 |
| 根目录 | `docker-compose.test.yml` | 存在 |
| 根目录 | `.env.test.example` | 存在 |
| 根目录 | `.gitignore` | 存在 |
| 目标版本确认 | `docs/nocobase-target-version-decision.md` | 存在 |
| 目标版本确认 | `docs/nocobase-target-version-confirmation-workflow.md` | 存在 |
| 目标版本确认 | `docs/nocobase-target-version-input-schema.md` | 存在 |
| 目标版本确认 | `scripts/nocobase/validate-target-version-confirmation.ts` | 存在 |
| 目标版本确认 | `scripts/nocobase/validate-can-start-real-adapter.ts` | 存在 |
| 目标版本确认 | `scripts/nocobase/validate-target-version-input.ts` | 存在 |
| 目标版本确认 | `scripts/nocobase/apply-target-version-confirmation.ts` | 存在 |
| 宿主工程准备 | `docs/nocobase-host-bootstrap-runbook.md` | 存在 |
| 宿主工程准备 | `docs/nocobase-host-integration-branch-plan.md` | 存在 |
| 宿主工程准备 | `docs/nocobase-source-api-verification-plan.md` | 存在 |
| 宿主工程准备 | `docs/real-nocobase-host-requirements.md` | 存在 |
| 宿主工程准备 | `docs/real-nocobase-integration-runbook.md` | 存在 |
| 宿主工程准备 | `docs/real-adapter-implementation-sequence.md` | 存在 |
| 宿主工程准备 | `docs/real-adapter-implementation-backlog.md` | 存在 |
| 宿主工程准备 | `docs/real-integration-risk-register.md` | 存在 |
| 真实 adapter 草案 | `docs/real-collection-registration-adapter.md` | 存在 |
| 真实 adapter 草案 | `docs/real-runtime-registration-adapter.md` | 存在 |
| 真实 adapter 草案 | `docs/real-page-registration-adapter.md` | 存在 |
| 真实 adapter 草案 | `docs/real-seed-data-import-adapter.md` | 存在 |
| 真实 adapter 草案 | `docs/real-smoke-test-adapter.md` | 存在 |
| 真实 adapter 草案 | `docs/real-backup-rollback-adapter.md` | 存在 |
| 真实 adapter 草案 | `packages/shared/nocobase-automation/src/nocobaseRealAdapter.ts` | 存在 |
| 真实 adapter 草案 | `packages/shared/nocobase-automation/src/unconfiguredRealAdapter.ts` | 存在 |
| 真实 adapter 草案 | `packages/shared/nocobase-automation/src/nocobaseAdapterFactory.ts` | 存在 |
| 真实 adapter 草案 | `packages/shared/nocobase-automation/src/nocobaseEnvironmentInspector.ts` | 存在 |
| 插件目录 | `packages/plugins/plugin-rental-core/` | 存在 |
| 插件目录 | `packages/plugins/plugin-contract-documents/` | 存在 |
| 插件目录 | `packages/plugins/plugin-iopgps/` | 存在 |
| 共享自动化 | `packages/shared/nocobase-automation/` | 存在 |

### 缺失项与风险

- 本轮要求核对的关键文件和目录无缺失。
- 当前仓库仍不包含完整 NocoBase 源码；本轮只能创建 NocoBase v2.0.61 宿主工程接入任务包、步骤文档、校验脚本草案和下一阶段指令。
- 当前不能在本仓库 clone NocoBase 源码，不能提交完整 NocoBase 源码，不能安装依赖，不能连接 NocoBase，不能写数据库，不能启用真实 IOPGPS，不能标记为 production_ready。

### 本轮结论

仓库全盘扫描已完成，关键文件均存在，可以继续执行目标版本门禁校验；门禁通过后才允许继续生成“完整 NocoBase v2.0.61 宿主工程接入任务包”。

## 2026-06-07 package_manager 修正任务前仓库扫描

### 扫描命令

```bash
find . -maxdepth 6 -type f \( -path './node_modules/*' -o -path './.git/*' -o -path './.test-dist/*' -o -path './storage-test/*' -o -path './backups-test/*' -o -path './logs-test/*' -o -path './test-runtime/*' \) -prune -o -type f -print | sort
```

### 扫描范围与关键文件清单

本轮已在修正 NocoBase v2.0.61 目标版本确认记录的 `package_manager` 前完成仓库文件结构扫描；扫描排除了 `node_modules`、`.git`、`.test-dist`、`storage-test`、`backups-test`、`logs-test`、`test-runtime`。终端输出确认当前仓库包含根目录说明文件、目标版本决策文档、宿主工程接入文档、真实 adapter 顺序文档、NocoBase 门禁脚本、插件目录、shared automation 包和 `tests/nocobase-automation/` 测试目录。

当前仓库关键文件摘要：

- 根目录：`AGENTS.md`、`SPEC.md`、`README.md`、`package.json`、`tsconfig.json`、`tsconfig.scripts.json`、`tsconfig.test.json`、`docker-compose.test.yml`。
- 目标版本与宿主工程文档：`docs/nocobase-target-version-decision.md`、`docs/nocobase-target-version-confirmation-workflow.md`、`docs/nocobase-target-version-input-schema.md`、`docs/nocobase-target-version-freeze-template.md`、`docs/nocobase-target-version-manual-confirmation.md`、`docs/nocobase-v2.0.61-host-integration-task.md`、`docs/nocobase-v2.0.61-host-bootstrap-commands.md`、`docs/nocobase-v2.0.61-plugin-copy-plan.md`、`docs/nocobase-host-bootstrap-runbook.md`、`docs/nocobase-host-integration-branch-plan.md`。
- 真实接入文档：`docs/real-nocobase-integration-runbook.md`、`docs/real-adapter-implementation-sequence.md`、`docs/real-adapter-implementation-backlog.md`、`docs/real-nocobase-host-requirements.md`。
- 门禁脚本：`scripts/nocobase/validate-target-version-confirmation.ts`、`scripts/nocobase/validate-can-start-real-adapter.ts`、`scripts/nocobase/validate-v2-host-integration-task.ts`、`scripts/nocobase/validate-host-bootstrap-docs.ts`。
- 测试：`tests/nocobase-automation/target-version-confirmation.test.ts`、`tests/nocobase-automation/target-version-application.test.ts`、`tests/nocobase-automation/v2-host-integration-task.test.ts`、`tests/nocobase-automation/host-bootstrap-readiness.test.ts`、`tests/nocobase-automation/nocobase-api-research.test.ts`。

### 本轮指定关键路径检查结果

| 路径 | 状态 |
| --- | --- |
| `docs/nocobase-target-version-decision.md` | 存在 |
| `docs/nocobase-target-version-confirmation-workflow.md` | 存在 |
| `docs/nocobase-target-version-input-schema.md` | 存在 |
| `docs/nocobase-target-version-freeze-template.md` | 存在 |
| `docs/nocobase-target-version-manual-confirmation.md` | 存在 |
| `docs/nocobase-v2.0.61-host-integration-task.md` | 存在 |
| `docs/nocobase-v2.0.61-host-bootstrap-commands.md` | 存在 |
| `docs/nocobase-v2.0.61-plugin-copy-plan.md` | 存在 |
| `docs/nocobase-host-bootstrap-runbook.md` | 存在 |
| `docs/nocobase-host-integration-branch-plan.md` | 存在 |
| `docs/real-nocobase-integration-runbook.md` | 存在 |
| `docs/real-adapter-implementation-sequence.md` | 存在 |
| `docs/real-adapter-implementation-backlog.md` | 存在 |
| `scripts/nocobase/validate-target-version-confirmation.ts` | 存在 |
| `scripts/nocobase/validate-can-start-real-adapter.ts` | 存在 |
| `scripts/nocobase/validate-v2-host-integration-task.ts` | 存在 |
| `tests/nocobase-automation/v2-host-integration-task.test.ts` | 存在 |
| `package.json` | 存在 |

### 缺失项与风险

- 本轮指定关键文件无缺失。
- 当前仓库仍不是完整 NocoBase v2.0.61 宿主工程；三个 car-rental 插件和 `packages/shared/nocobase-automation` 尚未复制到宿主工程，因此不能进入真实 Collection adapter 实现。
- 本轮只修正 package manager 决策和相关文档、脚本、测试，不连接 NocoBase、不安装依赖、不写数据库、不复制插件到宿主工程。
