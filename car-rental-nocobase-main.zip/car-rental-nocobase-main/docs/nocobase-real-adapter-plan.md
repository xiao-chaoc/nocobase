# 真实 NocoBase Adapter 实现计划与能力矩阵

## 为什么需要真实 NocoBase adapter

当前仓库已经具备插件注册计划、Collection 注册 dry-run、runtime 注册 dry-run、页面初始化 dry-run、测试数据导入 dry-run 和 smoke dry-run。这些能力可以验证计划结构和业务边界，但不能把 Collections、权限、页面、服务、定时任务或测试数据写入真实 NocoBase。真实 NocoBase adapter 的作用，是在进入完整 NocoBase 工程后，把已验证的计划转换为官方插件 API、数据库接口、ACL、UI Schema、Scheduler、Workflow 和文件存储等真实能力调用。

## 当前 dry-run adapter 与真实 adapter 的区别

| 项目 | 当前 dry-run adapter | 真实 adapter |
| --- | --- | --- |
| 运行位置 | 当前仓库本地测试环境 | 完整 NocoBase 工程内 |
| 数据写入 | 不写数据库，只产生内存结果和报告 | 在隔离 NocoBase 测试库中执行真实注册 |
| API 依赖 | 不引入 NocoBase npm 依赖 | 使用目标版本确认过的 NocoBase 官方插件 API |
| 页面能力 | 只校验页面计划 | 使用真实 UI Schema 或页面配置能力 |
| 权限能力 | 只校验角色与字段权限计划 | 使用真实 ACL 初始化角色、动作和字段权限 |
| 风险控制 | 防止误判、禁止伪造成功 | 需要隔离环境、备份、回滚和版本锁定 |

## 当前仓库为什么不能直接真实注册 NocoBase

当前仓库不是完整 NocoBase 源码工程，也没有真实 `app`、`db`、Collection Manager、ACL、UI Schema、Scheduler、Workflow、文件存储或插件管理器实例。本轮也明确禁止安装真实插件、连接真实数据库、导入真实数据或调用不确定的 NocoBase API。因此当前只能落地接口边界、能力矩阵、未配置占位实现、环境检测器和测试，不能声称已经完成真实 NocoBase 接入。

## 真实 adapter 需要的 NocoBase 能力矩阵

| 能力 | dry-run 已覆盖什么 | 真实实现缺什么 | 风险 | 验收方式 |
| --- | --- | --- | --- | --- |
| `app` | 校验注册计划与执行顺序 | 完整 NocoBase 应用实例与插件生命周期上下文 | 错误生命周期会导致插件注册顺序不可控 | 在隔离 NocoBase 工程中完成启动、注册、停止测试 |
| `db` | 校验 Collection 字段、索引、唯一约束和关联计划 | 真实数据库连接、事务和迁移接口 | 误写生产库或迁移不可回滚 | 使用测试库执行迁移前备份与回滚演练 |
| Collection Manager | 标准化 Collection 计划 | 目标版本 Collection 注册接口 | API 版本不匹配会导致注册失败 | 在目标版本中真实创建测试 Collections 并检查 schema |
| ACL / 权限 | 校验角色、动作和敏感字段计划 | 真实角色、动作、字段级权限注册能力 | 敏感字段暴露风险 | 使用不同角色账号验证字段可见性 |
| UI Schema / 页面配置 | 校验菜单、页面、区块、筛选器、按钮动作计划 | 真实页面 schema 写入或导入能力 | 页面结构不符合目标版本 schema | 在隔离环境打开页面并完成操作 smoke test |
| i18n | 校验三语言资源计划 | 真实 i18n 注册或资源加载机制 | 界面和合同语言缺失 | 检查中文、英文、法文切换结果 |
| Scheduler | 校验定时任务计划，IOPGPS dry-run 默认关闭 | 真实调度器注册、启停和失败隔离 | GPS 同步失败影响租金逻辑 | 验证调度失败不会影响台账和付款 |
| Workflow | 校验动作和审批边界 | 真实工作流注册与审批状态流转 | 免除、争议、审批状态错误 | 使用测试合同验证审批链路 |
| File Storage | 校验文件字段与敏感数据边界 | 真实付款截图、合同文件存储配置 | 泄露真实文件或错误上传 | 使用 mock 文件在隔离存储中验证权限 |
| Logger | dry-run 记录步骤与 warning | 真实日志上下文和审计追踪 | 注册失败不可追踪 | 检查注册日志、错误日志和操作审计 |

## 真实 adapter 实现顺序

1. 环境检测：确认 `app`、`db`、logger、storage、pluginManager、ACL、UI Schema、Scheduler、Workflow 是否存在。
2. Collection 注册：先实现 Collection 注册 adapter 草案，仍需在完整 NocoBase 工程内验证。
3. 服务注册：接入真实服务注册机制。
4. 权限注册：接入真实 ACL 与字段权限。
5. i18n 注册：接入目标版本多语言资源加载方式。
6. 动作注册：接入真实动作或服务绑定能力。
7. 页面注册：接入 UI Schema、菜单、区块、筛选器和按钮动作初始化。
8. 测试数据导入：只在隔离测试库导入 mock 数据。
9. smoke test：在隔离环境运行端到端 smoke test。
10. 回滚：验证注册失败、导入失败和页面初始化失败后的可回滚策略。

## 严格禁止事项

- 不允许伪造 NocoBase API。
- 不允许硬写不确定的 NocoBase 调用。
- 不允许在生产数据库上调试。
- 不允许把 dry-run 成功等同于真实接入成功。
- 不允许把当前项目标记为 `production_ready`。

## 进入下一阶段的条件

进入下一阶段前应满足：

- 本轮类型、测试和 readiness 生成校验通过。
- 当前真实 adapter 仍保持未配置占位，不连接真实 NocoBase。
- 已明确下一轮只实现第一项真实能力：Collection 注册 adapter 草案。
- Collection 注册草案必须在完整 NocoBase 工程内验证，不得在当前仓库伪造 API。
- 必须准备隔离测试数据库、备份和回滚方案后，才允许执行真实注册验证。

## 2026-06-04 补充：真实 Collection 注册 adapter 草案

本轮新增真实 Collection 注册 adapter 草案，范围限定为 schema draft、注册步骤、回滚计划、后置验证计划和安全检查。该草案基于现有自动化 Collection plan 和未配置真实 adapter 边界，不连接真实 NocoBase，不创建 Collections，不执行 migration，不写数据库，也不调用 `app.collection` 或 `db.collection`。

新增脚本：

- `npm run generate:real-collection-plan`
- `npm run validate:real-collection-plan`

当前 `real` 模式仍被明确阻断。未来只有在真实 NocoBase app、db、collection manager、migration、transaction、备份、回滚和审批机制全部就绪后，才允许进入下一阶段真实 adapter 设计评审。

## 2026-06-04 补充：真实 Runtime 注册 adapter 草案

本轮新增真实 Runtime 注册 adapter 草案，范围限定为服务、动作、权限、i18n 和定时任务的 schema draft、注册步骤、回滚计划、后置验证计划和安全检查。该草案不连接 NocoBase、不注册真实服务、不注册真实按钮或 API、不注册真实 ACL、不注册真实 scheduler、不加载真实 i18n，也不伪造任何 NocoBase API 成功。

真实 Runtime 草案的进入顺序应晚于 Collection 草案审查：先确认 Collection schema、关系、唯一约束和敏感字段，再确认 runtime 服务事务、动作绑定、字段权限、三语言资源和定时任务失败隔离。当前仓库继续禁止 `real` 模式；下一阶段必须在完整 NocoBase 工程、隔离测试数据库、备份和回滚方案齐备后，才能讨论真实 API 替换。

## 真实 Seed Data Import Adapter 草案补充（2026-06-04）

本轮在真实 Collection、Runtime、Page 注册草案之后，新增真实 Seed Data Import adapter 草案。该草案只把现有 `SeedDataImportPlan` 转换为真实导入 schema draft，并生成导入步骤、事务计划、回滚计划和后置验证计划；不连接真实 NocoBase、不写数据库、不上传文件、不创建记录、不执行真实事务。

新增草案继续保持当前仓库安全边界：`real` 模式必须被拒绝，测试数据只能以 `plan_only`、`validate_only` 或 `dry_run` 方式验证。后续真实 adapter 必须在完整 NocoBase 测试工程中接入真实 repository/db、事务、文件存储、备份、回滚和后置验证后才能进入下一阶段。

## 2026-06-04 真实 Smoke Test Adapter 草案

本轮在真实 Collection、Runtime、Page、Seed Data Import 草案之后，新增“真实 Smoke Test Adapter 草案”。当前阶段只设计接口边界、计划转换器、校验器、草案 adapter、脚本、测试和文档，不连接真实 NocoBase、不写数据库、不安装插件、不执行业务流程、不调用 IOPGPS、不生成合同文件，也不伪造任何 NocoBase API 成功。

本轮计划覆盖环境前置检查、Collection 注册验证、Runtime 注册验证、Page 注册验证、Seed Data 导入验证、核心业务流程、权限、GPS mock、合同文件、失败隔离、回滚验证和报告草案。`real` 模式在当前仓库必须被阻断，后续只有在独立测试环境、备份、回滚、mock 数据、禁用真实 IOPGPS 等条件全部满足后，才能进入下一阶段设计。

## 2026-06-05 补充：真实 Backup / Rollback adapter 草案

本轮新增真实 Backup / Rollback adapter 草案，范围限定为备份计划、回滚计划、失败恢复计划、后置验证计划和安全检查。该草案不连接 NocoBase、不执行 `pg_dump`、不执行 `pg_restore`、不删除 storage、不禁用插件、不读取 `.env.test` 真实值，也不声称真实备份或回滚已经完成。

新增草案覆盖数据库、文件存储、`storage/plugins`、Collection schema、Runtime registry、Page / UI Schema、Seed Data、日志和环境配置存在性。回滚草案覆盖数据库恢复、文件存储恢复、插件状态恢复、schema 恢复、mock 数据清理、生成产物清理、日志保留和环境配置恢复。失败恢复计划覆盖 Collection、Runtime、Page、Seed Data、Smoke Test、权限、IOPGPS、合同文件、单日超付和敏感数据暴露等失败类型。

当前仓库仍禁止 `real` 模式。进入下一阶段前，必须准备完整 NocoBase 隔离测试工程、mock 数据库、隔离 storage、备份文件不进入 Git 的保护、操作人确认机制和 IOPGPS 禁用证明。

## 2026-06-05 复核补充：Backup / Rollback 上下文边界

本轮复核真实 Backup / Rollback 草案后，后置验证计划明确接收上下文，只用于记录操作人草案归档提示和安全边界，不读取 `.env.test`、不连接 NocoBase、不执行备份或回滚。当前仓库仍只能输出 `plan_only`、`validate_only` 或 `dry_run` 计划，`real` 模式继续作为下一阶段隔离测试工程的待替换能力。

## 2026-06-06 真实工程接入 Runbook 更新

当前真实 Adapter 草案已覆盖 Collection、Runtime、Page、Seed Data、Smoke Test、Backup / Rollback。下一阶段不应继续新增同类草案，而应在完整 NocoBase 工程中按实施顺序开始真实 adapter 实现。

本轮新增的接入资料包括：

- `docs/real-nocobase-integration-runbook.md`
- `docs/real-adapter-implementation-sequence.md`
- `docs/real-nocobase-host-requirements.md`
- `docs/real-integration-risk-register.md`
- `scripts/nocobase/validate-real-integration-readiness.ts`

当前仓库仍不连接真实 NocoBase，不伪造真实 NocoBase API，不写数据库，不创建页面，不导入数据，不备份或回滚，因此不能正式上线测试，不能生产部署。
