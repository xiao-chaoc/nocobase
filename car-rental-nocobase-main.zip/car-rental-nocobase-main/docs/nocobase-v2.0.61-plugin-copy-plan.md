# NocoBase v2.0.61 插件复制计划

## 任务状态

- target_version = v2.0.61
- package_manager = yarn
- database = postgresql
- deployment_mode = source_host
- plugin_development_mode = packages_plugins
- plugin_install_mode = packages_plugins
- iopgps_real_sync_allowed = false
- mock_data_only = true

## 源路径

- `packages/plugins/plugin-rental-core`
- `packages/plugins/plugin-contract-documents`
- `packages/plugins/plugin-iopgps`
- `packages/shared/nocobase-automation`

## 目标路径建议

- `/volume1/projects/nocobase-host-v2.0.61/packages/plugins/plugin-rental-core`
- `/volume1/projects/nocobase-host-v2.0.61/packages/plugins/plugin-contract-documents`
- `/volume1/projects/nocobase-host-v2.0.61/packages/plugins/plugin-iopgps`
- `/volume1/projects/nocobase-host-v2.0.61/packages/shared/nocobase-automation`，或宿主工程认可的 packages 位置

## 复制规则

- 不在当前仓库 clone NocoBase 源码，不 clone NocoBase 源码到当前仓库。
- 不提交完整 NocoBase 源码。
- 不复制 `.env`。
- 不复制 `.env.test`。
- 不复制 `storage-test`。
- 不复制 `backups-test`。
- 不复制 `logs-test`。
- 不复制 `node_modules`。
- 不复制 `test-runtime`。
- 不复制真实业务文件。
- 不复制 `filled.json`。
- 不复制 `*confirmed*.json`。
- 不复制真实付款截图、真实合同扫描件、真实司机证件、真实 IOPGPS 凭据。
- 不使用生产库，不在生产库验证。
- 当前不能 production_ready，当前仍不能正式上线测试，当前仍不能生产部署。

## 复制后检查

| 检查项 | 期望 |
| --- | --- |
| `package.json` 是否存在 | 三个插件和 shared automation 均存在 |
| `src/server` 是否存在 | 三个插件均存在 |
| `locale` 是否存在 | 三个插件均存在 `zh-CN`、`en-US`、`fr-FR` 语言资源 |
| `pluginRegistration` 是否存在 | 三个插件均存在注册草案 |
| shared automation 是否可 import | 宿主工程 yarn workspace 可解析 |
| 不存在真实密钥 | 不包含真实密钥、`.env`、`.env.test`、真实 IOPGPS 凭据 |

## shared automation 接入说明

- shared automation 作为宿主工程 adapter、校验脚本和 dry-run 能力的共享包接入。
- 第一阶段仅用于环境检测 adapter，不连接 NocoBase、不写数据库、不创建 Collection。
- 后续环境检测通过后，再进入 Collection adapter，且必须使用隔离 postgresql 测试库。
