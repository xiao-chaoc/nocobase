# 下一阶段任务：真实 Collection adapter v2.0.61

## 任务状态

- target_version = v2.0.61
- package_manager = yarn
- database = postgresql
- deployment_mode = source_host
- plugin_development_mode = packages_plugins
- plugin_install_mode = packages_plugins
- iopgps_real_sync_allowed = false
- mock_data_only = true

## 前置条件

- 环境检测 adapter 通过。
- 已确认 Collection API。
- 已确认字段类型映射。
- 已有备份。
- 使用隔离 PostgreSQL 测试库，不使用生产库，不在生产库验证。
- 已确认当前仓库不包含完整 NocoBase 源码，不在当前仓库 clone NocoBase 源码，不提交完整 NocoBase 源码。
- 已确认不复制 `.env`、`.env.test`、`filled.json`、`*confirmed*.json`。

## 任务目标

实现真实 Collection 注册 adapter，并将最小业务 Collection 注册到完整 NocoBase v2.0.61 宿主工程的隔离测试库中。

## 最小范围

- `drivers`
- `vehicles`
- `lease_contracts`
- `rent_daily_ledgers`
- `rent_payments`
- `rent_payment_allocations`
- `deposit_records`
- `operation_logs`

## 暂不包含

- 真实页面。
- 真实权限。
- 真实付款业务动作。
- 真实 IOPGPS。
- 真实合同生成。
- 生产部署。
- 正式上线测试。
- 将当前项目标记为 production_ready；当前不能 production_ready。

## 验收标准

- Collection 注册成功。
- 唯一约束生效。
- relation 可用。
- 敏感字段策略已记录。
- 回滚方案可执行。
- 无生产数据。
- 不启用真实 IOPGPS。
- 不伪造 NocoBase API，不用不确定 API 写成已验证。
