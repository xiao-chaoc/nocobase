# IOPGPS 设计说明（第一版）

## 业务假设

- IOPGPS 用于车辆位置、每日行驶里程和设备状态监控。
- GPS 数据不参与租金计算，不影响每日租金台账的应收、已付、欠款和免除。
- IOPGPS 同步失败不能影响合同、台账、付款、押金和合同文件逻辑。
- 不提交真实 IOPGPS 凭据，不提交真实车辆定位数据样例。

## 数据字段

### GPS 设备

- `gps_device_id`：GPS 设备唯一标识。
- `device_code`：设备编号。
- `vehicle_id`：关联车辆。
- `plate_number_snapshot`：车牌快照。
- `device_status`：设备状态。
- `bound_at`：绑定时间。
- `unbound_at`：解绑时间。
- `notes`：备注。

### GPS 定位

- `location_id`：定位记录唯一标识。
- `gps_device_id`：关联 GPS 设备。
- `vehicle_id`：关联车辆。
- `location_time`：定位时间。
- `longitude`：经度。
- `latitude`：纬度。
- `address_text`：地址文本。
- `mileage`：里程。
- `speed`：速度。

### GPS 同步日志

- `sync_log_id`：同步日志唯一标识。
- `sync_started_at`：同步开始时间。
- `sync_finished_at`：同步结束时间。
- `sync_status`：同步状态。
- `records_received`：收到记录数。
- `error_message`：错误摘要，不包含密钥。

## 关系

- 一个 GPS 设备在同一时间只能绑定一辆车。
- 一辆车可以有历史 GPS 设备绑定记录。
- GPS 定位记录关联设备和车辆。
- GPS 同步日志记录接口同步结果。
- GPS 数据与合同和每日租金台账不建立计费依赖关系。

## 枚举值

- `device_status`：`online` 在线、`offline` 离线、`fault` 故障、`unbound` 未绑定。
- `sync_status`：`success` 成功、`partial_success` 部分成功、`failed` 失败、`skipped` 跳过。
- `binding_status`：`bound` 已绑定、`unbound` 已解绑。

## 校验规则

- 不得在仓库中保存真实 IOPGPS 密钥、账号、令牌或接口凭据。
- 同一 GPS 设备同一时间不能绑定多辆车。
- 同一车辆同一时间不应绑定多个主 GPS 设备，是否允许备用设备需后续确认。
- GPS 同步失败只能影响 GPS 同步日志和设备状态提示，不得阻止租金台账生成和付款录入。
- GPS 里程、位置、在线状态不得参与应收金额、欠款金额、免租日判断。
- GPS 错误日志不得记录完整密钥或敏感凭据。

## 工作流

1. GPS 维护人员为车辆绑定 GPS 设备。
2. 定时任务或维护人员触发 IOPGPS 同步。
3. 系统保存车辆定位、里程和设备状态。
4. 同步成功时更新设备最近状态。
5. 同步失败时记录失败日志并提示维护人员。
6. 合同、每日租金台账、付款和押金流程继续独立运行。

## 权限注意事项

- GPS 维护人员可查看和维护 GPS 设备、定位、里程、同步日志。
- GPS 维护人员不能查看付款截图、付款方式、司机证件和敏感财务汇总。
- 定位数据属于运营敏感数据，导出需要授权。
- IOPGPS 凭据应通过部署环境配置，不进入代码仓库。

## 验收测试点

- IOPGPS 同步失败时，付款录入仍可保存。
- IOPGPS 同步失败时，长租合同未来台账生成不受影响。
- GPS 里程变化不改变任何每日租金台账应收金额。
- GPS 维护账号无法查看付款截图。
- 仓库中不存在真实 IOPGPS 凭据。

## 本轮纯函数实现补充：IOPGPS 同步基础逻辑

- `plugin-iopgps` 已实现 token 过期判断、提前刷新判断、状态归一化、定位快照构建、每日里程构建、错误日志构建和同步安全包装等纯函数。
- 本轮不发送真实 HTTP 请求、不调用真实 IOPGPS API、不保存真实 GPS 数据，也不写入真实数据库。
- `safeIopgpsSyncWrapper` 会捕获同步异常并返回 `failed` 与脱敏错误日志，避免异常传播到租金台账、付款或押金逻辑。
- GPS 定位、设备状态和每日里程仅用于运营监控与核查，不参与任何租金计算。
