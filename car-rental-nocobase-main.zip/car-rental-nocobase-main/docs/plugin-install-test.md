# 插件接入测试文档

## 当前插件状态说明

- 当前 `packages/plugins` 下是插件源码骨架。
- 当前仓库不是完整 NocoBase 源码工程。
- 当前不能直接保证插件在容器内自动可用。
- 需要后续进行真实 NocoBase 工程适配、构建、注册和启用验证。

## 后续插件接入路径

### 方式 A：完整 NocoBase 源码工程开发调试

1. 准备完整 NocoBase 源码工程。
2. 将三个插件复制到完整工程的 `packages/plugins`。
3. 安装依赖。
4. 按目标 NocoBase 版本注册插件。
5. 启用插件。
6. 使用测试数据库运行插件生命周期和服务测试。

### 方式 B：构建为第三方插件包后导入

1. 按目标 NocoBase 版本构建插件包。
2. 放入 `storage/plugins` 或通过插件安装流程导入。
3. 启用插件。
4. 验证 Collection、服务方法、权限、i18n、定时任务和动作。

## 插件启用顺序

1. `plugin-rental-core`
2. `plugin-contract-documents`
3. `plugin-iopgps`

原因：

- `plugin-rental-core` 是核心依赖。
- `plugin-contract-documents` 依赖合同、司机、车辆数据。
- `plugin-iopgps` 依赖车辆数据。
- `plugin-rental-core` 不依赖 GPS 和合同文件插件。

## 插件加载成功判断

至少检查：

- Collections 是否注册。
- 服务方法是否可用。
- i18n 是否生效。
- 权限草案是否加载并转为服务端 ACL。
- 定时任务草案是否出现并可按测试配置启用。
- 动作草案是否出现并能绑定服务端方法。

## 插件测试顺序

建议：

1. 先测试 `plugin-rental-core` Collection。
2. 再测试每日台账生成。
3. 再测试付款禁止超付。
4. 再测试押金。
5. 再测试权限过滤。
6. 再测试合同文件状态。
7. 最后测试 IOPGPS mock 同步。

## 失败回滚

- 禁用插件。
- 恢复数据库备份。
- 清理测试数据。
- 还原 `storage/plugins`。
- 查看 logs，确认没有真实密钥、真实证件、真实付款截图或真实合同扫描件泄露。

## 测试边界

当前插件接入测试不得连接真实 IOPGPS，不得生成真实合同文件，不得上传真实文件，不得导入真实司机或车辆数据，不得用于生产环境。

## 插件打包测试草案补充

插件接入前可先运行：

```bash
npm run check:plugin-structure
npm run check:plugin-registration
```

这两个脚本只检查 `packages/plugins` 下三个插件的目录结构和 `pluginRegistration` 描述，不执行真实 NocoBase 插件安装。详细说明见 `docs/plugin-package-test.md`。

## NAS 测试 Compose 挂载边界补充

本轮修正后，NAS 测试 Compose 只用于基础 NocoBase + PostgreSQL 环境验证，不直接挂载 `packages/plugins`，也不表示插件已经在容器中自动启用。插件接入仍需后续按照真实 NocoBase 插件流程进行构建、安装、启用和回滚验证。

测试运行目录必须分离：`storage-test/nocobase` 用于 NocoBase storage，`storage-test/postgres` 用于 PostgreSQL 测试数据，两者不要混放。复制 `docker-compose.test.yml` 时推荐在 NAS 上直接 `git clone` 仓库；如手动下载，必须使用 GitHub Raw 原始文件，不要保存 GitHub HTML 页面。
