# Runtime 自动注册 dry-run 草案

## 1. 当前实现范围

本轮实现的是服务方法、动作、权限、定时任务和 i18n 的 **runtime 自动注册 dry-run 草案**。

当前只做：

- 标准化服务方法注册计划。
- 标准化动作注册计划。
- 标准化权限角色注册计划。
- 标准化定时任务注册计划。
- 标准化 i18n 注册计划。
- 校验核心服务、核心动作、角色权限、三语言 i18n 和禁止业务模式。
- 使用内存 mock runtime adapter 模拟注册步骤。
- 输出 runtime dry-run 注册结果。

## 2. 当前不会做什么

当前不会：

- 连接真实 NocoBase。
- 真实注册 API。
- 真实注册按钮或动作。
- 真实注册 ACL 或字段权限。
- 真实注册定时任务。
- 真实执行 scheduler。
- 创建页面或菜单。
- 导入数据。
- 调用真实 IOPGPS API。
- 生成真实合同文件。
- 上传真实文件。

因此，本阶段仍不能正式上线测试，更不能生产上线。

## 3. 当前目标

当前目标是验证 runtime 注册计划完整性，确认后续真实 adapter 接入前已经具备：

- 核心服务方法清单。
- 核心动作清单。
- 六个内部角色权限草案。
- 定时任务默认启用策略。
- zh-CN、en-US、fr-FR 三语言 i18n 计划。
- 禁止短租、司机登录、按车型出租、GPS 参与租金计算、押金计入租金已付等错误模式。

## 4. 未来真实 NocoBase adapter 需要实现的方法

真实 runtime adapter 后续需要实现：

- `registerServices`：注册真实服务方法或服务端调用入口。
- `registerActions`：注册真实动作、按钮或服务端 action。
- `registerPermissions`：注册真实服务端 ACL、字段可见性和文件访问权限。
- `registerSchedules`：注册真实 scheduler / workflow。
- `registerI18n`：注册真实 i18n 命名空间和语言资源。
- `validateServicePlan`：结合目标 NocoBase 版本校验服务注册计划。
- `validateActionPlan`：校验动作输入、输出、权限和服务绑定。
- `validatePermissionPlan`：校验角色、集合、动作和敏感字段策略。
- `validateSchedulePlan`：校验定时任务启用策略和服务绑定。
- `validateI18nPlan`：校验三语言资源完整性。

这些方法必须在完整 NocoBase 工程和明确版本中实现，不能伪造不确定的 `app.acl`、`app.router`、`app.command`、`app.scheduler` 等 API。

## 5. 服务注册顺序

服务注册建议遵循插件依赖顺序：

1. `plugin-rental-core`
   - 合同生命周期。
   - 台账生成。
   - 付款分配与冲正。
   - 欠款、未付原因、免除。
   - 押金。
   - 汇总和日历敏感字段过滤。
   - 操作日志。
2. `plugin-contract-documents`
   - 合同模板语言识别。
   - 合同文件记录生成。
   - 打印、扫描件登记和作废状态。
3. `plugin-iopgps`
   - token 状态。
   - GPS 状态归一化。
   - 定位、里程和错误隔离。

## 6. 权限注册策略

权限必须包含：

- `system_admin`
- `manager`
- `accountant`
- `operator`
- `gps_maintenance`
- `readonly_auditor`

策略要求：

- `system_admin` 可见全部敏感字段。
- `manager` 可查看欠款、未来应收并审批免除。
- `accountant` 可访问付款和押金。
- `operator` 默认不可查看付款截图和敏感财务汇总。
- `gps_maintenance` 默认不可查看财务汇总和付款截图。
- `readonly_auditor` 默认不可修改。

权限不能只靠前端隐藏，后续必须接入服务端 ACL、查询层和文件访问层。

## 7. 动作注册策略

动作注册必须绑定服务方法、输入、输出和 requiredPermissions。当前动作只做 dry-run 计划，不真实注册按钮、不真实注册 API。

核心动作包括：

- 合同激活。
- 时限合同台账生成。
- 长租未来台账补生成。
- 租金付款确认和冲正。
- 未付原因、免除申请和审批。
- 押金创建、抵扣和退款。
- 合同文件生成、打印、扫描件登记和作废。
- GPS 设备状态、定位和每日里程同步。

## 8. 定时任务注册策略

定时任务当前只做 dry-run 计划：

- `plugin-rental-core` 的长租未来台账补生成和汇总刷新需要说明事务、幂等和数据量风险。
- `plugin-iopgps` 的真实同步默认关闭，除非后续明确进入 mock 或测试密钥场景。
- 当前不注册真实 scheduler，不执行真实定时任务。

## 9. i18n 注册策略

i18n 必须覆盖：

- `zh-CN`
- `en-US`
- `fr-FR`

每个插件都应提供 localeFiles 计划。当前只验证资源计划，不真实注册 i18n。

## 10. 为什么用户不需要手动创建权限和动作

用户不需要在 NocoBase UI 中手动创建服务动作、按钮、权限或定时任务。后续真实接入应由插件和初始化脚本自动完成，避免手工遗漏权限、动作绑定、三语言资源或定时任务启用策略。

## 11. 可运行命令

```bash
npm run generate:registration-plan
npm run validate:registration-plan
npm run dry-run:register-runtime
npm run validate:runtime-registration
```

这些命令只生成和验证文件级 dry-run 结果，不连接真实 NocoBase，也不写数据库。

## 12. 当前仍不能正式上线测试

当前只是 runtime dry-run 注册草案。真实 NocoBase 中还没有安装插件，没有真实注册服务、动作、ACL、定时任务和 i18n，也没有真实导入测试数据或执行业务 smoke test，因此不能进入正式上线测试。

## 13. 进入下一阶段的条件

进入下一阶段前应满足：

- `npm run typecheck` 通过。
- `npm run test` 通过。
- `npm run generate:registration-plan` 通过。
- `npm run validate:registration-plan` 通过。
- `npm run dry-run:register-collections` 通过。
- `npm run validate:collection-registration` 通过。
- `npm run dry-run:register-runtime` 通过。
- `npm run validate:runtime-registration` 通过。
- 明确目标 NocoBase 版本。
- 在完整 NocoBase 工程中确认真实 runtime adapter 的接入方式。
