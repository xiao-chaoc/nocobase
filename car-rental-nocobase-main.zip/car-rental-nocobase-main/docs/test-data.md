# mock 测试数据说明

## 目录结构

- `test-data/fixtures/`：手写基础 mock 数据，包括测试司机、测试车辆、测试 GPS 设备、租金规则场景、合同模板占位和公司资料占位。
- `test-data/generated/`：由 `scripts/seed-test-data.ts` 生成的完整业务测试数据输出目录。
- `scripts/seed-test-data.ts`：基于 fixtures 生成可重复的 JSON 测试数据。
- `scripts/validate-test-data.ts`：读取 generated 数据并执行本地一致性校验。
- `scripts/clear-test-data.ts`：只清理 `test-data/generated/*.json`，不删除 fixtures。

## fixtures 和 generated 的区别

`fixtures` 是人工维护的基础数据，适合长期保留；`generated` 是脚本输出，包含合同、台账、付款、押金、GPS、合同文件和操作日志等完整测试对象。当前二者都只用于本地文件级测试，不会直接写入 NocoBase 数据库。

## 如何生成测试数据

```bash
npm run seed:test-data
```

生成脚本使用固定日期 `2026-06-15`，不使用随机真实数据，不连接数据库，不调用 NocoBase，不调用 IOPGPS。

## 如何校验测试数据

```bash
npm run validate:test-data
```

校验脚本会检查 driver_no、vehicle_no、plate_no、contract_no 唯一性，同车合同不冲突，每个合同每日台账唯一，付款分配不超付，免租日金额为 0，应收日金额大于 0，押金不计入租金已付，GPS 每日里程唯一，合同文件不包含真实 URL，操作日志不包含 access_token、login_key 或真实证件号，并确认没有 booking、reservation、short_rental_orders 等短租数据。

## 如何清理测试数据

```bash
npm run clear:test-data
```

清理脚本只删除 `test-data/generated/` 下的 `.json` 文件，不删除 fixtures，不删除源码，不删除 `.env`，不删除任何真实文件。

## 为什么不使用真实资料

- 不使用真实司机资料：避免提交真实姓名、真实手机号、真实证件号、真实驾照信息。
- 不使用真实付款截图：付款截图属于敏感财务文件，本轮只使用 `TEST_PAYMENT_SCREENSHOT_001` 这类占位值。
- 不使用真实合同扫描件：合同扫描件可能包含司机个人信息，本轮只使用占位值。
- 不使用真实 IOPGPS 密钥：appid、login key、access token 均不得进入仓库或日志。

## 后续如何用于 NocoBase 集成测试

后续接入真实 NocoBase 工程后，可以把 generated JSON 作为导入适配器的输入，验证 Collection 注册、服务方法、权限、定时任务、动作和回滚流程。导入前必须人工确认数据仍为 mock 数据，并单独实现导入适配器；当前脚本不会直接写数据库。

## 与 NAS 测试环境的关系

NAS 测试部署准备完成后，可以把 `test-data/generated/` 作为后续导入适配器的输入。当前数据仍不会自动写入 NocoBase，也不会随 `docker-compose.test.yml` 自动导入。导入前必须人工确认数据仍为 mock 数据，且 `.env.test`、数据库 dump、真实上传文件不得进入 Git。

## mock 测试数据导入 dry-run

新增 `npm run dry-run:import-test-data` 和 `npm run validate:seed-data-import`，用于在不连接真实 NocoBase、不写数据库、不上传文件的前提下，验证 `test-data/generated` 是否具备后续自动导入条件。校验范围包括导入顺序、引用完整性、唯一键、敏感真实数据、台账、付款分配、押金和 GPS mock 规则。
