# NocoBase 自动化构建方案

## 1. 当前仓库状态

当前仓库不是完整 NocoBase 源码工程，也不是已经可生产安装的插件包。当前内容包括插件源码骨架、Collection 草案、纯函数服务、文档、mock 数据和测试脚本。NAS 上启动官方 NocoBase 后看到空应用是正常状态，因为插件尚未真实安装，Collections、页面、菜单、权限和测试数据也尚未自动初始化。

## 2. 自动化接入路径

### 路径 A：创建完整 NocoBase 源码测试工程

- 使用完整 NocoBase 工程作为宿主。
- 将当前 `packages/plugins` 复制到宿主工程的 `packages/plugins`。
- 按目标 NocoBase 版本的插件开发方式构建、注册和启用。
- 适合插件开发调试、API 适配、Collection/migration 验证、服务端权限验证。
- 不建议在生产目录中直接调试源码插件。

### 路径 B：将插件构建为可安装包

- 将三个插件构建为可安装包。
- 放入 `storage/plugins` 或通过 NocoBase 插件安装流程启用。
- 适合 NAS 测试部署和接近真实运行方式的验证。
- 必须先经过路径 A 验证插件结构、API、迁移和权限，再进入路径 B。

## 3. 推荐路径

推荐顺序：

1. 先使用路径 A 做开发验证，确认插件入口、Collection 注册、服务注册、权限注册、i18n、定时任务和动作注册方式都符合目标 NocoBase 版本。
2. 再使用路径 B 构建插件包，在 NAS 测试环境中安装并执行自动初始化、mock 数据导入和 smoke test。
3. 不直接在生产目录调试源码插件，不直接在生产库试错。

## 4. Codex 后续需要生成的自动化构建产物

- `plugin-rental-core` 的真实 NocoBase 插件入口。
- `plugin-iopgps` 的真实 NocoBase 插件入口。
- `plugin-contract-documents` 的真实 NocoBase 插件入口。
- Collection 注册或 migration。
- 服务注册。
- 权限注册。
- i18n 注册。
- 定时任务注册。
- 动作注册。
- 页面、菜单和区块初始化脚本。
- 测试数据导入脚本。
- smoke test 脚本。
- 插件构建/打包脚本。
- NAS 自动化测试执行脚本。

## 5. 自动化限制

Codex 后续自动化不得做以下事情：

- 不能自动填真实 `.env`。
- 不能提交真实 `APP_KEY`、`DB_PASSWORD`、`INIT_ROOT_PASSWORD`。
- 不能提交真实 IOPGPS 密钥。
- 不能提交真实司机文件。
- 不能提交真实付款截图。
- 不能提交真实合同扫描件。
- 不能连接真实生产数据库。
- 不能调用真实 IOPGPS API。
- 不能把 GPS 数据接入租金计算。
- 不能引入短租、司机登录或按车型出租。

## 6. 自动化构建验收口径

- 构建命令可重复执行。
- 插件安装顺序固定且可验证。
- 初始化脚本幂等或提供安全清理流程。
- smoke test 可自动输出报告。
- 失败时能定位到插件构建、Collection 初始化、权限初始化、数据导入或业务断言阶段。
- 任何需要人工输入的内容仅限测试环境变量和 UAT 决策，不包括手动搭建业务系统。

## 7. dry-run 自动化适配层补充

本轮新增的 `packages/shared/nocobase-automation` 只定义 `NocobaseAutomationAdapter` 接口、注册计划生成器、注册计划校验器和 dry-run 执行器。它不会调用真实 NocoBase API，也不会伪造不确定 API。

后续在路径 A 的完整 NocoBase 源码测试工程中，应基于该接口实现真实 adapter；在路径 B 的 NAS 插件包测试中，应复用同一注册计划进行插件安装、初始化、mock 数据导入和 smoke test 验证。
