# mock 测试数据导入 dry-run 计划

## 1. 当前阶段目标

本阶段实现 mock 测试数据导入 dry-run，用于验证 `test-data/generated` 中的测试司机、车辆、GPS 设备、合同、每日台账、付款、押金、GPS mock、合同文件和操作日志数据是否具备自动导入条件。

当前不连接真实 NocoBase，不写数据库，不上传文件，不调用 IOPGPS，不生成真实合同文件。

## 2. 导入顺序

默认导入顺序为：

1. drivers
2. vehicles
3. gps_devices
4. lease_contracts
5. contract_billing_weeks
6. rent_daily_ledgers
7. rent_payments
8. rent_payment_allocations
9. deposit_records
10. gps_location_snapshots
11. gps_daily_mileages
12. contract_documents
13. operation_logs

该顺序确保司机、车辆、GPS 设备先于依赖它们的合同、台账和 GPS mock 数据导入。

## 3. 引用完整性

导入 dry-run 会校验：

- 合同引用的司机和车辆必须存在。
- 计费周和每日台账引用的合同必须存在。
- 每日台账引用的司机和车辆必须存在。
- 付款分配引用的付款和台账必须存在。
- 押金引用的合同必须存在。
- GPS 位置、GPS 里程引用的 GPS 设备必须存在。
- 合同文件引用的合同必须存在。

## 4. 唯一键校验

导入 dry-run 会校验：

- drivers：`driver_no`
- vehicles：`vehicle_no`、`plate_no`
- gps_devices：`imei`
- lease_contracts：`contract_no`
- rent_daily_ledgers：`contract_id + rent_date`
- rent_payments：`payment_no`
- deposit_records：`deposit_no` 或当前 mock 数据中的 `deposit_id`
- gps_daily_mileages：`device_id + mileage_date`
- contract_documents：`document_no`
- operation_logs：`log_no` 或当前 mock 数据中的 `log_id`

## 5. 敏感真实数据校验

导入 dry-run 会拒绝真实手机号、真实证件号、真实付款截图 URL、真实合同扫描件 URL、真实 `access_token` 和真实 `login_key`。测试文件字段必须使用 `TEST_` 前缀、`[已隐藏]` 或明显占位值。

## 6. 台账业务规则校验

每日租金台账必须满足：

- `contract_id + rent_date` 唯一。
- 免租日 `due_amount = 0`。
- 应收日 `due_amount > 0`。
- `paid_amount + waived_amount` 不得大于 `due_amount`。
- 未来应收不计入当前欠款。
- 单日不能超付。
- 不存在预收款。
- 不存在短租订单。

## 7. 付款分配校验

付款分配必须指向存在的台账和付款，不得分配到免租日，不得导致单日超付。非冲正或取消状态下，付款金额必须等于分配合计。

## 8. 押金校验

押金不得计入 `rent_payments`，不得计入租金收入或 `total_paid_amount`。押金实收、抵扣和退款金额必须满足非负和可退金额限制。

## 9. GPS mock 校验

GPS mock 数据只用于运营核查，不参与租金计算。`gps_daily_mileages` 必须满足 `device_id + mileage_date` 唯一，`raw_response` 中不能包含真实 token、login_key 或 access_token。

## 10. 用户不需要手动导入数据

导入计划、引用校验、唯一键校验和 dry-run 导入结果均由脚本生成。后续真实 adapter 完成后，用户只需要运行自动化脚本并查看报告，不需要手动在 NocoBase UI 中导入测试数据。

## 11. 当前仍不能正式上线测试

当前只是 mock 测试数据导入 dry-run：没有真实写入数据库，没有真实上传文件，没有真实安装插件，也没有执行真实 UAT。因此当前不能声明可以正式上线测试。

## 12. 进入下一阶段的条件

进入下一阶段前必须满足：

- `npm run seed:test-data` 通过。
- `npm run validate:test-data` 通过。
- `npm run dry-run:import-test-data` 通过。
- `npm run validate:seed-data-import` 通过。
- Collection、runtime、页面初始化 dry-run 均已通过。
- 明确后续 smoke test dry-run 的报告格式。
