# 插件自动安装计划

## 1. 插件安装顺序

自动安装顺序必须固定为：

1. `plugin-rental-core`
2. `plugin-contract-documents`
3. `plugin-iopgps`

原因：`plugin-rental-core` 提供司机、车辆、合同和租金台账核心数据；合同文件插件依赖合同、司机、车辆数据；IOPGPS 插件依赖车辆数据。`plugin-rental-core` 不依赖 GPS 和合同文件插件。

## 2. plugin-rental-core 自动验证

安装后必须自动验证：

- Collections 是否存在。
- 服务方法是否可调用。
- 台账生成是否可执行。
- 付款禁止超付是否生效。
- 押金服务是否生效。
- 权限过滤是否生效。
- 操作日志是否记录。
- 敏感字段是否受服务端权限控制。

## 3. plugin-contract-documents 自动验证

安装后必须自动验证：

- `contract_templates` 是否存在。
- `contract_documents` 是否存在。
- `zh-CN`、`en-US`、`fr-FR` 模板是否识别。
- 合同文件状态流转是否可用。
- 不真实生成 PDF，不调用 LibreOffice，不上传真实签署扫描件。
- 合同文件插件不处理租金、付款和 GPS 逻辑。

## 4. plugin-iopgps 自动验证

安装后必须自动验证：

- `gps_devices` 是否存在。
- `iopgps_settings` 是否存在。
- GPS 状态归一化是否可用。
- `IOPGPS_SYNC_ENABLED=false` 时不调用真实 API。
- GPS 失败不影响租金台账和付款。
- GPS 里程只用于运营核查，不参与租金计算。

## 5. 自动初始化脚本计划

后续 Codex 需要生成但本轮不创建以下脚本：

- `scripts/nocobase/init-collections.ts`
- `scripts/nocobase/init-pages.ts`
- `scripts/nocobase/init-roles.ts`
- `scripts/nocobase/import-test-data.ts`
- `scripts/nocobase/run-smoke-tests.ts`

这些脚本应在真实 NocoBase 插件接入后生成，并通过目标 NocoBase 版本验证。当前仓库仍不适合直接创建这些脚本，因为真实插件生命周期和 API 适配尚未完成。

## 6. 安装失败回滚

自动安装失败时，应按以下顺序回滚：

1. 禁用失败插件。
2. 恢复测试数据库备份。
3. 清理测试数据。
4. 恢复 `storage/plugins`。
5. 查看 NocoBase 日志、插件日志和初始化脚本报告。
6. 不在生产环境反复试错。

## 7. 人工边界

用户只负责合并 PR、创建 `.env.test`、启动 NAS 测试环境、查看自动化报告并决定是否进入 UAT。用户不需要手动创建 Collections、页面、菜单、权限或测试数据。
