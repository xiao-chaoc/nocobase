# NocoBase v2.0.61 宿主工程目录规划

## 任务状态

- target_version = v2.0.61
- package_manager = yarn
- database = postgresql
- deployment_mode = source_host
- plugin_development_mode = packages_plugins
- plugin_install_mode = packages_plugins
- iopgps_real_sync_allowed = false
- mock_data_only = true

## 推荐目录

| 用途 | 推荐路径 |
| --- | --- |
| 当前项目仓库 | `/volume1/projects/car-rental-nocobase` |
| NocoBase v2.0.61 host 工程 | `/volume1/projects/nocobase-host-v2.0.61` |
| Docker 测试 runtime 根目录 | `/volume1/docker/nocobase-car-lease-test` |
| NocoBase storage 测试目录 | `/volume1/docker/nocobase-car-lease-test/storage-test/nocobase` |
| PostgreSQL storage 测试目录 | `/volume1/docker/nocobase-car-lease-test/storage-test/postgres` |
| 测试备份目录 | `/volume1/docker/nocobase-car-lease-test/backups-test` |
| 测试日志目录 | `/volume1/docker/nocobase-car-lease-test/logs-test` |

## 目录边界

- 当前项目仓库不能包含完整 NocoBase 源码，不能在当前仓库 clone NocoBase 源码，不 clone NocoBase 源码到当前仓库。
- 当前项目仓库不提交完整 NocoBase 源码，不创建 Git submodule。
- NocoBase host 工程必须独立目录，并固定为 v2.0.61 目标版本。
- Docker runtime 目录必须独立，不能放进当前项目 Git 跟踪范围。
- storage 与 postgres 必须分离，避免文件存储与数据库数据混杂。
- `backups-test` 不进入 Git。
- `.env.test` 不进入 Git；复制规则中不复制 `.env`、不复制 `.env.test`。
- 插件复制应从当前项目到 host 工程，而不是反向复制。
- 不复制 `filled.json`，不复制 `*confirmed*.json`，不复制真实业务文件。
- 不使用生产库，不在生产库验证，不在生产库调试。
- 当前不能 production_ready，当前仍不能正式上线测试，当前仍不能生产部署。

## 目录准备原则

1. 先人工确认目标版本 v2.0.61 与宿主工程目录。
2. 后续命令只能在宿主工程任务或人工确认后执行，当前仓库只保留计划。
3. 宿主工程使用 yarn，数据库使用 postgresql，部署模式为 source_host。
4. 插件开发与安装模式均按 packages_plugins 规划。
5. 真实 IOPGPS 同步保持禁用：iopgps_real_sync_allowed = false。
6. 只允许 mock_data_only = true 的测试数据进入本阶段。
