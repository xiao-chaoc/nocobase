# 全自动化正式上线测试路线图

## 1. 当前状态

- NAS 基础环境已经可以启动官方 NocoBase + PostgreSQL 测试环境。
- 登录后系统仍是空应用，这是当前阶段的正常状态。
- 当前 `docker-compose.test.yml` 没有直接挂载 `packages/plugins`。
- 三个插件仍是源码骨架、纯函数、Collection 草案、注册描述和测试准备文件，尚未在 NocoBase 中真实安装启用。
- Collections 尚未通过插件或迁移自动注册。
- 页面、菜单、权限、工作流尚未自动创建。
- `test-data/` 中的 mock 数据尚未自动导入 NocoBase。
- 当前环境不能用于正式上线测试，也不能用于生产。
- 用户不需要、也不应手动在 NocoBase UI 中搭建 Collections、页面、菜单、权限或测试数据。

## 2. 目标状态

正式上线测试前，目标是由 Codex 后续自动化完成以下能力：

- NocoBase 测试环境自动安装或加载项目插件。
- `plugin-rental-core` 自动注册业务 Collections、服务方法、权限角色、敏感字段策略、基础菜单和页面配置。
- `plugin-contract-documents` 自动注册合同模板与合同文件 Collections，并接入合同文件状态服务。
- `plugin-iopgps` 自动注册 GPS 相关 Collections，默认关闭真实同步，并只运行 GPS mock / 状态归一化测试。
- 自动导入 mock 测试数据，不导入真实司机、真实付款截图、真实合同扫描件或真实 IOPGPS 密钥。
- 自动执行 smoke test，验证台账生成、付款禁止超付、押金、权限过滤、合同文件状态、GPS mock 错误隔离。
- 通过 UAT 检查后，才进入正式上线测试冻结；冻结前仍不能生产上线。

## 3. 阶段总览

从当前状态到正式上线测试，建议拆成 8 个详细阶段；也可归纳为 5 个核心阶段：

1. 插件真实 NocoBase 化。
2. 自动初始化 Collections / 页面 / 权限。
3. 自动导入 mock 数据和 smoke test。
4. NAS 自动化测试运行。
5. UAT 修复与上线测试冻结。

其中阶段 1、2、4、5、6、7、8 必须按顺序推进；阶段 3（页面/菜单）和阶段 4（权限）可在阶段 2 的 Collection 结构稳定后并行设计，但最终必须在阶段 6 smoke test 前合并验证。阶段 5、6、7、8 必须等插件真实接入并可安装后才能做。所有阶段都不要求用户手动在 UI 中搭建业务系统。

## 4. 阶段 1：插件可安装化重构

| 项目 | 内容 |
| --- | --- |
| 阶段目标 | 将 `packages/plugins` 下三个插件整理为 NocoBase 可安装插件形态，补齐 `package.json`、server 入口、client 入口占位、`plugin.ts`、collections、migrations、locale，并输出构建/打包方案。 |
| Codex 需要生成的文件 | 真实插件入口、client 占位入口、NocoBase 插件元数据、构建配置、打包脚本草案、版本说明。 |
| 自动化产物 | 可在完整 NocoBase 测试工程中构建的插件源码或可安装插件包草案。 |
| 人工只需做什么 | 合并 PR，确认目标 NocoBase 版本，不在 UI 中手动建表。 |
| 验收标准 | 三个插件可被宿主工程识别；插件顺序明确；不伪造不确定 API；不接真实 IOPGPS。 |
| 风险 | NocoBase 版本差异可能导致插件结构调整。 |
| 是否阻塞下一阶段 | 是。没有可安装化插件就不能进入真实 Collection 自动注册。 |

## 5. 阶段 2：自动注册 Collections 与迁移

| 项目 | 内容 |
| --- | --- |
| 阶段目标 | 由 Codex 生成真实插件中的 Collection 注册或 migration 草案，自动创建 `drivers`、`vehicles`、`lease_contracts`、`rent_daily_ledgers`、`rent_payments`、`rent_payment_allocations`、`deposit_records`、`gps_devices`、`contract_templates`、`contract_documents` 等。 |
| Codex 需要生成的文件 | Collection 定义、migration、枚举、关系、唯一约束、索引、敏感字段标记、结构校验脚本。 |
| 自动化产物 | 可执行的 Collection 初始化 / migration 方案。 |
| 人工只需做什么 | 运行自动化命令并查看报告，不手动在 UI 建 Collections。 |
| 验收标准 | 核心 Collections 自动出现；字段、枚举、关系、索引、唯一约束或服务端校验存在；无短租、司机登录、按车型出租模型。 |
| 风险 | 真实 NocoBase Collection API 需按目标版本验证。 |
| 是否阻塞下一阶段 | 是。页面、权限、数据导入都依赖 Collection 结构。 |

## 6. 阶段 3：自动初始化菜单、页面和区块

| 项目 | 内容 |
| --- | --- |
| 阶段目标 | 自动创建司机管理、车辆管理、合同管理、每日租金台账、付款记录、押金管理、GPS 设备、合同文件等基础业务页面配置。 |
| Codex 需要生成的文件 | 页面初始化脚本、菜单配置、区块配置、页面配置导入说明。 |
| 自动化产物 | 可执行页面/菜单初始化脚本，或稳定的配置导入方案。 |
| 人工只需做什么 | 查看初始化结果和测试报告，不手动建页面。 |
| 验收标准 | 业务入口自动出现；页面能查看 mock 数据；敏感字段展示依赖权限。 |
| 风险 | 如果 NocoBase 页面配置 API 不稳定，需改用可执行导入脚本并在测试工程验证。 |
| 是否阻塞下一阶段 | 阻塞完整 UAT，但可与阶段 4 并行设计。 |

## 7. 阶段 4：自动初始化权限角色

| 项目 | 内容 |
| --- | --- |
| 阶段目标 | 自动创建 `system_admin`、`manager`、`accountant`、`operator`、`gps_maintenance`、`readonly_auditor`，并配置敏感字段权限。 |
| Codex 需要生成的文件 | 角色初始化脚本、服务端 ACL 配置、敏感字段策略、权限测试脚本。 |
| 自动化产物 | 可重复运行的权限初始化与验证脚本。 |
| 人工只需做什么 | 查看权限测试报告，不手动配置权限。 |
| 验收标准 | 付款截图、押金金额、总已付、未来应收、总欠款、司机证件号、证件照片、驾照照片均受服务端权限控制。 |
| 风险 | 不能只靠前端隐藏，必须接入真实服务端 ACL。 |
| 是否阻塞下一阶段 | 是。权限不自动化不能进入正式 UAT。 |

## 8. 阶段 5：自动导入 mock 测试数据

| 项目 | 内容 |
| --- | --- |
| 阶段目标 | 使用 `test-data` 生成的 mock 数据，自动导入测试司机、车辆、合同、每日台账、付款、押金、GPS mock、合同模板占位数据。 |
| Codex 需要生成的文件 | `scripts/nocobase/import-test-data.ts`、导入映射、幂等校验、清理脚本、导入报告。 |
| 自动化产物 | 一键导入 mock 数据并输出结果的脚本。 |
| 人工只需做什么 | 运行命令和查看报告，不手动录入测试数据。 |
| 验收标准 | 无真实司机数据、真实付款截图、真实合同扫描件、真实 IOPGPS；数据可重复导入或安全重置。 |
| 风险 | 需要真实 Collection 已存在，且导入脚本要避免重复数据和超付。 |
| 是否阻塞下一阶段 | 是。没有 mock 数据就无法自动 smoke test。 |

## 9. 阶段 6：自动化业务 Smoke Test

| 项目 | 内容 |
| --- | --- |
| 阶段目标 | 自动测试时限合同完整台账、长租未来台账、付款分配、单日不可超付、未付原因、部分付款后状态、押金不计入租金、权限过滤、合同状态、GPS mock 错误隔离。 |
| Codex 需要生成的文件 | `scripts/nocobase/run-smoke-tests.ts`、断言工具、测试报告模板、失败回滚建议。 |
| 自动化产物 | 可重复执行的业务 smoke test 报告。 |
| 人工只需做什么 | 查看测试报告和失败项，不手工点页面补数据。 |
| 验收标准 | 核心业务规则自动验证通过；失败原因明确；不连接真实 IOPGPS。 |
| 风险 | 页面级测试和服务级测试需要分别设计。 |
| 是否阻塞下一阶段 | 是。Smoke test 不通过不能进入 NAS 自动化测试部署。 |

## 10. 阶段 7：NAS 自动化测试部署

| 项目 | 内容 |
| --- | --- |
| 阶段目标 | 使用 `docker-compose.test.yml` 启动 NocoBase + PostgreSQL，安装或加载构建后的插件，执行初始化脚本，导入 mock 数据，执行 smoke test，输出测试报告。 |
| Codex 需要生成的文件 | NAS 自动化测试脚本、插件包安装说明、初始化执行顺序、测试报告归档脚本。 |
| 自动化产物 | 可在 NAS 测试目录执行的自动化测试流程。 |
| 人工只需做什么 | 创建 `.env.test`、启动测试环境、执行自动化命令、查看报告。 |
| 验收标准 | 环境可启动；插件可启用；数据可导入；smoke test 通过；无真实数据和密钥。 |
| 风险 | NAS 文件权限、NocoBase 版本、插件安装机制可能需要迭代。 |
| 是否阻塞下一阶段 | 是。NAS 自动化测试不过不能进入冻结。 |

## 11. 阶段 8：正式上线测试前冻结

| 项目 | 内容 |
| --- | --- |
| 阶段目标 | 锁定测试版本，固定 NocoBase 镜像版本，固定插件版本，备份测试数据库，输出 UAT 测试报告。 |
| Codex 需要生成的文件 | 版本冻结清单、UAT 报告模板、备份说明、回滚脚本校验清单。 |
| 自动化产物 | 可审计的测试版本、数据库备份、UAT 结果和上线测试结论。 |
| 人工只需做什么 | 评审 UAT 报告并决定是否进入正式上线测试。 |
| 验收标准 | 不再使用 `latest-full` 作为正式测试基准；插件版本固定；UAT 阻塞项清零。 |
| 风险 | 若 UAT 发现阻塞问题，需要回到对应阶段修复。 |
| 是否阻塞下一阶段 | 是。冻结未完成不得生产上线。 |

## 12. 串行、并行与依赖结论

- 必须串行：阶段 1 → 阶段 2 → 阶段 5 → 阶段 6 → 阶段 7 → 阶段 8。
- 可并行设计：阶段 3 页面/菜单与阶段 4 权限可在 Collection 草案稳定后并行推进，但必须在阶段 6 前合并验证。
- 必须等插件真实接入后才能做：阶段 2、3、4、5、6、7、8。
- 不需要用户手动 UI 搭建：全部阶段都应由插件、migration、初始化脚本、导入脚本和测试脚本自动完成。

## 13. 自动化接入适配层补充

本轮新增 `packages/shared/nocobase-automation` 作为抽象适配层，只生成 dry-run 注册计划，不连接真实 NocoBase，也不创建数据库、页面、权限或测试数据。该层把三个插件的 `pluginRegistration` 合并为统一自动化计划，用于后续真实 adapter 实现前的结构校验。

新增命令：

```bash
npm run generate:registration-plan
npm run validate:registration-plan
```

该 dry-run 层属于阶段 1 和阶段 2 之间的准备工作：它不替代真实插件可安装化，也不代表已经完成 Collection 注册。下一步仍应推进插件真实 NocoBase 化，并在完整 NocoBase 工程中实现真实 adapter。

## 14. Collection 自动注册 dry-run 进展

本轮在阶段 2 之前新增 Collection 自动注册 dry-run 草案，目标是提前校验 Collection 计划完整性，而不是创建真实数据库表。

已完成的 dry-run 准备：

- 标准化 Collection 字段、关系、索引、唯一约束和敏感字段。
- 校验 `drivers`、`vehicles`、`lease_contracts`、`rent_daily_ledgers`、`rent_payments`、`deposit_records`、`gps_devices`、`contract_templates`、`contract_documents` 等关键 Collections。
- 校验核心唯一约束和敏感字段覆盖。
- 使用 mock adapter 模拟注册步骤。
- 输出 `test-data/generated/collection-registration-dry-run.generated.json`。

这仍不代表真实 NocoBase 已完成 Collection 注册。下一步需要在明确 NocoBase 版本后实现真实 Collection adapter 或 migration，并继续保持不由用户手动建表。

## 15. Runtime 自动注册 dry-run 进展

本轮在 Collection dry-run 之后新增 runtime 自动注册 dry-run 草案，目标是提前校验服务、动作、权限、定时任务和 i18n 计划，而不是在真实 NocoBase 中注册这些能力。

已完成的 dry-run 准备：

- 标准化核心服务方法计划，并标记需要事务保护的服务。
- 校验核心动作与服务绑定。
- 校验六个内部角色和敏感字段可见性策略。
- 校验 IOPGPS 定时任务默认关闭，不调用真实 API。
- 校验 zh-CN、en-US、fr-FR 三语言 i18n 计划。
- 输出 `test-data/generated/runtime-registration-dry-run.generated.json`。

这仍不代表真实 NocoBase 已完成服务、动作、权限、定时任务或 i18n 注册。下一步需要在明确 NocoBase 版本后实现真实 runtime adapter，并继续保持不由用户手动创建权限或动作。

## 页面初始化 dry-run 阶段补充

在 runtime dry-run 之后，需要增加页面初始化 dry-run：自动生成菜单、页面、区块、筛选器和按钮动作计划，并校验敏感字段控制、禁止短租/司机登录/按车型出租/GPS 参与租金计算等边界。该阶段不创建真实页面，只为后续真实 NocoBase adapter 提供可验证的页面初始化输入。

## mock 测试数据导入 dry-run 阶段补充

页面初始化 dry-run 之后，需要执行 mock 测试数据导入 dry-run：自动读取 `test-data/generated`，按司机、车辆、GPS 设备、合同、台账、付款、押金、GPS mock、合同文件、操作日志顺序模拟导入，并校验引用完整性、唯一键、敏感数据和核心业务规则。该阶段不写数据库，不代表真实测试数据已导入。

## 自动化 Smoke Test dry-run 编排补充

新增统一 smoke test dry-run 阶段后，进入真实 NAS 或真实 NocoBase 测试前，应先运行 `npm run smoke:dry-run` 和 `npm run validate:smoke-report`。该阶段串联注册计划、Collection、Runtime、页面初始化、mock 测试数据导入与 NAS 文件预检，并生成统一报告。该报告只能证明 dry-run 链路完整，不能替代真实 NocoBase 集成测试或上线测试。

## 正式上线测试前 readiness 报告补充

新增 readiness 报告后，统一 smoke dry-run 通过并不代表可以正式上线测试。应继续运行 `npm run generate:go-live-readiness` 和 `npm run validate:go-live-readiness`，确认当前 readiness level、阻塞项和下一阶段。当前预期下一阶段是实现真实 NocoBase adapter，而不是继续新增 dry-run；在真实 adapter、插件安装、UAT、权限验证和备份回滚完成前，不得标记为生产就绪。

## 真实 adapter 最小接口阶段补充

本轮路线图状态更新为：已完成真实 NocoBase adapter 的最小接口、能力矩阵、未配置占位实现、环境检测、factory、受控错误和测试。该阶段只是为下一轮完整 NocoBase 工程接入做边界准备，不代表已经具备真实注册能力。

当前仍不能进入真实插件接入测试，原因是当前仓库没有真实 NocoBase app、db、ACL、UI Schema、pluginManager、scheduler、workflow 和 file storage 上下文，也没有在目标 NocoBase 版本中验证任何官方注册 API。

下一轮建议只推进第一项真实能力：Collection 注册 adapter 草案。该草案应继续禁止生产数据库调试，并要求在隔离完整 NocoBase 工程中验证。

## 2026-06-04 补充：真实 Collection 注册草案阶段

自动化上线测试路线新增一个前置阶段：生成并校验真实 Collection 注册草案。

阶段命令：

- `npm run generate:real-collection-plan`
- `npm run validate:real-collection-plan`

该阶段只验证计划完整性和禁止业务边界，不执行真实 NocoBase 注册。通过该阶段不代表可以上线，只代表后续真实 adapter 接入评审有了可审查的 schema draft 输入。

## 2026-06-04 补充：真实 Runtime 注册草案阶段

在真实 Collection 注册草案之后，新增真实 Runtime 注册草案阶段。该阶段只生成服务、动作、权限、i18n、定时任务的 schema draft、步骤、回滚计划和后置验证计划，并通过脚本校验三语言、六角色、核心服务、核心动作、GPS 不参与租金计算、押金不计入租金已付、IOPGPS 定时任务默认关闭等边界。

该阶段不执行真实 NocoBase runtime 注册。后续路线仍需在完整 NocoBase 工程中确认真实服务注册、ACL、i18n、scheduler、action / command / route API 后再推进。

## 真实 Seed Data Import 草案阶段补充（2026-06-04）

自动化上线测试路线新增真实 Seed Data Import adapter 草案阶段。本阶段输出 `real-seed-data-import-plan.generated.json`，用于验证测试数据导入顺序、引用完整性、唯一键、文件字段占位、事务计划、回滚计划、后置验证和禁止真实数据边界。

该阶段仍是 dry-run/plan-only 边界，不进入真实 NocoBase，不执行真实导入。下一阶段应在完整 NocoBase 测试工程中替换真实 repository/db、事务、文件存储、回滚和验证 adapter。

## 2026-06-04 真实 Smoke Test Adapter 草案

本轮在真实 Collection、Runtime、Page、Seed Data Import 草案之后，新增“真实 Smoke Test Adapter 草案”。当前阶段只设计接口边界、计划转换器、校验器、草案 adapter、脚本、测试和文档，不连接真实 NocoBase、不写数据库、不安装插件、不执行业务流程、不调用 IOPGPS、不生成合同文件，也不伪造任何 NocoBase API 成功。

本轮计划覆盖环境前置检查、Collection 注册验证、Runtime 注册验证、Page 注册验证、Seed Data 导入验证、核心业务流程、权限、GPS mock、合同文件、失败隔离、回滚验证和报告草案。`real` 模式在当前仓库必须被阻断，后续只有在独立测试环境、备份、回滚、mock 数据、禁用真实 IOPGPS 等条件全部满足后，才能进入下一阶段设计。

## 2026-06-05 补充：真实 Backup / Rollback 草案阶段

本阶段新增真实 Backup / Rollback 草案，作为真实 Collection、Runtime、Page、Seed Data 和 Smoke Test 之后的安全兜底设计。该阶段只生成计划与校验结果，不执行真实备份、回滚、删除或 storage 修改。

下一阶段路线：

1. 在完整 NocoBase 隔离测试工程中确认目标版本备份能力。
2. 将数据库备份草案替换为经过人工确认的测试库 `pg_dump` / `pg_restore` 或官方备份能力。
3. 将文件存储和 `storage/plugins` 草案替换为隔离 storage snapshot。
4. 将 schema / runtime / page / seed data snapshot 草案替换为真实只读 snapshot。
5. 先演练失败隔离和回滚验证，再允许任何真实注册测试。

## 2026-06-05 复核补充：Backup / Rollback 后置验证

Backup / Rollback 草案阶段的后置验证计划已覆盖 NocoBase 启动、PostgreSQL 启动、测试数据库、storage、插件状态、mock 数据、真实数据隔离、IOPGPS 禁用和日志保留。该阶段仍只输出草案，不执行真实恢复；下一阶段应在完整 NocoBase 隔离测试工程中替换执行器并进行人工确认演练。

## 2026-06-06 路线图补充：从草案转入完整工程真实接入

当前所有真实 Adapter 草案已经覆盖 Collection、Runtime、Page、Seed Data、Smoke Test、Backup / Rollback。下一阶段不是继续新增草案，而是在完整 NocoBase 工程中开始真实 adapter 实现。

路线图新增阻塞条件：

1. 先确认 NocoBase 目标版本和插件 API。
2. 准备完整 NocoBase 源码工程、隔离 PostgreSQL 测试库、隔离 storage 和测试专用 `.env`。
3. 保持 `IOPGPS_SYNC_ENABLED=false`。
4. 按 `docs/real-adapter-implementation-sequence.md` 推进真实实现。
5. 在 Backup / Rollback 演练通过前，不执行真实 Smoke Test。

当前仓库仍不能正式上线测试，也不能生产部署。

## 2026-06-06 NocoBase 目标版本与插件 API 调研补充

本轮已新增目标版本与真实插件 API 映射调研文档：

- `docs/nocobase-target-version-research.md`
- `docs/nocobase-plugin-api-research.md`
- `docs/real-adapter-api-mapping.md`
- `docs/real-adapter-gap-analysis.md`
- `docs/real-adapter-implementation-backlog.md`

本轮结论如下：

- 下一阶段是锁定 NocoBase 目标版本和验证官方 API。
- 当前 `latest-full` 只能继续用于 NAS 基础环境测试，不能作为真实 adapter、UAT 或生产部署基准。
- 当前仍不能实现真实 adapter；未经官方 API 验证不得写真实 adapter。
- 当前不能正式上线测试，也不能生产部署。
- 任何无法确认的 NocoBase API 必须标记为待验证，不得伪造 API。
- 验证只能在完整 NocoBase 源码测试工程和隔离 PostgreSQL、隔离 storage 中进行，不得生产库调试。

## 本轮补充：宿主工程接入准备路线

当前自动化上线测试路线增加宿主工程接入准备阶段：先固定目标版本决策记录，再准备完整 NocoBase 宿主工程 Runbook、接入分支计划、源码 API 验证计划和默认 dry-run 的宿主准备脚本。

下一阶段需要人工确认 NocoBase 目标版本。未确认目标版本前，不应实现真实 adapter，不应运行真实插件安装，不应连接真实 NocoBase，不应写数据库。当前仍不能正式上线测试，当前仍不能生产部署。

## 目标版本人工确认门禁补充

自动化上线测试路线在真实 adapter 阶段前新增目标版本人工确认门禁。当前目标版本仍为 `pending_manual_confirmation`，不得继续实现真实 adapter，也不得进入正式上线测试或生产部署。

下一步需要用户提交目标 NocoBase 版本、来源、包管理器、部署模式、插件安装模式、PostgreSQL 测试库、隔离 storage、确认人和确认时间，并通过 `npm run validate:target-version-confirmation` 后，才能规划完整宿主工程接入。

## 目标版本确认后的推进条件

当前目标版本仍为 `pending_manual_confirmation`，`target_version = unset`，因此自动化上线测试路线图不得进入真实环境执行。用户需要先填写 `test-data/generated/nocobase-target-version-confirmation.filled.json`，运行 `validate:target-version-input` 和 `apply:target-version-confirmation` dry-run；只有 `validate:target-version-confirmation` 通过后，才允许规划完整 NocoBase 宿主工程接入、环境检测真实 adapter 和 Collection 真实 adapter。

在此之前，`validate:can-start-real-adapter` 必须失败，当前仍不能正式上线测试，仍不能生产部署。

## 本轮补充：目标版本确认流程依赖

自动化正式上线测试路线图仍依赖目标版本人工确认。确认流程必须通过 GitHub Issue + `filled.json` + apply 脚本 + PR 审查完成。当前目标版本仍为 `pending_manual_confirmation`，所以 `validate:target-version-confirmation` 和 `validate:can-start-real-adapter` 未通过前，不允许真实 adapter，不允许完整宿主工程真实接入，当前仍不能正式上线测试，仍不能生产部署。

## 本轮补充：v2.0.61 宿主工程接入任务包路线

目标版本已确认：`v2.0.61`。下一阶段是完整 NocoBase v2.0.61 宿主工程接入准备。

路线图新增任务包阶段：

1. 使用 `docs/nocobase-v2.0.61-host-integration-task.md` 作为总任务入口。
2. 使用 `docs/nocobase-v2.0.61-host-directory-plan.md` 固定独立目录边界。
3. 使用 `docs/nocobase-v2.0.61-host-bootstrap-commands.md` 作为人工执行命令清单，不在本轮执行。
4. 使用 `docs/nocobase-v2.0.61-plugin-copy-plan.md` 约束插件和 shared automation 复制。
5. 使用 `docs/task-real-environment-adapter-v2.0.61.md` 开启真实环境检测 adapter。
6. 环境检测通过后，再使用 `docs/task-real-collection-adapter-v2.0.61.md` 推进 Collection adapter。

当前项目仍不包含完整 NocoBase 源码，当前仍不能正式上线测试，当前仍不能生产部署，当前不能标记为 `production_ready`。
