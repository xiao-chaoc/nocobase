# NocoBase Collections 数据模型设计（第二版）

## 业务假设

- 本系统是基于 NocoBase 的内部汽车租赁记账与运营系统，由内部员工使用，司机不登录系统，不把司机设计成 NocoBase 用户。
- 系统不做短租预订，不创建任何短租预订或短租订单相关 Collection，不按车型出租；每份合同必须绑定具体车辆与车牌。
- 合同只分为两类：长租合同 `open_ended` 与 6 个月以上、按自然月递增的时限合同 `fixed_term`。
- 合同签订时固定计费规则，后续不按每周重新计算价格；每日租金台账保存到日的计费结果。
- 每日租金台账 `rent_daily_ledgers` 是应收、已付、欠款、免除、未来应收、司机对账与日历显示的唯一事实来源。
- 付款必须通过 `rent_payment_allocations` 分配到具体每日租金台账；单个日期不可超付，发生超付时整次付款操作失败。
- 未付日期必须注明未付原因；部分付款必须注明剩余金额是欠款、免除、待审批免除或争议。
- 未来应收不计入当前欠款；当前欠款只统计截至当前日期且未结清的应收台账。
- IOPGPS 只用于车辆位置、里程和设备状态监控；GPS 数据不参与租金计算，IOPGPS 同步失败不能影响租金台账和付款逻辑。
- 总已付、当前欠款、未来应收、押金、付款方式、付款截图、证件号、证件照片、驾照照片、合同签署扫描件、IOPGPS 密钥与令牌均为敏感数据，需要字段级权限控制。

## NocoBase 字段设计约定

- 字段类型使用适合 NocoBase Collection 的概念：`text`、`integer`、`decimal`、`boolean`、`date`、`datetime`、`enum`、`json`、`file`、`relation`、`password`、`encrypted text`。
- 所有金额字段建议使用 `decimal(12,2)` 或 NocoBase 等价精度配置，所有经纬度建议使用 `decimal(10,6)`。
- 所有业务 Collection 默认包含 NocoBase 常规审计字段 `createdAt`、`updatedAt`、`createdBy`、`updatedBy`；表内仅在业务要求明确时单独列出。
- `敏感字段` 标记为“是”的字段必须通过角色和字段级权限控制，并覆盖列表、详情、筛选、导出、文件预览与 API 访问。
- 除明确允许的基础配置或草稿模板外，业务记录默认不建议硬删除，应通过状态字段、冲正记录或调整记录处理。

## Collection 总览

| Collection | 中文名称 | 核心用途 | 是否允许硬删除 | 是否需要操作日志 |
| --- | --- | --- | --- | --- |
| `drivers` | 司机表 | 管理租赁对象资料，不作为登录用户 | 否 | 是 |
| `vehicles` | 车辆表 | 管理具体车牌车辆与 GPS 摘要 | 否 | 是 |
| `lease_contracts` | 合同表 | 记录长租或时限合同及固定计费快照 | 否 | 是 |
| `contract_billing_weeks` | 自然周账期表 | 保存合同自然周账期快照与周汇总 | 否 | 是 |
| `rent_daily_ledgers` | 每日租金台账 | 每日租金唯一事实来源 | 否 | 是 |
| `rent_payments` | 付款记录表 | 记录内部员工手工录入的付款 | 否 | 是 |
| `rent_payment_allocations` | 付款分配表 | 将付款分配到具体租金日期 | 否 | 是 |
| `rent_adjustments` | 租金调整表 | 记录免租、应收、免除、争议与修正 | 否 | 是 |
| `deposit_records` | 押金记录表 | 单独管理押金，独立于租金收入 | 否 | 是 |
| `contract_templates` | 合同模板表 | 管理中文、英文、法文合同模板版本 | 仅草稿可删除 | 是 |
| `contract_documents` | 合同文件表 | 管理生成合同、打印与签署扫描件 | 否 | 是 |
| `gps_devices` | GPS 设备表 | 管理 GPS 设备主数据与最新状态 | 否 | 是 |
| `gps_device_bindings` | GPS 绑定历史表 | 记录设备与车辆绑定历史 | 否 | 是 |
| `gps_location_snapshots` | GPS 定位快照表 | 保存 GPS 定位历史 | 可按归档策略清理 | 是 |
| `gps_daily_mileages` | GPS 每日里程表 | 保存每日里程运营核查数据 | 可按归档策略清理 | 是 |
| `gps_device_status_logs` | GPS 状态日志表 | 保存 GPS 设备状态变化 | 可按归档策略清理 | 是 |
| `iopgps_settings` | IOPGPS 配置表 | 保存 IOPGPS 同步配置与敏感凭据 | 否 | 是 |
| `operation_logs` | 操作日志表 | 保存关键业务操作审计记录 | 否 | 否，因其自身即日志 |

---

## 1. `drivers` 司机表

### Collection 基本信息

- Collection 名称：`drivers`
- 中文名称：司机表
- 业务用途：维护司机基础资料、证件资料、驾照资料、风险状态与当前合同引用；司机是租赁对象，不是系统登录用户。
- 是否允许硬删除：否。存在合同、台账、付款、押金或日志关联时不得删除；离场司机通过 `status = inactive` 处理。
- 是否需要操作日志：是，需记录创建、证件变更、风险状态变更、状态变更、当前合同变更。

### 字段清单

| 字段 | 类型 | 必填 | 默认值 | 枚举值或说明 | 敏感字段 | 关系字段 |
| --- | --- | --- | --- | --- | --- | --- |
| `driver_no` | text | 是 | 自动编号 | 司机编号，全局唯一 | 否 | 否 |
| `name` | text | 是 | 无 | 司机姓名 | 否 | 否 |
| `phone` | text | 是 | 无 | 联系电话 | 否 | 否 |
| `email` | text | 否 | 无 | 邮箱 | 否 | 否 |
| `nationality` | text | 否 | 无 | 国籍 | 否 | 否 |
| `id_type` | enum | 否 | 无 | `passport` 护照、`national_id` 身份证、`residence_permit` 居留证、`driver_license` 驾照、`other` 其他 | 否 | 否 |
| `id_no` | text | 否 | 无 | 证件号 | 是 | 否 |
| `id_front_file` | file | 否 | 无 | 证件正面文件 | 是 | 否 |
| `id_back_file` | file | 否 | 无 | 证件背面文件 | 是 | 否 |
| `license_no` | text | 是 | 无 | 驾照编号 | 否 | 否 |
| `license_class` | text | 否 | 无 | 驾照准驾类别 | 否 | 否 |
| `license_expiry_date` | date | 是 | 无 | 驾照到期日期 | 否 | 否 |
| `license_front_file` | file | 否 | 无 | 驾照正面文件 | 是 | 否 |
| `license_back_file` | file | 否 | 无 | 驾照背面文件 | 是 | 否 |
| `emergency_contact_name` | text | 否 | 无 | 紧急联系人姓名 | 否 | 否 |
| `emergency_contact_phone` | text | 否 | 无 | 紧急联系人电话 | 否 | 否 |
| `risk_status` | enum | 是 | `normal` | `normal` 正常、`watchlist` 关注、`blacklisted` 黑名单 | 否 | 否 |
| `current_contract_id` | relation | 否 | 无 | 当前有效合同 | 否 | 是，关联 `lease_contracts.id` |
| `status` | enum | 是 | `active` | `active` 在用、`inactive` 停用、`blocked` 已阻止 | 否 | 否 |
| `remark` | text | 否 | 无 | 内部备注 | 否 | 否 |

### 唯一约束

- `driver_no` 全局唯一。
- `id_no` 不强制唯一，避免不同证件类型或历史录入差异造成冲突；如后续确认，可增加 `id_type + id_no` 条件唯一。

### 索引建议

- `driver_no` 唯一索引。
- `phone` 普通索引。
- `risk_status` 普通索引。
- `status` 普通索引。
- `current_contract_id` 普通索引。

### 校验规则

- 司机不登录系统，不关联 NocoBase 用户表，不设计司机账号、密码或司机端权限。
- `risk_status = blacklisted` 时不能创建、提交、激活合同。
- `license_expiry_date` 早于合同激活日期时，不能激活合同。
- 证件号、证件照片、驾照照片必须按敏感字段控制。
- `current_contract_id` 只能指向该司机当前有效或待交车合同；合同结束或取消后应清空或更新。

### 权限注意事项

- 运营可维护基础联系资料，但不默认查看证件号、证件照片、驾照照片。
- 财务只在付款与押金业务需要时查看司机基础识别信息，不默认下载证件文件。
- GPS 维护人员不得查看证件号、证件照片、驾照照片。
- 只读审计按授权查看，不能修改司机资料。

### 与其他 Collection 的关系

- 一名司机可关联多份 `lease_contracts` 历史合同。
- 一名司机可关联多条 `rent_daily_ledgers`、`rent_payments`、`rent_payment_allocations`、`rent_adjustments`、`deposit_records`。
- `current_contract_id` 指向当前合同，但历史关系以 `lease_contracts.driver_id` 为准。

---

## 2. `vehicles` 车辆表

### Collection 基本信息

- Collection 名称：`vehicles`
- 中文名称：车辆表
- 业务用途：维护具体车辆、车牌、车辆状态、保险年检与最新 GPS 摘要；合同必须绑定这里的具体车辆和车牌。
- 是否允许硬删除：否。存在合同、GPS 绑定、台账或日志关联时不得删除；退役车辆通过 `status` 与 `availability_status` 处理。
- 是否需要操作日志：是，需记录车辆创建、车牌变更、状态变更、GPS 设备关联变更、保险年检信息变更。

### 字段清单

| 字段 | 类型 | 必填 | 默认值 | 枚举值或说明 | 敏感字段 | 关系字段 |
| --- | --- | --- | --- | --- | --- | --- |
| `vehicle_no` | text | 是 | 自动编号 | 车辆编号，全局唯一 | 否 | 否 |
| `plate_no` | text | 是 | 无 | 车牌号，全局唯一 | 否 | 否 |
| `vin` | text | 否 | 无 | 车辆识别号，建议有值时唯一 | 否 | 否 |
| `brand` | text | 否 | 无 | 品牌，仅作资料，不用于按车型出租 | 否 | 否 |
| `model` | text | 否 | 无 | 型号，仅作资料，不用于按车型出租 | 否 | 否 |
| `year` | integer | 否 | 无 | 年份 | 否 | 否 |
| `color` | text | 否 | 无 | 颜色 | 否 | 否 |
| `fuel_type` | enum | 否 | 无 | `gasoline` 汽油、`diesel` 柴油、`hybrid` 混动、`electric` 电动、`other` 其他 | 否 | 否 |
| `current_odometer` | decimal | 否 | `0` | 当前人工维护里程 | 否 | 否 |
| `gps_device_id` | relation | 否 | 无 | 当前 GPS 设备 | 否 | 是，关联 `gps_devices.id` |
| `gps_imei` | text | 否 | 无 | 当前 GPS IMEI 快照 | 否 | 否 |
| `availability_status` | enum | 是 | `available` | `available` 可用、`reserved` 内部预留、`rented` 已出租、`maintenance` 保养、`repair` 维修、`blocked` 锁定、`sold` 已出售 | 否 | 否 |
| `gps_status` | enum | 是 | `unknown` | `normal` 正常、`offline` 离线、`fault` 故障、`no_device` 无设备、`api_error` 接口异常、`unknown` 未知 | 否 | 否 |
| `last_gps_lat` | decimal | 否 | 无 | 最近 GPS 纬度 | 否 | 否 |
| `last_gps_lng` | decimal | 否 | 无 | 最近 GPS 经度 | 否 | 否 |
| `last_gps_address` | text | 否 | 无 | 最近 GPS 地址 | 否 | 否 |
| `last_gps_time` | datetime | 否 | 无 | 最近 GPS 时间 | 否 | 否 |
| `last_gps_mileage_km` | decimal | 否 | 无 | 最近 GPS 里程，单位公里 | 否 | 否 |
| `insurance_expiry_date` | date | 否 | 无 | 保险到期日期 | 否 | 否 |
| `inspection_expiry_date` | date | 否 | 无 | 年检到期日期 | 否 | 否 |
| `status` | enum | 是 | `active` | `active` 在用、`inactive` 停用、`disposed` 已处置 | 否 | 否 |
| `remark` | text | 否 | 无 | 内部备注 | 否 | 否 |

### 唯一约束

- `vehicle_no` 全局唯一。
- `plate_no` 全局唯一。
- `vin` 有值时唯一。

### 索引建议

- `plate_no` 唯一索引。
- `vehicle_no` 唯一索引。
- `vin` 条件唯一索引。
- `availability_status` 普通索引。
- `gps_status` 普通索引。
- `gps_device_id` 普通索引。
- `last_gps_time` 普通索引。

### 校验规则

- 每份合同必须绑定具体 `vehicle_id` 与当时 `plate_no`，不能只选择 `brand`、`model` 或车辆类别。
- `availability_status = rented` 的车辆不能再激活冲突合同。
- 同一车辆不能存在日期重叠的有效合同。
- GPS 摘要字段只用于运营监控、地图和设备状态显示，不参与租金金额、欠款金额、免租日或付款状态计算。
- 车辆出售或停用后不得创建新合同。

### 权限注意事项

- 运营可维护车辆基础信息和状态。
- GPS 维护人员可维护 GPS 相关字段和查看定位摘要。
- 财务可按合同与付款需要查看车辆和车牌，但不因此获得 GPS 运维配置权限。
- 车辆定位信息属于运营敏感数据，导出需授权。

### 与其他 Collection 的关系

- 一台车辆可关联多份历史 `lease_contracts`，但同一时间不能有冲突有效合同。
- 一台车辆可关联当前 `gps_devices`，并有多条 `gps_device_bindings` 历史。
- 一台车辆可关联多条 GPS 快照、每日里程、状态日志。
- 一台车辆可关联台账、付款、押金和调整记录的快照关系。

---

## 3. `lease_contracts` 合同表

### Collection 基本信息

- Collection 名称：`lease_contracts`
- 中文名称：合同表
- 业务用途：记录长租或时限合同、具体司机和车辆、固定计费规则快照、押金摘要和财务汇总。
- 是否允许硬删除：否。草稿如需废弃使用 `status = cancelled`；已生成台账或付款后不得删除。
- 是否需要操作日志：是，需记录合同创建、计费规则锁定、状态变化、激活、终止、取消、押金摘要变更、财务汇总刷新。

### 字段清单

| 字段 | 类型 | 必填 | 默认值 | 枚举值或说明 | 敏感字段 | 关系字段 |
| --- | --- | --- | --- | --- | --- | --- |
| `contract_no` | text | 是 | 自动编号 | 合同编号，全局唯一 | 否 | 否 |
| `contract_type` | enum | 是 | 无 | `open_ended` 长租合同、`fixed_term` 时限合同 | 否 | 否 |
| `driver_id` | relation | 是 | 无 | 合同司机 | 否 | 是，关联 `drivers.id` |
| `vehicle_id` | relation | 是 | 无 | 合同车辆，必须为具体车牌 | 否 | 是，关联 `vehicles.id` |
| `start_date` | date | 是 | 无 | 合同开始日期 | 否 | 否 |
| `term_months` | integer | 条件必填 | 无 | 时限合同租期月数，必须大于等于 6 | 否 | 否 |
| `calculated_end_date` | date | 条件必填 | 无 | 时限合同按自然月计算出的结束日期 | 否 | 否 |
| `termination_date` | date | 否 | 无 | 实际终止日期 | 否 | 否 |
| `weekly_payable_days` | enum | 是 | 无 | `3`、`4`、`5`、`6`、`7` | 否 | 否 |
| `default_free_weekdays` | json | 是 | `[]` | 默认免租星期数组，例如 `["saturday","sunday"]` | 否 | 否 |
| `daily_rent_amount` | decimal | 是 | 无 | 每日租金，签约时固定 | 否 | 否 |
| `deposit_required_amount` | decimal | 是 | `0` | 应收押金 | 是 | 否 |
| `deposit_received_amount` | decimal | 是 | `0` | 已收押金摘要 | 是 | 否 |
| `week_start_day` | enum | 是 | `monday` | `monday`、`tuesday`、`wednesday`、`thursday`、`friday`、`saturday`、`sunday` | 否 | 否 |
| `ledger_generate_until` | date | 条件必填 | 无 | 长租合同台账已生成至日期 | 否 | 否 |
| `total_due_amount` | decimal | 是 | `0` | 已生成台账应收总额 | 否 | 否 |
| `total_paid_amount` | decimal | 是 | `0` | 总已付金额 | 是 | 否 |
| `total_waived_amount` | decimal | 是 | `0` | 总免除金额 | 否 | 否 |
| `current_debt_amount` | decimal | 是 | `0` | 截至当前日期的当前欠款金额，不含未来应收 | 是 | 否 |
| `current_debt_days` | integer | 是 | `0` | 截至当前日期的欠款天数，不含未来日期 | 是 | 否 |
| `future_receivable_amount` | decimal | 是 | `0` | 未来应收金额 | 是 | 否 |
| `signature_status` | enum | 是 | `not_generated` | `not_generated` 未生成、`generated` 已生成、`printed` 已打印、`signed` 已签署、`scanned` 已上传扫描件 | 否 | 否 |
| `status` | enum | 是 | `draft` | `draft` 草稿、`pending_signature` 待签署、`pending_deposit` 待押金、`pending_handover` 待交车、`active` 生效、`overdue` 逾期、`defaulted` 违约、`terminating` 终止中、`completed` 已完成、`cancelled` 已取消 | 否 | 否 |
| `remark` | text | 否 | 无 | 内部备注 | 否 | 否 |

### 唯一约束

- `contract_no` 全局唯一。
- 有效合同范围内，同一 `vehicle_id` 的有效日期不得重叠；NocoBase 可通过工作流校验或数据库排他约束实现。

### 索引建议

- `contract_no` 唯一索引。
- `driver_id` 普通索引。
- `vehicle_id` 普通索引。
- `contract_type` 普通索引。
- `status` 普通索引。
- `start_date`、`calculated_end_date`、`termination_date` 普通索引。
- `ledger_generate_until` 普通索引，用于长租台账续生成扫描。

### 校验规则

- `contract_type = fixed_term` 时，`term_months` 必须大于等于 6，并按自然月递增；`calculated_end_date` 必须由 `start_date + term_months` 计算。
- `contract_type = open_ended` 时，不要求 `calculated_end_date`，实际结束时填写 `termination_date`。
- 时限合同创建时必须一次性生成整个合同期的 `contract_billing_weeks` 与 `rent_daily_ledgers`。
- 长租合同必须按配置持续向未来生成 `contract_billing_weeks` 与 `rent_daily_ledgers`，并更新 `ledger_generate_until`。
- `weekly_payable_days` 只能是 3、4、5、6、7；`default_free_weekdays` 数量必须等于 `7 - weekly_payable_days`。
- 合同签订时固定 `weekly_payable_days`、`default_free_weekdays`、`daily_rent_amount`、`week_start_day`，后续不每周重算价格。
- 司机 `risk_status = blacklisted` 或驾照过期时，不能创建或激活合同。
- 同一车辆不能存在冲突的有效合同。
- 不允许把合同作为短租订单、预订或车型出租订单。
- 财务汇总从 `rent_daily_ledgers`、`rent_payment_allocations`、`deposit_records` 汇总刷新；未来应收不得计入当前欠款。

### 权限注意事项

- 运营可创建合同和维护基础状态，但不默认查看 `total_paid_amount`、`current_debt_amount`、`current_debt_days`、`future_receivable_amount`、押金金额。
- 财务可查看应收、付款、欠款与押金字段。
- 经理可查看汇总并处理审批。
- GPS 维护人员不得查看合同敏感财务汇总。

### 与其他 Collection 的关系

- 一份合同属于一个 `drivers` 与一个 `vehicles`。
- 一份合同有多条 `contract_billing_weeks` 和 `rent_daily_ledgers`。
- 一份合同可有多条 `rent_payments`、`rent_payment_allocations`、`rent_adjustments`、`deposit_records`、`contract_documents`。
- `gps_daily_mileages.contract_id` 仅用于运营核查关联，不参与计费。

---

## 4. `contract_billing_weeks` 自然周账期表

### Collection 基本信息

- Collection 名称：`contract_billing_weeks`
- 中文名称：自然周账期表
- 业务用途：记录每份合同每个自然周的计费规则快照与周度应收、已付、免除、欠款汇总。
- 是否允许硬删除：否。合同取消或账期作废通过 `status` 处理。
- 是否需要操作日志：是，需记录生成、汇总刷新、状态变更。

### 字段清单

| 字段 | 类型 | 必填 | 默认值 | 枚举值或说明 | 敏感字段 | 关系字段 |
| --- | --- | --- | --- | --- | --- | --- |
| `contract_id` | relation | 是 | 无 | 关联合同 | 否 | 是，关联 `lease_contracts.id` |
| `driver_id` | relation | 是 | 无 | 司机快照关联 | 否 | 是，关联 `drivers.id` |
| `vehicle_id` | relation | 是 | 无 | 车辆快照关联 | 否 | 是，关联 `vehicles.id` |
| `natural_week_start_date` | date | 是 | 无 | 自然周开始日期 | 否 | 否 |
| `natural_week_end_date` | date | 是 | 无 | 自然周结束日期 | 否 | 否 |
| `week_start_day` | enum | 是 | `monday` | 合同生成台账时的自然周起始日快照 | 否 | 否 |
| `weekly_payable_days` | enum | 是 | 无 | `3`、`4`、`5`、`6`、`7` | 否 | 否 |
| `free_days_count` | integer | 是 | `0` | 免租天数 | 否 | 否 |
| `payable_days_count` | integer | 是 | `0` | 应收天数 | 否 | 否 |
| `default_free_weekdays_snapshot` | json | 是 | `[]` | 默认免租星期快照 | 否 | 否 |
| `week_due_amount` | decimal | 是 | `0` | 周应收金额 | 否 | 否 |
| `week_paid_amount` | decimal | 是 | `0` | 周已付金额 | 是 | 否 |
| `week_waived_amount` | decimal | 是 | `0` | 周免除金额 | 否 | 否 |
| `week_debt_amount` | decimal | 是 | `0` | 周欠款金额 | 是 | 否 |
| `status` | enum | 是 | `generated` | `generated` 已生成、`active` 生效、`closed` 已关闭、`cancelled` 已取消 | 否 | 否 |

### 唯一约束

- `contract_id + natural_week_start_date` 唯一。

### 索引建议

- `contract_id + natural_week_start_date` 唯一索引。
- `driver_id` 普通索引。
- `vehicle_id` 普通索引。
- `status` 普通索引。
- `natural_week_start_date + natural_week_end_date` 普通索引。

### 校验规则

- 所有合同按自然星期计费，默认周一到周日，但以合同 `week_start_day` 快照为准。
- 一个合同同一个自然周只能有一条账期记录。
- `free_days_count + payable_days_count` 应等于该合同在该自然周内的有效台账天数。
- `default_free_weekdays_snapshot` 必须保存生成台账时使用的默认免租日，后续合同配置或系统配置变化不得改写历史快照。
- 周汇总必须从该周 `rent_daily_ledgers` 汇总，不直接读取 GPS 数据。

### 权限注意事项

- `week_paid_amount`、`week_debt_amount` 为敏感财务汇总，运营和 GPS 维护人员不默认可见。
- 经理和财务可查看周度财务汇总。
- 只读审计按授权查看，不能修改账期。

### 与其他 Collection 的关系

- 多条自然周账期属于一份 `lease_contracts`。
- 一条自然周账期包含多条 `rent_daily_ledgers`。
- 周度汇总由每日台账聚合得出。

---

## 5. `rent_daily_ledgers` 每日租金台账

### Collection 基本信息

- Collection 名称：`rent_daily_ledgers`
- 中文名称：每日租金台账
- 业务用途：记录每份合同每个租金日期的应收、已付、免除、欠款、未付原因、差额处理和日历状态；这是核心表和唯一事实来源。
- 是否允许硬删除：否。不建议硬删除，应通过 `payment_status = cancelled`、`calendar_status = cancelled` 或 `rent_adjustments` 处理。
- 是否需要操作日志：是，需记录生成、付款更新、未付原因修改、免租日调整、应收日调整、免除、争议、取消。

### 字段清单

| 字段 | 类型 | 必填 | 默认值 | 枚举值或说明 | 敏感字段 | 关系字段 |
| --- | --- | --- | --- | --- | --- | --- |
| `ledger_no` | text | 是 | 自动编号 | 台账编号，全局唯一 | 否 | 否 |
| `contract_id` | relation | 是 | 无 | 关联合同 | 否 | 是，关联 `lease_contracts.id` |
| `billing_week_id` | relation | 是 | 无 | 关联自然周账期 | 否 | 是，关联 `contract_billing_weeks.id` |
| `driver_id` | relation | 是 | 无 | 关联司机 | 否 | 是，关联 `drivers.id` |
| `vehicle_id` | relation | 是 | 无 | 关联车辆 | 否 | 是，关联 `vehicles.id` |
| `rent_date` | date | 是 | 无 | 租金日期 | 否 | 否 |
| `natural_week_start_date` | date | 是 | 无 | 自然周开始日期 | 否 | 否 |
| `natural_week_end_date` | date | 是 | 无 | 自然周结束日期 | 否 | 否 |
| `weekday` | enum | 是 | 无 | `monday`、`tuesday`、`wednesday`、`thursday`、`friday`、`saturday`、`sunday` | 否 | 否 |
| `is_payable` | boolean | 是 | 无 | 是否应收 | 否 | 否 |
| `non_payable_reason` | enum | 条件必填 | 无 | `default_free_day` 默认免租日、`manual_free_day` 手动免租、`contract_not_active` 合同未生效或已终止、`cancelled` 已取消、`other` 其他 | 否 | 否 |
| `due_amount` | decimal | 是 | `0` | 应收金额 | 否 | 否 |
| `paid_amount` | decimal | 是 | `0` | 已付金额 | 是 | 否 |
| `waived_amount` | decimal | 是 | `0` | 免除金额 | 否 | 否 |
| `balance_amount` | decimal | 是 | `0` | 欠款或待处理余额；未来日期不计入当前欠款 | 是 | 否 |
| `payment_status` | enum | 是 | `unpaid` | `non_payable` 不应收、`unpaid` 未付、`partial` 部分付款、`paid` 已付、`waived` 已免除、`cancelled` 已取消 | 否 | 否 |
| `unpaid_reason` | enum | 条件必填 | 无 | `waiting_payment` 等待付款、`driver_promised` 司机承诺补付、`disputed` 争议中、`internal_review` 公司内部复核、`waiver_pending` 待免除审批、`other` 其他 | 否 | 否 |
| `shortfall_disposition` | enum | 是 | `none` | `none` 无差额、`debt` 欠款、`waived` 免除、`pending_waiver_approval` 待审批免除、`dispute` 争议 | 否 | 否 |
| `calendar_status` | enum | 是 | `future_receivable` | `non_payable` 不应收、`future_receivable` 未来应收、`paid` 已付、`unpaid_debt` 未付欠款、`partial_debt` 部分付款欠款、`waived` 已免除、`partial_waived` 部分免除、`dispute` 争议、`cancelled` 已取消 | 否 | 否 |
| `latest_payment_at` | datetime | 否 | 无 | 最近付款时间 | 否 | 否 |
| `manual_adjusted` | boolean | 是 | `false` | 是否人工调整 | 否 | 否 |
| `adjusted_reason` | text | 否 | 无 | 最近调整原因摘要 | 否 | 否 |
| `status` | enum | 是 | `active` | `active` 生效、`locked` 已锁定、`cancelled` 已取消 | 否 | 否 |
| `remark` | text | 否 | 无 | 内部备注 | 否 | 否 |

### 唯一约束

- `ledger_no` 全局唯一。
- `contract_id + rent_date` 唯一。

### 索引建议

- `contract_id + rent_date` 唯一索引。
- `billing_week_id` 普通索引。
- `driver_id + rent_date` 普通索引。
- `vehicle_id + rent_date` 普通索引。
- `payment_status` 普通索引。
- `calendar_status` 普通索引。
- `rent_date` 普通索引。
- `status` 普通索引。

### 校验规则

- 每份合同每个租金日期只能有一条台账。
- `is_payable = false` 时，`due_amount` 应为 0，且必须填写 `non_payable_reason`。
- `is_payable = true` 时，`due_amount` 应等于合同固定 `daily_rent_amount`，除非存在已审批调整。
- 付款必须分配到每日租金台账，不能只保存在付款总表。
- 单个日期不可超付：`paid_amount` 不得大于 `due_amount - waived_amount` 的可收余额；如超付，整次付款或分配操作失败。
- 截至当前日期的未付应收台账必须填写 `unpaid_reason`。
- 部分付款必须填写 `shortfall_disposition`，且不能为 `none`。
- `calendar_status = future_receivable` 的未来日期不计入当前欠款金额和当前欠款天数。
- GPS 位置、里程、设备状态不参与 `due_amount`、`balance_amount`、`payment_status` 计算。

### 权限注意事项

- `paid_amount`、`balance_amount` 属敏感财务字段，运营不默认可见。
- 日历可显示欠款天数与欠款状态，但总已付、未来应收和付款截图入口需权限控制。
- 财务可维护未付原因和付款状态；经理可审批免除；只读审计不可修改。

### 与其他 Collection 的关系

- 一条台账属于一份 `lease_contracts` 和一个 `contract_billing_weeks`。
- 一条台账可被多条 `rent_payment_allocations` 分配付款。
- 一条台账可有多条 `rent_adjustments`。
- 合同、周账期、日历和财务汇总均从每日台账读取或聚合。

---

## 6. `rent_payments` 付款记录表

### Collection 基本信息

- Collection 名称：`rent_payments`
- 中文名称：付款记录表
- 业务用途：记录内部员工手工录入的租金付款主记录、付款方式、付款截图和确认状态。
- 是否允许硬删除：否。已确认付款不能直接删除，只能冲正；草稿可取消。
- 是否需要操作日志：是，需记录付款创建、确认、截图上传、取消、冲正。

### 字段清单

| 字段 | 类型 | 必填 | 默认值 | 枚举值或说明 | 敏感字段 | 关系字段 |
| --- | --- | --- | --- | --- | --- | --- |
| `payment_no` | text | 是 | 自动编号 | 付款编号，全局唯一 | 否 | 否 |
| `driver_id` | relation | 是 | 无 | 付款司机 | 否 | 是，关联 `drivers.id` |
| `contract_id` | relation | 是 | 无 | 关联合同 | 否 | 是，关联 `lease_contracts.id` |
| `vehicle_id` | relation | 是 | 无 | 关联车辆 | 否 | 是，关联 `vehicles.id` |
| `payment_date` | date | 是 | 当前日期 | 付款业务日期 | 否 | 否 |
| `paid_at` | datetime | 是 | 当前时间 | 实际付款时间 | 否 | 否 |
| `amount` | decimal | 是 | 无 | 付款总金额 | 是 | 否 |
| `method` | enum | 否 | 无 | `cash` 现金、`bank_transfer` 银行转账、`card` 银行卡、`mobile_transfer` 移动转账、`other` 其他；具体可后续确认 | 是 | 否 |
| `screenshot_file` | file | 否 | 无 | 付款截图 | 是 | 否 |
| `received_by` | relation | 是 | 当前用户 | 收款或录入人员 | 否 | 是，关联 NocoBase 内部用户 |
| `status` | enum | 是 | `draft` | `draft` 草稿、`confirmed` 已确认、`reversed` 已冲正、`cancelled` 已取消 | 否 | 否 |
| `remark` | text | 否 | 无 | 内部备注 | 否 | 否 |

### 唯一约束

- `payment_no` 全局唯一。

### 索引建议

- `payment_no` 唯一索引。
- `contract_id + paid_at` 普通索引。
- `driver_id + payment_date` 普通索引。
- `vehicle_id + payment_date` 普通索引。
- `status` 普通索引。
- `received_by` 普通索引。

### 校验规则

- 系统暂不接在线支付，所有付款由内部员工手工录入。
- 付款不能只作为总金额保存，确认时必须通过 `rent_payment_allocations` 分配到具体每日租金台账。
- 确认付款时，所有分配金额合计必须等于 `amount`。
- 任意分配导致单日超付时，整笔付款确认失败，不写入部分结果。
- 已确认付款不能直接删除，只能通过冲正变更为 `reversed` 并冲正相关分配。
- `method`、`screenshot_file`、`amount` 为敏感字段。

### 权限注意事项

- 财务可创建、确认、冲正付款和上传付款截图。
- 运营不默认查看付款方式、付款截图、付款总额。
- GPS 维护人员不得查看付款方式和付款截图。
- 只读审计按授权查看，不可新增、确认或冲正付款。

### 与其他 Collection 的关系

- 一笔付款属于一名司机、一份合同、一台车辆。
- 一笔付款有多条 `rent_payment_allocations`。
- 付款确认后更新对应 `rent_daily_ledgers` 的已付金额、余额、状态和最近付款时间。

---

## 7. `rent_payment_allocations` 付款分配表

### Collection 基本信息

- Collection 名称：`rent_payment_allocations`
- 中文名称：付款分配表
- 业务用途：将一笔付款拆分分配到具体每日租金台账日期，是付款影响台账的唯一路径。
- 是否允许硬删除：否。取消或冲正通过 `status`、`reversed_at`、`reversed_reason` 记录。
- 是否需要操作日志：是，需记录分配创建、取消、冲正。

### 字段清单

| 字段 | 类型 | 必填 | 默认值 | 枚举值或说明 | 敏感字段 | 关系字段 |
| --- | --- | --- | --- | --- | --- | --- |
| `payment_id` | relation | 是 | 无 | 关联付款 | 否 | 是，关联 `rent_payments.id` |
| `ledger_id` | relation | 是 | 无 | 关联每日租金台账 | 否 | 是，关联 `rent_daily_ledgers.id` |
| `contract_id` | relation | 是 | 无 | 冗余关联合同，便于校验和查询 | 否 | 是，关联 `lease_contracts.id` |
| `driver_id` | relation | 是 | 无 | 冗余关联司机 | 否 | 是，关联 `drivers.id` |
| `rent_date` | date | 是 | 无 | 租金日期快照 | 否 | 否 |
| `allocated_amount` | decimal | 是 | 无 | 分配金额 | 是 | 否 |
| `status` | enum | 是 | `active` | `active` 生效、`reversed` 已冲正、`cancelled` 已取消 | 否 | 否 |
| `reversed_at` | datetime | 否 | 无 | 冲正时间 | 否 | 否 |
| `reversed_reason` | text | 否 | 无 | 冲正原因 | 否 | 否 |

### 唯一约束

- 不设置单字段唯一；允许一笔付款分配到多个日期，也允许一个日期由多笔付款分配。
- 可选防重复约束：同一 `payment_id + ledger_id + status = active` 不重复，防止误重复录入。

### 索引建议

- `payment_id` 普通索引。
- `ledger_id` 普通索引。
- `contract_id + rent_date` 普通索引。
- `driver_id + rent_date` 普通索引。
- `status` 普通索引。

### 校验规则

- `allocated_amount` 必须大于 0。
- 不能分配到 `is_payable = false` 的免租日或不应收台账。
- 不能分配到 `status = cancelled` 或 `payment_status = cancelled` 的台账。
- 分配的 `contract_id`、`driver_id`、`rent_date` 必须与 `ledger_id` 指向的台账一致。
- 同一付款所有分配金额合计必须等于付款 `amount`。
- 任一日期因分配导致累计 `paid_amount` 超过可收余额时，整个付款操作失败。

### 权限注意事项

- `allocated_amount` 为敏感财务字段，运营不默认可见。
- 财务可创建和冲正分配。
- 只读审计仅可按授权查看。

### 与其他 Collection 的关系

- 多条分配属于一条 `rent_payments`。
- 多条分配可指向同一 `rent_daily_ledgers`，但累计不能超付。
- 分配确认后反向更新每日台账和合同财务摘要。

---

## 8. `rent_adjustments` 租金调整表

### Collection 基本信息

- Collection 名称：`rent_adjustments`
- 中文名称：租金调整表
- 业务用途：记录应收日改免租、免租日改应收、租金免除、争议处理、错误修正等台账调整。
- 是否允许硬删除：否。不建议硬删除，应通过状态作废或驳回。
- 是否需要操作日志：是，需记录申请、审批、驳回、应用、作废。

### 字段清单

| 字段 | 类型 | 必填 | 默认值 | 枚举值或说明 | 敏感字段 | 关系字段 |
| --- | --- | --- | --- | --- | --- | --- |
| `adjustment_no` | text | 是 | 自动编号 | 调整编号，全局唯一 | 否 | 否 |
| `contract_id` | relation | 是 | 无 | 关联合同 | 否 | 是，关联 `lease_contracts.id` |
| `ledger_id` | relation | 是 | 无 | 关联每日租金台账 | 否 | 是，关联 `rent_daily_ledgers.id` |
| `driver_id` | relation | 是 | 无 | 关联司机 | 否 | 是，关联 `drivers.id` |
| `vehicle_id` | relation | 是 | 无 | 关联车辆 | 否 | 是，关联 `vehicles.id` |
| `adjustment_type` | enum | 是 | 无 | `change_to_free_day` 改为免租日、`change_to_payable_day` 改为应收日、`waive` 免除、`correction` 错误修正、`dispute` 争议 | 否 | 否 |
| `amount` | decimal | 否 | `0` | 调整金额，免除或修正时使用 | 是 | 否 |
| `reason` | text | 是 | 无 | 调整原因 | 否 | 否 |
| `requested_by` | relation | 是 | 当前用户 | 申请人 | 否 | 是，关联 NocoBase 内部用户 |
| `approved_by` | relation | 否 | 无 | 审批人 | 否 | 是，关联 NocoBase 内部用户 |
| `approved_at` | datetime | 否 | 无 | 审批时间 | 否 | 否 |
| `status` | enum | 是 | `draft` | `draft` 草稿、`pending_approval` 待审批、`approved` 已批准、`rejected` 已拒绝、`applied` 已应用、`cancelled` 已取消 | 否 | 否 |
| `remark` | text | 否 | 无 | 内部备注 | 否 | 否 |

### 唯一约束

- `adjustment_no` 全局唯一。

### 索引建议

- `adjustment_no` 唯一索引。
- `contract_id` 普通索引。
- `ledger_id` 普通索引。
- `driver_id` 普通索引。
- `vehicle_id` 普通索引。
- `adjustment_type` 普通索引。
- `status` 普通索引。

### 校验规则

- 所有调整必须记录 `reason`。
- `adjustment_type = waive` 时必须走审批，审批通过前不得最终改写为已免除。
- 改为应收日时，应重新计算该日 `due_amount`，但必须基于合同签订时固定每日租金，不按 GPS 或新价格重算。
- 改为免租日时，需校验该日未发生不可冲正的付款；如已付款，应先处理冲正或差额。
- 争议处理应更新台账 `shortfall_disposition = dispute` 或 `calendar_status = dispute`。
- 错误修正不得绕过单日不可超付规则。

### 权限注意事项

- 运营可发起部分调整申请，但免除审批需经理或授权角色。
- 财务可发起金额修正与欠款处理申请。
- 经理可审批免除租金。
- `amount` 为敏感财务字段，按财务权限控制。

### 与其他 Collection 的关系

- 一条调整属于一份合同、一条台账、一名司机和一台车辆。
- 调整应用后更新 `rent_daily_ledgers`，并刷新 `contract_billing_weeks` 与 `lease_contracts` 汇总。
- 调整过程应写入 `operation_logs`。

---

## 9. `deposit_records` 押金记录表

### Collection 基本信息

- Collection 名称：`deposit_records`
- 中文名称：押金记录表
- 业务用途：独立记录合同押金收取、持有、抵扣、退还、免除状态；押金与租金分开管理。
- 是否允许硬删除：否。押金操作应通过状态和日志追溯。
- 是否需要操作日志：是，需记录收取、抵扣、退还、免除、截图上传和状态变更。

### 字段清单

| 字段 | 类型 | 必填 | 默认值 | 枚举值或说明 | 敏感字段 | 关系字段 |
| --- | --- | --- | --- | --- | --- | --- |
| `deposit_no` | text | 是 | 自动编号 | 押金编号，全局唯一 | 否 | 否 |
| `contract_id` | relation | 是 | 无 | 关联合同 | 否 | 是，关联 `lease_contracts.id` |
| `driver_id` | relation | 是 | 无 | 关联司机 | 否 | 是，关联 `drivers.id` |
| `vehicle_id` | relation | 是 | 无 | 关联车辆 | 否 | 是，关联 `vehicles.id` |
| `required_amount` | decimal | 是 | `0` | 应收押金 | 是 | 否 |
| `received_amount` | decimal | 是 | `0` | 已收押金 | 是 | 否 |
| `method` | enum | 否 | 无 | `cash` 现金、`bank_transfer` 银行转账、`card` 银行卡、`mobile_transfer` 移动转账、`other` 其他 | 是 | 否 |
| `received_at` | datetime | 否 | 无 | 收取时间 | 否 | 否 |
| `screenshot_file` | file | 否 | 无 | 押金收款截图 | 是 | 否 |
| `deducted_amount` | decimal | 是 | `0` | 已抵扣金额 | 是 | 否 |
| `refunded_amount` | decimal | 是 | `0` | 已退还金额 | 是 | 否 |
| `status` | enum | 是 | `pending` | `pending` 待收、`collected` 已收、`held` 持有中、`deducted` 已抵扣、`partially_refunded` 部分退还、`refunded` 已退还、`waived` 已免除 | 否 | 否 |
| `remark` | text | 否 | 无 | 内部备注 | 否 | 否 |

### 唯一约束

- `deposit_no` 全局唯一。
- 建议一份合同仅一条主押金记录；如后续需多笔押金流水，应新增押金流水表而不是混入租金付款。

### 索引建议

- `deposit_no` 唯一索引。
- `contract_id` 普通索引。
- `driver_id` 普通索引。
- `vehicle_id` 普通索引。
- `status` 普通索引。

### 校验规则

- 押金和租金分开管理，押金不能计入每日租金收入、`rent_daily_ledgers.paid_amount` 或 `lease_contracts.total_paid_amount`。
- `received_amount`、`deducted_amount`、`refunded_amount` 不得为负数。
- `deducted_amount + refunded_amount` 不得超过 `received_amount`，除非另有审批规则确认。
- 押金截图不得使用真实样例提交到仓库。

### 权限注意事项

- 押金金额、付款方式、截图均为敏感字段。
- 财务可管理押金；经理可查看汇总和审批特殊处理；运营不默认查看押金金额和截图。
- GPS 维护人员不得查看押金记录敏感字段。

### 与其他 Collection 的关系

- 押金记录属于一份合同、一名司机、一台车辆。
- 押金不直接关联 `rent_daily_ledgers`，除非经过后续明确的押金抵扣审批流程。
- 押金操作应写入 `operation_logs`。

---

## 10. `contract_templates` 合同模板表

### Collection 基本信息

- Collection 名称：`contract_templates`
- 中文名称：合同模板表
- 业务用途：管理中文、英文、法文合同模板及版本，供合同文件生成使用。
- 是否允许硬删除：仅草稿且未被合同文件引用时可删除；启用或已引用模板不得硬删除，应归档。
- 是否需要操作日志：是，需记录模板创建、启用、默认模板切换、归档和文件变更。

### 字段清单

| 字段 | 类型 | 必填 | 默认值 | 枚举值或说明 | 敏感字段 | 关系字段 |
| --- | --- | --- | --- | --- | --- | --- |
| `template_no` | text | 是 | 自动编号 | 模板编号，全局唯一 | 否 | 否 |
| `name` | text | 是 | 无 | 模板名称 | 否 | 否 |
| `language` | enum | 是 | 无 | `zh-CN` 中文、`en-US` 英文、`fr-FR` 法文 | 否 | 否 |
| `version` | text | 是 | 无 | 模板版本 | 否 | 否 |
| `template_file` | file | 是 | 无 | 模板文件 | 否 | 否 |
| `is_default` | boolean | 是 | `false` | 是否为该语言默认模板 | 否 | 否 |
| `status` | enum | 是 | `draft` | `draft` 草稿、`active` 启用、`archived` 归档 | 否 | 否 |

### 唯一约束

- `template_no` 全局唯一。
- 建议 `language + version` 唯一。
- 每种语言同时只能有一个 `is_default = true` 且 `status = active` 的模板。

### 索引建议

- `template_no` 唯一索引。
- `language + version` 唯一索引。
- `language + is_default + status` 普通索引。

### 校验规则

- 必须支持中文、英文、法文合同模板。
- 模板版本变更不能影响历史合同文件；历史合同文件继续引用原 `template_id`。
- 启用模板前应完成内部审核。
- 模板不能包含真实司机证件、真实付款截图、真实合同扫描件或真实密钥。

### 权限注意事项

- 模板维护权限限管理员或授权经理。
- 普通运营可按授权选择模板生成合同，但不默认维护模板。
- 模板文件本身不是签署扫描件，但仍需避免泄露内部条款。

### 与其他 Collection 的关系

- 一个模板可被多条 `contract_documents` 引用。
- 模板不直接改变 `lease_contracts` 或 `rent_daily_ledgers`。

---

## 11. `contract_documents` 合同文件表

### Collection 基本信息

- Collection 名称：`contract_documents`
- 中文名称：合同文件表
- 业务用途：管理从模板生成的合同文件、打印、线下签署、签署扫描件上传与文件状态。
- 是否允许硬删除：否。作废使用 `status = voided`。
- 是否需要操作日志：是，需记录生成、打印、签署、扫描件上传、作废。

### 字段清单

| 字段 | 类型 | 必填 | 默认值 | 枚举值或说明 | 敏感字段 | 关系字段 |
| --- | --- | --- | --- | --- | --- | --- |
| `document_no` | text | 是 | 自动编号 | 合同文件编号，全局唯一 | 否 | 否 |
| `contract_id` | relation | 是 | 无 | 关联合同 | 否 | 是，关联 `lease_contracts.id` |
| `template_id` | relation | 是 | 无 | 关联模板 | 否 | 是，关联 `contract_templates.id` |
| `language` | enum | 是 | 无 | `zh-CN` 中文、`en-US` 英文、`fr-FR` 法文 | 否 | 否 |
| `generated_docx_file` | file | 否 | 无 | 生成的文档文件 | 否 | 否 |
| `generated_pdf_file` | file | 否 | 无 | 生成的 PDF 文件 | 否 | 否 |
| `printed_at` | datetime | 否 | 无 | 打印时间 | 否 | 否 |
| `signed_at` | datetime | 否 | 无 | 线下签署时间 | 否 | 否 |
| `signed_scan_file` | file | 否 | 无 | 签署扫描件 | 是 | 否 |
| `status` | enum | 是 | `generated` | `generated` 已生成、`printed` 已打印、`signed` 已签署、`scanned` 已上传扫描件、`voided` 已作废 | 否 | 否 |

### 唯一约束

- `document_no` 全局唯一。

### 索引建议

- `document_no` 唯一索引。
- `contract_id` 普通索引。
- `template_id` 普通索引。
- `language` 普通索引。
- `status` 普通索引。

### 校验规则

- 合同打印出来线下签署；系统不设计司机线上登录签署。
- 上传签署扫描件后，`signed_scan_file` 必须受敏感文件权限控制。
- 生成合同文件必须基于具体合同和具体车牌，不能按车型生成。
- 合同文件生成、打印和上传不得改变每日租金台账或计费规则。

### 权限注意事项

- 运营可按授权生成和打印合同。
- 签署扫描件预览、下载、导出需敏感文件权限。
- 只读审计只能按授权查看，不能上传或作废文件。

### 与其他 Collection 的关系

- 一份合同可关联多份合同文件。
- 一份合同文件引用一个合同模板版本。
- 合同文件状态可同步更新 `lease_contracts.signature_status`。

---

## 12. `gps_devices` GPS 设备表

### Collection 基本信息

- Collection 名称：`gps_devices`
- 中文名称：GPS 设备表
- 业务用途：维护 GPS 设备主数据、绑定状态、最新位置和设备状态摘要。
- 是否允许硬删除：否。设备报废或停用通过 `status` 处理。
- 是否需要操作日志：是，需记录设备创建、绑定状态变更、状态变更、最新定位摘要更新、停用。

### 字段清单

| 字段 | 类型 | 必填 | 默认值 | 枚举值或说明 | 敏感字段 | 关系字段 |
| --- | --- | --- | --- | --- | --- | --- |
| `imei` | text | 是 | 无 | 设备 IMEI，全局唯一 | 否 | 否 |
| `device_name` | text | 否 | 无 | 设备名称 | 否 | 否 |
| `sim_no` | text | 否 | 无 | SIM 卡号 | 否 | 否 |
| `vehicle_id` | relation | 否 | 无 | 当前绑定车辆 | 否 | 是，关联 `vehicles.id` |
| `provider` | enum | 是 | `iopgps` | `iopgps` | 否 | 否 |
| `bind_status` | enum | 是 | `unbound` | `unbound` 未绑定、`bound` 已绑定、`replaced` 已更换、`retired` 已退役 | 否 | 否 |
| `device_status` | enum | 是 | `unknown` | `normal` 正常、`offline` 离线、`fault` 故障、`low_power` 低电、`power_cut` 断电、`unknown` 未知 | 否 | 否 |
| `last_seen_at` | datetime | 否 | 无 | 最近在线或上报时间 | 否 | 否 |
| `last_lat` | decimal | 否 | 无 | 最近纬度 | 否 | 否 |
| `last_lng` | decimal | 否 | 无 | 最近经度 | 否 | 否 |
| `last_address` | text | 否 | 无 | 最近地址 | 否 | 否 |
| `last_status_raw` | json | 否 | 无 | 原始状态摘要，不含密钥 | 否 | 否 |
| `status` | enum | 是 | `active` | `active` 在用、`inactive` 停用、`retired` 报废 | 否 | 否 |

### 唯一约束

- `imei` 全局唯一。
- 当前有效绑定约束：一个 GPS 设备同一时间只能绑定一台车。

### 索引建议

- `imei` 唯一索引。
- `vehicle_id` 普通索引。
- `bind_status` 普通索引。
- `device_status` 普通索引。
- `last_seen_at` 普通索引。

### 校验规则

- 一个 GPS 设备同一时间只能绑定一台车。
- `bind_status = bound` 时必须有 `vehicle_id`。
- GPS 只用于运营监控，不参与租金计算、欠款计算、免租日判断或付款状态。
- `last_status_raw` 不得保存接口密钥、登录密钥或访问令牌。

### 权限注意事项

- GPS 维护人员可维护设备和查看状态。
- GPS 维护人员不能查看付款截图、付款方式、司机证件和敏感财务汇总。
- 定位摘要导出需要授权。

### 与其他 Collection 的关系

- 一个设备可有关联当前 `vehicles`。
- 一个设备有多条 `gps_device_bindings`、`gps_location_snapshots`、`gps_daily_mileages`、`gps_device_status_logs`。
- 车辆表保存当前设备摘要，但绑定历史以 `gps_device_bindings` 为准。

---

## 13. `gps_device_bindings` GPS 绑定历史表

### Collection 基本信息

- Collection 名称：`gps_device_bindings`
- 中文名称：GPS 绑定历史表
- 业务用途：记录 GPS 设备与车辆的绑定、解绑和更换历史，避免设备更换覆盖历史。
- 是否允许硬删除：否。错误记录通过状态和备注处理。
- 是否需要操作日志：是，需记录绑定、解绑、作废。

### 字段清单

| 字段 | 类型 | 必填 | 默认值 | 枚举值或说明 | 敏感字段 | 关系字段 |
| --- | --- | --- | --- | --- | --- | --- |
| `device_id` | relation | 是 | 无 | GPS 设备 | 否 | 是，关联 `gps_devices.id` |
| `vehicle_id` | relation | 是 | 无 | 绑定车辆 | 否 | 是，关联 `vehicles.id` |
| `bind_start_at` | datetime | 是 | 当前时间 | 绑定开始时间 | 否 | 否 |
| `bind_end_at` | datetime | 否 | 无 | 绑定结束时间 | 否 | 否 |
| `status` | enum | 是 | `active` | `active` 当前绑定、`ended` 已结束、`cancelled` 已取消 | 否 | 否 |
| `remark` | text | 否 | 无 | 内部备注 | 否 | 否 |

### 唯一约束

- 同一 `device_id` 同一时间只能存在一条 `status = active` 的绑定。
- 同一 `vehicle_id` 同一时间建议只能存在一条主 `status = active` 的绑定；是否允许备用设备需后续业务确认。

### 索引建议

- `device_id + bind_start_at` 普通索引。
- `vehicle_id + bind_start_at` 普通索引。
- `status` 普通索引。
- `bind_end_at` 普通索引。

### 校验规则

- 设备更换不能覆盖历史，必须结束旧绑定并创建新绑定。
- 当前绑定 `status = active` 时，`bind_end_at` 必须为空。
- 结束绑定时必须写入 `bind_end_at`，并同步更新 `gps_devices.bind_status`、`gps_devices.vehicle_id`、`vehicles.gps_device_id`。
- GPS 绑定不影响租金台账和付款逻辑。

### 权限注意事项

- 仅 GPS 维护人员或管理员可维护绑定关系。
- 绑定历史可供运营查看车辆状态，但导出需授权。

### 与其他 Collection 的关系

- 绑定历史属于一个 `gps_devices` 和一个 `vehicles`。
- 当前绑定用于同步 `vehicles` 与 `gps_devices` 的摘要字段。

---

## 14. `gps_location_snapshots` GPS 定位快照表

### Collection 基本信息

- Collection 名称：`gps_location_snapshots`
- 中文名称：GPS 定位快照表
- 业务用途：保存车辆定位历史，用于运营查看车辆位置轨迹和最近状态。
- 是否允许硬删除：可按合规归档策略清理历史快照；不得影响财务数据。
- 是否需要操作日志：是，需记录同步异常和批量清理动作；单条普通同步可通过同步日志或系统日志追溯。

### 字段清单

| 字段 | 类型 | 必填 | 默认值 | 枚举值或说明 | 敏感字段 | 关系字段 |
| --- | --- | --- | --- | --- | --- | --- |
| `vehicle_id` | relation | 是 | 无 | 关联车辆 | 否 | 是，关联 `vehicles.id` |
| `device_id` | relation | 是 | 无 | 关联 GPS 设备 | 否 | 是，关联 `gps_devices.id` |
| `imei` | text | 是 | 无 | IMEI 快照 | 否 | 否 |
| `lat` | decimal | 否 | 无 | 纬度 | 否 | 否 |
| `lng` | decimal | 否 | 无 | 经度 | 否 | 否 |
| `address` | text | 否 | 无 | 地址 | 否 | 否 |
| `speed` | decimal | 否 | 无 | 速度 | 否 | 否 |
| `acc_status` | enum | 否 | 无 | `on` 开、`off` 关、`unknown` 未知 | 否 | 否 |
| `position_type` | enum | 否 | 无 | `gps` 卫星、`lbs` 基站、`wifi` 无线、`unknown` 未知 | 否 | 否 |
| `gps_time` | datetime | 是 | 无 | GPS 上报时间 | 否 | 否 |
| `raw_response` | json | 否 | 无 | 原始响应，不含密钥 | 否 | 否 |
| `createdAt` | datetime | 是 | 当前时间 | NocoBase 创建时间 | 否 | 否 |

### 唯一约束

- 不强制唯一；如 IOPGPS 提供唯一流水号，后续可增加 `provider_record_id` 唯一。

### 索引建议

- `vehicle_id + gps_time` 普通索引。
- `device_id + gps_time` 普通索引。
- `imei + gps_time` 普通索引。
- `createdAt` 普通索引。

### 校验规则

- 用于保存定位历史，GPS 同步失败不能影响租金台账和付款逻辑。
- `raw_response` 不得保存登录密钥、访问令牌或其他凭据。
- 定位缺失时可以记录同步异常，但不得更改租金应收、欠款或付款状态。

### 权限注意事项

- GPS 维护人员可查看定位快照。
- 定位历史属于运营敏感数据，导出和批量查看需授权。
- 财务、运营查看定位不代表可查看 GPS 凭据。

### 与其他 Collection 的关系

- 快照属于一个 `vehicles` 和一个 `gps_devices`。
- 可用于更新 `vehicles.last_gps_*` 和 `gps_devices.last_*` 摘要字段。
- 不关联 `rent_daily_ledgers` 计费结果。

---

## 15. `gps_daily_mileages` GPS 每日里程表

### Collection 基本信息

- Collection 名称：`gps_daily_mileages`
- 中文名称：GPS 每日里程表
- 业务用途：保存 GPS 每日里程，用于运营核查车辆使用情况，不参与租金计算。
- 是否允许硬删除：可按合规归档策略清理历史数据；不得影响合同和台账。
- 是否需要操作日志：是，需记录同步失败、人工重同步、批量清理。

### 字段清单

| 字段 | 类型 | 必填 | 默认值 | 枚举值或说明 | 敏感字段 | 关系字段 |
| --- | --- | --- | --- | --- | --- | --- |
| `vehicle_id` | relation | 是 | 无 | 关联车辆 | 否 | 是，关联 `vehicles.id` |
| `device_id` | relation | 是 | 无 | 关联 GPS 设备 | 否 | 是，关联 `gps_devices.id` |
| `imei` | text | 是 | 无 | IMEI 快照 | 否 | 否 |
| `mileage_date` | date | 是 | 无 | 里程日期 | 否 | 否 |
| `start_time` | datetime | 否 | 无 | 统计开始时间 | 否 | 否 |
| `end_time` | datetime | 否 | 无 | 统计结束时间 | 否 | 否 |
| `mileage_km` | decimal | 是 | `0` | 当日里程公里数 | 否 | 否 |
| `runtime_seconds` | integer | 否 | `0` | 当日运行秒数 | 否 | 否 |
| `contract_id` | relation | 否 | 无 | 里程日期对应的合同，仅运营核查 | 否 | 是，关联 `lease_contracts.id` |
| `driver_id` | relation | 否 | 无 | 里程日期对应司机，仅运营核查 | 否 | 是，关联 `drivers.id` |
| `raw_response` | json | 否 | 无 | 原始响应，不含密钥 | 否 | 否 |
| `sync_status` | enum | 是 | `success` | `success` 成功、`partial_success` 部分成功、`failed` 失败、`skipped` 跳过 | 否 | 否 |
| `error_message` | text | 否 | 无 | 错误摘要，不含密钥 | 否 | 否 |

### 唯一约束

- `device_id + mileage_date` 唯一。

### 索引建议

- `device_id + mileage_date` 唯一索引。
- `vehicle_id + mileage_date` 普通索引。
- `contract_id + mileage_date` 普通索引。
- `driver_id + mileage_date` 普通索引。
- `sync_status` 普通索引。

### 校验规则

- GPS 里程只用于运营核查，不参与租金计算。
- `mileage_km` 不得改变 `rent_daily_ledgers.due_amount`、`balance_amount` 或合同价格。
- API 同步失败仅记录 `sync_status` 与 `error_message`，不得阻止付款或台账生成。
- `raw_response` 和 `error_message` 不得包含密钥或访问令牌。

### 权限注意事项

- GPS 维护人员和授权运营可查看每日里程。
- 每日里程导出需要授权。
- 财务可按授权用于运营核查，但不能据此自动改变租金。

### 与其他 Collection 的关系

- 每日里程属于一个 `vehicles` 和一个 `gps_devices`。
- 可选关联当天有效 `lease_contracts` 和 `drivers`，仅用于核查，不参与财务计算。

---

## 16. `gps_device_status_logs` GPS 状态日志表

### Collection 基本信息

- Collection 名称：`gps_device_status_logs`
- 中文名称：GPS 状态日志表
- 业务用途：记录 GPS 设备状态变化、原始状态和标准化状态，用于维护和异常追踪。
- 是否允许硬删除：可按合规归档策略清理历史状态日志；不得影响租金和付款数据。
- 是否需要操作日志：是，需记录同步异常和批量清理动作。

### 字段清单

| 字段 | 类型 | 必填 | 默认值 | 枚举值或说明 | 敏感字段 | 关系字段 |
| --- | --- | --- | --- | --- | --- | --- |
| `device_id` | relation | 是 | 无 | 关联 GPS 设备 | 否 | 是，关联 `gps_devices.id` |
| `vehicle_id` | relation | 否 | 无 | 关联车辆 | 否 | 是，关联 `vehicles.id` |
| `imei` | text | 是 | 无 | IMEI 快照 | 否 | 否 |
| `provider_status` | text | 否 | 无 | IOPGPS 原始状态文本或编码 | 否 | 否 |
| `normalized_status` | enum | 是 | `unknown` | `normal` 正常、`moving` 行驶、`static` 静止、`offline` 离线、`fault` 故障、`low_power` 低电、`power_cut` 断电、`unknown` 未知 | 否 | 否 |
| `lat` | decimal | 否 | 无 | 纬度 | 否 | 否 |
| `lng` | decimal | 否 | 无 | 经度 | 否 | 否 |
| `gps_time` | datetime | 否 | 无 | GPS 状态时间 | 否 | 否 |
| `raw_response` | json | 否 | 无 | 原始响应，不含密钥 | 否 | 否 |
| `createdAt` | datetime | 是 | 当前时间 | NocoBase 创建时间 | 否 | 否 |

### 唯一约束

- 不强制唯一；状态变化可能在同一时间多次上报。

### 索引建议

- `device_id + createdAt` 普通索引。
- `vehicle_id + createdAt` 普通索引。
- `normalized_status` 普通索引。
- `gps_time` 普通索引。

### 校验规则

- 用于记录设备状态变化，不参与租金计算。
- `raw_response` 不得记录密钥或访问令牌。
- `normalized_status` 更新车辆 `gps_status` 时，只影响运营监控展示，不影响合同、台账、付款。

### 权限注意事项

- GPS 维护人员可查看和处理状态日志。
- 普通运营可按授权查看设备状态，但不默认导出原始响应。
- 财务和审计不因查看财务数据而获得 GPS 原始响应权限。

### 与其他 Collection 的关系

- 状态日志属于一个 `gps_devices`，可选关联当前 `vehicles`。
- 状态日志可更新 `gps_devices.device_status` 和 `vehicles.gps_status` 摘要。

---

## 17. `iopgps_settings` IOPGPS 配置表

### Collection 基本信息

- Collection 名称：`iopgps_settings`
- 中文名称：IOPGPS 配置表
- 业务用途：保存 IOPGPS 接口基础地址、应用标识、加密凭据、同步开关与同步频率配置。
- 是否允许硬删除：否。停用通过 `status` 与 `sync_enabled` 处理。
- 是否需要操作日志：是，需记录配置创建、凭据更新、同步开关变更、频率变更、停用。

### 字段清单

| 字段 | 类型 | 必填 | 默认值 | 枚举值或说明 | 敏感字段 | 关系字段 |
| --- | --- | --- | --- | --- | --- | --- |
| `base_url` | text | 是 | 无 | IOPGPS API 基础地址 | 否 | 否 |
| `appid` | text | 是 | 无 | IOPGPS 应用标识 | 否 | 否 |
| `login_key_encrypted` | encrypted text | 是 | 无 | 加密保存的登录密钥 | 是 | 否 |
| `access_token` | encrypted text | 否 | 无 | 加密保存的访问令牌 | 是 | 否 |
| `token_expires_at` | datetime | 否 | 无 | 令牌过期时间 | 否 | 否 |
| `sync_enabled` | boolean | 是 | `false` | 是否启用同步 | 否 | 否 |
| `location_sync_interval_minutes` | integer | 是 | `15` | 定位同步间隔分钟 | 否 | 否 |
| `mileage_sync_interval_hours` | integer | 是 | `24` | 里程同步间隔小时 | 否 | 否 |
| `offline_threshold_minutes` | integer | 是 | `60` | 判定离线阈值分钟 | 否 | 否 |
| `status` | enum | 是 | `inactive` | `active` 启用、`inactive` 停用、`error` 异常 | 否 | 否 |

### 唯一约束

- 建议仅允许一条 `status = active` 的 IOPGPS 配置。

### 索引建议

- `status` 普通索引。
- `sync_enabled` 普通索引。
- `token_expires_at` 普通索引。

### 校验规则

- 真实密钥不能写死在代码、文档示例或仓库文件中。
- `login_key_encrypted`、`access_token` 必须使用 `encrypted text` 或 NocoBase 等价加密字段，并标记为敏感字段。
- API 失败只能更新 GPS 相关同步状态、日志或错误摘要，不能影响租金台账和付款逻辑。
- 错误日志不得记录完整密钥、令牌或登录凭据。

### 权限注意事项

- 仅系统管理员或授权 GPS 管理人员可维护配置。
- 普通运营、财务、只读审计不得查看密钥与令牌明文。
- 导出配置时必须屏蔽敏感凭据。

### 与其他 Collection 的关系

- 配置用于 IOPGPS 同步任务。
- 同步结果写入 `gps_location_snapshots`、`gps_daily_mileages`、`gps_device_status_logs`，并更新 `gps_devices`、`vehicles` 摘要字段。
- 与租金台账、付款分配无计费关系。

---

## 18. `operation_logs` 操作日志表

### Collection 基本信息

- Collection 名称：`operation_logs`
- 中文名称：操作日志表
- 业务用途：记录关键业务操作、变更前后摘要、原因、操作人和访问来源，用于审计和追溯。
- 是否允许硬删除：否。不建议硬删除；如需归档，应保留审计链路。
- 是否需要操作日志：否，因其自身即操作日志。

### 字段清单

| 字段 | 类型 | 必填 | 默认值 | 枚举值或说明 | 敏感字段 | 关系字段 |
| --- | --- | --- | --- | --- | --- | --- |
| `log_no` | text | 是 | 自动编号 | 日志编号，全局唯一 | 否 | 否 |
| `operator_id` | relation | 是 | 当前用户 | 操作人 | 否 | 是，关联 NocoBase 内部用户 |
| `action` | enum | 是 | 无 | `contract_created` 合同创建、`contract_activated` 合同激活、`ledger_generated` 台账生成、`free_day_changed` 免租日调整、`payable_day_changed` 应收日调整、`payment_created` 付款创建、`payment_confirmed` 付款确认、`payment_reversed` 付款冲正、`unpaid_reason_changed` 未付原因修改、`waiver_requested` 免除申请、`waiver_approved` 免除审批、`deposit_changed` 押金操作、`gps_sync_error` GPS 同步异常、`other` 其他 | 否 | 否 |
| `target_collection` | text | 是 | 无 | 目标 Collection 名称 | 否 | 否 |
| `target_id` | text | 是 | 无 | 目标记录标识 | 否 | 否 |
| `before_value` | json | 否 | 无 | 变更前摘要，应脱敏 | 是 | 否 |
| `after_value` | json | 否 | 无 | 变更后摘要，应脱敏 | 是 | 否 |
| `reason` | text | 否 | 无 | 操作原因 | 否 | 否 |
| `ip_address` | text | 否 | 无 | 操作来源 IP | 是 | 否 |
| `createdAt` | datetime | 是 | 当前时间 | 日志创建时间 | 否 | 否 |

### 唯一约束

- `log_no` 全局唯一。

### 索引建议

- `log_no` 唯一索引。
- `operator_id + createdAt` 普通索引。
- `target_collection + target_id` 普通索引。
- `action + createdAt` 普通索引。
- `createdAt` 普通索引。

### 校验规则

- 必须记录合同创建、合同激活、台账生成、免租日调整、应收日调整、付款创建、付款确认、付款冲正、未付原因修改、免除申请、免除审批、押金操作、GPS 同步异常等关键操作。
- `before_value`、`after_value` 应做摘要化和脱敏处理，不保存真实密钥、完整证件照片、完整付款截图内容或访问令牌。
- 操作日志不得用于修正业务数据，只用于审计追溯。

### 权限注意事项

- 系统管理员和只读审计可按授权查看操作日志。
- 普通运营只能查看与其授权业务相关的日志。
- 日志中的敏感摘要仍需字段级权限控制。

### 与其他 Collection 的关系

- 可通过 `target_collection + target_id` 指向任意业务 Collection。
- `operator_id` 关联内部用户，不关联司机。
- 关键业务 Collection 的创建、修改、审批、冲正、异常均应写入本表。

---

## 跨 Collection 关键规则

### 关键唯一约束

- `drivers.driver_no` 全局唯一。
- `vehicles.vehicle_no`、`vehicles.plate_no` 全局唯一，`vehicles.vin` 有值时唯一。
- `lease_contracts.contract_no` 全局唯一；同一 `vehicle_id` 不能存在冲突有效合同。
- `contract_billing_weeks.contract_id + natural_week_start_date` 唯一。
- `rent_daily_ledgers.ledger_no` 全局唯一，`rent_daily_ledgers.contract_id + rent_date` 唯一。
- `rent_payments.payment_no` 全局唯一。
- `rent_adjustments.adjustment_no` 全局唯一。
- `deposit_records.deposit_no` 全局唯一。
- `contract_templates.template_no` 全局唯一，建议 `language + version` 唯一。
- `contract_documents.document_no` 全局唯一。
- `gps_devices.imei` 全局唯一。
- `gps_daily_mileages.device_id + mileage_date` 唯一。
- `operation_logs.log_no` 全局唯一。

### 敏感字段汇总

- 司机身份与证件：`drivers.id_no`、`drivers.id_front_file`、`drivers.id_back_file`、`drivers.license_front_file`、`drivers.license_back_file`。
- 合同财务汇总：`lease_contracts.deposit_required_amount`、`lease_contracts.deposit_received_amount`、`lease_contracts.total_paid_amount`、`lease_contracts.current_debt_amount`、`lease_contracts.current_debt_days`、`lease_contracts.future_receivable_amount`。
- 周账期财务：`contract_billing_weeks.week_paid_amount`、`contract_billing_weeks.week_debt_amount`。
- 每日台账财务：`rent_daily_ledgers.paid_amount`、`rent_daily_ledgers.balance_amount`。
- 付款：`rent_payments.amount`、`rent_payments.method`、`rent_payments.screenshot_file`、`rent_payment_allocations.allocated_amount`。
- 调整：`rent_adjustments.amount`。
- 押金：`deposit_records.required_amount`、`deposit_records.received_amount`、`deposit_records.method`、`deposit_records.screenshot_file`、`deposit_records.deducted_amount`、`deposit_records.refunded_amount`。
- 合同文件：`contract_documents.signed_scan_file`。
- IOPGPS 凭据：`iopgps_settings.login_key_encrypted`、`iopgps_settings.access_token`。
- 操作日志敏感摘要：`operation_logs.before_value`、`operation_logs.after_value`、`operation_logs.ip_address`。

### 权限边界

- 司机不登录系统，`drivers` 不关联 NocoBase 用户账号。
- 普通运营可维护司机、车辆、合同基础资料，但不默认查看全部敏感财务字段、付款截图、押金金额、司机证件照片。
- 财务可处理付款、分配、押金和财务汇总。
- 经理可查看财务汇总并审批免除租金。
- GPS 维护人员只处理 GPS 设备、定位、里程和设备状态，不查看付款截图、押金金额、司机证件和敏感财务汇总。
- 只读审计按授权查看，不能修改、审批、上传、冲正或删除。

### 第一轮文档与 SPEC.md 冲突检查

- 本轮未发现第一轮文档与 `SPEC.md` 存在业务规则冲突。
- 第一轮文档中使用的部分枚举名称与本轮指定名称不同，例如合同类型曾使用 `long_term` / `fixed_term`，本轮按 NocoBase Collection 设计统一为 `open_ended` / `fixed_term`；这是命名细化，不改变“长租合同 / 时限合同”的业务规则。
- 第一轮文档中付款状态和押金状态的中文含义与本轮保持一致，本轮按用户指定补充了更精细的枚举编码和字段级敏感标记。
