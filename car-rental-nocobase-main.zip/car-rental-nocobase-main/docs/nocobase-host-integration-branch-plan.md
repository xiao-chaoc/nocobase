# NocoBase 宿主工程接入分支计划

## 分支命名建议

宿主工程内可使用以下分支命名之一：

- `integration/car-rental-nocobase`
- `feature/car-rental-plugins`
- `test/car-rental-adapter`

当前仓库不检查远端分支，不拉取主分支，不创建 Git submodule。宿主工程分支仅在独立完整 NocoBase 工程中使用。

## 分支目标

- 接入汽车租赁插件源码或插件包。
- 实现真实 adapter 并替换当前草案中的未配置适配器。
- 在隔离数据库中执行测试。
- 不影响生产。
- 不连接真实 IOPGPS。
- 不提交 `.env`、真实司机文件、真实付款截图、真实合同扫描件或真实密钥。

## 每个阶段 commit 边界

| 阶段 | 建议 commit 内容 | 边界 |
| --- | --- | --- |
| commit 1 | 复制插件源码 | 只复制 `plugin-rental-core`、`plugin-contract-documents`、`plugin-iopgps`，不改业务规则。 |
| commit 2 | 接入 shared automation | 只接入 `packages/shared/nocobase-automation`，保持 dry-run 默认行为。 |
| commit 3 | 实现环境检测 adapter | 只验证宿主工程、版本、数据库隔离、IOPGPS 禁用状态。 |
| commit 4 | 实现 Collection adapter | 只处理 Collection、字段、关系、索引、迁移最小闭环。 |
| commit 5 | 实现 Runtime adapter | 只处理服务、资源、权限、定时任务、工作流注册最小闭环。 |
| commit 6 | 实现 Page adapter | 只处理菜单、页面、区块、UI Schema、i18n 最小闭环。 |
| commit 7 | 实现 Seed Data adapter | 只导入 mock 数据，不导入真实司机、合同、付款或 GPS 文件。 |
| commit 8 | 实现 Backup / Rollback adapter | 只在测试库与测试 storage 验证备份回滚。 |
| commit 9 | 实现 Smoke Test adapter | 只运行隔离冒烟，不连接真实 IOPGPS，不生成真实合同。 |
| commit 10 | 测试与文档 | 汇总测试证据、风险、回滚说明和上线前阻断项。 |

## PR 检查项

- 是否只使用测试库。
- 是否不提交 `.env`。
- 是否不提交真实文件。
- 是否 IOPGPS 禁用。
- 是否有备份回滚。
- 是否所有权限测试通过。
- 是否目标 NocoBase 版本已人工确认。
- 是否没有把 `latest-full` 当作真实接入基准。
- 是否没有把完整 NocoBase 源码提交进当前仓库。
- 是否没有把当前项目标记为 `production_ready`。

## 本轮补充：v2.0.61 接入分支任务包衔接

> 包管理器修正：完整 NocoBase v2.0.61 宿主工程环境检测已确认当前接入基准为 `package_manager = yarn`。后续宿主工程人工命令应使用 `yarn`，不得把 `pnpm` 作为当前默认值；除非重新验证目标版本源码工程确实支持 `pnpm`。

目标版本已确认：`v2.0.61`。下一阶段是完整 NocoBase v2.0.61 宿主工程接入准备；接入分支应在独立宿主工程中创建，不应在当前仓库中引入完整 NocoBase 源码。

分支计划新增约束：

- 当前项目仍不包含完整 NocoBase 源码。
- 不在当前仓库 clone NocoBase 源码。
- 不提交完整 NocoBase 源码。
- 插件复制方向必须是从当前项目到 host 工程，而不是反向复制。
- 真实环境检测 adapter 通过前，不进入 Collection adapter。
- 当前仍不能正式上线测试，当前仍不能生产部署，当前不能标记为 `production_ready`。
