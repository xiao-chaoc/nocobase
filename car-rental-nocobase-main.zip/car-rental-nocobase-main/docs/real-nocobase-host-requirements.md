# 真实 NocoBase 宿主工程要求

## 1. 基本要求

真实接入需要完整 NocoBase 工程，而不是当前插件骨架仓库。当前仓库不能直接承担真实 app、数据库上下文、插件管理器、权限、UI Schema、文件存储和 scheduler 能力。

## 2. 宿主工程清单

| 类别 | 要求 |
| --- | --- |
| NocoBase 版本 | 必须确认目标 NocoBase 版本，并记录插件 API、Collection API、ACL API、UI Schema API 和 scheduler API 的兼容性。 |
| Node 环境 | 必须满足目标 NocoBase 版本要求的 Node 版本。 |
| 包管理器 | 当前 v2.0.61 宿主工程实际检测为 yarn；未来其他目标版本可按确认结果使用 Yarn、npm 或 pnpm，但不得混用未确认的包管理器。 |
| PostgreSQL | 必须准备隔离 PostgreSQL 测试数据库，禁止使用生产库。 |
| storage | 必须准备独立 storage，禁止复用生产文件目录。 |
| APP_KEY | 必须使用测试专用 `APP_KEY`，创建后不得随意修改。 |
| 管理员账号 | 必须准备测试专用管理员账号。 |
| IOPGPS | 必须设置 `IOPGPS_SYNC_ENABLED=false`，禁止真实 IOPGPS 同步。 |
| mock 数据 | 必须使用 mock 司机、车辆、合同、付款、GPS 和合同文件数据。 |
| 备份目录 | 必须准备测试专用数据库备份、storage 备份和 schema snapshot 目录。 |
| 日志目录 | 必须准备测试专用日志目录，并保留失败日志。 |
| 文件上传测试目录 | 必须准备只存放 mock 文件的上传测试目录。 |
| 权限测试账号 | 必须准备管理员、财务、运营、只读和无敏感字段权限账号。 |
| 生产数据 | 禁止导入或引用生产司机数据、真实付款截图、真实合同扫描件、真实司机证件和真实 IOPGPS 凭据。 |
| 回滚演练 | 必须在真实 smoke test 前完成数据库、storage、plugin storage 和 schema snapshot 回滚演练。 |

## 3. 环境变量边界

- 测试 `.env` 只允许存在于完整 NocoBase 测试工程，不得提交到当前仓库。
- 当前仓库只允许保留 `.env.example` 和 `.env.test.example` 等模板文件。
- 不读取 `.env.test` 真实值作为当前仓库 readiness 检查依据。
- 真实 IOPGPS 密钥不得进入测试 `.env`，除非未来单独批准外部 API 联调阶段。

## 4. 数据与文件边界

- mock 数据必须能被识别为测试数据。
- 付款截图只能使用 mock 占位文件。
- 合同扫描件只能使用 mock 占位文件。
- 司机证件只能使用 mock 占位文件或空引用。
- GPS 数据只能使用 mock 位置、里程和设备状态。

## 5. 验收要求

宿主工程准备完成后，应能支持真实 adapter 按顺序验证：环境检测、Collection、Runtime、Page、Seed Data、Backup / Rollback、Smoke Test、Readiness、插件打包安装和 UAT。

## 2026-06-06 NocoBase 目标版本与插件 API 调研补充

本轮已新增目标版本与真实插件 API 映射调研文档：

- `docs/nocobase-target-version-research.md`
- `docs/nocobase-plugin-api-research.md`
- `docs/real-adapter-api-mapping.md`
- `docs/real-adapter-gap-analysis.md`
- `docs/real-adapter-implementation-backlog.md`

本轮结论如下：

- 下一阶段是锁定 NocoBase 目标版本和验证官方 API。
- 当前 `latest-full` 只能继续用于 NAS 基础环境测试，不能作为真实 adapter、UAT 或生产部署基准。
- 当前仍不能实现真实 adapter；未经官方 API 验证不得写真实 adapter。
- 当前不能正式上线测试，也不能生产部署。
- 任何无法确认的 NocoBase API 必须标记为待验证，不得伪造 API。
- 验证只能在完整 NocoBase 源码测试工程和隔离 PostgreSQL、隔离 storage 中进行，不得生产库调试。

## 本轮补充：宿主工程准备要求

完整 NocoBase 宿主工程必须单独准备，建议与当前仓库分离：当前仓库保存插件和 dry-run 自动化，宿主工程保存完整 NocoBase 源码，NAS Docker 目录保存隔离测试运行数据。

目标版本必须人工确认。未确认前，不应实现真实 adapter，不应真实复制插件到宿主工程，不应连接真实 NocoBase，不应写数据库。`latest-full` 不能作为真实接入基准。

宿主工程准备阶段必须禁用真实 IOPGPS，同步只允许 mock 数据；必须使用隔离测试库和测试 storage；不得生产库调试；不要把完整 NocoBase 源码提交进当前仓库。当前仍不能正式上线测试，当前仍不能生产部署。




> 包管理器修正：完整 NocoBase v2.0.61 宿主工程环境检测已确认当前接入基准为 `package_manager = yarn`。后续宿主工程人工命令应使用 `yarn`，不得把 `pnpm` 作为当前默认值；除非重新验证目标版本源码工程确实支持 `pnpm`。
