# NocoBase v2.0.61 宿主工程接入总任务包

## 任务状态

| 字段 | 值 |
| --- | --- |
| target_version | v2.0.61 |
| source_type | release |
| source_reference | https://github.com/nocobase/nocobase/releases/tag/v2.0.61 |
| package_manager | yarn |
| database | postgresql |
| deployment_mode | source_host |
| plugin_development_mode | packages_plugins |
| plugin_install_mode | packages_plugins |
| iopgps_real_sync_allowed | false |
| mock_data_only | true |

## 当前允许进入的阶段

本任务包只允许进入“完整 NocoBase v2.0.61 宿主工程接入准备”阶段。目标版本已确认：v2.0.61；下一阶段是完整 NocoBase v2.0.61 宿主工程接入准备。

允许事项：

- 创建完整 NocoBase 宿主工程接入任务。
- 准备宿主工程目录。
- 准备插件复制计划。
- 准备 shared automation 接入计划。
- 准备真实 adapter 实现任务。
- 准备隔离测试库方案。
- 准备校验脚本草案，且只检查本地文档。

仍禁止事项：

- 禁止生产部署。
- 禁止真实业务数据。
- 禁止真实 IOPGPS。
- 禁止真实付款截图。
- 禁止真实合同扫描件。
- 禁止真实司机证件。
- 禁止未备份情况下执行迁移。
- 禁止在生产库验证，不使用生产库。
- 禁止在当前仓库 clone NocoBase 源码；也就是不 clone NocoBase 源码到当前仓库。
- 禁止提交完整 NocoBase 源码，不提交完整 NocoBase 源码。
- 禁止安装依赖、连接 NocoBase、写数据库、创建 Collections、创建页面、注册权限、导入数据、调用 IOPGPS、上传文件。
- 禁止复制 `.env`、`.env.test`、`filled.json` 或 `*confirmed*.json`。
- 当前不能 production_ready，当前项目仍不能标记为 production_ready。

## 最小接入目标

本阶段最小目标是：

- 在完整 NocoBase v2.0.61 源码工程内接入三个插件源码。
- 接入 shared automation 包。
- 实现真实环境检测 adapter。
- 验证可以检测 `app`、`db`、`acl`、`uiSchema`、`scheduler`、`workflow`、`storage`、`logger` 能力。
- 不先实现全部业务功能。
- 不先做生产部署。

## shared automation 接入计划

- 源路径：`packages/shared/nocobase-automation`。
- 目标位置建议：`/volume1/projects/nocobase-host-v2.0.61/packages/shared/nocobase-automation`，或宿主工程 v2.0.61 认可的 `packages` 工作区位置。
- 接入方式：仅在后续宿主工程任务中复制源码并纳入 yarn workspace 识别；本轮不真实复制。
- 第一阶段只暴露环境检测 adapter 所需接口，不伪造 NocoBase API，不把未验证 API 写成已验证。
- shared automation 应继续保留 mock 与 dry-run 能力，真实 adapter 必须通过环境检测报告证明宿主能力后再进入 Collection adapter。

## 完整接入阶段拆分

| 阶段 | 名称 | 最小产物 | 是否允许本轮执行 |
| --- | --- | --- | --- |
| 0 | 当前仓库任务包准备 | 本文档、目录规划、命令清单、插件复制计划、adapter 任务说明、校验脚本草案 | 允许 |
| 1 | 宿主工程目录准备 | 独立 host 目录、独立 Docker runtime 目录、隔离测试库方案 | 禁止真实执行，仅提供草案 |
| 2 | 获取 NocoBase v2.0.61 源码 | release 源码或固定标签源码，目录在宿主工程外部独立位置 | 禁止在当前仓库执行 |
| 3 | 插件与 shared automation 复制 | 三个插件和 shared automation 复制到 host 工程认可位置 | 禁止本轮真实复制 |
| 4 | 真实环境检测 adapter | 环境检测报告、能力矩阵、阻塞项 | 下一轮或宿主工程任务执行 |
| 5 | Collection adapter | 最小 Collection 注册、唯一约束、relation、回滚方案 | 环境检测通过后执行 |
| 6 | Runtime、页面、权限、导入、烟测 adapter | 分阶段真实接入并校验 | 后续执行 |
| 7 | 上线前 readiness | 隔离测试库验证、备份回滚演练、安全复核 | 后续执行，当前不能正式上线测试 |

## 隔离测试库边界

- database = postgresql。
- 只能使用隔离 PostgreSQL 测试库。
- 不使用生产库，不在生产库验证，不在生产库调试。
- 当前仓库不写数据库；本轮校验脚本只读本地文档。
- 真实迁移或 Collection 注册前必须已有备份和回滚方案。

## 当前结论

目标版本已锁定为 v2.0.61，但当前项目仍不包含完整 NocoBase 源码，仍不能正式上线测试，仍不能生产部署，仍不能启用真实 IOPGPS。本轮产物只用于下一阶段完整 NocoBase v2.0.61 宿主工程接入准备。
