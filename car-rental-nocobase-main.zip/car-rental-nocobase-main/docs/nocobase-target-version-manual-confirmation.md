# NocoBase 目标版本人工确认清单

## 当前状态

- `decision_status = confirmed`
- `target_version = v2.0.61`
- `requires_manual_confirmation = false`
- `package_manager = yarn`

当前目标 NocoBase 版本已锁定为 v2.0.61。本文件仍保留人工确认字段说明，用于未来版本变更时复用；当前状态不代表可以正式上线测试或生产部署。

## 需要用户人工确认的信息

进入下一阶段前，用户必须人工确认以下信息：

- 目标 NocoBase 版本号。
- 版本来源。
- 是否使用完整源码工程。
- 是否使用 Docker 镜像。
- 使用 `npm` / `yarn` / `pnpm`。
- 是否允许 `packages/plugins` 开发。
- 是否后续打包到 `storage/plugins`。
- 测试数据库类型，默认 PostgreSQL。
- 测试数据库是否独立。
- 测试 `storage` 路径。
- 是否需要模板打印插件。
- 是否需要合同 PDF。
- 是否禁用真实 IOPGPS。
- 是否只使用 mock 数据。
- 是否允许在 NAS 测试环境安装插件。
- 是否已有备份和回滚策略。

## 用户填写模板

| 项目 | 当前值 | 用户填写 | 是否必须 | 说明 |
| --- | --- | --- | --- | --- |
| 目标 NocoBase 版本号 | `unset` |  | 是 | 必须由用户或官方来源明确，不能使用 `latest-full` 作为真实接入版本。 |
| 版本来源 | 未确认 |  | 是 | 可填写官方源码标签、官方发布页、官方镜像标签或项目负责人书面确认来源。 |
| 是否使用完整源码工程 | 未确认 |  | 是 | 用于决定后续是否在完整 NocoBase 工程内开发调试。 |
| 是否使用 Docker 镜像 | 未确认 |  | 是 | 如使用镜像，必须同时固定镜像标签，禁止漂移。 |
| 包管理器 | 未确认 |  | 是 | 仅允许 `npm`、`yarn`、`pnpm` 之一。 |
| 是否允许 `packages/plugins` 开发 | 未确认 |  | 是 | 决定插件源码放置方式和构建方式。 |
| 是否后续打包到 `storage/plugins` | 未确认 |  | 是 | 决定第三方插件安装验证方式。 |
| 测试数据库类型 | `postgresql` |  | 是 | 默认且当前校验要求为 PostgreSQL。 |
| 测试数据库是否独立 | 未确认 |  | 是 | 必须使用隔离测试库，不得使用生产数据。 |
| 测试 `storage` 路径 | 未确认 |  | 是 | 必须是隔离测试路径，不得混用生产附件目录。 |
| 是否需要模板打印插件 | 未确认 |  | 是 | 影响合同模板、合同 PDF 和打印能力验证范围。 |
| 是否需要合同 PDF | 未确认 |  | 是 | 若需要，下一阶段仍只能用 mock 合同数据验证。 |
| 是否禁用真实 IOPGPS | `true` |  | 是 | 当前必须禁用真实 IOPGPS，同步失败也不得影响租金台账。 |
| 是否只使用 mock 数据 | `true` |  | 是 | 当前只允许 mock 数据，不得使用真实司机证件、付款截图或合同扫描件。 |

| 是否允许在 NAS 测试环境安装插件 | 未确认 |  | 是 | 只能在版本冻结后、隔离测试环境中执行。 |
| 是否已有备份和回滚策略 | 未确认 |  | 是 | 没有备份和回滚策略不得进入 UAT。 |
| 确认人 | 未确认 |  | 是 | 必须填写人工确认责任人。 |
| 确认时间 | 未确认 |  | 是 | 必须填写明确日期。 |

## 当前 v2.0.61 已确认基准

当前已确认目标版本为 `v2.0.61`，来源为 release，宿主工程实际检测包管理器为 `yarn`。人工确认表仍允许未来版本填写 `npm`、`yarn`、`pnpm`，但本次 v2.0.61 接入不得把 `pnpm` 作为当前默认值。


## 决策前禁止事项

目标版本确认前必须禁止：

- 不使用 production 数据。
- 不使用真实 IOPGPS。
- 不使用真实司机证件。
- 不使用真实付款截图。
- 不使用真实合同扫描件。
- 不继续写真实 adapter。
- 不直接安装插件到当前 NAS 空应用。
- 不创建完整 NocoBase 宿主工程。
- 不连接真实 NocoBase。
- 不写数据库。

## 下一步

用户填写并确认本清单后，应复制 `docs/nocobase-target-version-freeze-template.md` 的字段，形成正式冻结记录，再更新 `docs/nocobase-target-version-decision.md`。只有用户明确提供确认信息后，才允许把 `decision_status` 改为 `confirmed`。

## 机器校验与应用流程

人工填写时应优先复制 `test-data/generated/nocobase-target-version-confirmation.template.json` 为 `test-data/generated/nocobase-target-version-confirmation.filled.json`。填写文件不得包含任何密码、`APP_KEY`、`DB_PASSWORD`、`INIT_ROOT_PASSWORD`、`IOPGPS_LOGIN_KEY`、`access_token` 或 `login_key`。

未来版本变更时，填写完成后先运行 `npm run validate:target-version-input -- --file test-data/generated/nocobase-target-version-confirmation.filled.json`。通过后运行 `npm run apply:target-version-confirmation -- --file test-data/generated/nocobase-target-version-confirmation.filled.json` 做 dry-run。当前 v2.0.61 已确认，门禁通过也不代表可以正式上线测试或生产部署。

## 本轮补充：人工确认操作清单与 PR 审查

人工确认不应只停留在口头或聊天记录中。目标版本确认应先提交 GitHub Issue，再由操作者按 `docs/nocobase-target-version-operator-checklist.md` 创建并填写 `filled.json`，执行输入校验、apply dry-run 和必要门禁，最后通过 PR 模板审查。

当前目标版本已确认为 `v2.0.61`。在插件与 shared automation 复制到宿主工程、真实环境检测 adapter 通过、隔离测试库和备份策略确认前，仍不允许进入真实 Collection adapter，当前仍不能正式上线测试，仍不能生产部署。
