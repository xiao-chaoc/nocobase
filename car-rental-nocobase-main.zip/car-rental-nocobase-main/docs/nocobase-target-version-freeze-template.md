# NocoBase 目标版本冻结模板

本模板用于用户确认目标版本后复制填写。填写完成前，当前项目仍保持 `pending_manual_confirmation`，不得进入真实 adapter 实现。

## 版本冻结信息

| 字段 | 用户填写 | 说明 |
| --- | --- | --- |
| `decision_status` | `confirmed` | 只有用户明确确认后才能填写为 `confirmed`。 |
| `target_version` |  | 目标 NocoBase 版本号，禁止填写 `unset` 或 `latest-full`。 |
| `source_type` |  | 可选：`tag`、`branch`、`docker_image`、`release`。 |
| `source_reference` |  | 官方来源、镜像标签、源码标签或书面确认链接。 |
| `source_commit_or_tag` |  | 固定 commit、tag 或镜像摘要。 |
| `package_manager` |  | 可选：`npm`、`yarn`、`pnpm`。 |
| `node_version` |  | 与目标 NocoBase 版本匹配的 Node.js 版本。 |
| `database` | `postgresql` | 当前要求隔离 PostgreSQL 测试库。 |
| `deployment_mode` |  | 可选：`source_host`、`docker_host`、`plugin_package`。 |
| `plugin_development_mode` |  | 可选：`packages_plugins`、`storage_plugins`。 |
| `plugin_install_mode` |  | 插件安装和启用方式。 |
| `storage_strategy` |  | 隔离测试 storage 路径与附件策略。 |
| `template_printing_required` |  | 是否需要模板打印插件。 |
| `iopgps_real_sync_allowed` | `false` | 当前必须为 `false`。 |
| `mock_data_only` | `true` | 当前必须为 `true`。 |
| `confirmed_by` |  | 人工确认责任人。 |
| `confirmed_at` |  | 人工确认日期，格式建议 `YYYY-MM-DD`。 |


## 当前 v2.0.61 填写提示

如果本模板用于当前已确认的 NocoBase v2.0.61 接入基准，`package_manager` 应填写 `yarn`。模板继续保留 `npm`、`yarn`、`pnpm` 作为未来版本枚举，但当前 v2.0.61 宿主工程实际检测结果为 `yarn`，不能把 `pnpm` 作为默认值。


## 冻结后的效果

确认后允许：

- 创建完整 NocoBase 宿主工程接入任务。
- 实现真实环境检测 adapter。
- 实现真实 Collection adapter。
- 在隔离测试库验证插件接入。

确认后仍然禁止：

- 生产部署。
- 使用真实司机数据。
- 使用真实付款截图。
- 使用真实合同扫描件。
- 启用真实 IOPGPS。
- 绕过权限测试。
- 把当前项目标记为 `production_ready`。

## 修改规则

冻结记录必须由用户或项目负责人明确提供。Codex 不得编造目标版本号，不得把 `latest-full` 写成真实接入版本，不得用不确定 API 写成已验证。
