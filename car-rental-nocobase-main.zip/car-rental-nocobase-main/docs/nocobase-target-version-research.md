# NocoBase 目标版本调研与版本策略

## 本轮结论

本轮可以确认版本策略，但不能在当前仓库最终确认一个可直接实施的具体版本号。原因是当前仓库不是完整 NocoBase 工程，无法执行插件加载、Collection 同步、权限、页面、工作流、文件存储和备份恢复验证。

推荐策略：

1. NAS 基础环境可以继续使用 `nocobase/nocobase:latest-full` 做服务启动、PostgreSQL 连通、storage 挂载、端口、防火墙和基础 smoke 检查。
2. 真实插件接入测试必须固定具体 NocoBase 版本，并记录镜像 tag、源码 tag、文档版本、包管理器和升级策略。
3. 生产前必须固定版本，不得使用 `latest-full` 或 `beta-full` 作为生产或真实 adapter API 基准。
4. 目标版本候选优先选择当前稳定线 `2.0.x` 的最新稳定补丁版本，例如 GitHub 页面在本轮调研时显示的 `v2.0.57` 最新稳定发布；但该版本仍需人工在完整 NocoBase 工程中确认。

## 当前 docker-compose.test.yml 使用的镜像

当前 `docker-compose.test.yml` 中 `nocobase` 服务使用：

```yaml
image: nocobase/nocobase:latest-full
```

该文件已有注释说明：`latest-full` 仅用于测试环境快速验证，正式环境后续必须固定具体 NocoBase 版本号。

## 为什么 `latest-full` 只适合基础测试

`latest-full` 的风险在于：

- tag 会随官方发布移动，同一份仓库和同一条脚本在不同日期可能加载不同 NocoBase 代码。
- 插件生命周期、`client-v2`、UI Schema、权限、工作流、资源动作、备份恢复等 API 可能随版本变化。
- 真实 adapter 需要把每个调用映射到明确版本的官方文档或源码，移动 tag 无法提供可复现依据。
- 一旦测试通过后 tag 又变化，后续失败难以区分是业务代码问题、官方 API 变化还是镜像漂移。
- `latest-full` 适合检查 Docker、PostgreSQL、storage、端口和基础登录，不适合作为正式插件接入基准。

## 为什么真实接入测试应固定具体 NocoBase 版本

真实 adapter 会涉及数据库结构、权限、页面 schema、文件字段、工作流/定时任务、插件安装和回滚。固定版本可以保证：

- API 映射可复现。
- 测试结果可追溯。
- 回滚和备份恢复有明确目标。
- 插件包构建、安装、启用、禁用流程稳定。
- UAT 期间不会因镜像自动更新导致页面、权限或业务动作变化。

## 目标版本选择原则

| 原则 | 说明 | 本轮状态 |
| --- | --- | --- |
| 稳定版优先 | 优先选择正式稳定发布，不选择 alpha、beta、rc 作为真实接入基准。 | 待人工确认 |
| 与插件开发 API 文档匹配 | 文档和源码 tag 必须对应，避免 v1/v2 文档混用。 | 待验证 |
| 支持 PostgreSQL | 当前系统以 PostgreSQL 为测试和生产候选数据库。 | 需完整工程验证 |
| 支持插件开发 | 必须支持 server/client 插件、插件生命周期、插件包安装。 | 官方文档已有方向，仍需验证 |
| 支持权限 ACL | 必须支持角色、资源动作、字段级敏感数据控制和服务端强制。 | 待验证 |
| 支持 UI Schema / 页面配置 | 必须支持菜单、页面、区块、按钮动作和角色可见性。 | 待验证 |
| 支持文件存储 | 必须支持付款截图、合同扫描件、司机证件字段与权限隔离。 | 待验证 |
| 支持定时任务或工作流扩展 | IOPGPS mock/真实同步必须可被禁用且失败隔离。 | 待验证 |
| 支持模板打印或至少不阻塞合同文件模块 | 模板打印、Word/PDF、LibreOffice 能力不确定时不得阻塞核心租金台账。 | 待验证 |

## 需要人工确认的信息

- 目标 NocoBase 版本号。
- 是否使用源码工程开发。
- 是否使用 Docker 镜像部署。
- 是否使用 pnpm/yarn/npm。
- 是否允许插件放入 `packages/plugins`。
- 是否后续构建为 `storage/plugins` 插件包。
- 是否使用稳定线 `2.0.x`，以及是否允许观察但不采用 `2.1.x beta`。
- 是否有商业插件或模板打印插件授权需求。

## 建议版本策略

| 场景 | 策略 | 是否允许 `latest-full` |
| --- | --- | --- |
| NAS 基础环境测试 | 检查容器启动、PostgreSQL、storage、端口、基础登录。 | 可以 |
| 真实插件接入测试 | 固定具体版本，例如 `nocobase/nocobase:2.0.x-full` 与源码 tag 一致。 | 不可以 |
| UAT | 固定与真实接入测试一致的版本，并冻结升级。 | 不可以 |
| 生产部署 | 固定版本，记录升级窗口、备份、回滚和兼容性验证清单。 | 不可以 |

## 版本决策表

| 候选版本 | 来源 | 优点 | 风险 | 是否推荐 | 需要验证项 |
| --- | --- | --- | --- | --- | --- |
| `nocobase/nocobase:latest-full` | local_project：当前 `docker-compose.test.yml` | 启动方便，可做基础环境测试。 | tag 漂移，API 不可复现，不适合作为真实 adapter 基准。 | 仅推荐 NAS 基础测试 | 不得用于真实 adapter 实现、UAT 或生产。 |
| `v2.0.57` / `nocobase/nocobase:2.0.57-full` | official_source：GitHub releases 页面本轮显示 `v2.0.57` 为最新稳定发布；official_docs：2.0 正式发布说明 | 稳定线，适合作为候选固定版本。 | 仍需确认 Docker tag、源码 tag、文档 API 与插件包流程一致。 | 候选推荐 | 插件生命周期、Collection、ACL、UI Schema、i18n、工作流、文件存储、备份/回滚。 |
| `2.1.0-beta.*` / `2.1-full` | official_docs：2.1.0-beta 发布说明；Docker Hub tag | 新能力更活跃，包含 AI 与 V2 页面演进。 | beta 风险高，不适合作为内部运营系统真实接入基准。 | 不推荐作为首轮真实接入基准 | 仅可在独立实验环境观察，不进入 UAT。 |
| 完整源码工程当前 main | official_source：GitHub 仓库 | 可直接查看源码和调试。 | main 不等于稳定发布，变更频繁。 | 不推荐作为业务基准 | 仅用于 API 研究，不用于上线测试。 |

## 官方来源记录

- official_source：https://github.com/nocobase/nocobase
- official_source：https://github.com/nocobase/nocobase/releases
- official_docs：https://docs.nocobase.com/plugin-development
- official_docs：https://docs.nocobase.com/plugin-development/server/collections
- official_docs：https://docs.nocobase.com/plugin-development/server/resource-manager
- official_docs：https://docs.nocobase.com/plugin-development/client/router
- official_docs：https://docs.nocobase.com/plugin-development/common/i18n
- official_docs：https://docs.nocobase.com/api/server/migration
- official_docs：https://docs.nocobase.com/workflow
- local_project：`docker-compose.test.yml`

## 禁止项

- 不得伪造 API。
- 不得生产库调试。
- 不得把 dry-run 草案写成真实可用 API。
- 不得把当前项目标记为 production_ready。
- 未经官方 API 验证不得写真实 adapter。

## 本轮补充：目标版本仍需人工确认

当前目标 NocoBase 版本仍未锁定，状态必须保持 `pending_manual_confirmation`。本轮不编造版本号，不把 `latest-full` 作为真实接入目标版本，也不继续实现真实 adapter。

后续必须先由用户确认目标版本、版本来源、包管理器、部署模式、插件安装模式、数据库和 storage 策略，再进入完整宿主工程接入。确认前，当前项目仍不能正式上线测试，不能生产部署。
