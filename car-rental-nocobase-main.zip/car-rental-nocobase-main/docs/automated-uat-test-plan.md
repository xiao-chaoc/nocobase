# 自动化 UAT 测试计划

## 1. 测试原则

- UAT 以自动化脚本和报告为主，不要求用户手动在 NocoBase UI 中搭建 Collections、页面、菜单、权限或测试数据。
- 只使用 mock 数据，不使用真实司机资料、真实付款截图、真实合同扫描件或真实 IOPGPS 密钥。
- `IOPGPS_SYNC_ENABLED=false` 时不得调用真实 IOPGPS API。
- 通过自动化 UAT 前，不能进入正式上线测试，更不能生产上线。

## 2. UAT 用例清单

| 用例编号 | 前置条件 | 自动化脚本或操作入口 | 测试步骤 | 预期结果 | 失败处理 | 是否阻塞上线测试 |
| --- | --- | --- | --- | --- | --- | --- |
| UAT-ENV-001 | `.env.test` 已人工创建，Compose 文件存在 | NAS 自动化测试脚本 | 启动 PostgreSQL 容器 | PostgreSQL 正常启动，数据目录使用 `storage-test/postgres` | 查看容器日志，检查目录权限 | 是 |
| UAT-ENV-002 | PostgreSQL 已启动 | NAS 自动化测试脚本 | 启动 NocoBase 容器 | NocoBase 正常启动，端口可访问 | 查看 NocoBase 日志 | 是 |
| UAT-ENV-003 | NocoBase 已启动 | 初始化检查脚本 | 验证管理员登录、storage、templates 挂载 | 管理员可登录，`storage-test/nocobase` 与 `templates` 挂载正常 | 检查 `.env.test` 与目录权限 | 是 |
| UAT-PLUGIN-001 | 插件包已构建 | 插件安装脚本 | 按 rental-core、contract-documents、iopgps 顺序加载插件 | 三个插件加载成功，顺序正确 | 禁用失败插件，恢复备份 | 是 |
| UAT-PLUGIN-002 | 插件加载失败场景可复现 | 插件安装脚本 | 模拟插件失败并读取错误 | 错误信息可见，回滚步骤明确 | 修复插件入口或依赖 | 是 |
| UAT-DATA-001 | 插件已加载 | `scripts/nocobase/init-collections.ts` | 自动创建 Collections | 核心 Collections 存在 | 回滚数据库并修复 migration | 是 |
| UAT-DATA-002 | Collections 已创建 | Collection 校验脚本 | 校验字段、枚举、关系 | 字段、枚举、关系完整 | 修复 Collection 定义 | 是 |
| UAT-DATA-003 | Collection 校验脚本可运行 | Collection 校验脚本 | 校验唯一约束或服务端校验 | 合同编号、车辆冲突、台账日期等约束生效 | 修复约束或服务端校验 | 是 |
| UAT-CORE-001 | mock 司机和车辆可导入 | smoke test | 创建测试司机和测试车辆 | 司机、车辆记录自动创建，非真实数据 | 检查导入映射 | 是 |
| UAT-CORE-002 | 司机车辆存在 | smoke test | 创建 6 个月以上时限合同 | 合同绑定具体车牌，生成整个周期台账 | 修复合同和台账服务 | 是 |
| UAT-CORE-003 | 司机车辆存在 | smoke test | 创建长租合同 | 合同无固定结束日期，按 horizon 生成未来台账 | 修复长租台账补生成 | 是 |
| UAT-CORE-004 | 合同已创建 | smoke test | 校验默认免租日 | 默认免租日写入每日台账且 due_amount 为 0 | 修复计费规则 | 是 |
| UAT-CORE-005 | 每日台账存在 | smoke test | 创建付款并分配到具体日期 | 付款分配到日期，金额匹配 | 修复付款分配 | 是 |
| UAT-CORE-006 | 台账已有付款 | smoke test | 尝试单日超付 | 操作失败，不生成预收款，不转移到其他日期 | 修复超付校验 | 是 |
| UAT-CORE-007 | 存在未付日期 | smoke test | 标记未付原因 | 未付日期必须保存未付原因 | 修复未付原因校验 | 是 |
| UAT-CORE-008 | 存在部分付款 | smoke test | 标记欠款、免除、待审批或争议 | 剩余金额状态明确 | 修复短缺状态流 | 是 |
| UAT-CORE-009 | 已确认付款存在 | smoke test | 执行付款冲正 | 台账恢复，操作日志记录 | 修复冲正服务 | 是 |
| UAT-CORE-010 | 合同存在 | smoke test | 押金收取、抵扣、退还 | 押金状态和可用金额正确 | 修复押金服务 | 是 |
| UAT-CORE-011 | 押金和租金均存在 | smoke test | 汇总租金收入 | 押金不计入租金收入 | 修复汇总逻辑 | 是 |
| UAT-CORE-012 | 台账存在过去和未来日期 | smoke test | 计算日历汇总 | 当前欠款天数和金额正确，未来应收不计入当前欠款 | 修复汇总和日期边界 | 是 |
| UAT-PERM-001 | 角色已初始化 | 权限测试脚本 | accountant 查看付款截图 | 财务可见付款截图 | 修复 ACL | 是 |
| UAT-PERM-002 | 角色已初始化 | 权限测试脚本 | operator 查看付款截图 | 运营默认不可见付款截图 | 修复敏感字段策略 | 是 |
| UAT-PERM-003 | 角色已初始化 | 权限测试脚本 | gps_maintenance 查看财务汇总 | GPS 维护人员不可看财务汇总 | 修复角色权限 | 是 |
| UAT-PERM-004 | 角色已初始化 | 权限测试脚本 | manager 查看欠款和未来应收 | 经理可查看欠款和未来应收 | 修复角色权限 | 是 |
| UAT-PERM-005 | 角色已初始化 | 权限测试脚本 | readonly_auditor 尝试修改 | 只读审计无修改权限 | 修复 ACL 写权限 | 是 |
| UAT-PERM-006 | 无司机登录功能 | 权限测试脚本 | 检查司机账号入口 | 司机不登录系统 | 移除错误入口 | 是 |
| UAT-DOC-001 | 合同文件插件已加载 | 合同文件测试脚本 | 识别 zh-CN 模板 | 中文模板识别成功 | 修复模板注册 | 是 |
| UAT-DOC-002 | 合同文件插件已加载 | 合同文件测试脚本 | 识别 en-US 模板 | 英文模板识别成功 | 修复模板注册 | 是 |
| UAT-DOC-003 | 合同文件插件已加载 | 合同文件测试脚本 | 识别 fr-FR 模板 | 法文模板识别成功 | 修复模板注册 | 是 |
| UAT-DOC-004 | 合同文件存在 | 合同文件测试脚本 | 合同文件状态流转 | generated、printed、signed、scanned、voided 规则正确 | 修复状态服务 | 是 |
| UAT-DOC-005 | 合同扫描字段存在 | 权限测试脚本 | 查看签署扫描件字段 | 字段受敏感权限控制 | 修复字段权限 | 是 |
| UAT-DOC-006 | 模板打印未启用 | 合同文件测试脚本 | 尝试生成 PDF | 不真实生成 PDF，除非后续明确启用模板打印测试 | 阻断真实生成流程 | 是 |
| UAT-GPS-001 | GPS 插件已加载 | GPS mock 测试脚本 | 导入 GPS 设备 mock | GPS 设备存在且不调用真实 API | 修复导入或开关 | 是 |
| UAT-GPS-002 | GPS mock 数据存在 | GPS mock 测试脚本 | 校验 offline、fault、low_power、power_cut | 状态归一化正确 | 修复归一化 | 是 |
| UAT-GPS-003 | `IOPGPS_SYNC_ENABLED=false` | GPS mock 测试脚本 | 触发同步入口 | 不调用真实 IOPGPS API | 修复同步开关 | 是 |
| UAT-GPS-004 | GPS 同步失败模拟 | GPS mock 测试脚本 | 模拟 GPS 失败 | 租金台账和付款逻辑不受影响 | 修复失败隔离 | 是 |
| UAT-ROLLBACK-001 | 已完成测试数据导入 | 回滚脚本 | 停止容器并恢复测试数据库 | 测试库可恢复 | 修复备份恢复脚本 | 是 |
| UAT-ROLLBACK-002 | 插件已安装 | 回滚脚本 | 禁用插件、清理测试数据 | 环境回到可重试状态 | 修复回滚流程 | 是 |

## 3. UAT 输出

自动化 UAT 应输出：

- 执行时间和环境版本。
- 插件版本和安装顺序。
- 测试数据批次。
- 每个用例的通过/失败状态。
- 阻塞项列表。
- 回滚结果。
- 是否允许进入正式上线测试冻结的结论。
