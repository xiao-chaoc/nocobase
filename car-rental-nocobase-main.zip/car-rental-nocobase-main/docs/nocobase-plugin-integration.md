# NocoBase 插件接入说明

## 当前仓库定位

当前仓库不是完整 NocoBase 源码工程，也不是可直接部署的 NocoBase 应用。`packages/plugins` 下的 `plugin-rental-core`、`plugin-contract-documents`、`plugin-iopgps` 只是待接入真实 NocoBase 工程的插件源码骨架。

这些骨架目前提供：

- TypeScript 类型定义。
- 可单独测试的纯业务函数。
- Collection 注册草案对象。
- 服务端入口统一导出。
- 多语言资源草案。
- 测试 TODO 和接入文档。

这些骨架目前不提供：

- 真实 NocoBase 插件生命周期注册。
- 真实数据库迁移。
- 真实前端页面。
- 真实 IOPGPS HTTP 调用。
- 真实合同文件生成或上传。
- 生产 NAS 部署能力。

## 后续接入方式

### 方式 A：放入完整 NocoBase 源码工程的 `packages/plugins`

适用于开发调试和源码级集成。

1. 准备完整 NocoBase 源码工程。
2. 将三个插件目录复制或迁移到真实工程的 `packages/plugins` 下。
3. 按真实 NocoBase 版本校验 `package.json`、插件元数据、server/client 入口和构建命令。
4. 将当前 Collection 草案转换为真实 Collection 定义或迁移。
5. 接入服务端事务、权限、i18n 和测试数据库。

### 方式 B：构建为第三方插件包后放入 `storage/plugins`

适用于插件包形式的安装验证。

1. 先在完整 NocoBase 工程或兼容构建环境中完成插件构建。
2. 将构建后的插件包放入 NocoBase 的 `storage/plugins` 或通过插件安装流程启用。
3. 在测试环境启用插件并验证 Collection、服务方法、权限与日志。
4. 不得直接在生产 NAS 上首次启用未验证插件。

## `packages/plugins` 与 `storage/plugins` 的区别

- `packages/plugins` 通常用于源码工程内开发，便于参与工作区构建、类型检查和调试。
- `storage/plugins` 通常用于运行环境加载已构建或已安装的第三方插件包。
- 当前仓库只有插件源码骨架，没有完整 NocoBase 工作区配置，因此不能直接按生产插件包使用。

## 插件启用时需要注册的内容

真实接入 NocoBase 时，每个插件至少需要完成：

- 注册 Collection 或迁移。
- 注册服务端方法与动作。
- 注册权限和敏感字段访问控制。
- 注册 i18n 资源。
- 注册操作日志和错误日志策略。
- `plugin-iopgps` 还需要注册定时同步任务。
- `plugin-contract-documents` 还需要注册合同文档生成、打印、上传等服务端动作。

## 推荐启用顺序

1. `plugin-rental-core`
2. `plugin-contract-documents`
3. `plugin-iopgps`

## 插件依赖关系

- `plugin-rental-core` 是核心事实来源，不依赖 `plugin-iopgps`，也不依赖 `plugin-contract-documents`。
- `plugin-contract-documents` 依赖 `plugin-rental-core` 的合同、司机、车辆数据。
- `plugin-iopgps` 依赖 `plugin-rental-core` 的车辆数据。

## 失败隔离原则

- GPS 同步失败只能写入 IOPGPS 错误日志，不能影响租金台账和付款逻辑。
- 合同文件生成、打印或扫描件上传失败，不能影响租金台账和付款逻辑。
- 所有敏感数据必须由服务端权限控制保护，不能只靠前端隐藏。

## 当前不能直接生产启用的原因

- 当前没有真实插件生命周期注册。
- 当前没有真实 NocoBase Collection 注册或数据库迁移。
- 当前没有接入 NocoBase 权限、事务、文件存储、定时任务和工作流。
- 当前只有纯函数和草案对象，尚未在真实 NocoBase 版本中完成构建和启用验证。

## 本地或 NAS 测试前必须完成

- 确认 NocoBase 版本、Node/Yarn 版本和插件格式。
- 准备测试数据库并做好备份。
- 将 Collection 草案转换为真实定义。
- 接入服务端权限和敏感字段脱敏。
- 使用测试司机、测试车辆、测试合同、测试付款和 GPS mock 数据。
- 不连接真实 IOPGPS，不上传真实合同扫描件，不使用真实付款截图。
