# NocoBase 宿主工程准备 Runbook

## 当前项目与宿主工程关系

当前仓库是汽车租赁业务插件、自动化 dry-run 与真实 adapter 草案仓库。当前仓库不是完整 NocoBase 工程，不包含完整 NocoBase 源码、运行时宿主应用、真实数据库连接或生产 storage。

完整 NocoBase 宿主工程必须单独准备。不要把完整 NocoBase 源码提交进当前仓库，不要把当前仓库改造成完整宿主工程，也不要把 dry-run 成功当成真实接入成功。

## 推荐目录结构

```text
/volume1/projects/car-rental-nocobase
/volume1/projects/nocobase-host-test
/volume1/docker/nocobase-car-lease-test
```

目录说明：

- `/volume1/projects/car-rental-nocobase`：当前项目，保存汽车租赁插件、dry-run 自动化、真实 adapter 草案和文档。
- `/volume1/projects/nocobase-host-test`：完整 NocoBase 源码测试工程，只在宿主工程接入阶段使用。
- `/volume1/docker/nocobase-car-lease-test`：NAS Docker 测试运行目录，用于测试数据库、storage、日志和备份的隔离运行。

## 宿主工程准备步骤

以下内容只描述步骤，本轮不实际执行：

1. 人工确认目标 NocoBase 版本。
2. 获取完整 NocoBase 源码。
3. 切换到目标 tag 或 branch。
4. 按宿主工程要求安装依赖。
5. 配置隔离测试数据库，不使用生产库。
6. 配置隔离测试 storage，不使用真实合同、证件或付款截图目录。
7. 禁用真实 IOPGPS 同步，保留 mock 数据输入。
8. 准备 mock 司机、车辆、合同、付款、GPS 数据。
9. 创建宿主工程集成分支。
10. 复制或链接 `plugin-rental-core`、`plugin-contract-documents`、`plugin-iopgps` 三个插件。
11. 复制或链接 `packages/shared/nocobase-automation`。
12. 运行类型检查和插件构建。
13. 运行 dry-run 自动化校验。
14. 在 API 验证完成后，再进入真实 adapter 替换。

## 插件接入方式

### 方式 A：源码开发方式

- 将 `plugin-rental-core`、`plugin-contract-documents`、`plugin-iopgps` 放入宿主工程 `packages/plugins`。
- 将 `packages/shared/nocobase-automation` 放入宿主工程可解析的 shared 包位置。
- 适合开发调试、API 验证和真实 adapter 最小示例验证。
- 必须在隔离数据库中执行，不得生产库调试。

### 方式 B：插件包方式

- 先在源码工程验证插件构建与真实 adapter 行为。
- 再构建插件包。
- 将插件包放入 `storage/plugins` 或通过插件安装流程安装。
- 适合 NAS 测试安装和后续部署演练。
- 必须先在源码工程验证，不能跳过 API 验证直接安装。

## 安全 dry-run 工具

本轮新增 `scripts/host/` 下的脚本草案。这些脚本默认 dry-run，只能检查、打印计划、校验路径并输出中文提示。真实复制或写入必须显式传入 `--execute`，并设置额外确认环境变量。

## 严格禁止事项

- 不在生产库调试。
- 不提交 `.env`。
- 不提交真实司机文件。
- 不提交真实付款截图。
- 不提交真实合同扫描件。
- 不提交真实 IOPGPS 密钥。
- 不把完整 NocoBase 源码提交进当前仓库。
- 不把 dry-run 成功当成真实接入成功。
- 不手动绕过权限。
- 不让 GPS 参与租金计算。
- 不把押金计入租金收入。
- 不在目标版本未人工确认前实现真实 adapter。

## 当前状态

当前阶段是宿主工程接入准备。目标 NocoBase 版本已确认为 `v2.0.61`，包管理器基准为 `yarn`。在插件与 shared automation 复制到独立宿主工程并完成环境检测前，不应实现真实 Collection adapter。当前仍不能正式上线测试，当前仍不能生产部署。

## 已确认目标版本下的前置阻塞

当前 `decision_status = confirmed`，`target_version = v2.0.61`，`package_manager = yarn`。本 Runbook 仍只能作为准备文档，不能在当前仓库执行完整 NocoBase 宿主工程创建、真实插件安装或真实 adapter 接入。

下一步需要把三个 car-rental 插件和 `packages/shared/nocobase-automation` 复制到独立宿主工程，并先完成真实环境检测 adapter。完成前不得进入 UAT，不得正式上线测试，不得生产部署。

## 目标版本确认门禁补充

当前目标版本已确认为 `v2.0.61`。未来如需变更目标版本，用户仍需要填写 `test-data/generated/nocobase-target-version-confirmation.filled.json`，通过 `npm run validate:target-version-input -- --file test-data/generated/nocobase-target-version-confirmation.filled.json` 后，再使用 `npm run apply:target-version-confirmation -- --file test-data/generated/nocobase-target-version-confirmation.filled.json` 进行 dry-run。

当前 `npm run validate:target-version-confirmation` 与 `npm run validate:can-start-real-adapter` 应通过，但只表示可进入下一轮完整宿主工程接入准备。当前不得在本仓库创建完整 NocoBase 宿主工程，不得真实复制插件到宿主工程，不得连接 NocoBase，不得写数据库，仍不能正式上线测试，仍不能生产部署。

## 目标版本确认流程门禁

完整 NocoBase 宿主工程准备必须基于已确认目标版本。当前确认值为 `v2.0.61`，包管理器为 `yarn`；本 Runbook 仍只作为准备说明，不在当前仓库执行 clone、不创建宿主工程、不安装依赖、不连接 NocoBase。

即使 `validate:target-version-confirmation` 与 `validate:can-start-real-adapter` 通过，也只允许进入下一轮完整宿主工程接入准备；当前仍不能正式上线测试，仍不能生产部署。

## 本轮补充：v2.0.61 宿主工程接入任务包

> 包管理器修正：完整 NocoBase v2.0.61 宿主工程环境检测已确认当前接入基准为 `package_manager = yarn`。后续宿主工程人工命令应使用 `yarn`，不得把 `pnpm` 作为当前默认值；除非重新验证目标版本源码工程确实支持 `pnpm`。

目标版本已确认：`v2.0.61`。下一阶段是完整 NocoBase v2.0.61 宿主工程接入准备，但当前项目仍不包含完整 NocoBase 源码，不能在当前仓库 clone NocoBase 源码，不能提交完整 NocoBase 源码。

本轮新增任务包：

- `docs/nocobase-v2.0.61-host-integration-task.md`
- `docs/nocobase-v2.0.61-host-directory-plan.md`
- `docs/nocobase-v2.0.61-host-bootstrap-commands.md`
- `docs/nocobase-v2.0.61-plugin-copy-plan.md`
- `docs/task-real-environment-adapter-v2.0.61.md`
- `docs/task-real-collection-adapter-v2.0.61.md`

本阶段只允许准备任务包、目录规划、命令草案、插件复制计划、shared automation 接入计划、真实环境检测 adapter 任务和 Collection adapter 后续任务。当前仍不能正式上线测试，仍不能生产部署，仍不能使用生产库，仍不能启用真实 IOPGPS，仍不能标记为 `production_ready`。
