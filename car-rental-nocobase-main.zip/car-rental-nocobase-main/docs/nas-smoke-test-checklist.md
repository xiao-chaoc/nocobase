# NAS Smoke Test 清单

## 测试前条件

- [ ] 已合并所有 PR。
- [ ] `npm run typecheck` 通过。
- [ ] `npm run test` 通过。
- [ ] `npm run seed:test-data` 通过。
- [ ] `npm run validate:test-data` 通过。
- [ ] `npm run preflight:nas-test` 通过。
- [ ] 不使用真实司机资料。
- [ ] 不使用真实付款截图。
- [ ] 不使用真实合同扫描件。
- [ ] 不使用真实 IOPGPS 密钥。

## 第一阶段：NocoBase 基础环境 Smoke Test

- [ ] `docker-compose.test.yml` 是原始 YAML，不是 GitHub HTML 页面。
- [ ] `.env.test` 是从 `.env.test.example` 复制得到。
- [ ] PostgreSQL 容器启动。
- [ ] NocoBase 容器启动。
- [ ] 浏览器可访问 `http://NAS_IP:13000`。
- [ ] 管理员账号可初始化。
- [ ] `storage-test/nocobase` 存在且作为 NocoBase storage 挂载正常。
- [ ] `storage-test/postgres` 存在且作为 PostgreSQL 数据目录挂载正常。
- [ ] `templates` 目录为只读挂载或明确为测试模板目录。
- [ ] NocoBase 容器挂载 `storage-test/nocobase`。
- [ ] PostgreSQL 容器挂载 `storage-test/postgres`。
- [ ] `packages/plugins` 没有直接挂载到 NocoBase 容器。
- [ ] 当前测试只验证基础环境，不验证插件自动启用。
- [ ] 没有真实密钥、真实司机数据、真实付款截图、真实合同扫描件。
- [ ] 容器日志无严重错误。

## 第二阶段：插件接入准备 Smoke Test

- [ ] 三个插件结构检查通过。
- [ ] `pluginRegistration` 检查通过。
- [ ] 插件接入顺序明确。
- [ ] 当前不直接在生产库启用插件。
- [ ] 当前不使用真实 IOPGPS。

## 第三阶段：测试数据 Smoke Test

- [ ] `seed-test-data` 生成 mock 数据。
- [ ] `validate-test-data` 校验通过。
- [ ] 没有短租 `booking` / `reservation` 数据。
- [ ] 没有单日超付数据。
- [ ] 押金没有计入租金收入。
- [ ] GPS 数据没有参与租金计算。

## 第四阶段：后续插件集成 Smoke Test，预留

后续真实接入后才测试：

- [ ] Collection 注册。
- [ ] 服务方法调用。
- [ ] 台账生成。
- [ ] 付款禁止超付。
- [ ] 押金。
- [ ] 权限过滤。
- [ ] 合同文件状态。
- [ ] IOPGPS mock 同步。

## 失败处理

- 查看 `docker logs` 或 `docker compose logs`。
- 停止测试环境。
- 恢复备份。
- 清理 `storage-test`。
- 不要在生产环境继续试错。
- 不要把真实数据复制到测试仓库。

## 自动化 Smoke Test dry-run 报告检查

在进行任何真实 NAS 环境操作前，应先在本地执行 `npm run smoke:dry-run`，再执行 `npm run validate:smoke-report`。检查 `test-data/generated/automated-smoke-test-report.generated.json` 与 Markdown 报告，确认 Collection、Runtime、页面初始化、mock 测试数据导入和 NAS 文件预检均通过或明确跳过。该步骤不连接真实 NAS 服务，也不代表正式上线测试已经完成。
