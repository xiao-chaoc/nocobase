# Collection 自动注册 dry-run 草案

## 1. 当前实现范围

本轮实现的是 **Collection 自动注册 dry-run 草案**，用于在真实接入 NocoBase 之前验证 Collection 注册计划是否完整、一致、安全。

当前只做以下事情：

- 从自动化注册计划中提取 Collection plans。
- 标准化字段、索引、唯一约束、关系和敏感字段描述。
- 校验关键 Collections 是否齐全。
- 校验关键唯一约束是否齐全。
- 校验敏感字段是否被标记。
- 使用内存 mock adapter 模拟注册步骤。
- 输出结构化 dry-run 结果。

## 2. 当前不会做什么

当前不会：

- 连接真实 NocoBase。
- 创建真实数据库表。
- 执行真实 migration。
- 安装真实插件。
- 创建页面、菜单或区块。
- 初始化真实权限。
- 导入真实或 mock 数据到数据库。
- 调用真实 IOPGPS。
- 生成真实合同文件。
- 上传真实文件。

因此，本阶段仍不能正式上线测试，更不能生产上线。

## 3. 目标

本阶段目标是验证 Collection 计划完整性，确保后续真实 adapter 接入前已经具备以下基础：

- Collection 名称、标题和字段存在。
- 关系字段有目标 Collection。
- 关键唯一约束明确。
- 敏感字段被标记。
- 不包含短租、司机登录、按车型出租逻辑。
- GPS 数据不参与租金计算。
- 押金不作为租金收入。

## 4. 后续真实 NocoBase adapter 需要实现的方法

真实 adapter 后续需要实现 `NocobaseCollectionAdapter`，至少包括：

- `checkCollectionExists(collectionName)`：检查目标 NocoBase 中 Collection 是否已存在。
- `validateCollectionPlan(collectionPlan)`：结合目标 NocoBase 版本校验 Collection 定义。
- `registerCollection(collectionPlan)`：真实注册单个 Collection 或执行 migration。
- `registerCollections(collectionPlans)`：按顺序批量注册 Collections。
- `ensureIndexes(collectionPlan)`：创建索引。
- `ensureUniqueConstraints(collectionPlan)`：创建唯一约束或服务端唯一校验。
- `ensureRelations(collectionPlan)`：创建关系字段或外键关系。
- `markSensitiveFields(collectionPlan)`：注册敏感字段策略。

这些方法必须在完整 NocoBase 工程和明确版本中实现，不能伪造不确定的 NocoBase API。

## 5. 自动注册 Collections 的顺序

Collection 注册顺序应跟随插件依赖顺序：

1. `plugin-rental-core`
   - `drivers`
   - `vehicles`
   - `lease_contracts`
   - `contract_billing_weeks`
   - `rent_daily_ledgers`
   - `rent_payments`
   - `rent_payment_allocations`
   - `rent_adjustments`
   - `deposit_records`
   - `operation_logs`
2. `plugin-contract-documents`
   - `contract_templates`
   - `contract_documents`
3. `plugin-iopgps`
   - `gps_devices`
   - `gps_device_bindings`
   - `gps_location_snapshots`
   - `gps_daily_mileages`
   - `gps_device_status_logs`
   - `iopgps_settings`

`plugin-rental-core` 不依赖 GPS 或合同文件；GPS 失败不能影响租金台账和付款。

## 6. 关键唯一约束

必须保留的关键唯一约束包括：

- `drivers.driver_no`
- `vehicles.vehicle_no`
- `vehicles.plate_no`
- `lease_contracts.contract_no`
- `rent_daily_ledgers.contract_id + rent_date`
- `rent_payments.payment_no`
- `deposit_records.deposit_no`
- `gps_devices.imei`
- `gps_daily_mileages.device_id + mileage_date`
- `contract_templates.template_no`
- `contract_documents.document_no`

这些约束后续必须转为真实 NocoBase Collection 约束、数据库索引或服务端校验。

## 7. 敏感字段标记

必须标记的敏感字段包括：

- `drivers.id_no`
- `drivers.id_front_file`
- `drivers.id_back_file`
- `drivers.license_front_file`
- `drivers.license_back_file`
- `rent_payments.screenshot_file`
- `rent_payments.method`
- `deposit_records.required_amount`
- `deposit_records.received_amount`
- `deposit_records.screenshot_file`
- `iopgps_settings.login_key_encrypted`
- `iopgps_settings.access_token`
- `contract_documents.signed_scan_file`
- `contract_documents.generated_docx_file`
- `contract_documents.generated_pdf_file`

敏感字段不能只靠前端隐藏，后续必须接入服务端权限控制。

## 8. 为什么用户不需要手动建表

用户不需要在 NocoBase UI 中手动创建 Collections。后续应由插件、migration 或初始化脚本自动完成 Collection 注册、字段配置、关系配置、唯一约束和敏感字段策略。

手动建表会带来字段不一致、索引遗漏、权限遗漏和测试不可重复的问题，因此正式上线测试必须等待自动化接入完成。

## 9. 可运行命令

```bash
npm run generate:registration-plan
npm run validate:registration-plan
npm run dry-run:register-collections
npm run validate:collection-registration
```

这些命令只生成和验证文件级 dry-run 结果，不连接真实 NocoBase，也不写数据库。

## 10. 当前仍不能正式上线测试

当前只是 Collection dry-run 注册草案。真实 NocoBase 中还没有安装插件、没有真实注册 Collections、没有页面、没有权限、没有测试数据导入、没有 smoke test 执行结果，因此不能进入正式上线测试。

## 11. 进入下一阶段的条件

进入下一阶段前应满足：

- `npm run typecheck` 通过。
- `npm run test` 通过。
- `npm run generate:registration-plan` 通过。
- `npm run validate:registration-plan` 通过。
- `npm run dry-run:register-collections` 通过。
- `npm run validate:collection-registration` 通过。
- 明确目标 NocoBase 版本。
- 在完整 NocoBase 工程中确认真实 Collection adapter 的接入方式。
