# 测试环境规划

## 为什么现在不建议部署生产

当前仓库不是完整 NocoBase 应用，三个插件仍是待接入真实 NocoBase 工程的源码骨架。当前尚未完成真实插件注册、Collection 迁移、服务端权限、文件存储、定时任务、工作流和构建验证，因此不能直接部署到生产 NAS。

## 当前可以测试的内容

- 每日台账日期和金额纯函数。
- 付款分配与单日超付校验纯函数。
- 未付原因、欠款、争议、免除和冲正纯函数。
- 押金创建、抵扣、退款、免除纯函数。
- 操作日志脱敏纯函数。
- 合同财务汇总和司机日历汇总纯函数。
- 敏感字段权限过滤纯函数。
- IOPGPS token 状态、状态归一化、定位快照、每日里程、错误日志纯函数。
- 合同模板选择、合同文件状态流转、打印和扫描件状态纯函数。

## 当前不能完整测试的 NocoBase 功能

- 插件真实启用和生命周期钩子。
- Collection 注册和数据库迁移。
- NocoBase 权限系统与菜单/页面配置。
- 服务端事务和数据库回滚。
- 文件上传、文件访问权限和合同 PDF/Word 生成。
- IOPGPS 真实 HTTP 调用和定时任务。
- 工作流触发和生产日志采集。

## 后续本地测试推荐路径

1. 准备完整 NocoBase 源码工程。
2. 将三个插件放入真实工程的 `packages/plugins`。
3. 按真实工程安装依赖。
4. 启动测试 PostgreSQL。
5. 将 Collection 草案转换为真实定义或迁移。
6. 启用插件。
7. 创建测试司机、测试车辆、测试合同和测试台账。
8. 使用测试付款、测试押金、GPS mock 数据验证服务端动作。

## 后续 NAS 测试推荐路径

1. 先运行原生 NocoBase + PostgreSQL 测试实例。
2. 再接入已构建插件包，不直接使用生产库。
3. 使用测试数据，不连接真实 IOPGPS。
4. 验证插件启用、Collection、权限、日志和回滚。
5. 通过后再评估是否创建生产部署方案。

## 当前阶段不创建 `docker-compose.yml` 的原因

当前还没有确认真实 NocoBase 版本、插件构建格式、数据库迁移规范和运行时插件安装流程。此时创建生产 Docker 编排文件容易误导为可直接部署，因此本轮不创建真实 Docker 部署文件。

## 什么时候再创建 `docker-compose.test.yml`

当完成以下事项后，可以创建仅用于测试的 `docker-compose.test.yml`：

- 已确认 NocoBase 版本。
- 插件能在完整 NocoBase 工程中构建。
- Collection 定义和迁移规范已确定。
- 测试数据库、APP_KEY 和测试数据方案已确定。
- 明确不会连接真实 IOPGPS，不会使用真实司机、付款截图或合同扫描件。

## 测试数据建议

- 测试司机：使用虚构姓名和虚构证件号。
- 测试车辆：使用测试车牌和测试 VIN。
- 测试合同：覆盖长租和 6 个月以上时限合同。
- 测试每日台账：覆盖应收日、免租日、未来应收、取消日。
- 测试付款：覆盖单日付款、多日付款、超付失败、冲正。
- 测试押金：覆盖未收、已收、抵扣、退款、免除。
- 测试 GPS mock 数据：覆盖移动、静止、离线、低电、断电、故障和 API 失败。

## 当前可运行测试方式

本轮新增的根目录测试配置只用于纯函数测试：

- 不依赖真实 NocoBase。
- 不连接真实数据库。
- 不调用真实 IOPGPS。
- 不生成真实 Word/PDF 合同文件。
- 不上传真实文件。
- 不创建真实司机、车辆、付款截图或合同扫描件。

推荐在当前骨架阶段运行：

```bash
npm run typecheck
npm run test
```

这些测试不能替代后续 NocoBase 集成测试。真实接入后仍需验证 Collection 注册、插件启用、服务端权限、数据库事务、文件存储、定时任务和工作流触发。


## 本轮最小质量门禁状态

当前根目录已经具备最小质量门禁：

- `npm run typecheck`：已通过，用于检查 `packages/plugins/*/src/server/**/*.ts` 和 `tests/**/*.ts`。
- `npm run test`：已通过，会编译测试到 `.test-dist`，再运行最小测试 runner。
- 当前纯函数测试数量：45 个。
- 覆盖模块：rental-core、plugin-iopgps、plugin-contract-documents。

这些门禁仍然不是 NocoBase 集成测试，不能验证真实插件生命周期、数据库迁移、权限系统、文件存储、定时任务或工作流。后续接入真实 NocoBase 工程后，仍必须补充集成测试。

## 插件注册草案测试补充

当前新增的插件注册草案测试只检查结构化描述对象，不接真实 NocoBase：

- 验证三个插件都有 `pluginRegistration` 描述。
- 验证插件依赖关系和启用边界。
- 验证权限、定时任务、动作草案存在且不执行真实任务。
- 验证 GPS 与合同文件插件的失败隔离说明。

后续真实接入后，仍需在完整 NocoBase 工程中验证生命周期注册、Collection 元数据、服务动作、权限、i18n、scheduler/workflow 和回滚。

## mock 测试数据补充

当前可以通过 `npm run seed:test-data` 生成本地 JSON mock 数据，通过 `npm run validate:test-data` 校验数据一致性，通过 `npm run clear:test-data` 清理 `test-data/generated/*.json`。这些脚本只处理本地文件，不连接 NocoBase、不连接数据库、不调用 IOPGPS、不生成真实合同文件。

mock 数据可作为后续 NocoBase 集成测试的导入输入，但导入前必须人工确认数据内容，并单独实现导入适配器。当前阶段仍不建议直接部署生产，也不应把 generated 数据当作真实业务数据。

## Synology NAS 测试部署准备补充

当前新增 `docker-compose.test.yml` 和 `.env.test.example`，仅用于测试环境验证 NocoBase、PostgreSQL、storage 挂载和模板目录挂载。该 Compose 文件不是生产部署文件，也不表示插件已经在容器内自动可用。

NAS 测试前需要人工完成：复制 `.env.test.example` 为 `.env.test`、填写测试专用密码和 `APP_KEY`、确认端口 `13000` 未被占用、确认 `storage-test` / `backups-test` / `logs-test` / `templates` 为测试目录，并确认没有真实司机资料、付款截图、合同扫描件或 IOPGPS 密钥。

详细步骤见 `docs/deployment-nas-test.md`；插件接入测试步骤见 `docs/plugin-install-test.md`。

## NAS 测试前最终自检补充

本轮新增以下测试前准备文件：

- `docs/plugin-package-test.md`
- `docs/nas-smoke-test-checklist.md`
- `docs/nas-test-runbook.md`
- `scripts/check-plugin-structure.ts`
- `scripts/check-plugin-registration.ts`
- `scripts/preflight-nas-test.ts`

这些文件用于人工 NAS 测试前的最终自检，不做真实部署，不连接数据库，不调用 IOPGPS，不生成真实合同文件。通过这些检查后，下一步应是人工准备 NAS 测试目录和 `.env.test`，而不是继续扩大业务功能范围。

## NAS 测试目录分离修正补充

NAS 测试 Compose 的运行目录必须把 NocoBase storage 和 PostgreSQL 数据目录分离：`storage-test/nocobase` 只用于 NocoBase storage，`storage-test/postgres` 只用于 PostgreSQL 测试数据库文件。不要再使用 `./storage-test:/app/nocobase/storage` 这类整体挂载，也不要把 PostgreSQL 数据目录放进 NocoBase storage 根目录。

当前测试 Compose 不直接挂载 `packages/plugins`，不能证明插件已经自动启用。插件接入仍需后续在真实 NocoBase 工程或插件安装流程中验证。复制测试文件时推荐在 NAS 上直接 `git clone` 仓库；如手动下载，必须使用 GitHub Raw 原始内容，不要保存 GitHub HTML 页面。

## 自动化正式上线测试路线补充

后续不走手动搭建 MVP，不要求用户在 NocoBase UI 中手动创建 Collections、页面、菜单、权限或测试数据。正式上线测试前，所有 Collections、页面、权限和测试数据都应由插件、migration、初始化脚本和导入脚本自动完成。

用户只负责：合并 PR、创建 `.env.test`、启动 NAS 测试环境、检查自动化测试报告、决定是否进入 UAT。Codex 后续负责生成插件接入代码、初始化脚本、测试脚本和部署测试文档。

当前 NAS 环境只是基础空 NocoBase 测试环境，不能用于正式上线测试。下一阶段应推进“插件真实 NocoBase 化”，而不是手动 UI 搭建。详细路线见 `docs/automated-go-live-test-roadmap.md`。
