# NocoBase 目标版本确认输入 Schema

本文件定义目标版本人工确认后的推荐输入格式。该输入只用于版本冻结与下一阶段任务准备，不包含密码、不包含 `APP_KEY`、不包含 `DB_PASSWORD`、不包含真实 IOPGPS 密钥。

## 推荐 JSON 输入格式

```json
{
  "decision_status": "confirmed",
  "target_version": "请用户填写",
  "source_type": "tag | branch | docker_image | release",
  "source_reference": "请用户填写",
  "package_manager": "npm | yarn | pnpm",
  "node_version": "请用户填写",
  "database": "postgresql",
  "deployment_mode": "source_host | docker_host | plugin_package",
  "plugin_development_mode": "packages_plugins | storage_plugins",
  "plugin_install_mode": "请用户填写",
  "iopgps_real_sync_allowed": false,
  "mock_data_only": true,
  "confirmed_by": "请用户填写",
  "confirmed_at": "YYYY-MM-DD"
}
```

## 字段校验规则

| 字段 | 规则 |
| --- | --- |
| `decision_status` | 必须是 `confirmed`。 |
| `target_version` | 不能为空，不能是 `unset`，不能是 `latest-full`。 |
| `source_type` | 必须是 `tag`、`branch`、`docker_image`、`release` 之一。 |
| `source_reference` | 不能为空。 |
| `package_manager` | 必须是 `npm`、`yarn`、`pnpm` 之一。 |
| `iopgps_real_sync_allowed` | 必须为 `false`。 |
| `mock_data_only` | 必须为 `true`。 |
| `database` | 必须为 `postgresql`。 |
| `plugin_install_mode` | 不能为空。 |
| `confirmed_by` | 不能为空。 |
| `confirmed_at` | 不能为空。 |


## 当前 v2.0.61 接入基准

当前已确认的 NocoBase v2.0.61 宿主工程接入基准为 `package_manager = yarn`。Schema 仍保留 `npm`、`yarn`、`pnpm` 枚举用于未来其他目标版本确认，但本次 v2.0.61 宿主工程实际检测为 `yarn`，不得把 `pnpm` 写成当前默认值。


## 安全边界

- 不包含密码。
- 不包含 `APP_KEY`。
- 不包含 `DB_PASSWORD`。
- 不包含真实 IOPGPS 密钥。
- 不读取 `.env`。
- 不读取 `.env.test`。
- 不连接 NocoBase。
- 不访问外部网络。
- 不写数据库。

## 下一阶段输入要求

用户提供符合本 Schema 的确认信息后，才允许更新 `docs/nocobase-target-version-decision.md`，并启动完整 NocoBase 宿主工程接入任务。目标版本未确认前不得实现真实 adapter。

## 本轮新增校验脚本

本轮新增 `scripts/nocobase/validate-target-version-input.ts`，用于校验用户填写的 `filled.json`。该脚本要求 `decision_status = confirmed`、`target_version` 不能为 `unset` 或 `latest-full`、`database = postgresql`、`iopgps_real_sync_allowed = false`、`mock_data_only = true`，并拒绝 `APP_KEY`、`DB_PASSWORD`、`INIT_ROOT_PASSWORD`、`IOPGPS_LOGIN_KEY`、`access_token`、`login_key` 和任何密码字段。

本轮保留 `scripts/nocobase/apply-target-version-confirmation.ts`，默认 dry-run，不写文件；只有传入 `--execute` 才允许更新 `docs/nocobase-target-version-decision.md`。当前 v2.0.61 已确认后，`validate:target-version-confirmation` 与 `validate:can-start-real-adapter` 应通过，但只表示可进入下一轮完整宿主工程接入准备，当前仍不能正式上线测试，仍不能生产部署。

## GitHub Issue 到 filled.json 的映射

GitHub Issue 只负责收集人工确认字段，不会自动修改 decision 文件。操作者必须把 Issue 中的非敏感字段复制到 `test-data/generated/nocobase-target-version-confirmation.filled.json`，再运行 `validate:target-version-input` 与 apply 脚本。Issue、`filled.json` 和 PR 均不得包含密码、`APP_KEY`、`DB_PASSWORD`、`IOPGPS_LOGIN_KEY`、生产库连接或真实业务文件。

当前目标版本已确认为 `v2.0.61`，当前包管理器基准为 `yarn`。即使门禁脚本通过，仍不允许生产部署；必须先完成插件与 shared automation 复制、环境检测 adapter 验证和隔离测试准备。
