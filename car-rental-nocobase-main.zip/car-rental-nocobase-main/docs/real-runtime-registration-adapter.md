# 真实 Runtime 注册 Adapter 草案

## 本轮范围

本轮实现的是“真实 Runtime 注册 adapter 草案”，用于把现有 runtime dry-run 计划转换为真实 NocoBase 接入前可审查的 schema draft、注册步骤、回滚计划和后置验证计划。

Runtime 范围包括：

1. 服务方法注册草案。
2. 动作注册草案。
3. 权限注册草案。
4. i18n 注册草案。
5. 定时任务注册草案。

## 当前明确不执行的事项

当前仓库仍不是完整 NocoBase 工程，因此本轮明确不执行：

- 不连接真实 NocoBase。
- 不注册真实服务。
- 不注册真实按钮。
- 不注册真实权限。
- 不注册真实定时任务。
- 不加载真实 i18n。
- 不写数据库。
- 不调用或伪造 `app.acl`、`app.router`、`app.command`、`app.i18n`、`app.scheduler`、`workflow` 等真实 API。

## 本轮产物

本轮新增真实 Runtime schema mapper、安全检查器和 adapter 草案。adapter 只基于输入的 runtime plans 生成：

- 服务 schema draft。
- 动作 schema draft。
- 权限 schema draft。
- i18n schema draft。
- 定时任务 schema draft。
- 注册步骤草案。
- 回滚计划。
- 后置验证计划。
- 中文 warnings/errors。

## 服务注册策略

服务草案保留 `name`、`sourcePlugin`、`handlerName`、`permissions` 和 `transactional`。事务服务会被标记为后续必须接入真实数据库事务。当前不新增服务、不删除权限要求、不调用真实服务注册机制。

未来真实 adapter 需要在完整 NocoBase 工程中确认目标版本服务注册机制，并将事务服务放入真实 `db` transaction 边界内。

## 动作注册策略

动作草案保留 `name`、`title`、`sourcePlugin`、`serviceName`、`requiredPermissions`、`inputSchema` 和 `outputSchema`，并推导 `confirmationRequired` 与 `danger` 草案标记。

当前只记录按钮、API、action、command、route 绑定方式仍待确认，不注册真实按钮、不注册真实 API。

未来真实 adapter 需要接入真实 action / command / route 机制，并确保动作权限在服务端校验，不能只靠前端按钮隐藏。

## 权限注册策略

权限草案保留角色、Collection、动作、字段可见性和敏感字段。付款截图、总已付、未来应收、押金和财务汇总必须做服务端权限控制。

当前不注册真实 ACL、不写权限表、不创建真实角色。未来真实 adapter 必须接入真实 NocoBase ACL、字段级权限、脱敏和导出控制。

## 定时任务注册策略

定时任务草案保留 `name`、`title`、`sourcePlugin`、`cron`、`enabledByDefault` 和 `serviceName`。IOPGPS 相关定时任务默认不能真实启用，并必须保持失败隔离：IOPGPS 同步失败不能影响租金台账和付款逻辑。

当前不注册真实 scheduler、不启动定时任务。未来真实 adapter 需要接入目标版本 scheduler API、启停策略、失败隔离、错误日志和人工启用流程。

## i18n 注册策略

i18n 草案保留 `namespace`、`sourcePlugin`、`languages` 和 `localeFiles`。每个命名空间必须支持 `zh-CN`、`en-US`、`fr-FR`。

当前不加载真实 i18n。未来真实 adapter 需要接入目标版本多语言资源加载机制，并验证界面和合同语言切换。

## 安全检查要求

安全检查器会检查：

- `mode` 不能默认为 `real`。
- `real` 模式必须显式 `allowRealExecution = true`。
- `real` 模式必须要求备份和回滚计划。
- adapter 环境必须为 `ready` 才能考虑真实执行。
- 当前仓库环境下禁止执行 `real`。
- 不允许真实执行服务、动作、权限、定时任务或 i18n 注册。
- 不允许缺少 rollbackPlan。
- 不允许真实生产环境执行。
- IOPGPS 定时任务默认不能真实启用。
- 不允许短租、司机登录、客户门户、按车型出租、GPS 参与租金计算、押金计入租金已付等禁用边界。

## 为什么当前仓库不能执行 real 模式

当前仓库缺少完整 NocoBase `app`、`db`、ACL、i18n loader、scheduler、workflow、action/route/command、插件生命周期、真实日志和隔离数据库上下文。直接执行 real 模式会形成伪造接入风险，也可能误导上线判断。因此当前仓库必须保持 `plan_only`、`validate_only` 或 `dry_run`，不得标记为可正式上线测试。

## 未来真实 adapter 如何替换

进入真实接入阶段时，需要在完整 NocoBase 工程中逐项替换草案边界：

1. 接入真实服务注册机制。
2. 接入真实 ACL 和字段级权限。
3. 接入真实 i18n 资源加载机制。
4. 接入真实 scheduler。
5. 接入真实 action / command / route 机制。
6. 接入备份、回滚、后置验证和审计日志。

## 进入下一阶段的条件

下一阶段开始前至少需要满足：

- 当前类型检查、测试、生成脚本和校验脚本通过。
- 真实 Runtime 草案文档、schema draft、安全检查和脚本已完成。
- 已准备完整 NocoBase 工程和目标版本 API 文档。
- 已准备隔离测试数据库、备份和回滚演练方案。
- 已确认不会在当前仓库或生产环境执行 `real` 模式。
