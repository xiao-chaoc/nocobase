# 下一阶段任务：真实环境检测 adapter v2.0.61

## 任务状态

- target_version = v2.0.61
- package_manager = yarn
- database = postgresql
- deployment_mode = source_host
- plugin_development_mode = packages_plugins
- plugin_install_mode = packages_plugins
- iopgps_real_sync_allowed = false
- mock_data_only = true

## 任务目标

在完整 NocoBase v2.0.61 工程中实现真实环境检测 adapter。该任务必须在独立 NocoBase host 工程中执行，当前仓库仍不包含完整 NocoBase 源码，不在当前仓库 clone NocoBase 源码，不提交完整 NocoBase 源码。

## 需要确认的能力

- `app`
- `db`
- `logger`
- `storage`
- `pluginManager`
- `acl`
- `uiSchema`
- `scheduler`
- `workflow`
- `i18n`
- collection manager
- file storage
- template printing capability

## 输出

- 环境检测报告。
- 能力矩阵。
- 阻塞项。
- 下一阶段是否可以实现 Collection adapter。

## 禁止事项

- 不创建 Collection。
- 不写数据库。
- 不注册权限。
- 不创建页面。
- 不导入数据。
- 不启用真实 IOPGPS。
- 不复制 `.env`，不复制 `.env.test`，不复制 `filled.json`。
- 不使用生产库，不在生产库验证，不在生产库调试。
- 当前不能 production_ready，当前仍不能正式上线测试，当前仍不能生产部署。

## 验收边界

- adapter 只能读取运行时能力并生成报告。
- 不伪造 NocoBase API，不用不确定 API 写成已验证。
- 如果任一核心能力缺失，必须输出阻塞项，不得进入 Collection adapter。
