# 真实 Smoke Test Adapter 草案

## 本轮范围

本轮实现的是真实 Smoke Test adapter 草案，而不是正式 smoke test 执行器。当前草案只把已有真实 Collection 注册草案、真实 Runtime 注册草案、真实 Page 注册草案、真实 Seed Data Import 草案转换为统一的 smoke test plan、步骤、失败隔离计划、回滚验证计划和报告草案。

当前明确不做以下动作：

- 不连接真实 NocoBase。
- 不执行真实 smoke test。
- 不写数据库。
- 不调用 IOPGPS。
- 不生成合同文件。
- 不上传文件。
- 不调用真实权限系统。
- 不伪造任何 NocoBase API 成功。

## 草案产物

本轮草案产物包括：

1. 真实环境前置检查草案。
2. Collection 注册验证草案。
3. Runtime 注册验证草案。
4. Page 注册验证草案。
5. Seed Data 导入验证草案。
6. 核心业务流程 smoke test 草案。
7. 权限 smoke test 草案。
8. GPS mock smoke test 草案。
9. 合同文件 smoke test 草案。
10. 失败隔离与回滚验证草案。
11. Smoke Test 报告草案。

## Smoke Test 阶段说明

| 阶段 | 说明 |
| --- | --- |
| environment_check | 检查 adapter 环境状态、执行模式、备份、隔离数据库、mock 数据和 IOPGPS 禁用要求。 |
| plugin_installation_check | 只规划插件安装结果校验，不安装真实插件。 |
| collection_registration_check | 校验关键 Collection、唯一约束、敏感字段、relation 和业务边界。 |
| runtime_registration_check | 校验核心服务、动作、六个角色、三语言和敏感字段权限策略。 |
| page_registration_check | 校验司机、车辆、合同、台账、日历、付款、押金、合同文件和 GPS 页面草案。 |
| seed_data_import_check | 校验导入顺序、引用完整性、唯一键、单日不可超付、押金与 GPS 规则以及无真实敏感数据。 |
| core_business_flow_check | 规划合同、台账、付款、欠款、免租日和押金核心业务验证。 |
| permission_check | 规划敏感字段、付款截图、财务汇总、GPS 维护等权限验证。 |
| contract_document_check | 规划合同文件生成失败不影响付款和台账的验证。 |
| gps_mock_check | 规划 IOPGPS mock 失败不影响租金台账和付款逻辑的验证。 |
| failure_isolation_check | 规划外部失败、文件失败、页面失败和导入失败隔离。 |
| rollback_check | 规划超付、导入失败、页面初始化失败等回滚验证。 |
| report_generation | 规划报告草案输出，不声明真实测试成功。 |

## 核心业务测试策略

核心业务 smoke test 草案以每日租金台账作为唯一事实来源，覆盖时限合同完整台账生成、长租合同未来台账生成、默认免租日、付款分配到具体日期、单日不可超付、任一日期超付导致整笔付款失败、未付原因必填、部分付款剩余状态、付款冲正、押金收取抵扣退还、押金不计入租金收入、当前欠款只统计截至当前日期以及未来应收不计入当前欠款。

## 权限测试策略

权限 smoke test 草案只验证计划边界，不调用真实权限系统。当前规划要求 operator 不能查看付款截图，gps_maintenance 不能查看财务汇总，敏感字段必须隐藏或脱敏，总已付、未来应收、押金和付款截图必须按角色控制。

## GPS mock 测试策略

GPS mock smoke test 草案要求 IOPGPS 定时任务默认不真实启用，IOPGPS 同步失败不能影响租金台账和付款逻辑，GPS 数据不得参与租金计算。当前不调用真实 IOPGPS API，也不保存真实设备凭据。

## 合同文件测试策略

合同文件 smoke test 草案只规划合同生成、上传和失败隔离验证，不生成真实合同文件、不上传真实扫描件。合同文件生成失败不得影响付款和每日租金台账。

## 失败隔离策略

失败隔离草案覆盖 IOPGPS 同步失败、合同文件生成失败、付款超付失败、测试数据导入失败和页面初始化失败。每项只生成验证步骤，不执行真实事务。

## 回滚验证策略

回滚验证草案要求付款超付失败必须整体回滚，测试数据导入失败必须可回滚，页面初始化失败不能污染已成功注册的核心数据结构。当前只输出回滚验证计划，不写数据库。

## 未来真实 adapter 替换路径

未来真实 adapter 需要在下一阶段逐步替换以下边界：

1. 接入真实 NocoBase 测试环境，并确认它不是生产环境。
2. 接入真实插件安装结果。
3. 接入真实 Collection、Runtime、Page、Seed Data adapter 执行结果。
4. 接入真实业务动作，但必须使用 mock 数据。
5. 接入真实权限检查。
6. 接入真实失败回滚验证。
7. 生成真实测试报告，但不得把当前仓库直接标记为 production_ready。

## 为什么当前不能执行 real 模式

当前仓库没有真实隔离 NocoBase 测试环境证明，没有真实备份和回滚演练结果，没有真实插件安装结果，没有真实权限执行结果，也没有真实业务事务隔离证明。为了避免误写数据库、误调用 IOPGPS、误上传真实文件或伪造 API 成功，`real` 模式在当前仓库必须被安全检查器和 adapter 同时阻断。

## 进入下一阶段的条件

进入下一阶段前至少需要：

1. 独立 NocoBase 测试环境 ready。
2. 明确不是生产环境。
3. 已完成备份和回滚演练。
4. 使用 mock 数据且确认无真实司机资料、付款截图、合同扫描件或 IOPGPS 凭据。
5. 真实 IOPGPS 关闭或替换为 mock。
6. 插件安装、Collection、Runtime、Page、Seed Data 草案均通过校验。
7. 明确真实执行审批人和执行窗口。
