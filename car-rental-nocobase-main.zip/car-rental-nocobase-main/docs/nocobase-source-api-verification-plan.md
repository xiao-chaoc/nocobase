# NocoBase 源码 API 验证计划

## 为什么需要在完整 NocoBase 工程中验证 API

当前仓库只保存汽车租赁业务插件、自动化 dry-run 和真实 adapter 草案，不是完整 NocoBase 宿主工程。真实插件 API 需要依赖固定的 NocoBase 目标版本、源码结构、运行时插件加载流程和实际启用插件集合。

因此，必须在完整 NocoBase 工程中验证 API。未确认目标版本前，不应实现真实 adapter；不确定 API 必须标记为 `unknown` 或待验证，不能硬写、不能伪造、不能在当前仓库实现真实调用。

## API 验证矩阵

| API 区域 | 源码位置 | 文档位置 | 最小示例 | 是否支持插件内自动化 | 是否支持回滚 | 风险 | 结论 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Plugin lifecycle | `unknown` | `unknown` | `unknown` | `unknown` | `unknown` | 生命周期钩子变化会影响全部插件启动。 | 待完整宿主工程验证。 |
| Server plugin entry | `unknown` | `unknown` | `unknown` | `unknown` | `unknown` | 服务端入口签名不一致会导致插件无法加载。 | 待完整宿主工程验证。 |
| Client plugin entry | `unknown` | `unknown` | `unknown` | `unknown` | `unknown` | 客户端入口变化会影响页面、菜单、区块注册。 | 待完整宿主工程验证。 |
| Collection manager | `unknown` | `unknown` | `unknown` | `unknown` | `unknown` | Collection 注册方式变化会影响每日租金台账事实来源。 | 待完整宿主工程验证。 |
| Field types | `unknown` | `unknown` | `unknown` | `unknown` | `unknown` | 字段类型不匹配会导致金额、日期、状态字段错误。 | 待完整宿主工程验证。 |
| Relations | `unknown` | `unknown` | `unknown` | `unknown` | `unknown` | 合同、车牌、司机、台账关系错误会破坏业务一致性。 | 待完整宿主工程验证。 |
| Index / unique constraints | `unknown` | `unknown` | `unknown` | `unknown` | `unknown` | 唯一约束错误会导致车牌合同冲突无法拦截。 | 待完整宿主工程验证。 |
| Migration | `unknown` | `unknown` | `unknown` | `unknown` | `unknown` | 迁移不可回滚会阻断测试库恢复。 | 待完整宿主工程验证。 |
| ACL | `unknown` | `unknown` | `unknown` | `unknown` | `unknown` | 权限不正确会暴露总已付、未来应收、押金和付款截图。 | 待完整宿主工程验证。 |
| Resource / action / controller | `unknown` | `unknown` | `unknown` | `unknown` | `unknown` | 操作接口签名变化会影响付款分配、欠款标记和免除审批。 | 待完整宿主工程验证。 |
| UI Schema | `unknown` | `unknown` | `unknown` | `unknown` | `unknown` | 页面初始化失败会影响内部运营使用。 | 待完整宿主工程验证。 |
| Menu / page / block | `unknown` | `unknown` | `unknown` | `unknown` | `unknown` | 菜单或区块注册失败会影响业务入口。 | 待完整宿主工程验证。 |
| i18n | `unknown` | `unknown` | `unknown` | `unknown` | `unknown` | 中英法界面和合同语言可能无法加载。 | 待完整宿主工程验证。 |
| Scheduler | `unknown` | `unknown` | `unknown` | `unknown` | `unknown` | 长租未来台账生成和 GPS 同步调度可能失败。 | 待完整宿主工程验证。 |
| Workflow | `unknown` | `unknown` | `unknown` | `unknown` | `unknown` | 待审批免除、争议处理和通知流程可能不可用。 | 待完整宿主工程验证。 |
| File storage | `unknown` | `unknown` | `unknown` | `unknown` | `unknown` | 付款截图、合同扫描件和模板文件存储权限风险高。 | 待完整宿主工程验证。 |
| Template printing | `unknown` | `unknown` | `unknown` | `unknown` | `unknown` | 合同生成依赖模板打印能力，版本不匹配会阻断合同输出。 | 待完整宿主工程验证。 |
| Backup / restore | `unknown` | `unknown` | `unknown` | `unknown` | `unknown` | 无法回滚会阻断真实 adapter 测试。 | 待完整宿主工程验证。 |

## 每个 API 区域的验证要求

每个 API 区域必须记录：

- 源码位置。
- 文档位置。
- 最小示例。
- 是否支持插件内自动化。
- 是否支持回滚。
- 风险。
- 结论。

## 不确定 API 处理规则

- 不确定就标记 `unknown`。
- 不允许硬写。
- 不允许伪造。
- 不允许在当前仓库实现真实调用。
- 不允许在生产库调试。
- 不允许把 dry-run 结论写成真实接入结论。
- 不允许把 `latest-full` 写成真实接入基准。
