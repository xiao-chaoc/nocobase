# 真实 Adapter 实施顺序

## 1. 总阶段划分

真实 Adapter 实施分为 12 个阶段：

1. 确认 NocoBase 目标版本与插件 API。
2. 创建完整 NocoBase 测试工程接入分支。
3. 实现环境检测真实 adapter。
4. 实现 Collection 真实 adapter。
5. 实现 Runtime 真实 adapter。
6. 实现 Page 真实 adapter。
7. 实现 Seed Data 真实 adapter。
8. 实现 Backup / Rollback 真实 adapter。
9. 实现 Smoke Test 真实 adapter。
10. 打包插件并在 NAS 测试环境安装。
11. 执行 UAT。
12. 冻结上线测试版本。

当前仓库仅生成接入手册、实施顺序、风险清单、检查脚本和文档；不真实连接 NocoBase，不创建数据库对象，不导入数据，不备份或回滚。

## 2. 阶段明细

| 阶段 | 目标 | 需要 Codex 生成的文件 | 需要人工提供的信息 | 需要真实 NocoBase 工程验证的内容 | 每阶段命令 | 通过标准 | 失败处理 | 串行与并行关系 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 确认 NocoBase 目标版本与插件 API | 版本差异记录、API 清单、adapter 改造清单 | 目标 NocoBase 版本、部署方式、插件 API 文档来源 | Collection、ACL、UI Schema、插件生命周期、文件存储和 scheduler API | `node -v`、包管理器版本检查、目标工程依赖检查 | API 清单完整，无阻塞未知项 | 暂停真实实现，补齐版本信息 | 阻塞全部后续阶段 |
| 2 | 创建完整 NocoBase 测试工程接入分支 | 接入分支说明、目录映射、包接入说明 | 完整 NocoBase 源码工程路径、测试库连接、测试 storage 路径 | 三个插件和共享包能被目标工程识别 | 目标工程安装依赖命令、目标工程类型检查命令 | 目标工程能启动到测试环境 | 删除接入分支或恢复干净工程 | 阶段 1 后串行 |
| 3 | 实现环境检测真实 adapter | 环境检测实现、测试用例、能力报告模板 | 测试管理员账号、测试 `.env`、APP_KEY | app、db、logger、pluginManager、acl、uiSchema、storage、scheduler 能力检测 | `npm run typecheck`、目标工程环境检测命令 | 能准确输出缺失能力，不写数据库 | 回退环境检测实现 | 阻塞阶段 4 |
| 4 | 实现 Collection 真实 adapter | 字段映射实现、relation 映射、schema 校验、回滚脚本 | 目标版本字段类型、Collection API、约束能力 | 真实 Collection、字段、relation、唯一约束和索引注册 | `npm run validate:real-collection-plan`、目标工程 Collection 注册测试命令 | 隔离库注册成功且可回滚 | 恢复数据库备份，修正映射 | Collection 必须在 Runtime 之前完成 |
| 5 | 实现 Runtime 真实 adapter | 服务注册、动作注册、权限注册、i18n、定时任务实现 | 权限角色矩阵、scheduler 策略、IOPGPS 测试开关 | 服务、动作、ACL、i18n、scheduler 注册 | `npm run validate:real-runtime-plan`、目标工程 Runtime 注册测试命令 | 权限验证通过，IOPGPS 默认禁用 | 禁用插件并恢复备份 | Runtime 依赖 Collection，阻塞 Page 和 Smoke |
| 6 | 实现 Page 真实 adapter | 菜单、页面、区块、筛选器、按钮动作、收租日历页面实现 | 页面布局确认、敏感字段可见性规则 | UI Schema 兼容性、页面权限和敏感字段隐藏 | `npm run validate:real-page-plan`、目标工程页面初始化测试命令 | 页面可创建、可删除、按权限展示 | 恢复 schema snapshot | Page 依赖 Collection 和 Runtime |
| 7 | 实现 Seed Data 真实 adapter | mock 数据导入实现、事务和回滚实现 | mock 数据范围、唯一键策略、文件占位策略 | 引用完整性、唯一键冲突、事务、文件字段占位 | `npm run validate:real-seed-data-plan`、目标工程 mock 导入命令 | 只导入 mock 数据，事务可回滚 | 回滚事务或恢复数据库备份 | 可在 Page 后执行，阻塞 Smoke |
| 8 | 实现 Backup / Rollback 真实 adapter | 备份脚本、回滚脚本、日志保留说明 | 数据库备份工具、storage 路径、备份目录 | 数据库备份、storage 备份、plugin storage 备份、schema snapshot 和恢复 | `npm run validate:real-backup-rollback-plan`、目标工程备份回滚演练命令 | 可完成恢复演练 | 保留失败日志，人工恢复隔离环境 | Backup / Rollback 必须在 Smoke Test 之前完成 |
| 9 | 实现 Smoke Test 真实 adapter | smoke 用例、权限用例、GPS mock、合同文件 mock 验证 | UAT 核心流程确认、权限账号 | 合同、台账、付款、权限、GPS mock、合同文件和回滚验证 | `npm run validate:real-smoke-test-plan`、目标工程 smoke test 命令 | 核心流程全部通过，不触发真实外部 API | 运行回滚，定位失败用例 | 依赖阶段 4-8 |
| 10 | 打包插件并在 NAS 测试环境安装 | 插件包清单、安装步骤、NAS 验证记录 | NAS 测试环境路径、安装权限、测试 `.env` | 插件打包、安装、启用、禁用、卸载 | NAS 插件安装命令、`npm run preflight:nas-test` | NAS 测试环境可启动并启用插件 | 禁用插件、删除插件包、恢复 NAS 测试备份 | 依赖阶段 9 |
| 11 | 执行 UAT | UAT 用例、问题清单、签收记录 | 内部业务人员、测试排期、验收口径 | 真实用户角色下的核心流程 | UAT 执行命令或手工用例记录 | 无阻塞问题，业务确认 | 回到对应实现阶段修复 | 依赖阶段 10 |
| 12 | 冻结上线测试版本 | 版本冻结记录、变更摘要、已知问题 | 冻结版本号、部署窗口、回滚负责人 | 版本可复现、可回滚、文档完整 | 最终 readiness 命令 | 满足上线测试门槛，但不等于生产部署 | 取消冻结并补测 | 最终串行阶段 |

## 3. 最小可进入插件接入测试的条件

进入 NAS 插件接入测试前，至少需要满足：

- 目标 NocoBase 版本已确认。
- 完整 NocoBase 测试工程已能启动。
- Collection、Runtime、Page、Seed Data、Backup / Rollback、Smoke Test 真实 adapter 已在隔离工程验证。
- Backup / Rollback 在 Smoke Test 之前完成演练。
- `IOPGPS_SYNC_ENABLED=false`。
- 未使用真实司机数据、真实付款截图、真实合同扫描件、真实司机证件或真实 IOPGPS 密钥。
- 当前仓库和完整工程都没有提交 `.env` 或真实密钥。

## 4. 并行建议

- 阶段 1 和阶段 2 的准备材料可并行收集，但阶段 2 的实现必须等待目标版本确认。
- Collection 必须在 Runtime 之前，Runtime 必须在 Page 与 Smoke 之前。
- Page 布局确认可与 Seed Data mock 数据校验并行，但真实执行应在 Runtime 之后。
- Backup / Rollback 必须在 Smoke Test 之前。
- UAT 只能在 NAS 插件安装验证通过后进行。


## 2026-06-06 NocoBase 目标版本与插件 API 调研补充

本轮已新增目标版本与真实插件 API 映射调研文档：

- `docs/nocobase-target-version-research.md`
- `docs/nocobase-plugin-api-research.md`
- `docs/real-adapter-api-mapping.md`
- `docs/real-adapter-gap-analysis.md`
- `docs/real-adapter-implementation-backlog.md`

本轮结论如下：

- 下一阶段是锁定 NocoBase 目标版本和验证官方 API。
- 当前 `latest-full` 只能继续用于 NAS 基础环境测试，不能作为真实 adapter、UAT 或生产部署基准。
- 当前仍不能实现真实 adapter；未经官方 API 验证不得写真实 adapter。
- 当前不能正式上线测试，也不能生产部署。
- 任何无法确认的 NocoBase API 必须标记为待验证，不得伪造 API。
- 验证只能在完整 NocoBase 源码测试工程和隔离 PostgreSQL、隔离 storage 中进行，不得生产库调试。

## 本轮补充：实现序列前置阻断条件

真实 adapter 实现前必须先完成宿主工程接入准备，并人工确认 NocoBase 目标版本。未确认目标版本前，不应实现真实 adapter，也不应把任何不确定 API 写成已验证 API。

本轮新增的宿主工程准备材料用于下一阶段在完整 NocoBase 工程中验证 Plugin lifecycle、Collection、ACL、UI Schema、Scheduler、Workflow、文件存储、模板打印和备份恢复等 API。当前仍不能正式上线测试，当前仍不能生产部署。

## 本轮阻塞补充：目标版本未锁定

真实 adapter 实现顺序当前被目标版本确认阻塞。`decision_status` 仍为 `pending_manual_confirmation` 时，不应实现真实 Collection adapter、Runtime adapter、Page adapter、Seed Data adapter、Smoke Test adapter、Backup / Rollback adapter。

下一轮必须先取得用户人工确认的目标 NocoBase 版本和冻结字段，再启动第一个真实 adapter 阶段。当前不能正式上线测试，不能生产部署。

## 目标版本确认前置门禁

真实 adapter 实现序列的前置条件是目标 NocoBase 版本已人工确认并通过 `npm run validate:target-version-confirmation`。当前仍为 `decision_status = pending_manual_confirmation`、`target_version = unset`，因此 `npm run validate:can-start-real-adapter` 必须失败。

用户需要先填写 `test-data/generated/nocobase-target-version-confirmation.filled.json`，运行输入校验和应用 dry-run；未确认前不得实现环境检测真实 adapter、Collection 真实 adapter 或任何连接宿主工程的真实 adapter。当前仍不能正式上线测试，仍不能生产部署。

## 本轮新增前置门禁

真实 adapter 实现序列之前必须先完成目标版本确认 PR 审查。确认链路为 GitHub Issue + `filled.json` + apply 脚本 + PR 审查。当前目标版本仍为 `pending_manual_confirmation`，因此不得启动真实 adapter 编码，不得连接 NocoBase，不得写数据库。

只有 `validate:target-version-confirmation` 通过后，才允许讨论真实 adapter 最小实现任务；只有 `validate:can-start-real-adapter` 通过后，才允许进入完整宿主工程真实接入。当前仍不能正式上线测试，仍不能生产部署。

## 本轮补充：v2.0.61 adapter 实现顺序入口

> 包管理器修正：完整 NocoBase v2.0.61 宿主工程环境检测已确认当前接入基准为 `package_manager = yarn`。后续宿主工程人工命令应使用 `yarn`，不得把 `pnpm` 作为当前默认值；除非重新验证目标版本源码工程确实支持 `pnpm`。

目标版本已确认：`v2.0.61`。下一阶段是完整 NocoBase v2.0.61 宿主工程接入准备，真实 adapter 实现顺序新增前置阶段：先完成 `docs/task-real-environment-adapter-v2.0.61.md` 中定义的环境检测 adapter，再根据检测报告决定是否进入 `docs/task-real-collection-adapter-v2.0.61.md`。

新增顺序：

1. 环境检测 adapter：只检测 `app`、`db`、`logger`、`storage`、`pluginManager`、`acl`、`uiSchema`、`scheduler`、`workflow`、`i18n`、collection manager、file storage、template printing capability，不创建 Collection，不写数据库。
2. Collection adapter：仅在环境检测通过、API 与字段映射确认、已有备份、使用隔离 PostgreSQL 测试库后执行。
3. Runtime、Page、Seed Data、Smoke Test、Backup / Rollback adapter 继续保持后续阶段。

当前项目仍不包含完整 NocoBase 源码，当前仍不能正式上线测试，当前仍不能生产部署，当前不能标记为 `production_ready`。
