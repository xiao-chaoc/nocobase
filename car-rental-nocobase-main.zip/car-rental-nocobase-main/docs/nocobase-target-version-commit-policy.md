# NocoBase 目标版本确认提交规范

## 1. 允许提交的文件

目标版本确认 PR 原则上只允许提交以下文件：

- `docs/nocobase-target-version-decision.md`
- `docs/current-repository-scan.md`
- 必要的说明文档变更

如果本次 PR 是维护流程本身，也可以提交 GitHub 模板、流程校验脚本和对应测试。

## 2. 禁止提交的文件和内容

禁止提交：

- `.env`
- `.env.test`
- `filled.json`
- confirmed json
- 真实司机证件
- 真实付款截图
- 真实合同扫描件
- 真实 IOPGPS 密钥
- 完整 NocoBase 源码
- `node_modules`
- `storage-test`
- `backups-test`
- `logs-test`

禁止把 `latest-full` 写成真实接入目标版本，禁止把 `iopgps_real_sync_allowed` 改为 `true`，禁止把 `mock_data_only` 改为 `false`。

## 3. Commit message 建议

```text
确认 NocoBase 目标版本：<version>
```

如果只是维护确认流程，可使用：

```text
完善 NocoBase 目标版本确认审查流程
```

## 4. PR 标题建议

```text
确认 NocoBase 目标版本 <version>
```

如果只是维护确认流程，可使用：

```text
完善 NocoBase 目标版本确认审查流程
```

## 5. PR 内容必须包含

- `target_version`
- `source_type`
- `source_reference`
- `package_manager`
- `node_version`
- `database`
- `deployment_mode`
- `plugin_development_mode`
- `plugin_install_mode`
- `iopgps_real_sync_allowed = false`
- `mock_data_only = true`
- `confirmed_by`
- `confirmed_at`
- 执行过的命令
- 是否通过 `validate:target-version-confirmation`
- 是否通过 `validate:can-start-real-adapter`

## 6. 未确认版本时的提交边界

当前目标版本仍为 `pending_manual_confirmation` 时，只允许提交流程文档、模板、校验脚本和测试，不得修改 `target_version` 为具体版本，不得把 `decision_status` 改成 `confirmed`，不得进入真实 adapter 实现。
