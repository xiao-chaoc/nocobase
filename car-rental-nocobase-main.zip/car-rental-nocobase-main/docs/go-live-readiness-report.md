# 正式上线测试前 readiness 报告

## 目的

readiness 报告用于在正式上线测试前汇总当前仓库、dry-run 产物、NAS 测试基础文件、安全边界和真实 NocoBase adapter 准备度。它回答三个问题：当前是否仍停留在 dry-run 阶段、是否可以进入下一阶段、哪些条件会阻塞真实插件接入测试、UAT 或生产部署。

## readiness level 含义

- `dry_run_only`：只完成 dry-run 或部分 dry-run，不能进入真实插件接入测试。
- `nas_base_environment_ready`：NAS 基础测试文件与 smoke dry-run 基本齐备，可准备真实 adapter 或 NAS 基础环境验证，但仍不能真实上线。
- `plugin_integration_test_ready`：真实 NocoBase adapter 已实现并验证，可进入真实插件接入测试。
- `uat_ready`：真实插件接入测试通过，可准备 UAT。
- `production_not_ready`：已经有部分真实验证，但生产部署条件仍不完整。
- `production_ready`：真实插件安装、UAT、权限验证、备份回滚和固定版本全部通过。当前仓库不应被标记为该状态。

## Gate 含义

1. `repository_scan`：仓库扫描和关键文件检查。
2. `typecheck`：TypeScript 类型检查。
3. `unit_tests`：纯函数与脚本测试。
4. `registration_plan`：自动化注册计划生成与校验。
5. `collection_registration_dry_run`：Collection 注册 dry-run。
6. `runtime_registration_dry_run`：服务、动作、权限、定时任务、i18n dry-run。
7. `page_initialization_dry_run`：页面、菜单、区块、筛选器、按钮动作 dry-run。
8. `seed_data_generation`：mock 测试数据生成。
9. `seed_data_validation`：mock 测试数据校验。
10. `seed_data_import_dry_run`：mock 测试数据导入 dry-run。
11. `smoke_test_dry_run`：统一 smoke dry-run 报告。
12. `nas_test_files`：NAS 测试 compose、env 模板、runbook 和 smoke 清单。
13. `security_boundary`：真实密钥、真实 env、真实证件、付款截图、合同扫描件和 IOPGPS 凭据风险。
14. `forbidden_business_patterns`：短租、司机登录、按车型出租、GPS 参与租金计算、押金计入租金等禁止模式。
15. `plugin_installation_readiness`：插件结构、注册描述和依赖顺序是否适合后续安装测试。
16. `real_nocobase_adapter_readiness`：真实 NocoBase adapter 是否已经实现并验证。
17. `production_readiness`：真实安装、UAT、权限验证、备份回滚和固定版本是否全部完成。

## 阻塞范围

### 阻塞 NAS 基础环境测试的 gate

- `repository_scan`
- `registration_plan`
- `collection_registration_dry_run`
- `runtime_registration_dry_run`
- `page_initialization_dry_run`
- `seed_data_generation`
- `seed_data_validation`
- `seed_data_import_dry_run`
- `smoke_test_dry_run`
- `nas_test_files`
- `security_boundary`
- `forbidden_business_patterns`

### 阻塞真实插件接入测试的 gate

- `typecheck`
- `unit_tests`
- 所有注册与 dry-run gate
- `plugin_installation_readiness`
- `real_nocobase_adapter_readiness`
- `security_boundary`
- `forbidden_business_patterns`

### 阻塞 UAT 的 gate

- 真实 NocoBase adapter 未实现或未验证。
- 真实插件安装未执行。
- 权限、页面、测试数据导入和业务流程未在隔离 NocoBase 中验证。

### 阻塞生产部署的 gate

- `production_readiness` 未通过。
- 未完成真实插件安装、UAT、权限验证、备份回滚和固定 NocoBase 镜像版本。
- 存在任何真实密钥或真实业务数据风险。
- 存在短租、司机登录、按车型出租等禁止业务模式。

## 为什么当前不能 production_ready

当前仓库只包含插件骨架、mock adapter、dry-run 执行器、脚本和文档。它没有真实 NocoBase adapter，没有真实插件安装记录，没有 UAT 结果，没有备份回滚演练，也没有固定生产镜像版本。因此 readiness 报告必须把当前阶段标记为 dry-run 或 NAS 基础环境准备阶段，而不能标记为 `production_ready`。

## 生成器读取和校验范围

readiness 生成器会读取当前仓库文件列表、`docs/current-repository-scan.md`、`docker-compose.test.yml` 和 `test-data/generated/` 下已生成的 dry-run JSON 报告。对于注册计划、Collection、Runtime、页面初始化、测试数据导入和 smoke test，生成器不仅检查文件是否存在，也会检查报告中的 `success` 或 `validation.passed` 状态；如果文件存在但无法确认内部通过状态，会写入 warning 并要求重新生成对应 dry-run 产物。

## 如何运行

```bash
npm run generate:go-live-readiness
npm run validate:go-live-readiness
```

## 报告文件位置

- JSON：`test-data/generated/go-live-readiness-report.generated.json`
- Markdown：`test-data/generated/go-live-readiness-report.generated.md`

## 如何根据报告决定下一步

- 如果 security 或 forbidden gate 失败，先修复风险文件或业务边界。
- 如果 dry-run gate 失败，先重新运行对应 dry-run 和校验脚本。
- 如果 smoke dry-run 通过但真实 adapter gate 失败，下一阶段应实现真实 NocoBase adapter。
- 如果真实 adapter 通过后，再进入隔离环境插件接入测试。
- 不应在真实 adapter、插件安装、UAT、权限验证和回滚演练完成前进行生产部署。

## 当前下一阶段

当前下一阶段应是：真实 NocoBase adapter 实现，而不是继续新增 dry-run。新增 dry-run 只有在发现现有 dry-run 覆盖缺口时才应补充。

## 真实 NocoBase adapter 最小接口落地补充

本轮只完成真实 NocoBase adapter 的最小接口边界、未配置占位实现、能力矩阵、环境检测、受控错误和测试覆盖。当前仍没有可执行真实写入的 NocoBase adapter，也没有真实 NocoBase app、db、ACL、UI Schema、pluginManager、scheduler、workflow 或 file storage 上下文。

因此当前 readiness 判断保持谨慎：

- 不能进入真实插件接入测试。
- 不能真实创建 Collections、权限、页面、服务、定时任务或测试数据。
- 不能把 dry-run、未配置 adapter 或接口定义误判为真实接入完成。
- 不能将当前项目标记为 `production_ready`。

下一轮应实现真实 adapter 的第一项能力：Collection 注册 adapter 草案。该草案仍必须在完整 NocoBase 工程内验证，并且只能针对隔离测试库执行，不得在当前仓库伪造 NocoBase API。

## 2026-06-04 补充：真实 Collection 注册草案不改变上线状态

本轮新增真实 Collection 注册 adapter 草案和校验脚本，但该能力只生成计划文件，不连接真实 NocoBase、不创建真实 Collections、不执行 migration、不写数据库。因此项目仍不能标记为可生产上线，也不能进入正式上线测试。

新增草案可用于后续评审字段映射、关系、唯一约束、敏感字段、安全检查、回滚计划和后置验证计划。

## 2026-06-04 补充：真实 Runtime 注册草案 readiness 影响

已新增真实 Runtime 注册 adapter 草案与校验脚本，用于审查服务、动作、权限、i18n 和定时任务计划是否保留核心业务边界。该产物提升了进入真实 NocoBase 工程前的计划可验证性，但不改变上线状态：当前仍未连接真实 NocoBase，未注册真实服务、动作、ACL、scheduler 或 i18n，因此不能标记为可正式上线测试，也不能标记为 `production_ready`。

## 真实 Seed Data Import 草案 readiness 补充（2026-06-04）

本轮新增真实 Seed Data Import adapter 草案与生成、校验脚本后，readiness 只能说明测试数据导入计划边界更完整，不能说明已经完成真实导入。当前仍不允许真实连接 NocoBase、写数据库、上传文件、创建记录或执行事务，也不能把当前项目标记为 `production_ready`。

正式上线测试前仍必须在完整 NocoBase 测试工程中验证真实 Collection、Runtime、Page、Seed Data Import、文件存储、权限、事务、回滚和 smoke test。

## 2026-06-04 真实 Smoke Test Adapter 草案

本轮在真实 Collection、Runtime、Page、Seed Data Import 草案之后，新增“真实 Smoke Test Adapter 草案”。当前阶段只设计接口边界、计划转换器、校验器、草案 adapter、脚本、测试和文档，不连接真实 NocoBase、不写数据库、不安装插件、不执行业务流程、不调用 IOPGPS、不生成合同文件，也不伪造任何 NocoBase API 成功。

本轮计划覆盖环境前置检查、Collection 注册验证、Runtime 注册验证、Page 注册验证、Seed Data 导入验证、核心业务流程、权限、GPS mock、合同文件、失败隔离、回滚验证和报告草案。`real` 模式在当前仓库必须被阻断，后续只有在独立测试环境、备份、回滚、mock 数据、禁用真实 IOPGPS 等条件全部满足后，才能进入下一阶段设计。

## 2026-06-05 补充：Backup / Rollback readiness 状态

真实 Backup / Rollback adapter 当前处于草案阶段。readiness 只能确认计划结构、安全边界、失败恢复覆盖和脚本校验，不代表已具备上线能力。

当前仍不能进入正式上线测试，原因是：

- 未在完整 NocoBase 工程中验证真实备份和真实回滚。
- 未执行真实 `pg_dump`、`pg_restore` 或 NocoBase 官方备份能力。
- 未验证真实 storage snapshot 和 `storage/plugins` snapshot。
- 未验证 Collection、Runtime、Page / UI Schema、Seed Data 的真实前后 snapshot。
- 未演练 Smoke Test 失败后的真实回滚。
- 未完成真实日志保留和人工确认机制。

因此 readiness 结论仍必须保持非 `production_ready`。

## 2026-06-05 复核补充：Backup / Rollback 仍不是上线通过项

本轮 Backup / Rollback 草案复核只增加计划结构、安全校验、脚本生成和校验能力。由于当前仓库没有完整 NocoBase runtime、隔离测试数据库、真实 storage snapshot 和人工恢复演练结果，readiness 仍不得进入正式上线测试通过状态。

## 2026-06-06 真实接入 readiness 补充

所有真实 Adapter 草案已经覆盖 Collection、Runtime、Page、Seed Data、Smoke Test、Backup / Rollback。本轮新增真实 NocoBase 工程接入 Runbook、实施顺序、宿主工程要求、风险清单和 readiness 检查脚本。

当前 readiness 结论保持不变：当前仓库不能正式上线测试，也不能生产部署。原因是当前仓库不是完整 NocoBase 应用，没有真实 app、数据库上下文、插件管理器、ACL、UI Schema、文件存储和 scheduler 验证结果。dry-run 成功和真实 Adapter 草案通过只能说明计划层完整，不能代表真实接入成功。

下一阶段应在完整 NocoBase 工程、隔离 PostgreSQL 测试库和隔离 storage 中实现真实 adapter，并按环境检测、Collection、Runtime、Page、Seed Data、Backup / Rollback、Smoke Test、Readiness、插件打包安装、UAT 的顺序推进。

## 2026-06-06 NocoBase 目标版本与插件 API 调研补充

本轮已新增目标版本与真实插件 API 映射调研文档：

- `docs/nocobase-target-version-research.md`
- `docs/nocobase-plugin-api-research.md`
- `docs/real-adapter-api-mapping.md`
- `docs/real-adapter-gap-analysis.md`
- `docs/real-adapter-implementation-backlog.md`

本轮结论如下：

- 下一阶段是锁定 NocoBase 目标版本和验证官方 API。
- 当前 `latest-full` 只能继续用于 NAS 基础环境测试，不能作为真实 adapter、UAT 或生产部署基准。
- 当前仍不能实现真实 adapter；未经官方 API 验证不得写真实 adapter。
- 当前不能正式上线测试，也不能生产部署。
- 任何无法确认的 NocoBase API 必须标记为待验证，不得伪造 API。
- 验证只能在完整 NocoBase 源码测试工程和隔离 PostgreSQL、隔离 storage 中进行，不得生产库调试。

## 本轮补充：宿主工程接入准备状态

当前阶段是宿主工程接入准备。目标 NocoBase 版本尚未锁定，决策状态为 `pending_manual_confirmation`，下一阶段需要人工确认 NocoBase 目标版本。

未确认目标版本前，不应实现真实 adapter，不应真实安装插件，不应连接真实 NocoBase，不应写数据库。`latest-full` 不能作为真实接入基准。当前仍不能正式上线测试，当前仍不能生产部署，也不能将当前项目标记为 `production_ready`。

## 本轮 readiness 补充：目标版本未确认

当前上线准备状态继续保持未就绪。目标 NocoBase 版本仍为 `pending_manual_confirmation`，`target_version = unset`，因此不得实现真实 adapter，不得进入 UAT，不得正式上线测试，不得生产部署。

新门禁为 `npm run validate:target-version-confirmation`。在用户未确认版本时，该命令应失败，用于阻止误进入真实 adapter 实现。下一步必须取得用户人工确认的版本冻结信息。

## 本轮目标版本门禁补充

当前目标 NocoBase 版本仍未确认：`decision_status = pending_manual_confirmation`，`target_version = unset`。用户需要填写 `test-data/generated/nocobase-target-version-confirmation.filled.json` 后运行 `npm run validate:target-version-input -- --file test-data/generated/nocobase-target-version-confirmation.filled.json`，再运行 `npm run apply:target-version-confirmation -- --file test-data/generated/nocobase-target-version-confirmation.filled.json` 做 dry-run。

未通过 `npm run validate:target-version-confirmation` 前，`npm run validate:can-start-real-adapter` 必须失败。该失败是预期门禁，说明当前不能继续真实 adapter，不能正式上线测试，不能生产部署，不能标记为 `production_ready`。

## 本轮补充：目标版本确认流程 readiness

当前新增 GitHub Issue 模板、PR 模板、人工确认操作清单、提交规范、review checklist 和 `validate:target-version-workflow-files`，用于确认目标版本流程文件齐备。目标版本确认应通过 Issue + `filled.json` + apply 脚本 + PR 审查完成。

当前目标版本仍为 `pending_manual_confirmation`。未通过 `validate:target-version-confirmation` 前，不允许真实 adapter；未通过 `validate:can-start-real-adapter` 前，不允许进入完整宿主工程真实接入。当前仍不能正式上线测试，仍不能生产部署，也不能标记为 `production_ready`。

## 本轮补充：v2.0.61 宿主工程接入任务包 readiness

目标版本已确认：`v2.0.61`，但当前 readiness 结论不变：当前项目仍不能正式上线测试，仍不能生产部署，不能标记为 `production_ready`。

本轮完成的是完整 NocoBase v2.0.61 宿主工程接入准备任务包，不是生产上线验证。当前项目仍不包含完整 NocoBase 源码，不在当前仓库 clone NocoBase 源码，不提交完整 NocoBase 源码，不安装依赖，不连接 NocoBase，不写数据库，不启用真实 IOPGPS。

下一阶段 readiness 前置条件：

1. 在独立 host 工程中准备完整 NocoBase v2.0.61 源码。
2. 接入三个插件与 shared automation。
3. 先实现真实环境检测 adapter 并输出能力矩阵。
4. 环境检测通过后，再进入 Collection adapter。
5. 全程使用隔离 PostgreSQL 测试库，不使用生产库。
