# NocoBase 插件注册适配计划

## 当前插件源码骨架状态

当前仓库不是完整 NocoBase 源码工程，三个插件仍是待接入真实 NocoBase 工程后验证的源码骨架。本轮新增的 `pluginRegistration.ts`、权限草案、定时任务草案和动作草案只描述后续注册项，不调用真实 NocoBase API，不创建数据库，不执行外部请求。

## 后续接入真实 NocoBase 工程步骤

1. 确认目标 NocoBase 版本、插件目录规范和插件生命周期接口。
2. 将插件源码放入完整 NocoBase 工程的 `packages/plugins`，或构建后通过 `storage/plugins` / 插件安装流程启用。
3. 按目标版本校验 package 元信息、server/client 入口和构建命令。
4. 将 Collection 草案转换为真实 Collection 定义或迁移。
5. 将服务纯函数接入服务端事务、ACL、操作日志、文件存储和定时任务。
6. 使用测试数据库和测试数据完成插件启用、权限、动作和回滚测试。

## Collection 注册计划

- `plugin-rental-core`：注册 drivers、vehicles、lease_contracts、contract_billing_weeks、rent_daily_ledgers、rent_payments、rent_payment_allocations、rent_adjustments、deposit_records、operation_logs。
- `plugin-iopgps`：注册 gps_devices、gps_device_bindings、gps_location_snapshots、gps_daily_mileages、gps_device_status_logs、iopgps_settings。
- `plugin-contract-documents`：注册 contract_templates、contract_documents。

Collection 注册前必须复核字段、索引、唯一约束、敏感字段和关系。当前草案不等同于真实数据库迁移。

## 服务方法注册计划

- `plugin-rental-core`：台账生成、付款分配、禁止超付、欠款/免除/争议、押金、汇总、权限过滤、操作日志。
- `plugin-iopgps`：token、状态归一化、设备状态、定位、每日里程、错误日志。
- `plugin-contract-documents`：模板选择、合同上下文构建、合同文件记录生成、打印状态、签署扫描件状态、作废。

## 权限注册计划

`plugin-rental-core/src/server/permissions/permissionRegistry.ts` 已列出六个角色的权限草案：system_admin、manager、accountant、operator、gps_maintenance、readonly_auditor。后续必须接入 NocoBase 服务端 ACL、查询层权限和文件访问权限，不能只靠前端隐藏。

敏感字段包括付款截图、押金金额、总已付、未来应收、司机证件号、证件照片、驾照照片、合同扫描件、IOPGPS token 和原始响应。

## i18n 注册计划

三个插件均保留 zh-CN、en-US、fr-FR 资源。后续接入真实 NocoBase 时，需要按目标版本注册 i18n namespace，并验证服务端错误码和前端显示文案一致。

## 定时任务注册计划

- `plugin-rental-core` 预留 ensure_open_ended_ledgers、refresh_contract_summaries、refresh_driver_calendar_summaries。
- `plugin-iopgps` 预留 sync_iopgps_device_status、sync_iopgps_location、sync_iopgps_daily_mileage。

当前定时任务草案不会执行，不调用 IOPGPS，不写数据库。后续需接入 NocoBase scheduler / workflow。

## 动作注册计划

- `plugin-rental-core` 预留激活合同、生成台账、确认付款、冲正付款、标记未付原因、免除申请/审批、押金创建/抵扣/退款等动作。
- `plugin-iopgps` 预留设备状态同步、定位同步、每日里程同步、历史里程补同步。
- `plugin-contract-documents` 预留生成合同文件、标记已打印、上传签署扫描件、作废合同文件。

当前动作草案不会注册按钮、不会注册 API、不会执行数据库操作。

## 插件启用顺序

1. `plugin-rental-core`
2. `plugin-contract-documents`
3. `plugin-iopgps`

## 插件依赖关系

- `plugin-rental-core` 不依赖 IOPGPS 和合同文件插件。
- `plugin-iopgps` 依赖 `plugin-rental-core` 的车辆数据。
- `plugin-contract-documents` 依赖 `plugin-rental-core` 的合同、司机、车辆数据。

GPS 失败不能影响租金台账和付款逻辑。合同文件失败不能影响租金台账和付款逻辑。

## 不能直接生产部署的原因

- 当前仓库不是完整 NocoBase 应用。
- 当前未完成真实插件生命周期注册。
- 当前未完成真实数据库迁移和服务端 ACL。
- 当前未接入真实文件存储、定时任务、工作流和操作按钮。
- 当前未完成真实 NocoBase 集成测试和回滚验证。

## 接入测试前检查

- 确认 NocoBase 版本和 Node/Yarn 版本。
- 准备测试数据库并备份。
- 使用虚拟司机、车辆、合同、付款、押金和 GPS mock 数据。
- 不连接真实 IOPGPS。
- 不上传真实付款截图或合同扫描件。
- 检查敏感字段是否做服务端权限控制。

## 如何判断插件成功加载

- 插件在测试 NocoBase 工程中显示为启用状态。
- Collection 定义出现在管理界面或元数据中。
- 服务端方法可在测试动作中调用。
- i18n 文案可加载。
- 定时任务和动作只在测试环境按预期注册。
- 日志中没有真实 token、login key、司机证件或真实文件 URL。

## 如何回滚插件接入

1. 禁用插件。
2. 停止相关定时任务。
3. 恢复测试数据库备份。
4. 删除测试数据和测试文件。
5. 还原 `storage/plugins` 或源码目录变更。
6. 检查日志，确认没有敏感数据泄露。
