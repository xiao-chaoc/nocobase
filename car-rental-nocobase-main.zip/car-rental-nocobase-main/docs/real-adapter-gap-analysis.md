# 真实 Adapter 差距分析

## 当前已完成

- dry-run 自动化层。
- 真实 adapter 接口。
- 未配置占位实现。
- Collection 草案。
- Runtime 草案。
- Page 草案。
- Seed Data 草案。
- Smoke Test 草案。
- Backup / Rollback 草案。
- Runbook。
- Readiness 检查。

## 当前未完成

- 目标 NocoBase 版本锁定。
- 官方 API 验证。
- 完整 NocoBase 工程接入。
- 真实 Collection 注册。
- 真实 Runtime 注册。
- 真实 Page 注册。
- 真实 Seed Data 导入。
- 真实 Smoke Test。
- 真实 Backup / Rollback。
- 插件打包安装。
- UAT。

## 差距明细

| 差距 | 严重程度 | 阻塞阶段 | 解决方式 | 需要 Codex 生成的文件 | 需要人工确认的信息 | 验收标准 |
| --- | --- | --- | --- | --- | --- | --- |
| 目标 NocoBase 版本未锁定 | 高 | 所有真实 adapter | 固定稳定版本、源码 tag、镜像 tag、文档版本。 | 版本锁定记录、compose 固定版本草案。 | 目标版本号、部署方式、包管理器。 | 版本、源码和镜像一致，禁止 `latest-full` 作为真实基准。 |
| 官方 API 未完整验证 | 高 | Collection/Runtime/Page | 在完整工程读取官方源码并运行最小插件。 | API 验证记录、最小插件测试。 | 是否允许使用源码工程。 | 每个 API 标记 official_docs/official_source/local_project/unknown。 |
| 完整 NocoBase 工程未接入 | 高 | 插件加载 | 创建隔离源码测试工程。 | 工程接入清单。 | 工程位置、包管理器。 | 插件能加载但不接入生产资源。 |
| 真实 Collection 注册未完成 | 高 | 数据模型 | 基于 defineCollection/Migration 实现最小 schema。 | Collection adapter 实现和测试。 | 字段类型与命名确认。 | 隔离库创建成功，可回滚。 |
| 真实 Runtime 注册未完成 | 高 | 服务和权限 | 验证 resource action、ACL、i18n、workflow/scheduler。 | Runtime adapter 实现和测试。 | 角色矩阵确认。 | 服务端权限强制通过，IOPGPS 默认禁用。 |
| 真实 Page 注册未完成 | 中 | 页面 UAT | 验证 router、UI Schema、区块和角色可见性。 | Page adapter 实现和测试。 | 页面布局确认。 | 敏感字段不暴露，页面可按角色访问。 |
| 真实 Seed Data 导入未完成 | 中 | UAT 数据 | 使用 mock 数据、事务、唯一键和依赖检查。 | Seed adapter 实现和测试。 | mock 数据范围确认。 | 不导入真实资料，失败可回滚。 |
| 真实 Smoke Test 未完成 | 高 | 上线测试冻结 | 组合环境、插件、业务、权限、GPS mock、合同文件、回滚检查。 | Smoke adapter 实现和报告。 | UAT 用例确认。 | 全部 smoke 通过且无生产资源。 |
| 真实 Backup / Rollback 未完成 | 高 | 任何真实写入前 | 先备份数据库和 storage，再执行写入验证。 | Backup adapter 实现和演练记录。 | 备份目录和恢复窗口。 | 恢复演练成功，日志保留。 |
| 插件打包安装未完成 | 中 | NAS 测试 | 构建 storage/plugins 插件包并安装。 | 打包脚本和安装 Runbook。 | NAS 路径和权限。 | 隔离 NAS 测试环境启用成功。 |
| UAT 未完成 | 高 | 上线测试 | 冻结版本后执行业务验收。 | UAT 计划和报告。 | 验收人员和窗口。 | 关键业务、权限、备份均通过。 |

## 当前上线判断

当前不能正式上线测试，不能生产部署。原因是目标版本、官方 API、完整工程、真实权限、真实页面、真实备份/回滚和 UAT 均未完成。

不得伪造 API。不得生产库调试。所有无法确认的 API 必须标记待验证。
