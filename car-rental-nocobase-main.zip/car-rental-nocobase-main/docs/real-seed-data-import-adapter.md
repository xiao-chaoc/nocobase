# 真实 Seed Data Import Adapter 草案

## 本轮范围

本轮实现的是真实 Seed Data Import adapter 草案，不是真实导入实现。Seed Data Import 草案覆盖测试数据导入、导入顺序、引用完整性、唯一键冲突、文件字段占位、事务、回滚、导入后验证，以及数据脱敏与禁止真实数据校验。

当前明确禁止：

- 不连接真实 NocoBase。
- 不写数据库。
- 不导入真实数据。
- 不上传真实文件。
- 不创建真实记录。
- 不执行真实事务。
- 不伪造 `repository.create`、`db.collection.create` 或 file storage API 成功。

当前只生成 schema draft、导入步骤、事务计划、回滚计划和后置验证计划。

## 草案组成

- `realSeedDataSchemaMapper.ts`：将 `SeedDataImportPlan` 转换为真实导入 schema draft，保留实体、源文件、目标 Collection、导入顺序、依赖、唯一键、敏感字段和记录数占位。
- `realSeedDataSafetyChecker.ts`：校验 real 模式边界、计划完整性、禁止业务、文件字段敏感标记、GPS 与押金边界、真实数据风险。
- `realSeedDataImportAdapter.ts`：只生成 `RealSeedDataImportPlan`，不执行任何真实导入。
- `generate-real-seed-data-import-plan.ts`：从 `seed-data-import-dry-run.generated.json` 生成 `real-seed-data-import-plan.generated.json`。
- `validate-real-seed-data-import-plan.ts`：校验生成的真实 Seed Data Import 草案。

## 导入顺序策略

草案沿用 dry-run 计划的导入顺序：司机、车辆和 GPS 设备先于合同；合同先于计费周与每日台账；付款先于付款分配；合同先于押金和合同文件；GPS 设备先于 GPS 位置与里程 mock 数据。真实导入阶段不得重新排序破坏引用完整性。

## 引用完整性策略

草案保留并显式识别以下关键引用：

- `lease_contracts.driver_id -> drivers.driver_id`
- `lease_contracts.vehicle_id -> vehicles.vehicle_id`
- `rent_daily_ledgers.contract_id -> lease_contracts.contract_id`
- `rent_payment_allocations.payment_id -> rent_payments.payment_id`
- `rent_payment_allocations.ledger_id -> rent_daily_ledgers.ledger_id`
- `deposit_records.contract_id -> lease_contracts.contract_id`
- `gps_daily_mileages.device_id -> gps_devices.device_id`
- `contract_documents.contract_id -> lease_contracts.contract_id`

真实导入前必须先校验父记录存在；任一引用缺失时取消本次导入。

## 唯一键冲突处理策略

草案保留每个实体的唯一键计划。真实导入阶段应在写入前检查唯一键冲突，冲突处理不得静默覆盖真实数据；推荐策略是中止事务、输出冲突键、要求人工确认后重新导入。

## 文件字段策略

文件字段包括司机证件、付款截图、押金截图、合同 docx/pdf 和签署扫描件。当前只允许 `TEST_` 或 `MOCK` 占位策略，不上传文件，不绑定真实 file storage 对象。所有文件字段默认敏感，未来必须接入文件存储、访问权限、对象 key 记录和失败清理。

## 敏感数据策略

草案检查真实 URL、真实证件号、真实手机号、真实 IOPGPS token、真实 login_key 和真实合同扫描件风险。`access_token`、`login_key` 只能作为敏感字段名或 mock 占位规则出现，不能作为真实值导入。

## 事务策略

真实阶段必须在隔离测试数据库中开启事务，按导入顺序执行唯一键预检、引用完整性预检、记录转换、文件占位校验和批量写入。本轮只生成事务计划，不调用 `db.transaction`。

## 回滚策略

真实阶段必须先创建备份或可回滚快照。回滚顺序应与导入顺序相反，先回滚付款分配、台账、合同文件、GPS 明细，再回滚合同、车辆、司机等父记录。未来如果接入真实文件存储，还必须清理已上传对象。

## 后置验证策略

导入后必须验证记录数、引用完整性、唯一键、文件字段占位、付款分配、单日不可超付、GPS 不参与租金计算、押金不计入租金已付，以及不包含真实敏感数据。

## 为什么当前仓库不能执行 real 模式

当前仓库不是完整 NocoBase 工程，没有已验证的真实 repository/db API、事务 API、文件存储 API、ACL、备份与回滚机制。为避免伪造真实导入成功或污染真实数据，`real` 模式在当前仓库被安全检查器和草案 adapter 双重阻断。

## 未来真实 adapter 替换条件

进入下一阶段前必须：

1. 接入目标 NocoBase 版本确认过的真实 repository / db。
2. 接入真实事务与失败回滚。
3. 接入真实文件存储和文件访问权限。
4. 接入真实备份、回滚与导入后验证。
5. 使用隔离测试环境与 mock 数据执行，不得使用生产环境或真实业务数据。
6. 保持禁止短租、司机登录、按车型出租、GPS 参与租金计算和押金计入租金已付的业务边界。
