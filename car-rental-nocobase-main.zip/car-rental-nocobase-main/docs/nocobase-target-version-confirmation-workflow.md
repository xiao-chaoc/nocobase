# NocoBase 目标版本确认工作流

## 当前确认状态

当前目标版本已经确认，基准如下：

- `decision_status = confirmed`。
- `target_version = v2.0.61`。
- `source_type = release`。
- `package_manager = yarn`。
- `iopgps_real_sync_allowed = false`。
- `mock_data_only = true`。

历史上目标版本未确认时，`npm run validate:target-version-confirmation` 应失败以阻止误推进；当前已确认后该门禁应通过，但仍不能连接 NocoBase、写数据库或直接进入生产部署。目标版本未确认前不能继续真实 adapter。

`latest-full` 只能用于 NAS 基础容器启动、端口、挂载和连通性等基础测试说明，禁止写成真实 adapter 或生产部署的目标版本。

## 用户需要做什么

用户确认目标版本后，应按以下步骤准备输入文件：

1. 打开 `test-data/generated/nocobase-target-version-confirmation.template.json`。
2. 复制为 `test-data/generated/nocobase-target-version-confirmation.filled.json`。
3. 填写目标版本、来源、包管理器、Node 版本、数据库、部署模式、插件开发模式、插件安装模式、确认人和确认日期。
4. 不填写任何密码。
5. 不填写 `APP_KEY`。
6. 不填写 `DB_PASSWORD`。
7. 不填写 `IOPGPS_LOGIN_KEY`。
8. 保持 `iopgps_real_sync_allowed = false`。
9. 保持 `mock_data_only = true`。


10. 不使用真实司机证件、真实付款截图、真实合同扫描件或真实 IOPGPS 凭据。

## 当前 v2.0.61 包管理器基准

当前已确认的 NocoBase v2.0.61 宿主工程接入基准为 `package_manager = yarn`。确认流程仍接受 `npm`、`yarn`、`pnpm` 作为未来目标版本的候选枚举，但本次 v2.0.61 宿主工程实际检测为 `yarn`，不能把 `pnpm` 写成当前默认包管理器。


## 校验命令

当前项目的 npm 参数传递方式为：脚本参数写在 `npm run <script> --` 之后。因此输入校验命令为：

```bash
npm run validate:target-version-input -- --file test-data/generated/nocobase-target-version-confirmation.filled.json
```

## dry-run 应用命令

默认不写文件，只输出将要更新的字段：

```bash
npm run apply:target-version-confirmation -- --file test-data/generated/nocobase-target-version-confirmation.filled.json
```

## 真实应用命令

只有显式传入 `--execute` 才会更新 `docs/nocobase-target-version-decision.md`。当前项目实际用法可以直接把 `--execute` 放在同一个参数列表中：

```bash
npm run apply:target-version-confirmation -- --file test-data/generated/nocobase-target-version-confirmation.filled.json --execute
```

如果操作者使用双重分隔符，也允许以下形式，脚本会忽略中间的 `--`：

```bash
npm run apply:target-version-confirmation -- --file test-data/generated/nocobase-target-version-confirmation.filled.json -- --execute
```

## 应用后校验

应用后必须再运行：

```bash
npm run validate:target-version-confirmation
```

只有 `validate:target-version-confirmation` 通过后，才允许进入下一阶段：

- 创建完整 NocoBase 宿主工程接入任务。
- 实现环境检测真实 adapter。
- 实现 Collection 真实 adapter。

在 `validate:target-version-confirmation` 未通过前，`npm run validate:can-start-real-adapter` 必须失败。这是防误推进门禁，不是脚本错误。

## 明确禁止

- 不把 `latest-full` 写成真实目标版本。
- 不提交 `filled.json`，除非确认它不含敏感信息并且项目决定允许提交。
- 不提交 `.env`。
- 不提交 `.env.test`。
- 不使用真实数据。
- 不启用真实 IOPGPS。
- 不在生产库验证。
- 不把当前项目标记为 `production_ready`。
- 不在目标版本确认前继续真实 adapter。

## 当前上线状态

当前目标版本已确认为 `v2.0.61`，但仍不能正式上线测试，仍不能生产部署。下一轮应先完成插件与 shared automation 复制到独立宿主工程，并在真实环境检测 adapter 通过后再决定是否进入 Collection adapter。

## GitHub Issue + PR 审查流程

目标版本确认必须通过可审查链路完成：

1. 使用 `.github/ISSUE_TEMPLATE/nocobase-target-version-confirmation.yml` 创建 GitHub Issue，仅收集非敏感确认字段。
2. 操作者按 `docs/nocobase-target-version-operator-checklist.md` 从 Issue 复制字段到 `test-data/generated/nocobase-target-version-confirmation.filled.json`。
3. 运行 `npm run validate:target-version-input -- --file test-data/generated/nocobase-target-version-confirmation.filled.json`。
4. 运行 apply 脚本 dry-run，确认将要写入的字段。
5. 只有用户已明确确认且输入校验通过，才允许使用 `--execute` 更新 decision 文件。
6. 通过 `.github/pull_request_template.md`、`docs/nocobase-target-version-commit-policy.md` 和 `docs/nocobase-target-version-review-checklist.md` 完成 PR 审查。

当前目标版本已确认为 `v2.0.61`。即使 `validate:target-version-confirmation` 与 `validate:can-start-real-adapter` 通过，也只表示允许进入下一轮完整宿主工程接入准备；当前仍不能正式上线测试，仍不能生产部署。
