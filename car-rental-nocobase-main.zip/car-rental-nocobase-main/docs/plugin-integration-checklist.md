# 插件接入检查清单

## 接入前检查

- [ ] 确认当前 NocoBase 版本。
- [ ] 确认 Node / Yarn 环境与目标 NocoBase 版本兼容。
- [ ] 确认是否为完整 NocoBase 源码工程。
- [ ] 确认是否使用 Docker 运行测试环境。
- [ ] 准备独立测试数据库。
- [ ] 启用插件前备份数据库。

## 插件代码检查

- [ ] `package.json` 名称、版本、入口和脚本已按真实 NocoBase 工程校验。
- [ ] server 入口能导出服务、类型和 Collection 草案。
- [ ] client 入口如暂缺，需要明确当前不实现前端页面。
- [ ] zh-CN、en-US、fr-FR i18n 文件存在。
- [ ] Collection 定义已从草案转换为真实 NocoBase 定义。
- [ ] 服务方法已接入数据库事务、权限和日志。
- [ ] 权限声明覆盖敏感财务、文件、GPS token 和合同扫描件字段。
- [ ] 纯函数测试和接入测试覆盖关键业务。

## 启用前检查

- [ ] 不使用真实司机数据。
- [ ] 不使用真实付款截图。
- [ ] 不使用真实合同扫描件。
- [ ] 不使用真实 IOPGPS 密钥。
- [ ] `APP_KEY` 已在测试环境设置。
- [ ] PostgreSQL 已启动并连接测试库。

## 启用后检查

- [ ] Collections 是否在 NocoBase 中出现。
- [ ] 服务方法是否可调用。
- [ ] 日志是否正常且敏感字段已脱敏。
- [ ] 敏感字段权限是否生效。
- [ ] 台账生成测试是否通过。
- [ ] 付款超付是否被阻止。
- [ ] GPS 失败是否不影响租金台账和付款。

## 回滚方案

- [ ] 禁用插件。
- [ ] 恢复数据库备份。
- [ ] 删除测试数据。
- [ ] 还原 `storage/plugins` 中的测试插件包。
- [ ] 检查日志确认没有真实密钥、真实证件、真实截图或真实扫描件泄露。

## 禁止事项

- [ ] 不直接在生产库测试。
- [ ] 不提交 `.env`。
- [ ] 不提交真实司机证件、真实付款截图、真实合同扫描件或数据库文件。
- [ ] 不在日志中输出 `access_token`、`login_key`、`login_key_encrypted` 或其他密钥。

## 注册草案检查

- [ ] 三个插件均存在 `src/server/pluginRegistration.ts`。
- [ ] `plugin-rental-core` 权限草案包含六个内部角色。
- [ ] `plugin-rental-core` 和 `plugin-iopgps` 定时任务草案只描述任务，不真实执行。
- [ ] 三个插件动作草案只描述输入、输出、权限、调用服务和失败场景，不注册真实按钮或 API。
- [ ] 注册草案中的 notes 明确 GPS 不参与租金计算，合同文件插件不处理租金、付款和 GPS。

## mock 测试数据检查

- [ ] 已运行 `npm run seed:test-data` 生成本地 mock JSON。
- [ ] 已运行 `npm run validate:test-data` 校验唯一约束、付款不超付、合同不冲突、GPS 里程唯一和敏感字段不泄露。
- [ ] 已确认 `test-data/fixtures` 和 `test-data/generated` 中没有真实司机资料、真实付款截图、真实合同扫描件、真实 IOPGPS 密钥或真实文件 URL。
- [ ] 后续导入 NocoBase 前已人工复核，并使用单独导入适配器；当前脚本不得直接写数据库。

## NAS 测试部署检查

- [ ] 已复制 `docker-compose.test.yml` 到 NAS 测试运行目录。
- [ ] 已复制 `.env.test.example` 为 `.env.test`，并确认 `.env.test` 不进入 Git。
- [ ] 已确认 `APP_KEY` 是测试环境专用值，创建后不会随意修改。
- [ ] 已创建 `storage-test`、`backups-test`、`logs-test`、`templates` 测试目录。
- [ ] 已运行或人工参考 `scripts/check-nas-test-env.sh` 检查 Docker、Compose、端口和目录。
- [ ] 已确认当前环境只做基础测试，不能用于生产部署。
- [ ] 已确认插件仍需真实 NocoBase 工程适配和安装验证。

## 插件打包测试与 NAS 自检

- [ ] 已阅读 `docs/plugin-package-test.md`。
- [ ] 已运行 `npm run check:plugin-structure`。
- [ ] 已运行 `npm run check:plugin-registration`。
- [ ] 已运行 `npm run preflight:nas-test`。
- [ ] 已阅读 `docs/nas-smoke-test-checklist.md`。
- [ ] 已阅读 `docs/nas-test-runbook.md`。
- [ ] 已确认当前不做真实 NAS 部署，不做生产上线。

## NAS 测试挂载边界修正检查

- [ ] `docker-compose.test.yml` 使用 `storage-test/nocobase` 挂载 NocoBase storage。
- [ ] `docker-compose.test.yml` 使用 `storage-test/postgres` 挂载 PostgreSQL 测试数据库目录。
- [ ] 已确认没有继续使用 `./storage-test:/app/nocobase/storage` 整体挂载。
- [ ] 已确认测试 Compose 不直接挂载 `packages/plugins`，插件仍需后续真实 NocoBase 插件流程接入。
- [ ] 手动下载文件时已使用 GitHub Raw 原始内容，或在 NAS 上直接 `git clone` 仓库。
- [ ] 已确认复制到 NAS 的 `docker-compose.test.yml` 是 YAML 原始内容，不是 GitHub HTML 页面。

## 自动化正式上线测试接入检查

- [ ] 不走手动搭建 MVP。
- [ ] 不要求用户手动创建 NocoBase Collections。
- [ ] 不要求用户手动创建页面、菜单或区块。
- [ ] 不要求用户手动配置角色权限。
- [ ] 不要求用户手动录入测试数据。
- [ ] Collections、页面、权限、测试数据均由插件、migration、初始化脚本或导入脚本自动完成。
- [ ] 用户只负责合并 PR、创建 `.env.test`、启动 NAS 测试环境、检查测试报告并决定是否进入 UAT。
- [ ] Codex 后续负责生成插件接入代码、初始化脚本、测试脚本和部署测试文档。
- [ ] 下一阶段是插件真实 NocoBase 化，不是手动 UI 搭建。
