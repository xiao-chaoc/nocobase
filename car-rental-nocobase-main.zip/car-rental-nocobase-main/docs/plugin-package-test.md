# 插件打包测试草案

## 当前插件状态

- 当前 `packages/plugins` 下是插件源码骨架。
- 当前仓库不是完整 NocoBase 源码工程。
- 当前插件不能直接声称已可生产安装。
- 当前目标是准备插件测试接入流程，先做结构、注册描述和安全边界检查。

## 插件打包测试目标

本轮只做打包前结构检查草案，不执行真实 NocoBase 插件安装。检查目标包括：

- 检查三个插件目录结构是否完整。
- 检查 `package.json` 是否存在。
- 检查 server 入口是否存在。
- 检查 `services` / `types` / `collections` / `locale` 是否存在。
- 检查 `pluginRegistration.ts` 是否存在。
- 检查敏感字段、唯一约束、权限草案是否存在。
- 不执行真实 NocoBase 插件安装。
- 不连接数据库。
- 不调用真实 IOPGPS。
- 不生成真实合同文件。

## 三个插件

本草案覆盖：

- `plugin-rental-core`
- `plugin-iopgps`
- `plugin-contract-documents`

## 插件依赖顺序

1. `plugin-rental-core`
2. `plugin-contract-documents`
3. `plugin-iopgps`

说明：

- `plugin-rental-core` 是核心依赖。
- `plugin-contract-documents` 依赖合同、司机、车辆数据。
- `plugin-iopgps` 依赖车辆数据。
- `plugin-rental-core` 不依赖 GPS 和合同文件。
- GPS 失败不能影响租金台账和付款。

## 后续真实接入 NocoBase 的路径

### 方式 A：完整 NocoBase 源码工程 `packages/plugins` 开发调试

1. 准备完整 NocoBase 源码工程。
2. 将三个插件复制到完整工程的 `packages/plugins`。
3. 按目标 NocoBase 版本安装依赖并校验插件元信息。
4. 接入真实插件生命周期、Collection 注册、权限、i18n、服务方法、定时任务和动作。
5. 使用测试数据库验证启用、禁用、回滚和失败隔离。

### 方式 B：构建插件包后放入 `storage/plugins` 或通过插件安装流程启用

1. 在真实 NocoBase 工程中按目标版本构建插件包。
2. 将构建结果放入 `storage/plugins` 或通过插件安装流程导入。
3. 按顺序启用插件。
4. 验证 Collection、服务方法、权限、i18n、定时任务和动作。

当前脚本只是草案，必须在真实 NocoBase 工程中验证，不能据此声称已经可生产安装。
