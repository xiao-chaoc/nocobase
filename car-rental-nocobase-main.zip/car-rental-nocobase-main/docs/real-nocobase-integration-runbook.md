# 真实 NocoBase 工程接入 Runbook 与实施顺序

## 1. 当前状态总结

当前仓库是内部汽车租赁记账与运营系统的插件骨架、领域规则、测试数据、dry-run 自动化层和真实 Adapter 草案集合，不是完整 NocoBase 应用。

当前仓库已经具备以下基础：

- 三个插件骨架：`plugin-rental-core`、`plugin-contract-documents`、`plugin-iopgps`。
- dry-run 层：Collection 注册、Runtime 注册、页面初始化、mock 数据导入、自动化 smoke dry-run、go-live readiness 报告。
- 真实 Adapter 草案：Collection、Runtime、Page、Seed Data、Smoke Test、Backup / Rollback。
- 真实 Adapter 基础：环境检查、未配置 adapter、adapter factory、错误类型。

当前仓库仍保持以下边界：

- 不连接真实 NocoBase。
- 不安装真实 NocoBase 插件。
- 不创建真实 Collections。
- 不写真实数据库。
- 不创建真实页面。
- 不导入真实数据。
- 不执行真实备份或回滚。
- 不能直接生产部署。
- 不能直接正式上线测试。

下一阶段不是继续新增真实 Adapter 草案，而是必须在完整 NocoBase 工程中基于目标版本官方能力实现真实 adapter，并在隔离测试数据库和隔离 storage 中验证。

## 2. 当前仓库与完整 NocoBase 工程的关系

当前仓库提供业务规则、插件源码草案、自动化计划、mock 数据和安全边界；完整 NocoBase 工程提供真实运行时、数据库上下文、插件管理器、权限系统、UI Schema、文件存储、定时任务和日志能力。

真实接入时应把当前仓库视为输入包，而不是把当前仓库改造成完整 NocoBase 应用。真实 adapter 的最终实现需要在完整 NocoBase 工程中调用目标版本真实 API，并由隔离环境验证。

## 3. 推荐接入路径

### 路径 A：完整 NocoBase 源码工程开发调试

1. 准备完整 NocoBase 源码工程，并确认目标版本。
2. 将当前三个插件复制到完整 NocoBase 工程的 `packages/plugins`，或作为内部包接入。
3. 将 `packages/shared/nocobase-automation` 作为共享包接入完整 NocoBase 工程。
4. 在完整 NocoBase 工程中实现真实 adapter，禁止在当前仓库伪造 NocoBase API。
5. 使用隔离 PostgreSQL 测试数据库、隔离 storage、测试专用 `.env` 和测试管理员账号。
6. 依次运行真实 Collection、Runtime、Page、Seed、Backup / Rollback、Smoke、Readiness 验证。

### 路径 B：构建为插件包后在 NAS 测试环境安装

1. 先在完整 NocoBase 工程中完成路径 A 的真实 API 验证。
2. 构建 `plugin-rental-core`、`plugin-contract-documents`、`plugin-iopgps`。
3. 将插件包放入 NAS 测试环境的 `storage/plugins`，或通过 NocoBase 插件安装流程安装。
4. 启用插件。
5. 执行初始化脚本。
6. 执行 mock 数据导入和 smoke test。
7. 验证备份、回滚、权限、日志和文件上传隔离。

### 推荐顺序

- 先路径 A。
- 再路径 B。
- 不建议直接在 NAS 容器里调试源码插件，因为容器内调试会增加依赖、构建、回滚和文件污染风险。

## 4. 真实接入前置条件

| 条件 | 要求 |
| --- | --- |
| NocoBase 版本 | 已确认目标版本和插件 API 兼容范围。 |
| 完整工程 | 已准备完整 NocoBase 源码工程，而不是只使用当前插件骨架仓库。 |
| 数据库 | 已准备隔离 PostgreSQL 测试库，禁止连接生产库。 |
| storage | 已准备隔离 storage，禁止复用生产文件目录。 |
| 环境变量 | 已准备测试专用 `.env`，且不提交到当前仓库。 |
| APP_KEY | 已设置测试专用 `APP_KEY`，并且不会随意修改。 |
| IOPGPS | `IOPGPS_SYNC_ENABLED=false`，禁止真实 IOPGPS 同步。 |
| 测试数据 | 只使用 mock 数据，不使用真实司机数据。 |
| 付款截图 | 不使用真实付款截图。 |
| 合同扫描件 | 不使用真实合同扫描件。 |
| 司机证件 | 不使用真实司机证件。 |
| IOPGPS 凭据 | 不使用真实 IOPGPS 密钥。 |
| 备份策略 | 已有数据库备份、storage 备份和 schema snapshot 策略。 |
| 回滚策略 | 已有失败回滚、插件禁用、数据恢复和日志保留策略。 |

## 5. 真实 Adapter 实现顺序

| 顺序 | Adapter / 阶段 | 输入文件 | 输出结果 | 需要的 NocoBase 能力 | 主要风险 | 验收标准 | 回滚方式 | 是否阻塞下一步 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 环境检测 adapter | `nocobaseEnvironmentInspector.ts`、目标工程配置 | 环境能力报告 | app、db、logger、pluginManager、acl、uiSchema、storage、scheduler | 目标版本能力缺失或识别错误 | 能准确报告真实工程能力和缺失项，不连接生产资源 | 不写入任何资源，仅撤销测试配置 | 是 |
| 2 | Collection 注册 adapter | Collection 草案、字段映射、schema 计划 | 真实 Collections、字段、关系、约束和索引 | db、collection manager、pluginManager | 字段类型、relation、唯一约束不兼容 | 所有 Collection 在隔离库创建成功，schema 校验通过 | 删除测试 Collection 或恢复数据库备份 | 是 |
| 3 | Runtime 注册 adapter | 服务、动作、权限、i18n、定时任务计划 | 服务、动作、权限、i18n、定时任务注册结果 | plugin runtime、acl、i18n、scheduler、workflow | 权限失效、定时任务误启用 | IOPGPS 定时任务默认禁用，权限矩阵校验通过 | 禁用插件、撤销服务动作、恢复备份 | 是 |
| 4 | Page 注册 adapter | 页面草案、菜单、区块、筛选器、按钮动作 | 菜单、页面、区块、收租日历页面和 UI Schema | uiSchema、acl、pluginManager | UI Schema 不兼容或敏感字段暴露 | 页面可在测试账号下按权限显示，敏感字段受控 | 删除 UI Schema 节点或恢复 schema snapshot | 是 |
| 5 | Seed Data Import adapter | mock 数据、引用映射、文件占位 | mock 司机、车辆、合同、台账、付款、GPS mock 数据 | db、transaction、storage | 唯一键冲突、引用断裂、误导入真实数据 | 事务导入成功，引用完整，不含真实数据 | 事务回滚或恢复数据库备份 | 是 |
| 6 | Backup / Rollback adapter | 备份计划、目录配置、schema snapshot 计划 | 数据库备份、storage 备份、plugin storage 备份、回滚演练报告 | db dump、文件系统、日志 | 备份不完整或回滚失败 | 可从备份恢复隔离环境并保留日志 | 执行已验证的恢复流程 | 是 |
| 7 | Smoke Test adapter | 核心业务流程、权限矩阵、GPS mock、合同文件 mock | 真实 smoke test 报告 | app、db、acl、storage、scheduler mock | 失败污染测试环境 | 核心流程、权限、GPS mock、合同文件和回滚验证通过 | 触发 Backup / Rollback adapter 恢复 | 是 |
| 8 | Readiness adapter | 前序报告、测试结果、风险状态 | 真实接入 readiness 报告 | 报告生成、日志读取 | 把草案通过误判为真实通过 | 报告明确仍需 UAT 或允许进入下一阶段的条件 | 撤回 readiness 结论并补测 | 是 |
| 9 | 插件打包和安装验证 | 已验证插件源码、构建脚本 | 插件包、安装日志、启用记录 | 插件打包、插件安装、NAS 测试环境 | 插件安装后无法启动 | 插件能安装、启用、禁用和卸载 | 禁用插件、删除插件包、恢复 NAS 测试备份 | 是 |
| 10 | UAT 测试 | UAT 用例、mock 业务数据、权限账号 | UAT 记录和问题清单 | 完整测试环境 | 业务流程遗漏 | 内部人员确认核心流程可用且无阻断问题 | 冻结版本回退或重新进入修复阶段 | 否 |

## 6. 每个 Adapter 的真实实现边界

### 6.1 Collection

真实实现只负责在隔离完整 NocoBase 工程中注册真实 Collection，并完成字段类型映射、relation 映射、唯一约束、索引、敏感字段标记、schema 验证和回滚策略验证。字段映射必须以目标 NocoBase 版本支持的类型为准。敏感字段包括总已付、未来应收、押金、付款截图、合同文件、司机证件相关字段。失败时必须回滚到注册前状态或恢复数据库备份。

### 6.2 Runtime

真实实现只负责服务注册、动作注册、权限注册、i18n 注册、定时任务注册和权限验证。IOPGPS 定时任务必须默认禁用，只有 mock 或测试开关明确允许时才可验证调度注册。任何 GPS 同步失败都不能影响租金台账和付款逻辑。失败时必须可禁用插件、撤销动作或恢复备份。

### 6.3 Page

真实实现只负责菜单、页面、区块、筛选器、按钮动作、收租日历页面、敏感字段可见性和 UI Schema 验证。页面必须按权限隐藏总已付、未来应收、押金、付款截图等敏感数据。失败时必须删除测试 UI Schema 或恢复 schema snapshot。

### 6.4 Seed Data

真实实现只导入 mock 数据，禁止导入真实数据。导入必须验证引用完整性、唯一键冲突、文件字段占位、事务和回滚。付款截图、合同扫描件和司机证件只能使用占位 mock 文件或空引用。失败时必须事务回滚或恢复数据库备份。

### 6.5 Backup / Rollback

真实实现必须覆盖数据库备份、storage 备份、plugin storage 备份、schema snapshot、回滚、日志保留和失败恢复。备份目录必须为测试专用目录，不得覆盖生产备份。回滚演练是进入真实 smoke test 前的阻塞条件。

### 6.6 Smoke Test

真实实现必须覆盖核心流程、权限、GPS mock、合同文件、失败隔离和回滚验证。核心流程至少包括合同绑定具体车牌、生成每日租金台账、付款分配到具体日期、单日不可超付、未付原因、欠款/免除/待审批免除/争议标记、未来应收不计入欠款、押金不计入租金收入。Smoke Test 不得调用真实 IOPGPS API。

## 7. 严格禁止事项

- 不在生产库上调试。
- 不在当前仓库伪造 NocoBase API。
- 不把 dry-run 成功当成真实接入成功。
- 不接真实 IOPGPS。
- 不使用真实司机证件。
- 不使用真实付款截图。
- 不使用真实合同扫描件。
- 不绕过权限控制。
- 不让 GPS 参与租金计算。
- 不把押金计入租金收入。
- 不引入短租。
- 不引入司机登录。
- 不按车型出租。
- 不把当前项目标记为 `production_ready`。

## 8. 检查脚本草案

当前仓库新增 `scripts/nocobase/validate-real-integration-readiness.ts`，仅检查当前仓库是否具备进入完整 NocoBase 工程真实接入准备的文档与草案条件。

该脚本只做以下事情：

- 检查本 Runbook、实施顺序、宿主工程要求、风险清单是否存在。
- 检查所有真实 Adapter 草案文档、生成脚本和校验脚本是否存在。
- 检查 `package.json` 是否包含所有真实 plan 生成、校验脚本和 readiness 校验脚本。
- 检查当前仓库不存在 `.env`、`.env.test`、真实付款截图目录、真实合同扫描件目录和真实司机证件目录。
- 输出中文检查结果。
- 缺失关键文件时以非零状态退出。

该脚本明确不连接 NocoBase、不读取 `.env.test`、不执行真实注册、不写数据库。

## 9. 安全、权限、mock 数据和备份边界

- 真实测试必须在隔离 NocoBase 工程和隔离数据库中执行。
- 权限测试必须覆盖管理员、财务、运营、只读和无敏感字段权限账号。
- mock 数据必须可追溯、可重复生成、可整体清理。
- 文件上传测试目录必须仅存放 mock 付款截图、mock 合同文件和 mock 占位附件。
- 备份、回滚和日志目录必须测试专用，不能复用生产路径。
- `.env`、真实密钥、真实文件、真实证件和真实 IOPGPS 凭据不得提交。


## 2026-06-06 NocoBase 目标版本与插件 API 调研补充

本轮已新增目标版本与真实插件 API 映射调研文档：

- `docs/nocobase-target-version-research.md`
- `docs/nocobase-plugin-api-research.md`
- `docs/real-adapter-api-mapping.md`
- `docs/real-adapter-gap-analysis.md`
- `docs/real-adapter-implementation-backlog.md`

本轮结论如下：

- 下一阶段是锁定 NocoBase 目标版本和验证官方 API。
- 当前 `latest-full` 只能继续用于 NAS 基础环境测试，不能作为真实 adapter、UAT 或生产部署基准。
- 当前仍不能实现真实 adapter；未经官方 API 验证不得写真实 adapter。
- 当前不能正式上线测试，也不能生产部署。
- 任何无法确认的 NocoBase API 必须标记为待验证，不得伪造 API。
- 验证只能在完整 NocoBase 源码测试工程和隔离 PostgreSQL、隔离 storage 中进行，不得生产库调试。

## 本轮补充：宿主工程接入准备前置阶段

当前阶段是宿主工程接入准备，不是真实 adapter 实现阶段。本轮新增 `docs/nocobase-target-version-decision.md`、`docs/nocobase-host-bootstrap-runbook.md`、`docs/nocobase-host-integration-branch-plan.md`、`docs/nocobase-source-api-verification-plan.md` 与 `scripts/host/` dry-run 脚本草案。

下一阶段需要人工确认 NocoBase 目标版本。未确认目标版本前，不应实现真实 adapter，不应真实安装插件，不应连接真实 NocoBase，不应写数据库。`latest-full` 只能作为 NAS 基础环境测试镜像说明，不能作为真实接入基准。

当前仍不能正式上线测试，当前仍不能生产部署。宿主工程必须在当前仓库外部单独准备，且不要把完整 NocoBase 源码提交进当前仓库，不得生产库调试。

## 目标版本确认门禁

当前目标 NocoBase 版本尚未锁定，`decision_status = pending_manual_confirmation`。本 Runbook 在版本冻结前不得进入真实集成执行阶段，不得连接 NocoBase，不得写数据库，不得安装插件到 NAS 测试应用。

下一步需要用户人工确认目标版本并通过 `npm run validate:target-version-confirmation`。在此之前，当前仍不能正式上线测试，不能生产部署。

## 本轮补充：v2.0.61 宿主工程接入准备 Runbook 入口

> 包管理器修正：完整 NocoBase v2.0.61 宿主工程环境检测已确认当前接入基准为 `package_manager = yarn`。后续宿主工程人工命令应使用 `yarn`，不得把 `pnpm` 作为当前默认值；除非重新验证目标版本源码工程确实支持 `pnpm`。

目标版本已确认：`v2.0.61`。下一阶段是完整 NocoBase v2.0.61 宿主工程接入准备。本轮新增的总任务文档、目录规划、命令清单、插件复制计划、环境检测 adapter 任务和 Collection adapter 任务，是进入真实接入前的准备入口。

执行顺序必须保持为：

1. 在独立目录准备完整 NocoBase v2.0.61 host 工程。
2. 保持当前项目不包含完整 NocoBase 源码。
3. 使用隔离 PostgreSQL 测试库和隔离 storage。
4. 先实现真实环境检测 adapter。
5. 环境检测通过后，才允许进入真实 Collection adapter。

当前仍不能正式上线测试，仍不能生产部署，不能使用生产库，不能启用真实 IOPGPS，不能把当前项目标记为 `production_ready`。
