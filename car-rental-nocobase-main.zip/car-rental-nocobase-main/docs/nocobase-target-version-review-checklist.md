# NocoBase 目标版本确认 Review Checklist

## 1. 版本合法性检查

- `decision_status` 是否为 `confirmed`，且只在用户明确确认后出现。
- `target_version` 是否非空、不是 `unset`、不是占位值。

## 2. latest-full 禁用检查

- 确认 `target_version` 不是 `latest-full`。
- 确认文档只把 `latest-full` 描述为基础环境测试用途。

## 3. 来源引用检查

- `source_type` 是否为 `tag`、`branch`、`docker_image`、`release` 之一。
- `source_reference` 是否可审查、可追溯、非空。

## 4. 包管理器检查

- `package_manager` 是否为 `npm`、`yarn`、`pnpm` 之一。

## 5. PostgreSQL 检查

- `database` 是否为 `postgresql`。
- 是否未引入生产库连接配置。

## 6. IOPGPS 禁用检查

- `iopgps_real_sync_allowed` 是否为 `false`。
- 是否没有真实 IOPGPS 凭据。
- 是否没有调用 IOPGPS。

## 7. mock 数据检查

- `mock_data_only` 是否为 `true`。
- 是否没有真实司机资料、付款截图或合同扫描件。

## 8. 密钥泄露检查

- PR diff 是否不包含真实密钥、密码、生产连接串或未脱敏 token。
- 是否没有新增任何要求填写密钥的模板字段。

## 9. filled.json 未提交检查

- `test-data/generated/nocobase-target-version-confirmation.filled.json` 是否未提交。
- 其他 filled.json 是否未提交。

## 10. .env 未提交检查

- `.env` 是否未提交。
- `.env.test` 是否未提交。

## 11. 真实业务文件未提交检查

- 是否没有真实司机证件。
- 是否没有真实付款截图。
- 是否没有真实合同扫描件。
- 是否没有数据库文件、完整 NocoBase 源码或 `node_modules`。

## 12. validate:target-version-confirmation 是否通过

- PR 是否列明 `npm run validate:target-version-confirmation` 的结果。
- 如果目标版本未确认，该命令失败应被标注为预期门禁。

## 13. validate:can-start-real-adapter 是否通过

- PR 是否列明 `npm run validate:can-start-real-adapter` 的结果。
- 该命令未通过前，不允许进入完整宿主工程真实接入。

## 14. production_ready 检查

- 当前是否仍未进入 `production_ready`。
- 是否没有宣称可以生产部署。
- 是否没有宣称可以正式上线测试。

## 15. 下一步范围检查

- 若版本确认通过，下一步只允许创建完整 NocoBase 宿主工程接入任务。
- 下一步仍需隔离测试库、mock 数据、真实 IOPGPS 禁用和 readiness 门禁。
