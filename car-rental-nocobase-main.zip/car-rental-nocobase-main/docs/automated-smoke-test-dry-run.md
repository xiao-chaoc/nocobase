# 自动化 Smoke Test dry-run 编排

## 当前实现范围

本轮实现的是自动化 smoke test dry-run 编排与统一报告。它把已有的自动化注册计划、Collection 注册 dry-run、Runtime 注册 dry-run、页面初始化 dry-run、mock 测试数据生成与导入 dry-run 串联为一条可重复执行的本地检查链路。

## 安全边界

- 当前不连接真实 NocoBase。
- 当前不写数据库。
- 当前不调用 IOPGPS。
- 当前不生成真实合同文件。
- 当前不上传文件。
- 当前不创建真实页面、菜单、权限、动作或定时任务。
- 当前不导入真实司机、车辆、付款截图、合同扫描件或 GPS 凭据。

## 统一 smoke test 步骤

1. 仓库结构检查：扫描本地关键文件与目录，确认 dry-run 前置脚本存在。
2. 自动化注册计划生成：输出 `test-data/generated/automated-registration-plan.generated.json`。
3. 自动化注册计划校验：检查计划完整性与禁止业务模式。
4. Collection 注册 dry-run：输出 Collection mock 注册结果。
5. Collection 注册结果校验：确认 Collection dry-run 成功。
6. Runtime 注册 dry-run：输出服务、动作、权限、定时任务、i18n 的 mock 注册结果。
7. Runtime 注册结果校验：确认 runtime dry-run 成功。
8. 页面初始化 dry-run：输出菜单、页面、区块、筛选器、按钮动作计划结果。
9. 页面初始化结果校验：确认页面计划完整且敏感字段受控。
10. 测试数据生成：生成 mock JSON 数据。
11. 测试数据校验：校验 mock 数据业务规则与敏感数据占位。
12. 测试数据导入 dry-run：模拟导入测试数据，不写数据库。
13. 测试数据导入结果校验：确认 mock 导入结果通过。
14. NAS 测试文件预检：执行 NAS 本地测试文件预检脚本；如果脚本不存在，报告中必须明确跳过。
15. 统一报告生成：输出 JSON 与 Markdown 报告。

## 每一步输入与输出

| 步骤 | 输入 | 输出 |
| --- | --- | --- |
| 仓库结构检查 | 当前工作区文件列表 | 前置文件检查结果 |
| 自动化注册计划生成 | 插件注册草案与集合草案 | `test-data/generated/automated-registration-plan.generated.json` |
| 自动化注册计划校验 | 注册计划 JSON | 中文校验输出 |
| Collection dry-run | 注册计划 JSON | `test-data/generated/collection-registration-dry-run.generated.json` |
| Runtime dry-run | 注册计划 JSON | `test-data/generated/runtime-registration-dry-run.generated.json` |
| 页面初始化 dry-run | 注册计划 JSON | `test-data/generated/page-initialization-dry-run.generated.json` |
| 测试数据生成 | `test-data/fixtures/` | `test-data/generated/*.generated.json` |
| 测试数据导入 dry-run | 生成的 mock JSON 数据 | `test-data/generated/seed-data-import-dry-run.generated.json` |
| 统一报告 | 所有步骤结果 | `test-data/generated/automated-smoke-test-report.generated.json` 和 `.md` |

## 阻塞步骤与非阻塞步骤

- 阻塞步骤失败时，默认停止后续业务步骤，并在报告中写入 `blockers` 与 `next_actions`。
- 非阻塞步骤产生 warning 时，不一定导致整体失败，但必须进入报告的 warnings。
- 使用 `--continue-on-error` 时，即使阻塞步骤失败也会继续执行剩余步骤，但最终报告仍会标记失败并列出阻塞项。

## 报告文件位置

- JSON 报告：`test-data/generated/automated-smoke-test-report.generated.json`
- Markdown 报告：`test-data/generated/automated-smoke-test-report.generated.md`

## 如何运行

```bash
npm run smoke:dry-run
npm run validate:smoke-report
```

如果需要失败后继续执行剩余步骤，可直接运行脚本并追加参数：

```bash
npm run build:scripts && node .test-dist/scripts/scripts/nocobase/run-automated-smoke-dry-run.js --continue-on-error
```

## 如果失败如何处理

1. 先查看 JSON 报告中的 `blockers`、`errors` 和对应步骤的 `output_summary`。
2. 按照 `next_actions` 中的建议修复缺失文件、失败脚本或 dry-run 校验问题。
3. 重新运行失败的单个脚本，再运行 `npm run smoke:dry-run`。
4. 如果报告校验失败，先确认报告是否包含所有必要步骤，以及是否误写入真实敏感数据或禁止业务模式。

## 当前仍不能正式上线测试

当前 smoke test 只证明本地 dry-run 链路可编排、计划可校验、mock 数据可生成和模拟导入。它没有连接真实 NocoBase，没有执行真实数据库迁移，没有创建真实页面或权限，也没有调用真实 IOPGPS，因此不能作为正式上线测试结论。

## 进入下一阶段的条件

- 统一 smoke test dry-run 与报告校验稳定通过。
- 真实 NocoBase 工程中的 adapter 接口已经明确并经评审。
- 测试环境具备隔离数据库、隔离文件存储和安全的 mock 凭据。
- 真实 adapter 仍保留 dry-run 与回滚能力。
- 所有敏感字段、禁止业务模式、GPS 不参与租金计算、押金不计入租金收入等规则继续由自动化校验覆盖。

## 与 readiness 报告的关系

Smoke Test dry-run 报告只证明本地 dry-run 链路可编排。正式上线测试前还需要运行 readiness 报告：`npm run generate:go-live-readiness` 和 `npm run validate:go-live-readiness`。readiness 报告会把真实 NocoBase adapter、插件安装、UAT、生产部署条件单独列为 gate，避免把 smoke dry-run 通过误判为可以正式上线或生产部署。
