# NocoBase 目标版本决策记录

## 决策状态

| 字段 | 值 |
| --- | --- |
| `plugin_install_mode` | `packages_plugins` |
| `plugin_development_mode` | `packages_plugins` |
| `deployment_mode` | `source_host` |
| `database` | `postgresql` |
| `node_version` | `待完整 NocoBase 源码工程确认` |
| `package_manager` | `yarn` |
| `decision_status` | `confirmed` |
| `target_version` | `v2.0.61` |
| `source_type` | `release` |
| `source_reference` | `https://github.com/nocobase/nocobase/releases/tag/v2.0.61` |
| `decided_at` | `2026-06-06` |
| `decided_by` | `Codex` |
| `requires_manual_confirmation` | `false` |
| `confirmed_target_version` | `v2.0.61` |
| `confirmed_source_url_or_tag` | `https://github.com/nocobase/nocobase/releases/tag/v2.0.61` |
| `confirmed_package_manager` | `yarn` |
| `confirmed_deployment_mode` | `source_host` |
| `confirmed_plugin_install_mode` | `packages_plugins` |
| `confirmed_database` | `postgresql` |
| `confirmed_storage_strategy` | `unset` |
| `iopgps_real_sync_allowed` | `false` |
| `mock_data_only` | `true` |
| `confirmed_by` | `xiao-chaoc` |
| `confirmed_at` | `2026-06-06` |
| `notes` | 当前任务只基于已检出的本地仓库与既有调研文档整理接入准备材料；本轮不拉取完整 NocoBase 源码，不连接真实 NocoBase，不伪造官方版本结论。|

## 决策结论

当前已锁定真实接入准备使用的 NocoBase 目标版本：v2.0.61。目标版本门禁已允许进入下一阶段隔离测试接入准备，但仍只能准备完整宿主工程接入任务、环境检测 adapter 和后续 Collection adapter 计划。

历史安全规则保留：如果后续版本来源被撤销、无法从官方文档、官方镜像标签、官方源码标签或项目负责人确认具体版本，则必须回退到：

- `decision_status = pending_manual_confirmation`
- `target_version = unset`
- `requires_manual_confirmation = true`

`latest-full` 只能作为 NAS 基础环境测试镜像说明，不能作为真实插件接入基准，不能写成生产或真实 adapter 的目标版本。

## 包管理器修正记录

原确认记录使用 `pnpm` 作为 `package_manager` 和 `confirmed_package_manager`。完整 NocoBase v2.0.61 宿主工程环境检测结果显示，实际宿主工程路径为 `/workspace/nocobase`，NocoBase 版本为 `2.0.61`，检测到的包管理器为 `yarn`。

宿主工程已通过 `yarn install --ignore-scripts`、`yarn nocobase postinstall`、`yarn test` 等命令验证，因此本记录将 `package_manager` 与 `confirmed_package_manager` 从 `pnpm` 修正为 `yarn`。

后续宿主工程接入命令必须以 `yarn` 为准。不能再使用 `pnpm` 作为该宿主工程的默认包管理器，除非重新验证目标版本源码工程确实支持 `pnpm`。本修正不改变 `target_version = v2.0.61`、`source_type = release`、`database = postgresql`、`deployment_mode = source_host`、`packages_plugins` 插件接入方式、`iopgps_real_sync_allowed = false` 和 `mock_data_only = true`。


## 为什么必须固定版本

真实插件 API 依赖目标 NocoBase 版本。Collection、ACL、UI Schema、Scheduler、Workflow、文件存储 API、模板打印插件、备份恢复能力都可能随版本变化。若未固定版本就实现真实 adapter，容易出现以下风险：

- Collection 字段定义、关系、索引或迁移 API 与宿主工程不一致。
- ACL、Resource、Action、Controller 注册方式变化导致权限绕过或无法访问。
- UI Schema、菜单、页面、区块注册方式变化导致页面初始化失败。
- Scheduler、Workflow、文件存储和模板打印插件 API 不同导致运行期任务失败。
- 使用 `latest-full` 会随镜像更新漂移，不适合作为真实插件接入、权限验证和升级回滚基准。

生产前必须固定版本，并记录升级策略、回滚策略、插件兼容性检查方式和 API 重新验证清单。

## 候选版本决策表

| candidate_version | source | evidence | advantages | risks | verification_required | recommendation |
| --- | --- | --- | --- | --- | --- | --- |
| `pending` | `unknown` | 当前任务环境无法确认具体官方版本；本轮不拉取完整 NocoBase 源码，不访问真实宿主工程。 | 不伪造版本号，保留人工决策空间。 | 无法启动真实 adapter 实现；无法确认 Collection、ACL、UI Schema 等 API 的最终签名。 | `true` | 保持 `pending_manual_confirmation`，下一阶段由项目负责人或官方来源确认。 |
| `latest-full` | NAS 基础环境测试镜像说明 | 仅可用于基础容器启动和环境冒烟，不代表固定插件 API。 | 可用于验证 NAS 容器目录、端口、测试库连通性等基础环境。 | 镜像可能漂移，不能作为真实接入基准，不能作为生产部署版本。 | `true` | 不推荐作为真实 adapter 目标版本。 |

## 人工确认清单

进入下一阶段前，必须人工确认以下项目：

- 目标 NocoBase 版本号。
- 是否使用完整源码工程。
- 是否使用 Docker 镜像。
- 包管理器选择。
- 是否允许在宿主工程 `packages/plugins` 开发。
- 是否后续打包到 `storage/plugins`。
- 测试数据库类型、地址、库名、账号与隔离策略。
- 测试 `storage` 路径与备份路径。
- 是否启用模板打印插件。
- 是否禁用 IOPGPS 真实同步。
- 是否只使用 mock GPS 数据。
- 是否允许执行迁移与回滚验证。
- 是否具备从测试库恢复的备份。

## 冻结条件

只有同时满足以下条件，才能把 `decision_status` 从 `pending_manual_confirmation` 改为已锁定状态：

1. 版本号来自官方文档、官方源码标签、官方镜像标签或项目负责人书面确认。
2. 版本号被写入本文件的 `target_version`。
3. 完整 NocoBase 宿主工程已切换到同一版本。
4. `docs/nocobase-source-api-verification-plan.md` 中关键 API 已在宿主工程验证。
5. 真实 adapter 仍保持禁止连接生产库、禁止真实 IOPGPS 同步、禁止写入真实文件的安全边界。


## 禁止自动推进

目标版本已确认后仍不允许在当前任务中执行以下事项；如果目标版本回退为未确认，也同样不允许：

- 实现真实 Collection adapter。
- 实现真实 Runtime adapter。
- 实现真实 Page adapter。
- 实现真实 Seed Data adapter。
- 实现真实 Smoke Test adapter。
- 实现真实 Backup / Rollback adapter。
- 创建完整 NocoBase 宿主工程。
- 在 NAS 上安装插件。
- 进入 UAT。

以上限制用于防止在 `target_version = unset` 或仅有 `latest-full` 镜像说明时误把不确定 API 写成已验证实现。

## 人工确认后才能修改的字段

以下字段只有在用户明确提供确认信息后才能修改：

- `confirmed_target_version`
- `confirmed_source_url_or_tag`
- `confirmed_package_manager`
- `confirmed_deployment_mode`
- `confirmed_plugin_install_mode`
- `confirmed_database`
- `confirmed_storage_strategy`
- `confirmed_by`
- `confirmed_at`

## 修改规则

只有用户明确提供上述确认信息后，才允许将 `decision_status` 改为 `confirmed`。在确认信息缺失、来源不明、数据库不是 PostgreSQL、`iopgps_real_sync_allowed = true` 或 `mock_data_only != true` 时，必须继续保持：

- `decision_status = pending_manual_confirmation`
- `target_version = unset`
- `requires_manual_confirmation = true`

Codex 不得编造 NocoBase 版本号，不得把 `latest-full` 作为真实接入目标版本，不得在未验证官方 API 的情况下推进真实 adapter。

## 本轮人工确认包产物

- `docs/nocobase-target-version-manual-confirmation.md`：人工确认清单。
- `docs/nocobase-target-version-freeze-template.md`：版本冻结模板。
- `docs/nocobase-target-version-input-schema.md`：目标版本确认输入 Schema。
- `scripts/nocobase/validate-target-version-confirmation.ts`：目标版本确认校验脚本。
- `scripts/nocobase/generate-target-version-confirmation-template.ts`：待填写确认草案生成脚本。

## 本轮确认应用流程补充

当前仍未锁定 NocoBase 目标版本，必须继续保持 `decision_status = pending_manual_confirmation` 和 `target_version = unset`，不得把 `latest-full` 写成真实接入目标版本。

用户确认目标版本后，应填写 `test-data/generated/nocobase-target-version-confirmation.filled.json`，先运行 `npm run validate:target-version-input -- --file test-data/generated/nocobase-target-version-confirmation.filled.json`，再运行 `npm run apply:target-version-confirmation -- --file test-data/generated/nocobase-target-version-confirmation.filled.json` 做 dry-run。只有用户明确允许应用时，才可添加 `--execute` 更新本文件。

在 `npm run validate:target-version-confirmation` 通过前，`npm run validate:can-start-real-adapter` 必须失败。当前仍不能正式上线测试，仍不能生产部署。

## 目标版本确认应用记录

- 本记录由 `scripts/nocobase/apply-target-version-confirmation.ts` 在用户显式传入 `--execute` 后更新。
- `latest-full` 仍只能用于基础测试说明，不能作为真实 adapter 或生产部署目标版本。
- `iopgps_real_sync_allowed` 必须保持为 `false`，当前不允许真实 IOPGPS 同步。
- `mock_data_only` 必须保持为 `true`，当前只允许 mock 数据。
- 当前即使完成目标版本确认，也不能直接标记为 `production_ready`，仍需隔离测试、权限验证、备份回滚验证和 UAT 准入。

## 本轮确认后的保留门禁说明

目标版本必须人工确认；本文件当前记录的人工确认结果为 `v2.0.61`。该确认只允许进入下一阶段隔离测试接入准备与完整 NocoBase v2.0.61 宿主工程接入准备，不代表当前项目可以正式上线测试或生产部署。
