# 权限设计（第一版）

## 业务假设

- 系统由内部员工使用，司机不登录系统。
- 权限目标是保护敏感财务数据、司机证件信息、付款截图、押金和合同扫描件。
- GPS 维护人员只处理车辆位置、里程和设备状态，不参与租金计费和付款管理。
- 只读审计按授权查看，不能修改数据。

## 数据字段

### 用户与角色

- `user_id`：内部用户唯一标识。
- `display_name`：用户显示名称。
- `role_code`：角色编码。
- `role_name`：角色名称。
- `status`：账号状态。

### 权限项

- `resource_code`：资源编码。
- `action_code`：操作编码。
- `field_code`：字段编码，可用于字段级权限。
- `permission_scope`：数据范围。
- `is_allowed`：是否允许。

### 敏感字段

- `total_paid_amount`：总已付金额。
- `total_future_receivable_amount`：未来应收金额。
- `total_arrears_amount`：总欠款金额。
- `deposit_amount`：押金金额。
- `payment_method`：付款方式。
- `payment_screenshot_files`：付款截图。
- `identity_document_number`：司机证件号。
- `identity_document_files`：司机证件照片。
- `driver_license_files`：司机驾照照片。
- `signed_contract_scan_files`：合同签署扫描件。

## 关系

- 一个内部用户可以拥有一个或多个角色。
- 一个角色拥有多项资源权限、操作权限和字段权限。
- 字段级权限优先保护敏感字段，即使用户可查看列表，也不代表可查看敏感字段。
- GPS 权限与财务权限分离。

## 枚举值

- `role_code`：`system_admin` 系统管理员、`manager` 经理、`finance` 财务、`operations` 运营、`gps_maintainer` GPS 维护人员、`readonly_auditor` 只读审计。
- `action_code`：`create` 新增、`read` 查看、`update` 修改、`delete` 删除、`approve` 审批、`export` 导出、`upload` 上传。
- `permission_scope`：`all` 全部、`department` 本部门、`assigned` 已分配、`readonly` 只读、`none` 无权限。
- `sensitive_level`：`normal` 普通、`financial` 财务敏感、`identity` 身份敏感、`document` 文件敏感、`gps` GPS 数据。

## 校验规则

- 司机不得拥有系统登录账号或司机端权限。
- 未授权角色不能查看付款截图、付款方式、押金金额、总已付金额、未来应收金额。
- GPS 维护人员不能查看付款截图、付款方式和司机敏感证件。
- 运营可维护司机、车辆和合同资料，但不默认查看完整财务汇总。
- 经理可查看财务汇总并审批免除租金。
- 财务可录入付款、上传付款截图、管理押金、查看应收和欠款。
- 只读审计不能修改、删除、上传或审批任何业务数据。
- 导出功能必须遵守与界面一致的字段级权限。

## 工作流

1. 系统管理员创建内部用户并分配角色。
2. 员工访问司机、车辆、合同、台账、付款、GPS 等资源时，系统检查资源权限。
3. 页面展示字段时，系统按字段级权限隐藏或脱敏敏感字段。
4. 财务录入付款或上传截图时，系统检查付款操作权限。
5. 经理审批免除租金时，系统检查审批权限。
6. GPS 维护人员查看设备状态时，只能进入 GPS 相关资源。
7. 审计用户查看日志和数据时，只能按授权只读访问。

## 权限注意事项

- 敏感数据默认拒绝，明确授权后才可查看。
- 权限控制应覆盖列表、详情、日历、统计、导出和文件预览。
- 合同扫描件和付款截图都属于敏感文件，不得作为公开附件。
- 多语言字段标签不能泄露被隐藏的敏感字段。
- 权限变更应保留审计记录。

## 验收测试点

- 运营账号可创建合同但看不到付款截图。
- GPS 维护账号可查看设备状态但看不到司机证件照片。
- 财务账号可录入付款并上传付款截图。
- 经理账号可审批免除租金。
- 只读审计账号无法修改台账或付款。
- 未授权导出时，敏感字段应被隐藏或拒绝导出。

## 本轮纯函数实现补充：日历敏感字段过滤

- `plugin-rental-core` 已预留并实现纯函数级别的 `getCalendarFieldVisibility`、`canViewCalendarField` 与 `filterCalendarSensitiveData`，用于在服务端返回司机日历数据前统一过滤敏感字段。
- 敏感字段包括 `total_paid_amount`、`current_debt_amount`、`current_debt_days`、`future_receivable_amount`、`deposit_required_amount`、`deposit_received_amount`、`payment_screenshot`、`payment_method`、`due_amount`、`paid_amount`、`waived_amount`、`balance_amount` 以及司机证件相关字段。
- `system_admin` 默认可见全部；`manager` 和 `accountant` 可见财务汇总、押金和付款相关字段；`operator` 默认只看每日状态，不默认看总已付、未来应收、押金、付款截图和付款方式；`gps_maintenance` 默认看不到财务汇总和付款资料；`readonly_auditor` 默认隐藏敏感财务字段，需通过显式权限配置开放。
- 当前实现只是纯函数过滤，不替代 NocoBase ACL。后续接入真实 NocoBase 应用时，仍必须在服务端查询、服务方法和字段权限层同时控制，不能只靠前端页面隐藏。

## 本轮纯函数实现补充：押金与操作日志敏感信息

- 押金金额、押金付款方式、押金付款截图、退款凭据均属于敏感字段，普通运营角色默认不可见。
- 操作日志中的 `before_value` 和 `after_value` 必须在服务端脱敏后写入，不能记录完整证件号、付款截图 URL、合同扫描件、IOPGPS 密钥或 access token。
- 本轮 `maskSensitiveLogValue` 仅提供纯函数脱敏能力；后续真实日志落库时仍需在服务端统一调用，不能由前端决定是否脱敏。
