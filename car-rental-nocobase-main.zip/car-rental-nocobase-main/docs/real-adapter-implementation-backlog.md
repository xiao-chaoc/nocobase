# 真实 Adapter 下阶段实施 Backlog

## 使用原则

下一阶段是锁定 NocoBase 目标版本和验证官方 API。当前仍不能实现真实 adapter。未经官方 API 验证不得写真实 adapter。当前不能正式上线测试，不能生产部署。

不得伪造 API。不得生产库调试。无法确认的 API 必须标记待验证。

| 编号 | 标题 | 目标 | 输入 | 输出 | 依赖 | 是否需要官方 API 确认 | 是否需要完整 NocoBase 工程 | 是否可以由 Codex 实现 | 是否需要人工确认 | 验收标准 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| B01 | 锁定 NocoBase 目标版本 | 完成 锁定 NocoBase 目标版本 的最小可验证步骤。 | 本轮调研文档、草案 adapter、Runbook。 | 版本记录、代码或验证报告。 | 前序 backlog 和官方 API 结论。 | 是 | 否 | 是 | 是 | 在隔离环境通过，未连接生产，未伪造 API。 |
| B02 | 创建完整 NocoBase 源码测试工程 | 完成 创建完整 NocoBase 源码测试工程 的最小可验证步骤。 | 本轮调研文档、草案 adapter、Runbook。 | 版本记录、代码或验证报告。 | 前序 backlog 和官方 API 结论。 | 是 | 是 | 是 | 是 | 在隔离环境通过，未连接生产，未伪造 API。 |
| B03 | 接入 plugin-rental-core | 完成 接入 plugin-rental-core 的最小可验证步骤。 | 本轮调研文档、草案 adapter、Runbook。 | 版本记录、代码或验证报告。 | 前序 backlog 和官方 API 结论。 | 是 | 是 | 是 | 视情况 | 在隔离环境通过，未连接生产，未伪造 API。 |
| B04 | 接入 plugin-contract-documents | 完成 接入 plugin-contract-documents 的最小可验证步骤。 | 本轮调研文档、草案 adapter、Runbook。 | 版本记录、代码或验证报告。 | 前序 backlog 和官方 API 结论。 | 是 | 是 | 是 | 视情况 | 在隔离环境通过，未连接生产，未伪造 API。 |
| B05 | 接入 plugin-iopgps | 完成 接入 plugin-iopgps 的最小可验证步骤。 | 本轮调研文档、草案 adapter、Runbook。 | 版本记录、代码或验证报告。 | 前序 backlog 和官方 API 结论。 | 是 | 是 | 是 | 视情况 | 在隔离环境通过，未连接生产，未伪造 API。 |
| B06 | 实现 Collection 真实 adapter | 完成 实现 Collection 真实 adapter 的最小可验证步骤。 | 本轮调研文档、草案 adapter、Runbook。 | 版本记录、代码或验证报告。 | 前序 backlog 和官方 API 结论。 | 是 | 是 | 是 | 视情况 | 在隔离环境通过，未连接生产，未伪造 API。 |
| B07 | 实现 Runtime 真实 adapter | 完成 实现 Runtime 真实 adapter 的最小可验证步骤。 | 本轮调研文档、草案 adapter、Runbook。 | 版本记录、代码或验证报告。 | 前序 backlog 和官方 API 结论。 | 是 | 是 | 是 | 视情况 | 在隔离环境通过，未连接生产，未伪造 API。 |
| B08 | 实现 Page 真实 adapter | 完成 实现 Page 真实 adapter 的最小可验证步骤。 | 本轮调研文档、草案 adapter、Runbook。 | 版本记录、代码或验证报告。 | 前序 backlog 和官方 API 结论。 | 是 | 是 | 是 | 视情况 | 在隔离环境通过，未连接生产，未伪造 API。 |
| B09 | 实现 Seed Data 真实 adapter | 完成 实现 Seed Data 真实 adapter 的最小可验证步骤。 | 本轮调研文档、草案 adapter、Runbook。 | 版本记录、代码或验证报告。 | 前序 backlog 和官方 API 结论。 | 是 | 是 | 是 | 视情况 | 在隔离环境通过，未连接生产，未伪造 API。 |
| B10 | 实现 Backup / Rollback 真实 adapter | 完成 实现 Backup / Rollback 真实 adapter 的最小可验证步骤。 | 本轮调研文档、草案 adapter、Runbook。 | 版本记录、代码或验证报告。 | 前序 backlog 和官方 API 结论。 | 是 | 是 | 是 | 视情况 | 在隔离环境通过，未连接生产，未伪造 API。 |
| B11 | 实现 Smoke Test 真实 adapter | 完成 实现 Smoke Test 真实 adapter 的最小可验证步骤。 | 本轮调研文档、草案 adapter、Runbook。 | 版本记录、代码或验证报告。 | 前序 backlog 和官方 API 结论。 | 是 | 是 | 是 | 视情况 | 在隔离环境通过，未连接生产，未伪造 API。 |
| B12 | 插件打包 | 完成 插件打包 的最小可验证步骤。 | 本轮调研文档、草案 adapter、Runbook。 | 版本记录、代码或验证报告。 | 前序 backlog 和官方 API 结论。 | 是 | 是 | 是 | 视情况 | 在隔离环境通过，未连接生产，未伪造 API。 |
| B13 | NAS 插件安装测试 | 完成 NAS 插件安装测试 的最小可验证步骤。 | 本轮调研文档、草案 adapter、Runbook。 | 版本记录、代码或验证报告。 | 前序 backlog 和官方 API 结论。 | 是 | 是 | 是 | 是 | 在隔离环境通过，未连接生产，未伪造 API。 |
| B14 | UAT 测试 | 完成 UAT 测试 的最小可验证步骤。 | 本轮调研文档、草案 adapter、Runbook。 | 版本记录、代码或验证报告。 | 前序 backlog 和官方 API 结论。 | 是 | 是 | 是 | 是 | 在隔离环境通过，未连接生产，未伪造 API。 |
| B15 | 上线测试冻结 | 完成 上线测试冻结 的最小可验证步骤。 | 本轮调研文档、草案 adapter、Runbook。 | 版本记录、代码或验证报告。 | 前序 backlog 和官方 API 结论。 | 是 | 是 | 是 | 是 | 在隔离环境通过，未连接生产，未伪造 API。 |

## 下阶段最小执行顺序

1. 先完成 B01 与 B02。
2. 再用 B03 验证最小插件加载与 Collection 能力。
3. 通过后再推进 B06、B07、B08。
4. 最后推进 Seed、Backup/Rollback、Smoke、打包、NAS 测试、UAT 和上线测试冻结。

## 本轮补充：宿主工程接入准备 Backlog

- 新增目标版本决策记录，当前状态为 `pending_manual_confirmation`，目标版本尚未锁定。
- 新增宿主工程准备 Runbook，明确当前仓库不是完整 NocoBase 工程，不要把完整 NocoBase 源码提交进当前仓库。
- 新增宿主工程接入分支计划，明确每个 commit 边界和 PR 检查项。
- 新增 NocoBase 源码 API 验证计划，所有不确定 API 必须标记 `unknown` 或待验证。
- 新增 `scripts/host/` dry-run 脚本草案和 `validate:host-bootstrap-docs` 校验命令。

下一阶段需要人工确认 NocoBase 目标版本。未确认目标版本前，不应实现真实 adapter。当前仍不能正式上线测试，当前仍不能生产部署。

## 本轮 Backlog 补充：版本冻结前禁止推进真实 adapter

当前目标 NocoBase 版本仍为 `pending_manual_confirmation`，`target_version = unset`。真实 adapter Backlog 必须整体等待用户人工确认目标版本后再执行。

版本确认前新增的唯一可执行项是维护确认包和校验机制：人工确认清单、版本冻结模板、输入 Schema、确认草案生成脚本和确认校验脚本。当前不能正式上线测试，也不能生产部署。

## 目标版本确认阻塞项

当前 backlog 中所有真实 adapter 实现项继续被目标版本确认阻塞。状态保持 `decision_status = pending_manual_confirmation`、`target_version = unset`。用户需要填写 `filled.json` 并运行 `validate:target-version-input` 与 `apply:target-version-confirmation` dry-run；在 `validate:target-version-confirmation` 未通过前，`validate:can-start-real-adapter` 必须失败。当前仍不能正式上线测试，仍不能生产部署。

## 本轮补充：目标版本确认审查前置项

Backlog 中所有真实 adapter 条目均依赖目标版本确认流程完成。该流程必须通过 GitHub Issue + `filled.json` + apply 脚本 + PR 审查完成。当前目标版本仍为 `pending_manual_confirmation`，未通过 `validate:target-version-confirmation` 前，不允许真实 adapter；未通过 `validate:can-start-real-adapter` 前，不允许进入完整宿主工程真实接入。当前仍不能正式上线测试，仍不能生产部署。

## 本轮新增 Backlog：NocoBase v2.0.61 宿主工程接入任务包

> 包管理器修正：完整 NocoBase v2.0.61 宿主工程环境检测已确认当前接入基准为 `package_manager = yarn`。后续宿主工程人工命令应使用 `yarn`，不得把 `pnpm` 作为当前默认值；除非重新验证目标版本源码工程确实支持 `pnpm`。

目标版本已确认：`v2.0.61`。下一阶段是完整 NocoBase v2.0.61 宿主工程接入准备。

新增 Backlog 项：

- 阅读 `docs/nocobase-v2.0.61-host-integration-task.md`，确认 source_host、packages_plugins、yarn、postgresql、iopgps_real_sync_allowed = false、mock_data_only = true。
- 按 `docs/nocobase-v2.0.61-host-directory-plan.md` 准备独立 host 目录与独立 Docker runtime 目录。
- 按 `docs/nocobase-v2.0.61-host-bootstrap-commands.md` 由人工确认后在宿主工程执行命令草案，禁止在当前仓库执行。
- 按 `docs/nocobase-v2.0.61-plugin-copy-plan.md` 复制三个插件和 shared automation，禁止复制 `.env`、`.env.test`、`filled.json`、`*confirmed*.json`。
- 在宿主工程中执行 `docs/task-real-environment-adapter-v2.0.61.md`。
- 环境检测通过后，再执行 `docs/task-real-collection-adapter-v2.0.61.md`。

当前项目仍不包含完整 NocoBase 源码，当前仍不能正式上线测试，当前仍不能生产部署，当前不能标记为 `production_ready`。
