# NocoBase 目标版本人工确认操作清单

## 1. 操作目标

本清单用于把 GitHub Issue 中的人工确认信息，转为可校验、可 dry-run、可审查的目标 NocoBase 版本确认 PR。当前目标版本仍是 `pending_manual_confirmation`，本清单不会要求操作者编造版本号，也不会要求连接 NocoBase 或写数据库。

## 2. 操作前确认

- 已阅读 `docs/nocobase-target-version-decision.md`。
- 已阅读 `docs/nocobase-target-version-confirmation-workflow.md`。
- 已确认本轮不使用生产库。
- 已确认本轮不提交 `.env` 或 `.env.test`。
- 已确认本轮不提交真实司机资料、真实付款截图、真实合同扫描件或真实 IOPGPS 凭据。
- 已确认 `latest-full` 仅可用于基础环境测试，不能作为真实接入目标版本。
- 已确认 `iopgps_real_sync_allowed` 必须为 `false`。
- 已确认 `mock_data_only` 必须为 `true`。

## 3. 从 GitHub Issue 获取用户填写内容

1. 打开使用 `.github/ISSUE_TEMPLATE/nocobase-target-version-confirmation.yml` 创建的 Issue。
2. 只复制目标版本确认字段：`target_version`、`source_type`、`source_reference`、`package_manager`、`node_version`、`database`、`deployment_mode`、`plugin_development_mode`、`plugin_install_mode`、`confirmed_by`、`confirmed_at`。
3. 不复制任何评论中的密钥、密码、真实司机文件、付款截图或合同扫描件。
4. 如 Issue 中出现密钥或真实业务文件，应先要求删除或脱敏，并暂停后续操作。

## 4. 复制模板

在本地任务工作区复制模板：

```bash
cp test-data/generated/nocobase-target-version-confirmation.template.json test-data/generated/nocobase-target-version-confirmation.filled.json
```

`filled.json` 只是人工操作输入文件，默认不得提交。

## 5. 填写 filled.json

编辑 `test-data/generated/nocobase-target-version-confirmation.filled.json`：

- `decision_status` 填写为 `confirmed`，仅限用户已经明确确认时。
- `target_version` 填写用户确认的目标版本，不能是 `unset` 或 `latest-full`。
- `source_type` 只能是 `tag`、`branch`、`docker_image`、`release`。
- `source_reference` 必须填写可审查来源引用。
- `package_manager` 只能是 `npm`、`yarn`、`pnpm`。
- `database` 必须是 `postgresql`。
- `iopgps_real_sync_allowed` 必须是 `false`。
- `mock_data_only` 必须是 `true`。
- `confirmed_by` 与 `confirmed_at` 必须来自人工确认信息。
- 不增加任何密码字段，不增加 `APP_KEY`、`DB_PASSWORD` 或 `IOPGPS_LOGIN_KEY`。

## 6. 校验输入文件

```bash
npm run validate:target-version-input -- --file test-data/generated/nocobase-target-version-confirmation.filled.json
```

如果失败，停止操作，回到 Issue 核对字段，不得绕过脚本。

## 7. dry-run 应用

```bash
npm run apply:target-version-confirmation -- --file test-data/generated/nocobase-target-version-confirmation.filled.json
```

dry-run 只输出将要更新的字段，不写入 `docs/nocobase-target-version-decision.md`。

## 8. 真实应用

只有输入校验与 dry-run 均符合预期后，才允许执行：

```bash
npm run apply:target-version-confirmation -- --file test-data/generated/nocobase-target-version-confirmation.filled.json -- --execute
```

执行后应只产生目标版本决策文档和必要说明文档变更。

## 9. 应用后门禁

```bash
npm run validate:target-version-confirmation
npm run validate:can-start-real-adapter
```

`validate:target-version-confirmation` 未通过前，不允许真实 adapter。`validate:can-start-real-adapter` 未通过前，不允许进入完整宿主工程真实接入。

## 10. 创建 PR

1. 确认变更只包含允许提交的文件。
2. 使用 PR 标题：`确认 NocoBase 目标版本 <version>`。
3. 在 PR 内容中填写 `.github/pull_request_template.md` 的全部检查项。
4. 列出执行过的命令和结果。

## 11. 检查 PR

- 确认没有提交 `.env` 或 `.env.test`。
- 确认没有提交 `filled.json`。
- 确认没有提交真实司机资料、真实付款截图、真实合同扫描件。
- 确认没有真实密钥。
- 确认 `latest-full` 没有作为真实目标版本。
- 确认 `iopgps_real_sync_allowed = false`。
- 确认 `mock_data_only = true`。

## 12. 校验失败处理

- 如果输入校验失败，修正 `filled.json` 后重新校验。
- 如果 apply 失败，不要手工绕过，先检查错误提示。
- 如果门禁失败，保持 PR 为未就绪状态，并在 PR 中说明失败原因。
- 如果发现密钥或真实业务文件，立即从变更中移除并重新检查。

## 13. 确认 filled.json 没有提交

运行：

```bash
git status --short
```

确认输出中没有 `test-data/generated/nocobase-target-version-confirmation.filled.json`。

## 14. 确认 .env 没有提交

运行：

```bash
git status --short
```

确认输出中没有 `.env` 或 `.env.test`。

## 15. 确认没有真实密钥

检查 PR diff 中不得出现真实密钥、密码、生产连接串、真实 IOPGPS 凭据或未脱敏 token。发现后必须删除并重新提交。

## 16. 确认未进入真实 adapter 实现

本流程只做版本确认，不实现真实 adapter，不连接 NocoBase，不写数据库，不创建 Collections，不创建页面，不注册权限，不导入数据。

## 17. 通过后下一步

全部门禁通过后，下一步只能创建完整 NocoBase 宿主工程接入任务，并继续保持隔离测试库、mock 数据和真实 IOPGPS 禁用边界。正式上线测试和生产部署仍需后续 readiness 门禁。
