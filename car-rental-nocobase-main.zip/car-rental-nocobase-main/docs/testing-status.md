# 测试状态说明

## 当前测试框架

当前项目使用根目录最小 TypeScript 测试框架，不引入真实 NocoBase、数据库、IOPGPS、PDF、地图或文件上传依赖。

- `npm run typecheck`：执行 `tsc --noEmit -p tsconfig.json`。
- `npm run test`：先执行 `tsc -p tsconfig.test.json` 编译测试，再执行 `node .test-dist/tests/run-tests.js`。
- `tests/testHarness.ts` 提供最小 `test`、`assert`、`assertEqual`、`assertThrows` 和汇总报告能力。
- `.test-dist/` 是测试编译输出，已加入 `.gitignore`，不提交构建产物。

## 当前测试范围

当前测试只覆盖纯函数，不伪造 NocoBase 运行环境。

已覆盖模块：

1. `plugin-rental-core`
   - 自然周计费与默认免租日校验。
   - 时限合同 6 个月以上台账生成。
   - 长租合同按 `horizonDays` 生成未来台账。
   - 每日台账状态、未来应收、当前欠款、免租日。
   - 付款分配、单日不可超付、整笔失败、付款冲正。
   - 未付原因、欠款、争议、待免除审批和免除审批。
   - 合同汇总、司机日历汇总、`debt_only` 过滤。
   - 敏感字段权限过滤。
   - 押金创建、抵扣、退款、免除边界。
   - 操作日志敏感字段脱敏。
2. `plugin-iopgps`
   - token 过期和提前刷新判断。
   - `buildTokenState` 不暴露 `login_key_encrypted`。
   - GPS 状态归一化和车辆 GPS 状态映射。
   - 定位快照、车辆位置 patch、每日里程、幂等键。
   - IOPGPS 错误日志脱敏和失败隔离。
3. `plugin-contract-documents`
   - 三语合同语言校验。
   - 默认 active 模板选择和最新版本回退。
   - 缺失模板汇总。
   - 合同文件生成记录不真实生成 Word/PDF。
   - 文件名不包含司机证件号或手机号。
   - 合同文件状态流转、作废和签署状态推导。

4. 插件注册草案
   - 三个插件均有 `pluginRegistration` 描述。
   - 插件依赖关系、核心 Collection、权限角色、定时任务草案、动作草案和失败隔离说明。

## 未覆盖模块

当前尚未覆盖或尚未完整覆盖：

- 真实 NocoBase 插件生命周期注册。
- 真实 Collection 注册和数据库迁移。
- 真实 NocoBase ACL、菜单、页面、动作和工作流。
- 真实文件存储和文件访问权限。
- 真实 IOPGPS HTTP 客户端、token 刷新落库和定时任务。
- 真实合同 Word/PDF 生成、LibreOffice 转换和上传。
- 并发事务、数据库唯一约束和回滚。
- 端到端验收测试。

## 外部依赖边界

当前测试明确不依赖：

- 真实 NocoBase。
- 真实数据库。
- 真实 IOPGPS。
- 真实合同文件生成。
- 真实文件上传。
- 真实司机、车辆、付款截图、合同扫描件或 IOPGPS 密钥。

## 本轮质量门禁结果

本轮已执行并通过：

- `npm run typecheck`：通过。
- `npm run test`：通过。
- 纯函数测试数量：63 个。
- 失败项：无。

## 后续仍需补充的集成测试

后续接入真实 NocoBase 工程后，仍必须补充：

- 插件启用和禁用测试。
- Collection 注册和迁移测试。
- 数据库唯一约束、事务和回滚测试。
- 服务端权限和敏感字段访问测试。
- 文件存储、合同扫描件和生成文件权限测试。
- IOPGPS 定时任务、错误日志和失败隔离测试。
- 工作流触发和操作日志落库测试。

## mock 测试数据脚本覆盖

本轮新增 `tests/test-data/`，覆盖 seed、validate、clear 本地文件级脚本，确认生成数据可校验通过、清理脚本不删除 fixtures、生成数据不包含真实文件 URL 或短租预订字段。

## NAS 测试部署文件校验

本轮新增 `validate:nas-test-docs` 脚本和 `tests/deployment/` 测试，用于校验测试 Compose、环境变量模板、NAS 测试文档、插件接入测试文档和测试脚本草案是否存在，并检查文档明确不能用于生产。

## 插件打包与 NAS 自检测试覆盖

本轮新增插件结构、插件注册描述和 NAS 测试前自检相关测试。当前测试仍然只检查本地文件、结构和纯函数，不做真实部署，不连接数据库，不调用 IOPGPS。
