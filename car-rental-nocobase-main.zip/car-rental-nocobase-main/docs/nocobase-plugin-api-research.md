# NocoBase 插件 API 调研

## 本轮边界

本轮只做调研、映射和待验证清单，不实现真实 adapter，不连接 NocoBase，不写数据库，不创建页面，不安装插件。所有 API 判断必须标记来源：`official_docs`、`official_source`、`local_project`、`unknown`。

本轮联网可访问 NocoBase 官方文档和官方 GitHub 页面，因此文档中只记录已看到的官方能力方向，不把未验证调用写成真实可用 API。

## 官方来源摘要

| 来源标记 | 来源 | 本轮用途 |
| --- | --- | --- |
| official_docs | `https://docs.nocobase.com/plugin-development/server/collections` | 确认插件可通过 `defineCollection()`、`extendCollection()` 定义 Collection，并通过同步/升级处理结构。 |
| official_docs | `https://docs.nocobase.com/plugin-development/server/resource-manager` | 确认资源动作、内置 CRUD、关系动作、`registerActionHandlers`、`resourceManager.define` 的方向。 |
| official_docs | `https://docs.nocobase.com/plugin-development/client/router` | 确认客户端页面可通过 router 和 plugin settings manager 注册。 |
| official_docs | `https://docs.nocobase.com/plugin-development/common/i18n` | 确认 `src/locale`、`app.t`、`ctx.t`、`plugin.t`、`useT`、`tExpr`。 |
| official_docs | `https://docs.nocobase.com/api/server/migration` | 确认 Migration、执行时机、`db`、`queryInterface`、`pm` 等能力方向。 |
| official_docs | `https://docs.nocobase.com/workflow` | 确认 Workflow 产品能力存在。 |
| official_source | `https://github.com/nocobase/nocobase` | 确认官方源码工程存在，后续需固定 tag 调研。 |
| local_project | 当前仓库真实 adapter 草案与 Runbook | 确认本项目自动化边界和草案方法。 |
| unknown | 本轮未能从官方文档直接确认的编程 API | 必须待真实工程验证。 |

## API 区域总表

| API 区域 | 目标能力 | 当前草案模块 | 预期真实 NocoBase 能力 | 官方来源 | 是否已验证 | 风险 | 后续验证步骤 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 插件生命周期 | 插件定义方式、server 入口、client 入口、加载顺序、依赖声明、启用/禁用流程、初始化时机 | realRuntimeRegistrationAdapter、nocobaseRealAdapter | Plugin server/client 类、插件管理器、CLI 插件 enable/disable；具体生命周期顺序需在目标版本源码验证 | official_docs + official_source | 部分 | 文档可确认插件架构存在，但不能确认本项目草案的调用点 | 在固定源码 tag 中读取 Plugin、PluginManager、插件 package 配置，并创建隔离插件加载 smoke test |
| Collection 注册 | Collection 定义格式、字段类型、relation、file、json、decimal、date/datetime、索引、唯一约束、migration/schema sync、存在检测、回滚 | realCollectionRegistrationAdapter | defineCollection、extendCollection、db.collection、Migration、queryInterface；字段完整映射待验证 | official_docs | 部分 | 字段类型和 UI interface 可能随版本变化，索引/唯一约束不能凭草案硬写 | 在完整工程中对每个业务 Collection 生成最小 schema 并验证同步和回滚 |
| 服务方法注册 | 服务端方法、controller/action/route/resource/action、事务、错误返回、操作日志 | realRuntimeRegistrationAdapter | resourceManager 自动资源、registerActionHandlers、resourceManager.define；事务和日志接入待验证 | official_docs | 部分 | 错误格式、事务边界、审计日志需要源码确认 | 固定版本中验证 resource action、ctx、repository transaction 和 audit manager |
| 权限 ACL | 角色、资源权限、动作权限、字段级权限、敏感字段隐藏、数据范围、服务端强制 | realRuntimeRegistrationAdapter | 官方产品能力确认有用户与权限，README 说明字段级权限和审计；具体 ACL 编程 API 待验证 | official_docs + unknown | 待验证 | 仅靠前端隐藏会泄露敏感数据 | 在完整工程中验证角色、资源动作、字段级权限和服务端强制 |
| UI Schema / 页面配置 | 菜单、页面、区块、表格、表单、详情、日历替代、筛选器、按钮、角色可见性、schema 导入导出 | realPageRegistrationAdapter | client router、pluginSettingsManager；业务页面 UI Schema 自动导入/导出 API 待验证 | official_docs + unknown | 待验证 | V2 页面体系变化可能导致页面草案不可用 | 固定版本验证菜单、动态页面、区块 schema、日历替代和导入导出 |
| i18n | 插件多语言文件位置、zh-CN/en-US/fr-FR、服务端错误、页面标题、枚举值 | realRuntimeRegistrationAdapter、realPageRegistrationAdapter | src/locale，plugin.t、app.t、ctx.t、useT、tExpr | official_docs | 部分 | fr-FR 文件是否自动加载和枚举多语言需验证 | 在插件 server/client 中验证三语文件、错误消息和枚举显示 |
| 定时任务 / 工作流 | scheduler、workflow、任务注册、失败处理、禁用 IOPGPS、GPS 失败隔离 | realRuntimeRegistrationAdapter、realSmokeTestAdapter | 官方 Workflow 能力存在；scheduler 编程 API 未确认 | official_docs + unknown | 待验证 | 误启用真实 IOPGPS 或失败影响租金台账 | 先实现 mock/禁用开关，再验证 workflow/scheduler API，确保失败隔离 |
| 文件存储 | 文件字段、上传存储、文件权限、付款截图、合同扫描件、司机证件、mock 文件导入 | realCollectionRegistrationAdapter、realSeedDataImportAdapter | 官方有文件集合和 SDK storage API；字段、权限和导入策略待验证 | official_docs + unknown | 待验证 | 敏感文件权限错误风险高 | 完整工程中用 mock 文件验证上传、读取、字段级权限和 storage 隔离 |
| 模板打印 / 合同文件 | 模板打印插件、Word/PDF、LibreOffice、打印状态、扫描件上传 | realSmokeTestAdapter、plugin-contract-documents | 官方生态可能有模板打印能力，但本轮未确认可编程 API | unknown | 待验证 | 合同生成若依赖未授权插件会阻塞合同文件模块 | 把合同文件模块拆为状态建模+扫描件上传先行，生成能力单独验证 |
| 备份 / 回滚 | 官方备份能力、PostgreSQL 备份、storage 备份、插件禁用、migration 回滚 | realBackupRollbackAdapter | CLI 有插件 enable/disable，Migration 有 up；官方备份/restore API 待确认；PostgreSQL/storage 可用外部策略 | official_docs + unknown | 待验证 | 回滚不完整会污染测试库或丢文件 | 先使用隔离库 pg_dump/storage snapshot 草案，再验证官方发布管理/备份能力 |

## API 区域细化清单

### 插件生命周期

| 检查项 | 来源 | 状态 | 说明 |
| --- | --- | --- | --- |
| 插件定义方式 | official_docs | 待验证 | 文档确认插件开发入口存在，具体 server/client 类、包名、导出方式需在固定版本源码验证。 |
| server 入口 | official_docs | 待验证 | 需验证 `src/server` 约定和导出形式。 |
| client 入口 | official_docs | 待验证 | 需验证 `client-v2`、router 和插件设置页注册。 |
| 插件加载顺序 | unknown | 待验证 | 不得凭记忆写入实现。 |
| 插件依赖声明 | unknown | 待验证 | 需读取目标版本插件 package 规范。 |
| 插件启用/禁用流程 | official_docs | 部分 | CLI 文档存在 enable/disable 方向，真实运行 API 仍需验证。 |
| 插件初始化时机 | official_docs | 部分 | Migration 有 beforeLoad/afterSync/afterLoad；插件 load/install 时机需源码确认。 |

### Collection 注册

| 检查项 | 来源 | 状态 | 说明 |
| --- | --- | --- | --- |
| Collection 定义格式 | official_docs | 部分 | 文档确认 `defineCollection()`、`db.collection()` 方向。 |
| 字段类型 | official_docs | 待验证 | string/text/relation 示例存在，file/json/decimal/date/datetime 需完整确认。 |
| enum / select 字段 | unknown | 待验证 | 不得硬写 interface 或字段配置。 |
| relation 字段 | official_docs | 部分 | hasOne/hasMany/belongsTo/belongsToMany 方向已见。 |
| file 字段 | official_docs | 待验证 | 文件集合能力存在，具体字段和权限待验证。 |
| json 字段 | unknown | 待验证 | 待源码确认。 |
| decimal 字段 | unknown | 待验证 | 待源码确认。 |
| date / datetime 字段 | unknown | 待验证 | 待源码确认。 |
| 索引和唯一约束 | official_docs | 部分 | Migration 示例有 `queryInterface.addConstraint`，Collection 配置方式待验证。 |
| migration 或 schema sync | official_docs | 部分 | 文档确认激活同步、upgrade、Migration。 |
| 如何检测 Collection 是否已存在 | unknown | 待验证 | 需验证 collection manager 或 db API。 |
| 如何安全回滚 | official_docs + unknown | 待验证 | Migration 和外部备份可做方向，真实回滚 API 待验证。 |

### 服务方法注册

| 检查项 | 来源 | 状态 | 说明 |
| --- | --- | --- | --- |
| 服务端方法注册方式 | official_docs | 部分 | resourceManager 可注册动作。 |
| controller / action / route / resource/action 机制 | official_docs | 部分 | 资源动作 `:action` 机制已确认方向。 |
| 事务处理方式 | unknown | 待验证 | 需验证 repository/sequelize 事务写法。 |
| 错误返回方式 | unknown | 待验证 | 需验证 ctx 异常和多语言错误格式。 |
| 操作日志接入方式 | official_source + unknown | 待验证 | GitHub README 提到审计日志，编程 API 待源码验证。 |

### 权限 ACL

| 检查项 | 来源 | 状态 | 说明 |
| --- | --- | --- | --- |
| 角色创建 | official_docs | 待验证 | 产品文档有用户权限，编程 API 待验证。 |
| 资源权限 | official_docs | 待验证 | 需验证 ACL 数据模型或 API。 |
| 动作权限 | official_docs | 待验证 | 需验证资源动作与 ACL 绑定。 |
| 字段级权限 | official_source | 待验证 | 官方 README 描述字段级权限，需 API 验证。 |
| 敏感字段隐藏 | unknown | 待验证 | 必须服务端强制，不得仅靠页面隐藏。 |
| 数据范围控制 | unknown | 待验证 | 待真实工程验证。 |
| 服务端强制权限 | unknown | 待验证 | 关键阻塞项。 |
| 避免仅靠前端隐藏 | local_project | 已明确 | 本项目安全要求强制。 |

### UI Schema / 页面配置

| 检查项 | 来源 | 状态 | 说明 |
| --- | --- | --- | --- |
| 菜单注册 | official_docs | 部分 | plugin settings menu 可注册，业务菜单待验证。 |
| 页面注册 | official_docs | 部分 | router 可注册页面。 |
| 区块注册 | official_docs | 待验证 | Blocks 文档需在下一阶段细查。 |
| 表格/表单/详情区块 | unknown | 待验证 | 不得把草案写成真实 UI Schema。 |
| 日历区块或替代方案 | unknown | 待验证 | 需确认是否有 Calendar collection/block。 |
| 筛选器 | unknown | 待验证 | 待验证。 |
| 按钮动作绑定 | unknown | 待验证 | 待验证。 |
| 角色可见性 | unknown | 待验证 | 待验证。 |
| 页面 schema 导入/导出方式 | unknown | 待验证 | 下一阶段关键项。 |

### i18n

| 检查项 | 来源 | 状态 | 说明 |
| --- | --- | --- | --- |
| 插件多语言文件位置 | official_docs | 部分 | `src/locale` 已确认方向。 |
| zh-CN / en-US / fr-FR 注册方式 | official_docs | 部分 | 多语言文件机制已确认，fr-FR 需实测。 |
| 服务端错误消息多语言 | official_docs | 部分 | `ctx.t`、`plugin.t` 可用方向。 |
| 页面标题多语言 | official_docs | 部分 | `plugin.t`、`useT`、`tExpr` 方向。 |
| 枚举值多语言 | unknown | 待验证 | 待验证。 |

### 定时任务 / 工作流

| 检查项 | 来源 | 状态 | 说明 |
| --- | --- | --- | --- |
| 是否有 scheduler | unknown | 待验证 | 未确认目标版本编程 API。 |
| 是否有 workflow | official_docs | 部分 | 产品能力存在。 |
| 定时任务注册方式 | unknown | 待验证 | 不得硬写。 |
| 任务失败处理 | unknown | 待验证 | 需验证重试、日志和隔离。 |
| 禁用 IOPGPS 真实同步的方法 | local_project | 已明确 | `IOPGPS_SYNC_ENABLED=false`，真实 API 待验证。 |
| GPS 失败隔离方式 | local_project + unknown | 待验证 | 本项目业务规则明确，NocoBase 接入待验证。 |

### 文件存储

| 检查项 | 来源 | 状态 | 说明 |
| --- | --- | --- | --- |
| 文件字段类型 | official_docs + unknown | 待验证 | 文件集合方向存在，具体字段配置待验证。 |
| 上传文件存储方式 | official_docs + unknown | 待验证 | SDK storage 文档入口存在，完整策略待验证。 |
| 文件权限 | unknown | 待验证 | 敏感资料必须服务端控制。 |
| 付款截图、合同扫描件、司机证件安全控制 | local_project | 需求已明确 | API 待验证。 |
| mock 文件导入策略 | local_project | 已明确 | 仅 mock，不上传真实文件。 |

### 模板打印 / 合同文件

| 检查项 | 来源 | 状态 | 说明 |
| --- | --- | --- | --- |
| 模板打印插件能力 | unknown | 待验证 | 本轮未确认官方可编程 API。 |
| Word / PDF 生成能力 | unknown | 待验证 | 待验证。 |
| LibreOffice 依赖 | unknown | 待验证 | 待验证。 |
| 打印状态和扫描件上传建模 | local_project | 可规划 | 真实实现待 API 验证。 |
| API 不确定处理 | local_project | 已明确 | 标记待验证，不阻塞租金台账。 |

### 备份 / 回滚

| 检查项 | 来源 | 状态 | 说明 |
| --- | --- | --- | --- |
| NocoBase 官方备份能力 | unknown | 待验证 | 2.1 beta 文档提到发布管理/备份恢复方向，但生产基准仍待验证。 |
| PostgreSQL 备份策略 | local_project | 草案已明确 | 用外部 `pg_dump` 策略，真实执行在隔离环境。 |
| storage 备份策略 | local_project | 草案已明确 | snapshot 草案，不在当前仓库执行。 |
| 插件禁用/回滚方式 | official_docs | 部分 | CLI enable/disable 方向存在。 |
| migration 回滚方式 | official_docs + unknown | 待验证 | Migration `up` 已确认方向，down/回滚需验证。 |

## 不得伪造 API 与不得生产库调试

- 不得伪造 API。
- 不得生产库调试。
- 所有 unknown 均必须待验证。
- 未经官方 API 验证不得写真实 adapter。
- 当前仓库不能正式上线测试，也不能生产部署。
