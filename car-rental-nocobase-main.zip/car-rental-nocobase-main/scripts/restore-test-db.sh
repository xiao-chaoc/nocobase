#!/usr/bin/env bash
set -euo pipefail

# 测试环境数据库恢复脚本草案，不是生产恢复方案。
# 使用条件：在包含 docker-compose.test.yml 和 .env.test 的测试运行目录执行。
# 安全提示：只恢复测试数据库，不要对生产环境执行。

COMPOSE_FILE="${COMPOSE_FILE:-docker-compose.test.yml}"
ENV_FILE="${ENV_FILE:-.env.test}"
DUMP_FILE="${1:-}"

if [[ -z "$DUMP_FILE" ]]; then
  echo "用法：scripts/restore-test-db.sh <backups-test/xxx.dump>" >&2
  exit 1
fi

if [[ ! -f "$DUMP_FILE" ]]; then
  echo "未找到 dump 文件：$DUMP_FILE" >&2
  exit 1
fi

if [[ ! -f "$COMPOSE_FILE" || ! -f "$ENV_FILE" ]]; then
  echo "请在 NAS 测试运行目录执行，并确认 $COMPOSE_FILE 与 $ENV_FILE 存在。" >&2
  exit 1
fi

set -a
# shellcheck disable=SC1090
source "$ENV_FILE"
set +a

: "${DB_DATABASE:?缺少 DB_DATABASE}"
: "${DB_USER:?缺少 DB_USER}"

echo "警告：即将恢复测试数据库 $DB_DATABASE。"
echo "dump 文件：$DUMP_FILE"
echo "这会覆盖测试环境数据；不得用于生产环境。"
read -r -p "请输入 RESTORE_TEST_DB 确认继续：" CONFIRM
if [[ "$CONFIRM" != "RESTORE_TEST_DB" ]]; then
  echo "已取消恢复。"
  exit 0
fi

docker compose -f "$COMPOSE_FILE" --env-file "$ENV_FILE" exec -T postgres \
  pg_restore --clean --if-exists -U "$DB_USER" -d "$DB_DATABASE" < "$DUMP_FILE"

echo "测试数据库恢复完成。"
