declare const require: any;
declare const process: { cwd(): string };
declare const module: any;

import { getTestDataPaths, removeGeneratedJsonFiles } from './test-data-common';

export function clearTestData(rootDir = process.cwd()): string[] {
  const paths = getTestDataPaths(rootDir);
  console.log(`准备清理测试数据生成目录：${paths.generatedDir}`);
  const deleted = removeGeneratedJsonFiles(rootDir);
  console.log(`已删除生成文件：${deleted.length > 0 ? deleted.join(', ') : '无'}`);
  return deleted;
}

if (typeof module !== 'undefined' && module === require.main) {
  clearTestData();
}
