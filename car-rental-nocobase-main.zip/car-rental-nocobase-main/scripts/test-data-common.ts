declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };
declare const module: any;

const fs = require('fs');
const path = require('path');

export const TEST_DATA_TODAY = '2026-06-15';
export const TEST_DATA_NOW = '2026-06-15T10:00:00.000Z';
export const DEFAULT_ROOT_DIR = process.cwd();

export interface TestDataPaths {
  rootDir: string;
  fixturesDir: string;
  generatedDir: string;
}

export function getTestDataPaths(rootDir = DEFAULT_ROOT_DIR): TestDataPaths {
  return {
    rootDir,
    fixturesDir: path.join(rootDir, 'test-data', 'fixtures'),
    generatedDir: path.join(rootDir, 'test-data', 'generated'),
  };
}

export function ensureDir(dir: string): void {
  fs.mkdirSync(dir, { recursive: true });
}

export function readJsonFile<T>(filePath: string): T {
  return JSON.parse(fs.readFileSync(filePath, 'utf8')) as T;
}

export function writeJsonFile(filePath: string, value: unknown): void {
  ensureDir(path.dirname(filePath));
  fs.writeFileSync(filePath, `${JSON.stringify(value, null, 2)}\n`, 'utf8');
}

export function readFixture<T>(fileName: string, rootDir = DEFAULT_ROOT_DIR): T {
  return readJsonFile<T>(path.join(getTestDataPaths(rootDir).fixturesDir, fileName));
}

export function writeGenerated(fileName: string, value: unknown, rootDir = DEFAULT_ROOT_DIR): void {
  writeJsonFile(path.join(getTestDataPaths(rootDir).generatedDir, fileName), value);
}

export function readGenerated<T>(fileName: string, rootDir = DEFAULT_ROOT_DIR): T {
  return readJsonFile<T>(path.join(getTestDataPaths(rootDir).generatedDir, fileName));
}

export function listGeneratedJsonFiles(rootDir = DEFAULT_ROOT_DIR): string[] {
  const generatedDir = getTestDataPaths(rootDir).generatedDir;
  if (!fs.existsSync(generatedDir)) return [];
  return fs.readdirSync(generatedDir).filter((fileName: string) => fileName.endsWith('.json')).sort();
}

export function removeGeneratedJsonFiles(rootDir = DEFAULT_ROOT_DIR): string[] {
  const generatedDir = getTestDataPaths(rootDir).generatedDir;
  ensureDir(generatedDir);
  const deleted: string[] = [];
  for (const fileName of listGeneratedJsonFiles(rootDir)) {
    fs.unlinkSync(path.join(generatedDir, fileName));
    deleted.push(fileName);
  }
  return deleted;
}

export function addDays(date: string, days: number): string {
  const [year, month, day] = date.split('-').map(Number);
  const time = Date.UTC(year, month - 1, day) + days * 24 * 60 * 60 * 1000;
  const next = new Date(time);
  return `${next.getUTCFullYear()}-${String(next.getUTCMonth() + 1).padStart(2, '0')}-${String(next.getUTCDate()).padStart(2, '0')}`;
}

export function compareDate(a: string, b: string): number {
  return Date.parse(`${a}T00:00:00.000Z`) - Date.parse(`${b}T00:00:00.000Z`);
}

export function failCli(errors: string[]): never {
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

export { fs, path };
