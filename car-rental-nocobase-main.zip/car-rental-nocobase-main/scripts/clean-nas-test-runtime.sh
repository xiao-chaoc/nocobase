#!/usr/bin/env bash
set -euo pipefail

# NAS 测试运行目录清理脚本草案，不用于生产环境。
# 只清理明确的测试目录，默认不删除 .env.test，不删除 Git 仓库源码，不删除 templates。

TARGET_DIR="${1:-$(pwd)}"
TARGET_BASE="$(basename "$TARGET_DIR")"

if [[ "$TARGET_DIR" != *"nocobase-car-lease-test"* && "$TARGET_DIR" != *"storage-test"* ]]; then
  echo "拒绝清理：目标目录必须包含 nocobase-car-lease-test 或 storage-test。" >&2
  echo "当前目标：$TARGET_DIR" >&2
  exit 1
fi

if [[ -d "$TARGET_DIR/.git" ]]; then
  echo "拒绝清理：目标目录看起来是 Git 仓库源码目录。" >&2
  exit 1
fi

DELETE_TARGETS=()
if [[ "$TARGET_BASE" == "storage-test" ]]; then
  [[ -e "$TARGET_DIR/nocobase" ]] && DELETE_TARGETS+=("$TARGET_DIR/nocobase")
  [[ -e "$TARGET_DIR/postgres" ]] && DELETE_TARGETS+=("$TARGET_DIR/postgres")
else
  [[ -e "$TARGET_DIR/storage-test/nocobase" ]] && DELETE_TARGETS+=("$TARGET_DIR/storage-test/nocobase")
  [[ -e "$TARGET_DIR/storage-test/postgres" ]] && DELETE_TARGETS+=("$TARGET_DIR/storage-test/postgres")
  for name in backups-test logs-test test-runtime; do
    [[ -e "$TARGET_DIR/$name" ]] && DELETE_TARGETS+=("$TARGET_DIR/$name")
  done
fi

if [[ "${#DELETE_TARGETS[@]}" -eq 0 ]]; then
  echo "没有发现可清理的测试目录。"
  exit 0
fi

echo "将清理以下测试目录："
printf ' - %s\n' "${DELETE_TARGETS[@]}"
echo "不会删除 Git 仓库源码，不会默认删除 .env.test，不会删除 templates。"
echo "本脚本只用于 NAS 测试环境，不用于生产。"
read -r -p "请输入 CLEAN_NAS_TEST 确认继续：" CONFIRM
if [[ "$CONFIRM" != "CLEAN_NAS_TEST" ]]; then
  echo "已取消清理。"
  exit 0
fi

for item in "${DELETE_TARGETS[@]}"; do
  rm -rf "$item"
  echo "已删除：$item"
done

if [[ "${CLEAR_ENV_TEST:-0}" == "1" && -f "$TARGET_DIR/.env.test" ]]; then
  read -r -p "确认删除 .env.test？请输入 DELETE_ENV_TEST：" ENV_CONFIRM
  if [[ "$ENV_CONFIRM" == "DELETE_ENV_TEST" ]]; then
    rm -f "$TARGET_DIR/.env.test"
    echo "已删除：$TARGET_DIR/.env.test"
  else
    echo "保留 .env.test。"
  fi
fi
