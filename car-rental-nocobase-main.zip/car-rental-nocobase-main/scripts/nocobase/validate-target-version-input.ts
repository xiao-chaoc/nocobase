declare const require: any;
declare const process: any;
declare const module: any;

const { existsSync, readFileSync } = require('fs');
const path = require('path');

const requiredFields = [
  'decision_status',
  'target_version',
  'source_type',
  'source_reference',
  'package_manager',
  'node_version',
  'database',
  'deployment_mode',
  'plugin_development_mode',
  'plugin_install_mode',
  'iopgps_real_sync_allowed',
  'mock_data_only',
  'confirmed_by',
  'confirmed_at',
];

const outputFields = [...requiredFields];
const allowedSourceTypes = new Set(['tag', 'branch', 'docker_image', 'release']);
const allowedPackageManagers = new Set(['npm', 'yarn', 'pnpm']);
const forbiddenExactKeys = new Set([
  'APP_KEY',
  'DB_PASSWORD',
  'INIT_ROOT_PASSWORD',
  'IOPGPS_LOGIN_KEY',
  'access_token',
  'login_key',
]);

type ValidationResult = {
  ok: boolean;
  data?: Record<string, unknown>;
  failures: string[];
};

const parseArgs = (argv: string[]): { file?: string; execute: boolean } => {
  let file: string | undefined;
  let execute = false;
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === '--') continue;
    if (arg === '--execute') {
      execute = true;
      continue;
    }
    if (arg === '--file') {
      file = argv[index + 1];
      index += 1;
      continue;
    }
    if (arg.startsWith('--file=')) {
      file = arg.slice('--file='.length);
    }
  }
  return { file, execute };
};

const isPlainObject = (value: unknown): value is Record<string, unknown> => {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
};

const isBlank = (value: unknown): boolean => typeof value !== 'string' || value.trim().length === 0;

const walkSecrets = (value: unknown, failures: string[], keyPath = 'root'): void => {
  if (Array.isArray(value)) {
    value.forEach((item, index) => walkSecrets(item, failures, `${keyPath}[${index}]`));
    return;
  }
  if (!isPlainObject(value)) return;

  for (const [key, child] of Object.entries(value)) {
    const childPath = `${keyPath}.${key}`;
    if (forbiddenExactKeys.has(key)) {
      failures.push(`禁止在确认输入中包含敏感字段 ${keyPath}.${key}。`);
    }
    if (key.toLowerCase().includes('password')) {
      failures.push(`禁止在确认输入中包含任何密码字段 ${childPath}。`);
    }
    walkSecrets(child, failures, childPath);
  }
};

const validateTargetVersionInputData = (data: unknown): ValidationResult => {
  const failures: string[] = [];
  if (!isPlainObject(data)) {
    return { ok: false, failures: ['确认输入必须是 JSON 对象。'] };
  }

  walkSecrets(data, failures);

  for (const field of requiredFields) {
    if (!(field in data)) failures.push(`缺少必填字段 ${field}。`);
  }

  if (data.decision_status !== 'confirmed') failures.push('decision_status 必须是 confirmed。');
  if (isBlank(data.target_version)) failures.push('target_version 不能为空。');
  if (data.target_version === 'unset') failures.push('target_version 不能是 unset。');
  if (data.target_version === 'latest-full') failures.push('target_version 不能是 latest-full，latest-full 只能用于基础测试说明。');
  if (!allowedSourceTypes.has(String(data.source_type))) failures.push('source_type 必须是 tag、branch、docker_image、release 之一。');
  if (isBlank(data.source_reference)) failures.push('source_reference 不能为空。');
  if (!allowedPackageManagers.has(String(data.package_manager))) failures.push('package_manager 必须是 npm、yarn、pnpm 之一。');
  if (isBlank(data.node_version)) failures.push('node_version 不能为空。');
  if (data.database !== 'postgresql') failures.push('database 必须是 postgresql。');
  if (isBlank(data.deployment_mode)) failures.push('deployment_mode 不能为空。');
  if (isBlank(data.plugin_development_mode)) failures.push('plugin_development_mode 不能为空。');
  if (isBlank(data.plugin_install_mode)) failures.push('plugin_install_mode 不能为空。');
  if (data.iopgps_real_sync_allowed !== false) failures.push('iopgps_real_sync_allowed 必须为 false。');
  if (data.mock_data_only !== true) failures.push('mock_data_only 必须为 true。');
  if (isBlank(data.confirmed_by)) failures.push('confirmed_by 不能为空。');
  if (isBlank(data.confirmed_at)) failures.push('confirmed_at 不能为空。');
  if (typeof data.confirmed_at === 'string' && !/^\d{4}-\d{2}-\d{2}$/.test(data.confirmed_at)) {
    failures.push('confirmed_at 格式建议为 YYYY-MM-DD。');
  }

  return { ok: failures.length === 0, data, failures };
};

const loadAndValidateTargetVersionInput = (filePath: string | undefined): ValidationResult => {
  if (!filePath) {
    return { ok: false, failures: ['缺少 --file 参数，请传入目标版本确认 JSON 文件路径。'] };
  }

  const resolvedPath = path.resolve(process.cwd(), filePath);
  if (!existsSync(resolvedPath)) {
    return { ok: false, failures: [`确认输入文件不存在：${filePath}`] };
  }

  try {
    const parsed = JSON.parse(readFileSync(resolvedPath, 'utf8') as string) as unknown;
    return validateTargetVersionInputData(parsed);
  } catch (error) {
    return { ok: false, failures: [`确认输入文件不是有效 JSON：${(error as Error).message}`] };
  }
};

const printValidationResult = (result: ValidationResult): void => {
  console.log('NocoBase 目标版本确认输入校验');
  console.log('安全边界：不读取 .env，不读取 .env.test，不连接 NocoBase，不访问外部网络，不写数据库。');
  if (!result.ok) {
    console.error('检查未通过：确认输入不满足目标版本冻结要求。');
    for (const failure of result.failures) console.error(`- ${failure}`);
    return;
  }
  console.log('检查通过：确认输入可用于 dry-run 或人工执行应用。');
};

if (require.main === module) {
  const args = parseArgs(process.argv.slice(2));
  const result = loadAndValidateTargetVersionInput(args.file);
  printValidationResult(result);
  if (!result.ok) process.exit(1);
}

module.exports = {
  outputFields,
  parseArgs,
  validateTargetVersionInputData,
  loadAndValidateTargetVersionInput,
  printValidationResult,
};
