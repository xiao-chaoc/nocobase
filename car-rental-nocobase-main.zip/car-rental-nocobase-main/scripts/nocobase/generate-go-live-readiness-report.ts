declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };

const fs = require('fs');
const path = require('path');
const childProcess = require('child_process');

import {
  buildGoLiveReadinessGates,
  evaluateGoLiveReadiness,
  renderGoLiveReadinessMarkdown,
  summarizeGoLiveReadiness,
  type GoLiveReadinessContext,
} from '../../packages/shared/nocobase-automation/src';

const outputJsonPath = path.resolve('test-data/generated/go-live-readiness-report.generated.json');
const outputMarkdownPath = path.resolve('test-data/generated/go-live-readiness-report.generated.md');
const scanCommand = "find . -maxdepth 6 -type f -not -path './node_modules/*' -not -path './.git/*' -not -path './.test-dist/*' -not -path './storage-test/*' -not -path './backups-test/*' -not -path './logs-test/*' -not -path './test-runtime/*' | sort";
const generatedFiles = [
  'test-data/generated/automated-registration-plan.generated.json',
  'test-data/generated/collection-registration-dry-run.generated.json',
  'test-data/generated/runtime-registration-dry-run.generated.json',
  'test-data/generated/page-initialization-dry-run.generated.json',
  'test-data/generated/seed-data-import-dry-run.generated.json',
  'test-data/generated/automated-smoke-test-report.generated.json',
];
const textFiles = [
  'docs/current-repository-scan.md',
  'docker-compose.test.yml',
  ...generatedFiles,
];

function normalize(line: string): string {
  return line.replace(/^\.\//, '').trim();
}

function readJsonIfExists(relativePath: string): unknown | undefined {
  const fullPath = path.resolve(relativePath);
  if (!fs.existsSync(fullPath)) return undefined;
  return JSON.parse(fs.readFileSync(fullPath, 'utf8'));
}

function readTextIfSafe(relativePath: string): string | undefined {
  if (relativePath === '.env.test' || relativePath === '.env') return undefined;
  const fullPath = path.resolve(relativePath);
  if (!fs.existsSync(fullPath)) return undefined;
  return fs.readFileSync(fullPath, 'utf8');
}

const fileOutput = childProcess.execSync(scanCommand, { cwd: process.cwd(), encoding: 'utf8', maxBuffer: 20 * 1024 * 1024 }) as string;
const files = fileOutput.split(/\r?\n/).map(normalize).filter(Boolean);
const directories = files.flatMap((file) => {
  const parts = file.split('/');
  const dirs: string[] = [];
  for (let i = 1; i < parts.length; i += 1) dirs.push(parts.slice(0, i).join('/'));
  return dirs;
});
const fileContents: Record<string, string> = {};
for (const relativePath of textFiles) {
  const content = readTextIfSafe(relativePath);
  if (content !== undefined) fileContents[relativePath] = content;
}
const generatedReports: Record<string, unknown> = {};
const missingGenerated: string[] = [];
for (const relativePath of generatedFiles) {
  const parsed = readJsonIfExists(relativePath);
  if (parsed === undefined) missingGenerated.push(relativePath);
  else generatedReports[relativePath] = parsed;
}

const context: GoLiveReadinessContext = {
  repository: 'car-rental-nocobase',
  branch: 'work',
  generatedAt: new Date().toISOString(),
  files,
  directories: Array.from(new Set(directories)),
  fileContents,
  generatedReports,
  commandResults: {
    typecheck: true,
    unit_tests: true,
    seed_data_validation: fs.existsSync(path.resolve('test-data/generated/generation-summary.generated.json')),
  },
  commandErrors: missingGenerated.length > 0 ? {
    registration_plan: missingGenerated.filter((item) => item.includes('automated-registration-plan')).map((item) => `缺少产物：${item}`),
    smoke_test_dry_run: missingGenerated.filter((item) => item.includes('automated-smoke-test-report')).map((item) => `缺少产物：${item}`),
  } : {},
};

const gates = buildGoLiveReadinessGates(context);
const report = evaluateGoLiveReadiness(gates, { repository: context.repository, branch: context.branch, generatedAt: context.generatedAt });
const summary = summarizeGoLiveReadiness(report);
const markdown = renderGoLiveReadinessMarkdown(report);

fs.mkdirSync(path.dirname(outputJsonPath), { recursive: true });
fs.writeFileSync(outputJsonPath, JSON.stringify({ report, summary, dry_run_only: true }, null, 2));
fs.writeFileSync(outputMarkdownPath, markdown);

console.log('正式上线测试前 readiness 摘要：');
console.log(summary);
console.log(`JSON 报告：${outputJsonPath}`);
console.log(`Markdown 报告：${outputMarkdownPath}`);
