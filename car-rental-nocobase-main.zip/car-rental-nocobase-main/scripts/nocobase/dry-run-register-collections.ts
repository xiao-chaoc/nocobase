declare const require: any;
declare const process: { exit(code?: number): never };

const fs = require('fs');
const path = require('path');
import {
  buildCollectionRegistrationPlanFromAutomatedPlan,
  dryRunRegisterCollections,
  summarizeCollectionRegistrationResult,
  type AutomatedGoLiveRegistrationPlan,
} from '../../packages/shared/nocobase-automation/src';

const inputPath = path.resolve('test-data/generated/automated-registration-plan.generated.json');
const outputPath = path.resolve('test-data/generated/collection-registration-dry-run.generated.json');

if (!fs.existsSync(inputPath)) {
  console.error('缺少自动化注册计划，请先运行：npm run generate:registration-plan');
  process.exit(1);
}

const input = JSON.parse(fs.readFileSync(inputPath, 'utf8')) as { plan?: AutomatedGoLiveRegistrationPlan } & AutomatedGoLiveRegistrationPlan;
const plan = input.plan ?? input;
const collectionPlans = buildCollectionRegistrationPlanFromAutomatedPlan(plan);
const result = dryRunRegisterCollections(collectionPlans);
const summary = summarizeCollectionRegistrationResult(result);

fs.mkdirSync(path.dirname(outputPath), { recursive: true });
fs.writeFileSync(
  outputPath,
  JSON.stringify(
    {
      generated_at: '2026-06-02T00:00:00.000Z',
      dry_run_only: true,
      collectionPlans,
      result,
      summary,
      notes: [
        '本文件仅为 Collection dry-run 注册结果。',
        '未连接真实 NocoBase，未写数据库，未执行 migration，未调用 IOPGPS。',
      ],
    },
    null,
    2,
  ),
);

console.log('Collection dry-run 注册摘要：');
console.log(summary);
console.log(`已输出：${outputPath}`);

if (!result.success) {
  console.error('Collection dry-run 注册校验失败。');
  for (const error of result.errors) {
    console.error(`- ${error}`);
  }
  process.exit(1);
}
