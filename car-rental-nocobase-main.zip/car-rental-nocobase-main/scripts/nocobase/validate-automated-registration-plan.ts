declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };
declare const module: any;

import { dryRunAutomatedRegistration, validateAutomatedRegistrationPlan } from '../../packages/shared/nocobase-automation/src';
import type { AutomatedGoLiveRegistrationPlan } from '../../packages/shared/nocobase-automation/src';

const fs = require('fs');
const path = require('path');

export function validateGeneratedAutomatedRegistrationPlan(rootDir = process.cwd()) {
  const filePath = path.join(rootDir, 'test-data', 'generated', 'automated-registration-plan.generated.json');
  if (!fs.existsSync(filePath)) {
    return { passed: false, errors: [`缺少自动化注册计划文件：${filePath}`], warnings: [] };
  }
  const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
  const plan: AutomatedGoLiveRegistrationPlan = parsed.plan;
  const validation = validateAutomatedRegistrationPlan(plan);
  const dryRun = dryRunAutomatedRegistration(plan);
  const errors = [...validation.errors, ...dryRun.errors];
  const warnings = [...validation.warnings, ...dryRun.warnings];
  return { passed: validation.passed && dryRun.success, errors, warnings };
}

if (typeof module !== 'undefined' && module === require.main) {
  const result = validateGeneratedAutomatedRegistrationPlan();
  for (const warning of result.warnings) console.warn(`警告：${warning}`);
  if (!result.passed) {
    console.error('自动化注册计划校验失败：');
    for (const error of result.errors) console.error(`- ${error}`);
    process.exit(1);
  }
  console.log('自动化注册计划校验通过：插件顺序、Collections、权限、页面计划、Smoke Test 和禁用规则均符合 dry-run 要求。');
}
