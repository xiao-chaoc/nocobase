declare const require: any;
declare const process: { argv: string[]; cwd(): string; exit(code?: number): never };

const fs = require('fs');
const path = require('path');
const childProcess = require('child_process');

import {
  buildSmokeTestPlan,
  buildSmokeTestReport,
  createSmokeTestStepResult,
  summarizeSmokeTestResult,
  validateSmokeTestPrerequisites,
  type SmokeTestPlanStep,
  type SmokeTestStepResult,
} from '../../packages/shared/nocobase-automation/src';

const reportJsonPath = path.resolve('test-data/generated/automated-smoke-test-report.generated.json');
const reportMarkdownPath = path.resolve('test-data/generated/automated-smoke-test-report.generated.md');
const continueOnError = process.argv.includes('--continue-on-error');

function summarizeOutput(output: string): string {
  const lines = output.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  return lines.slice(-12).join('\n').slice(0, 3000) || '命令没有输出。';
}

function runShellCommand(step: SmokeTestPlanStep): SmokeTestStepResult {
  const startedAt = new Date().toISOString();
  const startedMs = Date.now();
  try {
    const output = childProcess.execSync(step.command, {
      cwd: process.cwd(),
      encoding: 'utf8',
      maxBuffer: 20 * 1024 * 1024,
    }) as string;
    const finishedAt = new Date().toISOString();
    return createSmokeTestStepResult({
      name: step.name,
      status: 'passed',
      started_at: startedAt,
      finished_at: finishedAt,
      duration_ms: Date.now() - startedMs,
      command: step.command,
      output_summary: summarizeOutput(output),
      artifacts: step.artifacts,
    });
  } catch (error: any) {
    const stdout = typeof error?.stdout === 'string' ? error.stdout : '';
    const stderr = typeof error?.stderr === 'string' ? error.stderr : '';
    const finishedAt = new Date().toISOString();
    return createSmokeTestStepResult({
      name: step.name,
      status: 'failed',
      started_at: startedAt,
      finished_at: finishedAt,
      duration_ms: Date.now() - startedMs,
      command: step.command,
      output_summary: summarizeOutput(`${stdout}\n${stderr}`),
      errors: [`命令执行失败：${step.command}`],
      artifacts: step.artifacts,
    });
  }
}

function runRepositoryScan(step: SmokeTestPlanStep): SmokeTestStepResult {
  const startedAt = new Date().toISOString();
  const startedMs = Date.now();
  try {
    const output = childProcess.execSync(step.command, {
      cwd: process.cwd(),
      encoding: 'utf8',
      maxBuffer: 20 * 1024 * 1024,
    }) as string;
    const fileList = output.split(/\r?\n/)
      .map((line) => line.replace(/^\.\//, '').trim())
      .filter(Boolean);
    const validation = validateSmokeTestPrerequisites(fileList);
    const finishedAt = new Date().toISOString();
    return createSmokeTestStepResult({
      name: step.name,
      status: validation.passed ? 'passed' : 'failed',
      started_at: startedAt,
      finished_at: finishedAt,
      duration_ms: Date.now() - startedMs,
      command: step.command,
      output_summary: `仓库扫描完成，共发现 ${fileList.length} 个文件；前置文件${validation.passed ? '全部存在' : '存在缺失'}。`,
      warnings: validation.warnings,
      errors: validation.errors,
      artifacts: step.artifacts,
    });
  } catch (error: any) {
    const stdout = typeof error?.stdout === 'string' ? error.stdout : '';
    const stderr = typeof error?.stderr === 'string' ? error.stderr : '';
    const finishedAt = new Date().toISOString();
    return createSmokeTestStepResult({
      name: step.name,
      status: 'failed',
      started_at: startedAt,
      finished_at: finishedAt,
      duration_ms: Date.now() - startedMs,
      command: step.command,
      output_summary: summarizeOutput(`${stdout}\n${stderr}`),
      errors: ['仓库扫描命令执行失败。'],
      artifacts: step.artifacts,
    });
  }
}

function npmScriptExists(scriptName: string): boolean {
  const packageJson = JSON.parse(fs.readFileSync(path.resolve('package.json'), 'utf8')) as { scripts?: Record<string, string> };
  return Boolean(packageJson.scripts?.[scriptName]);
}

function createSkippedStep(step: SmokeTestPlanStep, reason: string): SmokeTestStepResult {
  const now = new Date().toISOString();
  return createSmokeTestStepResult({
    name: step.name,
    status: 'skipped',
    started_at: now,
    finished_at: now,
    command: step.command,
    output_summary: reason,
    warnings: [reason],
    artifacts: step.artifacts,
  });
}

function renderMarkdownReport(payload: { result: ReturnType<typeof summarizeSmokeTestResult>; report: ReturnType<typeof buildSmokeTestReport> }): string {
  const { result, report } = payload;
  const stepRows = result.steps.map((step) => `| ${step.name} | ${step.status} | ${step.duration_ms} | ${step.command || '无'} |`).join('\n');
  const blockers = report.blockers.length > 0 ? report.blockers.map((item) => `- ${item}`).join('\n') : '- 无';
  const warnings = report.warnings.length > 0 ? report.warnings.map((item) => `- ${item}`).join('\n') : '- 无';
  const artifacts = report.artifacts.length > 0 ? report.artifacts.map((item) => `- ${item}`).join('\n') : '- 无';
  return `# 自动化 Smoke Test dry-run 报告\n\n` +
    `- 报告编号：${report.report_no}\n` +
    `- 生成时间：${report.generated_at}\n` +
    `- 执行环境：${report.environment}\n` +
    `- 是否成功：${report.success ? '是' : '否'}\n` +
    `- dry-run 边界：未连接真实 NocoBase，未写数据库，未调用 IOPGPS，未生成真实合同文件。\n\n` +
    `## 步骤统计\n\n` +
    `- 通过步骤：${report.passed_steps}\n` +
    `- 失败步骤：${report.failed_steps}\n` +
    `- 警告步骤：${report.warning_steps}\n` +
    `- 跳过步骤：${report.skipped_steps}\n\n` +
    `## 步骤明细\n\n| 步骤 | 状态 | 耗时毫秒 | 命令 |\n| --- | --- | ---: | --- |\n${stepRows}\n\n` +
    `## 阻塞项\n\n${blockers}\n\n` +
    `## 警告\n\n${warnings}\n\n` +
    `## 产物\n\n${artifacts}\n\n` +
    `## 下一步\n\n${report.next_actions.map((item) => `- ${item}`).join('\n')}\n`;
}

const plan = buildSmokeTestPlan();
const stepResults: SmokeTestStepResult[] = [];
let shouldSkipBlockingSteps = false;

for (const step of plan) {
  if (step.name === 'generate_smoke_report') continue;
  if (shouldSkipBlockingSteps) {
    stepResults.push(createSkippedStep(step, '前置阻塞步骤失败，默认停止后续步骤。'));
    continue;
  }
  let stepResult: SmokeTestStepResult;
  if (step.name === 'repository_scan') {
    stepResult = runRepositoryScan(step);
  } else if (step.name === 'preflight_nas_test' && !npmScriptExists('preflight:nas-test')) {
    stepResult = createSkippedStep(step, 'package.json 中未配置 preflight:nas-test，已明确跳过。');
  } else {
    stepResult = runShellCommand(step);
  }
  stepResults.push(stepResult);
  if (stepResult.status === 'failed' && step.blocking && !continueOnError) {
    shouldSkipBlockingSteps = true;
  }
}

const reportStepPlan = plan.find((step) => step.name === 'generate_smoke_report');
const reportStartedAt = new Date().toISOString();
let result = summarizeSmokeTestResult(stepResults);
let report = buildSmokeTestReport(result);
fs.mkdirSync(path.dirname(reportJsonPath), { recursive: true });
fs.writeFileSync(reportJsonPath, JSON.stringify({ result, report, dry_run_only: true }, null, 2));
fs.writeFileSync(reportMarkdownPath, renderMarkdownReport({ result, report }));
const reportFinishedAt = new Date().toISOString();
if (reportStepPlan) {
  stepResults.push(createSmokeTestStepResult({
    name: 'generate_smoke_report',
    status: 'passed',
    started_at: reportStartedAt,
    finished_at: reportFinishedAt,
    duration_ms: new Date(reportFinishedAt).getTime() - new Date(reportStartedAt).getTime(),
    command: reportStepPlan.command,
    output_summary: `已生成报告：${reportJsonPath} 和 ${reportMarkdownPath}`,
    artifacts: reportStepPlan.artifacts,
  }));
  result = summarizeSmokeTestResult(stepResults);
  report = buildSmokeTestReport(result);
  fs.writeFileSync(reportJsonPath, JSON.stringify({ result, report, dry_run_only: true }, null, 2));
  fs.writeFileSync(reportMarkdownPath, renderMarkdownReport({ result, report }));
}

console.log('自动化 Smoke Test dry-run 摘要：');
console.log(`- 成功：${result.success ? '是' : '否'}`);
console.log(`- 通过步骤：${result.summary.passed_steps}`);
console.log(`- 失败步骤：${result.summary.failed_steps}`);
console.log(`- 警告步骤：${result.summary.warning_steps}`);
console.log(`- 跳过步骤：${result.summary.skipped_steps}`);
console.log(`- JSON 报告：${reportJsonPath}`);
console.log(`- Markdown 报告：${reportMarkdownPath}`);

if (!result.success) {
  console.error('自动化 Smoke Test dry-run 存在阻塞失败：');
  for (const error of result.errors) console.error(`- ${error}`);
  process.exit(1);
}
