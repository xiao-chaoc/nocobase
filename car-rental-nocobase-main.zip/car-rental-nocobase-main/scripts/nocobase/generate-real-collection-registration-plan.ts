declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };
declare const module: any;

import { normalizeCollectionPlans, RealCollectionRegistrationAdapter, createDefaultRealCollectionRegistrationContext } from '../../packages/shared/nocobase-automation/src';
import type { NocobaseCollectionPlan } from '../../packages/shared/nocobase-automation/src';

const fs = require('fs');
const path = require('path');

export function generateRealCollectionRegistrationPlan(rootDir = process.cwd()) {
  const inputPath = path.join(rootDir, 'test-data', 'generated', 'automated-registration-plan.generated.json');
  if (!fs.existsSync(inputPath)) throw new Error(`缺少自动化注册计划文件：${inputPath}`);
  const parsed = JSON.parse(fs.readFileSync(inputPath, 'utf8'));
  const rawCollections: NocobaseCollectionPlan[] = parsed.plan?.collections ?? parsed.collections ?? [];
  const collectionPlans = normalizeCollectionPlans(rawCollections);
  const adapter = new RealCollectionRegistrationAdapter();
  const context = createDefaultRealCollectionRegistrationContext('plan_only');
  const plan = adapter.buildRealCollectionRegistrationPlan(collectionPlans, context);
  if (plan.mode === 'real') throw new Error('当前脚本不允许 real 模式。');
  const report = adapter.validateRealCollectionRegistrationPlan(plan);
  const output = {
    generated_at: '2026-06-04T00:00:00.000Z',
    draft_only: true,
    real_execution_allowed: false,
    executed: false,
    source: 'automated-registration-plan.generated.json',
    plan,
    report,
  };
  const outputDir = path.join(rootDir, 'test-data', 'generated');
  fs.mkdirSync(outputDir, { recursive: true });
  const outputPath = path.join(outputDir, 'real-collection-registration-plan.generated.json');
  fs.writeFileSync(outputPath, `${JSON.stringify(output, null, 2)}\n`, 'utf8');
  return { outputPath, output };
}

if (typeof module !== 'undefined' && module === require.main) {
  try {
    const result = generateRealCollectionRegistrationPlan();
    if (!result.output.report.success) {
      console.error('真实 Collection 注册草案生成后校验失败：');
      for (const error of result.output.report.errors) console.error(`- ${error}`);
      process.exit(1);
    }
    console.log(`真实 Collection 注册草案已生成：${result.outputPath}`);
    console.log(`模式：${result.output.plan.mode}，Collection 草案：${result.output.plan.collections.length} 个，步骤：${result.output.plan.steps.length} 个。`);
    console.log('本脚本未连接 NocoBase、未写数据库、未执行 migration、未调用 app.collection 或 db.collection。');
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}
