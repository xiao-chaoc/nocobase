declare const require: any;
declare const process: { exit(code?: number): never };

const fs = require('fs');
const path = require('path');
import {
  buildRuntimeRegistrationPlanFromAutomatedPlan,
  dryRunRegisterRuntime,
  summarizeRuntimeRegistrationResult,
  type AutomatedGoLiveRegistrationPlan,
} from '../../packages/shared/nocobase-automation/src';

const inputPath = path.resolve('test-data/generated/automated-registration-plan.generated.json');
const outputPath = path.resolve('test-data/generated/runtime-registration-dry-run.generated.json');

if (!fs.existsSync(inputPath)) {
  console.error('缺少自动化注册计划，请先运行：npm run generate:registration-plan');
  process.exit(1);
}

const input = JSON.parse(fs.readFileSync(inputPath, 'utf8')) as { plan?: AutomatedGoLiveRegistrationPlan } & AutomatedGoLiveRegistrationPlan;
const plan = input.plan ?? input;
const runtimePlan = buildRuntimeRegistrationPlanFromAutomatedPlan(plan);
const result = dryRunRegisterRuntime(runtimePlan);
const summary = summarizeRuntimeRegistrationResult(result);

fs.mkdirSync(path.dirname(outputPath), { recursive: true });
fs.writeFileSync(
  outputPath,
  JSON.stringify(
    {
      generated_at: '2026-06-03T00:00:00.000Z',
      dry_run_only: true,
      runtimePlan,
      result,
      summary,
      notes: [
        '本文件仅为 runtime dry-run 注册结果。',
        '未连接真实 NocoBase，未写数据库，未注册真实 API/按钮/ACL/定时任务/i18n，未调用 IOPGPS。',
      ],
    },
    null,
    2,
  ),
);

console.log('runtime dry-run 注册摘要：');
console.log(summary);
console.log(`已输出：${outputPath}`);

if (!result.success) {
  console.error('runtime dry-run 注册校验失败：');
  for (const error of result.errors) console.error(`- ${error}`);
  process.exit(1);
}
