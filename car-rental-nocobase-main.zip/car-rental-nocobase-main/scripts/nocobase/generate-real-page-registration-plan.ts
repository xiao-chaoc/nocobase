declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };
declare const module: any;

import {
  buildPageInitializationPlan,
  createDefaultRealPageRegistrationContext,
  RealPageRegistrationAdapter,
} from '../../packages/shared/nocobase-automation/src';
import type { PageInitializationPlan } from '../../packages/shared/nocobase-automation/src';

const fs = require('fs');
const path = require('path');

export function generateRealPageRegistrationPlan(rootDir = process.cwd()) {
  const inputPath = path.join(rootDir, 'test-data', 'generated', 'automated-registration-plan.generated.json');
  if (!fs.existsSync(inputPath)) throw new Error(`缺少自动化注册计划文件：${inputPath}`);
  const parsed = JSON.parse(fs.readFileSync(inputPath, 'utf8'));
  const source = parsed.plan ?? parsed;
  const pagePlan: PageInitializationPlan = buildPageInitializationPlan(source);
  const adapter = new RealPageRegistrationAdapter();
  const context = createDefaultRealPageRegistrationContext('plan_only');
  const plan = adapter.buildRealPageRegistrationPlan(pagePlan, context);
  if (plan.mode === 'real') throw new Error('当前脚本不允许 real 模式。');
  const report = adapter.validateRealPageRegistrationPlan(plan);
  const output = {
    generated_at: '2026-06-04T00:00:00.000Z',
    draft_only: true,
    real_execution_allowed: false,
    executed: false,
    source: 'automated-registration-plan.generated.json',
    plan,
    report,
  };
  const outputDir = path.join(rootDir, 'test-data', 'generated');
  fs.mkdirSync(outputDir, { recursive: true });
  const outputPath = path.join(outputDir, 'real-page-registration-plan.generated.json');
  fs.writeFileSync(outputPath, `${JSON.stringify(output, null, 2)}\n`, 'utf8');
  return { outputPath, output };
}

if (typeof module !== 'undefined' && module === require.main) {
  try {
    const result = generateRealPageRegistrationPlan();
    if (!result.output.report.success) {
      console.error('真实 Page 注册草案生成后校验失败：');
      for (const error of result.output.report.errors) console.error(`- ${error}`);
      process.exit(1);
    }
    console.log(`真实 Page 注册草案已生成：${result.outputPath}`);
    console.log(`模式：${result.output.plan.mode}，菜单：${result.output.plan.menus.length} 个，页面：${result.output.plan.pages.length} 个，区块：${result.output.plan.blocks.length} 个，筛选器：${result.output.plan.filters.length} 个，页面动作：${result.output.plan.actions.length} 个。`);
    console.log('本脚本未连接 NocoBase、未写 UI Schema、未创建页面/菜单/区块/筛选器、未注册按钮动作。');
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}
