declare const require: any;
declare const process: any;

const { existsSync, readFileSync } = require('fs');
const path = require('path');
const childProcess = require('child_process');

const rootDir = process.cwd();
const decisionPath = path.join(rootDir, 'docs/nocobase-target-version-decision.md');

const extractField = (content: string, field: string): string | undefined => {
  const escapedField = field.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`\\|\\s*\\\`${escapedField}\\\`\\s*\\|\\s*(?:\\\`([^\\\`]*)\\\`|([^|]*?))\\s*\\|`);
  const match = content.match(pattern);
  return (match?.[1] ?? match?.[2])?.trim();
};

const failures: string[] = [];

try {
  childProcess.execFileSync('node', [path.join(rootDir, '.test-dist/scripts/scripts/nocobase/validate-target-version-confirmation.js')], {
    cwd: rootDir,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  });
} catch (error) {
  const execError = error as { stdout?: string; stderr?: string };
  failures.push(`validate-target-version-confirmation 未通过：${`${execError.stdout ?? ''}${execError.stderr ?? ''}`.trim()}`);
}

if (!existsSync(decisionPath)) {
  failures.push('缺少 docs/nocobase-target-version-decision.md。');
} else {
  const content = readFileSync(decisionPath, 'utf8') as string;
  const decisionStatus = extractField(content, 'decision_status');
  const targetVersion = extractField(content, 'target_version');
  const packageManager = extractField(content, 'package_manager');
  const confirmedPackageManager = extractField(content, 'confirmed_package_manager');
  const iopgpsRealSyncAllowed = extractField(content, 'iopgps_real_sync_allowed');
  const mockDataOnly = extractField(content, 'mock_data_only');
  const confirmedBy = extractField(content, 'confirmed_by');
  const confirmedAt = extractField(content, 'confirmed_at');

  if (decisionStatus !== 'confirmed') failures.push(`decision_status 必须为 confirmed，当前为 ${decisionStatus ?? '缺失'}。`);
  if (!targetVersion || targetVersion === 'unset') failures.push(`target_version 必须是已确认版本，当前为 ${targetVersion ?? '缺失'}。`);
  if (targetVersion === 'latest-full') failures.push('target_version 不能是 latest-full。');
  if (packageManager !== 'yarn') failures.push(`package_manager 必须为 yarn，当前为 ${packageManager ?? '缺失'}。`);
  if (confirmedPackageManager !== 'yarn') failures.push(`confirmed_package_manager 必须为 yarn，当前为 ${confirmedPackageManager ?? '缺失'}。`);
  if (iopgpsRealSyncAllowed !== 'false') failures.push(`iopgps_real_sync_allowed 必须为 false，当前为 ${iopgpsRealSyncAllowed ?? '缺失'}。`);
  if (mockDataOnly !== 'true') failures.push(`mock_data_only 必须为 true，当前为 ${mockDataOnly ?? '缺失'}。`);
  if (!confirmedBy || confirmedBy === 'unset') failures.push('confirmed_by 必须存在且不能为 unset。');
  if (!confirmedAt || confirmedAt === 'unset') failures.push('confirmed_at 必须存在且不能为 unset。');
}

for (const requiredDoc of [
  'docs/nocobase-host-bootstrap-runbook.md',
  'docs/real-adapter-implementation-sequence.md',
  'docs/real-nocobase-host-requirements.md',
]) {
  if (!existsSync(path.join(rootDir, requiredDoc))) failures.push(`缺少 ${requiredDoc}。`);
}

console.log('真实 adapter 阶段启动门禁');
console.log('安全边界：不读取 .env，不读取 .env.test，不连接 NocoBase，不访问外部网络，不写数据库。');

if (failures.length > 0) {
  console.error('检查未通过：当前不得进入真实 adapter 实现阶段。');
  for (const failure of failures) console.error(`- ${failure}`);
  process.exit(1);
}

console.log('检查通过：允许进入真实 adapter 实现阶段的下一轮任务准备。');
