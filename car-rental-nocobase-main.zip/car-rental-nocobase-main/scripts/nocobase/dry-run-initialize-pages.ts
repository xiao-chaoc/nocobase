declare const require: any;
declare const process: { exit(code?: number): never };

const fs = require('fs');
const path = require('path');
import {
  buildPageInitializationPlan,
  dryRunInitializePages,
  summarizePageInitializationResult,
  type AutomatedGoLiveRegistrationPlan,
} from '../../packages/shared/nocobase-automation/src';

const inputPath = path.resolve('test-data/generated/automated-registration-plan.generated.json');
const outputPath = path.resolve('test-data/generated/page-initialization-dry-run.generated.json');

if (!fs.existsSync(inputPath)) {
  console.error('缺少自动化注册计划，请先运行：npm run generate:registration-plan');
  process.exit(1);
}

const input = JSON.parse(fs.readFileSync(inputPath, 'utf8')) as { plan?: AutomatedGoLiveRegistrationPlan } & AutomatedGoLiveRegistrationPlan;
const automatedPlan = input.plan ?? input;
const pagePlan = buildPageInitializationPlan(automatedPlan);
const result = dryRunInitializePages(pagePlan);
const summary = summarizePageInitializationResult(result);

fs.mkdirSync(path.dirname(outputPath), { recursive: true });
fs.writeFileSync(
  outputPath,
  JSON.stringify(
    {
      generated_at: '2026-06-03T00:00:00.000Z',
      dry_run_only: true,
      pagePlan,
      result,
      summary,
      notes: [
        '本文件仅为页面初始化 dry-run 结果。',
        '未连接真实 NocoBase，未创建真实页面、菜单、区块、筛选器或按钮，未导入真实数据，未调用 IOPGPS，未生成合同文件。',
      ],
    },
    null,
    2,
  ),
);

console.log('页面初始化 dry-run 摘要：');
console.log(summary);
console.log(`已输出：${outputPath}`);

if (!result.success) {
  console.error('页面初始化 dry-run 校验失败：');
  for (const error of result.errors) console.error(`- ${error}`);
  process.exit(1);
}
