declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };

const { existsSync, mkdirSync, readFileSync, writeFileSync } = require('fs');
const path = require('path');

const rootDir = process.cwd();
const freezeTemplatePath = path.join(rootDir, 'docs/nocobase-target-version-freeze-template.md');
const outputDir = path.join(rootDir, 'test-data/generated');
const outputPath = path.join(outputDir, 'nocobase-target-version-confirmation.template.json');

if (!existsSync(freezeTemplatePath)) {
  console.error('缺少 docs/nocobase-target-version-freeze-template.md，无法生成目标版本确认草案。');
  process.exit(1);
}

const freezeTemplate = readFileSync(freezeTemplatePath, 'utf8') as string;

const template = {
  decision_status: 'pending_manual_confirmation',
  target_version: 'unset',
  source_type: '请用户填写：tag | branch | docker_image | release',
  source_reference: '请用户填写官方来源、镜像标签、源码标签或书面确认链接',
  source_commit_or_tag: '请用户填写固定 commit、tag 或镜像摘要',
  package_manager: '请用户填写：npm | yarn | pnpm',
  node_version: '请用户填写',
  database: 'postgresql',
  deployment_mode: '请用户填写：source_host | docker_host | plugin_package',
  plugin_development_mode: '请用户填写：packages_plugins | storage_plugins',
  plugin_install_mode: '请用户填写',
  storage_strategy: '请用户填写隔离测试 storage 路径与附件策略',
  template_printing_required: '请用户填写：true | false',
  iopgps_real_sync_allowed: false,
  mock_data_only: true,
  confirmed_by: '请用户填写',
  confirmed_at: 'YYYY-MM-DD',
  source_document: 'docs/nocobase-target-version-freeze-template.md',
  safety_note: '本草案不得包含真实密钥、应用密钥、数据库密码或真实 IOPGPS 凭据。用户必须人工填写后，才可进入下一阶段。',
  freeze_template_excerpt_available: freezeTemplate.includes('版本冻结信息'),
};

mkdirSync(outputDir, { recursive: true });
writeFileSync(outputPath, `${JSON.stringify(template, null, 2)}\n`);

console.log(`已生成目标版本确认草案：${path.relative(rootDir, outputPath)}`);
console.log('用户必须人工填写并确认目标 NocoBase 版本后，才可进入下一阶段。');
console.log('本脚本不读取 .env，不读取 .env.test，不连接 NocoBase，不访问外部网络，不安装依赖，不写数据库。');
