declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };
declare const module: any;

import { RealCollectionRegistrationAdapter, validateRealCollectionSchemaDraft } from '../../packages/shared/nocobase-automation/src';
import type { RealCollectionRegistrationPlan } from '../../packages/shared/nocobase-automation/src';

const fs = require('fs');
const path = require('path');

const requiredCollections = ['drivers', 'vehicles', 'lease_contracts', 'rent_daily_ledgers', 'rent_payments', 'deposit_records', 'gps_devices', 'contract_documents'];

export function validateGeneratedRealCollectionRegistrationPlan(rootDir = process.cwd()) {
  const filePath = path.join(rootDir, 'test-data', 'generated', 'real-collection-registration-plan.generated.json');
  const errors: string[] = [];
  const warnings: string[] = [];
  if (!fs.existsSync(filePath)) return { passed: false, errors: [`缺少真实 Collection 注册草案文件：${filePath}`], warnings };
  const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
  const plan: RealCollectionRegistrationPlan = parsed.plan;
  const adapter = new RealCollectionRegistrationAdapter();
  const report = adapter.validateRealCollectionRegistrationPlan(plan);
  errors.push(...report.errors);
  warnings.push(...report.warnings);

  if (plan.mode === 'real') errors.push('真实 Collection 注册草案不得使用 real 模式。');
  if (parsed.executed || parsed.real_execution_allowed) errors.push('真实 Collection 注册草案不得标记为已执行或允许真实执行。');

  for (const name of requiredCollections) {
    if (!plan.collections.some((collection) => collection.name === name)) errors.push(`缺少关键 Collection schema draft：${name}`);
  }
  for (const collection of plan.collections) {
    const validation = validateRealCollectionSchemaDraft(collection);
    errors.push(...validation.errors);
    warnings.push(...validation.warnings);
    if (!Array.isArray(collection.uniqueConstraints)) errors.push(`${collection.name} 未保留唯一约束数组。`);
    if (!Array.isArray(collection.sensitiveFields)) errors.push(`${collection.name} 未保留敏感字段数组。`);
  }

  return { passed: errors.length === 0 && report.success, errors, warnings };
}

if (typeof module !== 'undefined' && module === require.main) {
  const result = validateGeneratedRealCollectionRegistrationPlan();
  for (const warning of result.warnings) console.warn(`警告：${warning}`);
  if (!result.passed) {
    console.error('真实 Collection 注册草案校验失败：');
    for (const error of result.errors) console.error(`- ${error}`);
    process.exit(1);
  }
  console.log('真实 Collection 注册草案校验通过：plan_only、未真实执行、关键 Collection、唯一约束、敏感字段和禁用业务边界均符合要求。');
}
