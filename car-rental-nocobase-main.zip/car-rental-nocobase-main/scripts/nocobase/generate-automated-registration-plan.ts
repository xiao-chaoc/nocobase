declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };
declare const module: any;

import { contractDocumentsPluginRegistration } from '../../packages/plugins/plugin-contract-documents/src/server/pluginRegistration';
import { iopgpsPluginRegistration } from '../../packages/plugins/plugin-iopgps/src/server/pluginRegistration';
import { rentalCorePluginRegistration } from '../../packages/plugins/plugin-rental-core/src/server/pluginRegistration';
import { buildAutomatedRegistrationPlan, dryRunAutomatedRegistration, validateAutomatedRegistrationPlan } from '../../packages/shared/nocobase-automation/src';

const fs = require('fs');
const path = require('path');

export function generateAutomatedRegistrationPlan(rootDir = process.cwd()) {
  const plan = buildAutomatedRegistrationPlan([
    rentalCorePluginRegistration,
    contractDocumentsPluginRegistration,
    iopgpsPluginRegistration,
  ]);
  const validation = validateAutomatedRegistrationPlan(plan);
  const dryRun = dryRunAutomatedRegistration(plan);
  const output = {
    generated_at: '2026-06-02T00:00:00.000Z',
    dry_run_only: true,
    warnings: dryRun.warnings,
    plan,
    validation,
    dryRun,
  };
  const outputDir = path.join(rootDir, 'test-data', 'generated');
  fs.mkdirSync(outputDir, { recursive: true });
  const outputPath = path.join(outputDir, 'automated-registration-plan.generated.json');
  fs.writeFileSync(outputPath, `${JSON.stringify(output, null, 2)}\n`, 'utf8');
  return { outputPath, output };
}

if (typeof module !== 'undefined' && module === require.main) {
  const result = generateAutomatedRegistrationPlan();
  if (!result.output.validation.passed || !result.output.dryRun.success) {
    console.error('自动化注册计划生成失败：');
    for (const error of result.output.validation.errors) console.error(`- ${error}`);
    process.exit(1);
  }
  console.log(`自动化注册计划已生成：${result.outputPath}`);
  console.log(`插件：${result.output.plan.plugins.length} 个，Collections：${result.output.plan.collections.length} 个，页面计划：${result.output.plan.pages.length} 个，Smoke Test：${result.output.plan.smokeTests.length} 个。`);
  console.log('dry-run 未连接 NocoBase、未写数据库、未调用 IOPGPS、未生成合同文件。');
}
