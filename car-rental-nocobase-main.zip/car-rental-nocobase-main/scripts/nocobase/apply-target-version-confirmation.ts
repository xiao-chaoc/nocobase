declare const require: any;
declare const process: any;

const { existsSync, readFileSync, writeFileSync } = require('fs');
const path = require('path');
const {
  outputFields,
  parseArgs,
  loadAndValidateTargetVersionInput,
  printValidationResult,
} = require('./validate-target-version-input');

const rootDir = process.cwd();
const decisionPath = path.join(rootDir, 'docs/nocobase-target-version-decision.md');

const fieldValue = (data: Record<string, unknown>, field: string): string => String(data[field]);

const replaceOrInsertField = (content: string, field: string, value: string): string => {
  const escapedField = field.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`\\|\\s*\\\`${escapedField}\\\`\\s*\\|[^\\n]*\\|`);
  const line = `| \`${field}\` | \`${value}\` |`;
  if (pattern.test(content)) return content.replace(pattern, line);

  const tableHeader = '| 字段 | 值 |\n| --- | --- |\n';
  if (content.includes(tableHeader)) return content.replace(tableHeader, `${tableHeader}${line}\n`);
  return `${content.trimEnd()}\n\n| 字段 | 值 |\n| --- | --- |\n${line}\n`;
};

const applyDecisionUpdate = (content: string, data: Record<string, unknown>): string => {
  const updates: Record<string, string> = {
    decision_status: 'confirmed',
    target_version: fieldValue(data, 'target_version'),
    source_type: fieldValue(data, 'source_type'),
    source_reference: fieldValue(data, 'source_reference'),
    package_manager: fieldValue(data, 'package_manager'),
    node_version: fieldValue(data, 'node_version'),
    database: fieldValue(data, 'database'),
    deployment_mode: fieldValue(data, 'deployment_mode'),
    plugin_development_mode: fieldValue(data, 'plugin_development_mode'),
    plugin_install_mode: fieldValue(data, 'plugin_install_mode'),
    confirmed_target_version: fieldValue(data, 'target_version'),
    confirmed_source_url_or_tag: fieldValue(data, 'source_reference'),
    confirmed_package_manager: fieldValue(data, 'package_manager'),
    confirmed_deployment_mode: fieldValue(data, 'deployment_mode'),
    confirmed_plugin_install_mode: fieldValue(data, 'plugin_install_mode'),
    confirmed_database: fieldValue(data, 'database'),
    confirmed_by: fieldValue(data, 'confirmed_by'),
    confirmed_at: fieldValue(data, 'confirmed_at'),
    iopgps_real_sync_allowed: String(data.iopgps_real_sync_allowed),
    mock_data_only: String(data.mock_data_only),
    requires_manual_confirmation: 'false',
  };

  let next = content;
  for (const [field, value] of Object.entries(updates)) next = replaceOrInsertField(next, field, value);

  const marker = '## 目标版本确认应用记录';
  const note = [
    marker,
    '',
    '- 本记录由 `scripts/nocobase/apply-target-version-confirmation.ts` 在用户显式传入 `--execute` 后更新。',
    '- `latest-full` 仍只能用于基础测试说明，不能作为真实 adapter 或生产部署目标版本。',
    '- `iopgps_real_sync_allowed` 必须保持为 `false`，当前不允许真实 IOPGPS 同步。',
    '- `mock_data_only` 必须保持为 `true`，当前只允许 mock 数据。',
    '- 当前即使完成目标版本确认，也不能直接标记为 `production_ready`，仍需隔离测试、权限验证、备份回滚验证和 UAT 准入。',
  ].join('\n');

  if (!next.includes(marker)) next = `${next.trimEnd()}\n\n${note}\n`;
  return next;
};

const args = parseArgs(process.argv.slice(2));
const result = loadAndValidateTargetVersionInput(args.file);
printValidationResult(result);
if (!result.ok) process.exit(1);

const data = result.data as Record<string, unknown>;
console.log(args.execute ? '执行模式：将更新目标版本决策记录。' : 'dry-run 模式：不会修改任何文件。');
console.log('将要更新的字段：');
for (const field of outputFields as string[]) {
  console.log(`- ${field}: ${String(data[field])}`);
}

if (!args.execute) {
  console.log('未传入 --execute，本次不会写入 docs/nocobase-target-version-decision.md。');
  process.exit(0);
}

if (!existsSync(decisionPath)) {
  console.error('缺少 docs/nocobase-target-version-decision.md，无法应用目标版本确认。');
  process.exit(1);
}

const currentContent = readFileSync(decisionPath, 'utf8') as string;
const nextContent = applyDecisionUpdate(currentContent, data);
writeFileSync(decisionPath, nextContent);
console.log('已更新 docs/nocobase-target-version-decision.md。请继续运行 npm run validate:target-version-confirmation。');
