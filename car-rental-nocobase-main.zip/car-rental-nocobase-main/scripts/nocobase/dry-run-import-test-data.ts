declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };

const fs = require('fs');
const path = require('path');
import { buildSeedDataImportPlan, dryRunImportSeedData, summarizeSeedDataImportResult } from '../../packages/shared/nocobase-automation/src';

const sourceDir = path.resolve('test-data/generated');
const outputPath = path.resolve('test-data/generated/seed-data-import-dry-run.generated.json');

if (!fs.existsSync(sourceDir)) {
  console.error('缺少 test-data/generated 目录，请先运行：npm run seed:test-data');
  process.exit(1);
}

const manifest = fs.readdirSync(sourceDir).filter((fileName: string) => fileName.endsWith('.json')).sort();
const importPlan = buildSeedDataImportPlan(manifest);
const result = dryRunImportSeedData({
  importPlan,
  dryRun: true,
  sourceDir,
  targetEnvironment: 'dry-run-nocobase-test',
  importedBy: 'codex-dry-run',
  importedAt: '2026-06-03T00:00:00.000Z',
});
const summary = summarizeSeedDataImportResult(result);

fs.mkdirSync(path.dirname(outputPath), { recursive: true });
fs.writeFileSync(outputPath, JSON.stringify({ generated_at: '2026-06-03T00:00:00.000Z', dry_run_only: true, importPlan, result, summary, notes: ['本文件仅为 mock 测试数据导入 dry-run 结果。', '未连接真实 NocoBase，未写数据库，未上传文件，未调用 IOPGPS，未生成合同文件。'] }, null, 2));

console.log('测试数据导入 dry-run 摘要：');
console.log(summary);
console.log(`已输出：${outputPath}`);

if (!result.success) {
  console.error('测试数据导入 dry-run 校验失败：');
  for (const error of result.errors) console.error(`- ${error}`);
  process.exit(1);
}
