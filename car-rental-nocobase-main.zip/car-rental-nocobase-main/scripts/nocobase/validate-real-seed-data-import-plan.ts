declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };
declare const module: any;

import { RealSeedDataImportAdapter, validateRealSeedDataNoRealData, validateRealSeedDataSchemaDraft } from '../../packages/shared/nocobase-automation/src';
import type { RealSeedDataImportPlan } from '../../packages/shared/nocobase-automation/src';

const fs = require('fs');
const path = require('path');

const requiredEntities = ['drivers', 'vehicles', 'lease_contracts', 'rent_daily_ledgers', 'rent_payments', 'rent_payment_allocations', 'deposit_records', 'gps_devices', 'gps_location_snapshots', 'gps_daily_mileages', 'contract_documents'];

export function validateGeneratedRealSeedDataImportPlan(rootDir = process.cwd()) {
  const filePath = path.join(rootDir, 'test-data', 'generated', 'real-seed-data-import-plan.generated.json');
  const errors: string[] = [];
  const warnings: string[] = [];
  if (!fs.existsSync(filePath)) return { passed: false, errors: [`缺少真实 Seed Data Import 草案文件：${filePath}`], warnings };
  const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
  const plan: RealSeedDataImportPlan = parsed.plan;
  const adapter = new RealSeedDataImportAdapter();
  const report = adapter.validateRealSeedDataImportPlan(plan);
  const schema = validateRealSeedDataSchemaDraft(plan);
  const noRealData = validateRealSeedDataNoRealData(plan);
  errors.push(...report.errors, ...schema.errors, ...noRealData.errors);
  warnings.push(...report.warnings, ...schema.warnings, ...noRealData.warnings);
  if (plan.mode === 'real') errors.push('真实 Seed Data Import 草案不得使用 real 模式。');
  if (parsed.executed || parsed.real_execution_allowed || report.executed) errors.push('真实 Seed Data Import 草案不得标记为已执行或允许真实执行。');
  const entities = new Set(plan.entities.map((entity) => entity.entityType));
  for (const entity of requiredEntities) if (!entities.has(entity)) errors.push(`缺少核心实体：${entity}`);
  const order = new Map(plan.entities.map((entity) => [entity.entityType, entity.importOrder]));
  const before = (left: string, right: string) => (order.get(left) ?? 9999) < (order.get(right) ?? -1);
  if (!before('drivers', 'lease_contracts')) errors.push('导入顺序必须保证 drivers 在 lease_contracts 之前。');
  if (!before('vehicles', 'lease_contracts')) errors.push('导入顺序必须保证 vehicles 在 lease_contracts 之前。');
  if (!before('lease_contracts', 'rent_daily_ledgers')) errors.push('导入顺序必须保证 lease_contracts 在 rent_daily_ledgers 之前。');
  if (!before('rent_payments', 'rent_payment_allocations')) errors.push('导入顺序必须保证 rent_payments 在 rent_payment_allocations 之前。');
  if (plan.entities.some((entity) => entity.relationFields.length === 0 && entity.dependencies.length > 0)) errors.push('引用完整性计划未保留。');
  if (plan.entities.some((entity) => entity.uniqueKeys.length === 0)) errors.push('唯一键计划未保留。');
  if (!plan.transactionPlan?.length) errors.push('事务计划必须存在。');
  if (!plan.rollbackPlan?.length) errors.push('回滚计划必须存在。');
  if (!plan.postImportValidationPlan?.length) errors.push('后置验证计划必须存在。');
  for (const entity of plan.entities) for (const fileField of entity.fileFields) if (!fileField.sensitive) errors.push(`文件字段必须标记敏感：${entity.entityType}.${fileField.fieldName}`);
  const text = JSON.stringify(plan).toLowerCase();
  for (const forbidden of ['booking', 'reservation', 'short_rental_order', 'driver_login', 'customer_portal', 'vehicle_category_rental']) if (text.includes(forbidden)) errors.push(`不允许出现禁用业务：${forbidden}`);
  if (text.includes('gps_rent_calculation') || text.includes('gps 参与租金计算') || text.includes('gps参与租金计算')) errors.push('GPS 不得参与租金计算。');
  if (text.includes('deposit_as_rent_payment') || text.includes('押金计入租金已付') || text.includes('押金作为租金已付')) errors.push('押金不得计入租金已付。');
  return { passed: errors.length === 0 && report.success, errors: [...new Set(errors)], warnings: [...new Set(warnings)] };
}

if (typeof module !== 'undefined' && module === require.main) {
  const result = validateGeneratedRealSeedDataImportPlan();
  for (const warning of result.warnings) console.warn(`警告：${warning}`);
  if (!result.passed) {
    console.error('真实 Seed Data Import 草案校验失败：');
    for (const error of result.errors) console.error(`- ${error}`);
    process.exit(1);
  }
  console.log('真实 Seed Data Import 草案校验通过：plan_only、未真实执行、核心实体、导入顺序、引用完整性、唯一键、事务、回滚、后置验证、文件字段敏感、禁止真实数据和业务边界均符合要求。');
}
