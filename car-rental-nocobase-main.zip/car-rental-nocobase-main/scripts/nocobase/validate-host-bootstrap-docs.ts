declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };

const { existsSync, readFileSync, statSync } = require('fs');
const path = require('path');

const rootDir = process.cwd();
const failures: string[] = [];

const requiredFiles = [
  'docs/nocobase-target-version-decision.md',
  'docs/nocobase-host-bootstrap-runbook.md',
  'docs/nocobase-host-integration-branch-plan.md',
  'docs/nocobase-source-api-verification-plan.md',
  'scripts/host/prepare-nocobase-host-workspace.sh',
  'scripts/host/check-host-prerequisites.ts',
  'scripts/host/copy-project-plugins-to-host.ts',
  'scripts/host/validate-host-workspace.ts',
];

const read = (relativePath: string): string => readFileSync(path.join(rootDir, relativePath), 'utf8') as string;
const existsFile = (relativePath: string): boolean => {
  const absolutePath = path.join(rootDir, relativePath);
  return existsSync(absolutePath) && statSync(absolutePath).isFile();
};

for (const filePath of requiredFiles) {
  if (!existsFile(filePath)) {
    failures.push(`缺少文件：${filePath}`);
  } else {
    console.log(`文件存在：${filePath}`);
  }
}

const existingContents = requiredFiles.filter(existsFile).map((filePath) => ({ filePath, content: read(filePath) }));
const docsContent = existingContents
  .filter(({ filePath }) => filePath.startsWith('docs/'))
  .map(({ content }) => content)
  .join('\n');
const scriptsContent = existingContents
  .filter(({ filePath }) => filePath.startsWith('scripts/host/'))
  .map(({ content }) => content)
  .join('\n');

const requireDocKeyword = (keyword: string, message: string): void => {
  if (!docsContent.includes(keyword)) failures.push(message);
};

requireDocKeyword('不要把完整 NocoBase 源码提交进当前仓库', '文档必须明确不要提交完整 NocoBase 源码。');
requireDocKeyword('不在生产库调试', '文档必须明确不要在生产库调试。');
requireDocKeyword('目标版本必须人工确认', '文档必须明确目标版本必须人工确认。');
requireDocKeyword('latest-full', '文档必须提及 latest-full。');
requireDocKeyword('不能作为真实接入基准', '文档必须明确 latest-full 不能作为真实接入基准。');

if (!scriptsContent.includes('dry-run')) failures.push('脚本必须明确默认 dry-run。');
if (!scriptsContent.includes('不读取 .env.test 真实值')) failures.push('脚本必须明确不读取 .env.test 真实值。');
if (!scriptsContent.includes('不会默认') && !scriptsContent.includes('不默认')) failures.push('脚本必须明确不默认写入宿主工程。');
if (!scriptsContent.includes('--execute')) failures.push('脚本必须要求真实操作显式传入 --execute。');
if (!scriptsContent.includes('CONFIRM_NOCOBASE_HOST_BOOTSTRAP_EXECUTE')) failures.push('脚本必须检查确认环境变量。');

console.log('宿主工程准备文档与脚本校验');
console.log('检查范围：只检查本地文档和 dry-run 脚本，不连接 NocoBase，不写数据库，不复制插件。');

if (failures.length > 0) {
  console.error('检查未通过：');
  for (const failure of failures) console.error(`- ${failure}`);
  process.exit(1);
}

console.log('检查通过：宿主工程准备文档与 dry-run 脚本满足本轮要求。');
