declare const require: any;
declare const process: { exit(code?: number): never };

const fs = require('fs');
const path = require('path');
import {
  validatePageForbiddenPatterns,
  validatePageInitializationPlan,
  validateRequiredPageActions,
  validateSensitivePageFields,
  type PageInitializationPlan,
  type PageInitializationResult,
} from '../../packages/shared/nocobase-automation/src';

const inputPath = path.resolve('test-data/generated/page-initialization-dry-run.generated.json');

if (!fs.existsSync(inputPath)) {
  console.error('缺少页面初始化 dry-run 结果，请先运行：npm run dry-run:initialize-pages');
  process.exit(1);
}

const parsed = JSON.parse(fs.readFileSync(inputPath, 'utf8')) as {
  pagePlan: PageInitializationPlan;
  result: PageInitializationResult;
};

const errors: string[] = [];
if (!parsed.result?.success) {
  errors.push('页面初始化 dry-run 结果不是 success。');
  errors.push(...(parsed.result?.errors ?? []));
}

for (const validation of [
  validatePageInitializationPlan(parsed.pagePlan),
  validatePageForbiddenPatterns(parsed.pagePlan),
  validateSensitivePageFields(parsed.pagePlan),
  validateRequiredPageActions(parsed.pagePlan),
]) {
  if (!validation.passed) errors.push(...validation.errors);
}

const serialized = JSON.stringify(parsed).toLowerCase();
for (const forbidden of ['booking', 'reservation', 'short_rental', 'driver_login', 'customer_portal', 'vehicle_category_rental', 'gps_rent_calculation']) {
  if (serialized.includes(forbidden)) errors.push(`页面初始化结果中出现禁止对象或逻辑：${forbidden}`);
}

if (serialized.includes('gps 参与租金计算') || serialized.includes('gps参与租金计算')) {
  errors.push('GPS 不得参与租金计算。');
}

if (errors.length > 0) {
  console.error('页面初始化 dry-run 结果校验失败：');
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log('页面初始化 dry-run 结果校验通过：菜单、页面、区块、筛选器、动作、敏感字段和业务边界均符合计划。');
