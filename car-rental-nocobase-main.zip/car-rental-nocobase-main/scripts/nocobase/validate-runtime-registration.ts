declare const require: any;
declare const process: { exit(code?: number): never };

const fs = require('fs');
const path = require('path');
import {
  validateCoreActionCoverage,
  validateCoreServiceCoverage,
  validateRolePermissionCoverage,
  validateRuntimeForbiddenPatterns,
  validateRuntimeRegistrationPlan,
  type RuntimeRegistrationBatchResult,
  type RuntimeRegistrationPlan,
} from '../../packages/shared/nocobase-automation/src';

const inputPath = path.resolve('test-data/generated/runtime-registration-dry-run.generated.json');

if (!fs.existsSync(inputPath)) {
  console.error('缺少 runtime dry-run 注册结果，请先运行：npm run dry-run:register-runtime');
  process.exit(1);
}

const parsed = JSON.parse(fs.readFileSync(inputPath, 'utf8')) as {
  runtimePlan: RuntimeRegistrationPlan;
  result: RuntimeRegistrationBatchResult;
};

const errors: string[] = [];
if (!parsed.result?.success) {
  errors.push('runtime dry-run 注册结果不是 success。');
  errors.push(...(parsed.result?.errors ?? []));
}

for (const validation of [
  validateRuntimeRegistrationPlan(parsed.runtimePlan),
  validateCoreServiceCoverage(parsed.runtimePlan),
  validateCoreActionCoverage(parsed.runtimePlan),
  validateRolePermissionCoverage(parsed.runtimePlan),
  validateRuntimeForbiddenPatterns(parsed.runtimePlan),
]) {
  if (!validation.passed) errors.push(...validation.errors);
}

const serialized = JSON.stringify(parsed).toLowerCase();
for (const forbidden of ['booking', 'reservation', 'short_rental_order', 'driver_login', 'customer_portal', 'vehicle_category_rental', 'gps_rent_calculation', 'deposit_as_rent_payment']) {
  if (serialized.includes(forbidden)) errors.push(`runtime 注册结果中出现禁止对象或逻辑：${forbidden}`);
}

for (const language of ['zh-CN', 'en-US', 'fr-FR']) {
  if (!parsed.runtimePlan.i18n.every((item) => item.languages.includes(language))) {
    errors.push(`i18n 注册计划缺少语言：${language}`);
  }
}

if (serialized.includes('gps 参与租金计算') || serialized.includes('gps参与租金计算')) {
  errors.push('GPS 不得参与租金计算。');
}
if (serialized.includes('押金计入租金已付') || serialized.includes('deposit_as_rent_payment')) {
  errors.push('押金不得计入租金已付。');
}

if (errors.length > 0) {
  console.error('runtime dry-run 注册结果校验失败：');
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log('runtime dry-run 注册结果校验通过：核心服务、动作、角色权限、定时任务、i18n 和业务边界均符合计划。');
