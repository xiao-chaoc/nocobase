declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };
declare const module: any;

import { RealBackupRollbackAdapter } from '../../packages/shared/nocobase-automation/src';
import type { RealBackupRollbackReport } from '../../packages/shared/nocobase-automation/src';

const fs = require('fs');
const path = require('path');

function containsForbiddenSecret(text: string): boolean {
  const normalized = text.toLowerCase();
  return ['db_password=', 'password=真实', 'secret=', 'iopgps_token=', 'private_key=', '真实密钥值'].some((item) => normalized.includes(item));
}

export function validateGeneratedRealBackupRollbackPlan(rootDir = process.cwd()) {
  const filePath = path.join(rootDir, 'test-data', 'generated', 'real-backup-rollback-plan.generated.json');
  const errors: string[] = [];
  const warnings: string[] = [];
  if (!fs.existsSync(filePath)) return { passed: false, errors: [`缺少真实 Backup / Rollback 草案文件：${filePath}`], warnings };
  const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
  const report: RealBackupRollbackReport = parsed.report;
  const adapter = new RealBackupRollbackAdapter();
  const validated = adapter.validateBackupRollbackPlans(report);
  errors.push(...validated.errors);
  warnings.push(...validated.warnings);
  if (!validated.success && validated.mode !== 'plan_only' && validated.mode !== 'validate_only' && validated.mode !== 'dry_run') errors.push('计划不可用且模式不在允许范围内。');
  if (validated.mode === 'real') errors.push('Backup / Rollback 草案不得使用 real 模式。');
  if (parsed.executed || validated.executed) errors.push('Backup / Rollback 草案不得标记为已执行。');
  if (parsed.real_execution_allowed) errors.push('Backup / Rollback 草案不得允许真实执行。');
  if (!validated.backupPlan) errors.push('backupPlan 缺失。');
  if (!validated.rollbackPlan) errors.push('rollbackPlan 缺失。');
  if (!validated.failureRecoveryPlans?.length) errors.push('failureRecoveryPlans 缺失。');
  for (const target of ['database', 'file_storage', 'plugin_storage']) {
    if (!validated.backupPlan.steps.some((step) => step.targetType === target)) errors.push(`缺少备份草案：${target}`);
  }
  for (const target of ['database_restore', 'file_storage_restore', 'plugin_disable', 'logs_preserve']) {
    if (!validated.rollbackPlan.steps.some((step) => step.targetType === target)) errors.push(`缺少回滚草案：${target}`);
  }
  if (validated.backupPlan.steps.some((step) => step.executed || step.canExecute)) errors.push('备份步骤不得真实执行或可执行。');
  if (validated.rollbackPlan.steps.some((step) => step.executed || step.canExecute)) errors.push('回滚步骤不得真实执行或可执行。');
  const text = JSON.stringify(parsed);
  if (containsForbiddenSecret(text)) errors.push('计划中疑似包含真实密码、真实 .env.test 值或真实密钥。');
  const lower = text.toLowerCase();
  if (lower.includes('production_ready') || lower.includes('生产部署完成') || lower.includes('正式上线完成')) errors.push('计划不得包含生产部署声明。');
  const uniqueErrors = [...new Set(errors)];
  return { passed: uniqueErrors.length === 0, errors: uniqueErrors, warnings: [...new Set(warnings)] };
}

if (typeof module !== 'undefined' && module === require.main) {
  const result = validateGeneratedRealBackupRollbackPlan();
  for (const warning of result.warnings) console.warn(`警告：${warning}`);
  if (!result.passed) {
    console.error('真实 Backup / Rollback 草案校验失败：');
    for (const error of result.errors) console.error(`- ${error}`);
    process.exit(1);
  }
  console.log('真实 Backup / Rollback 草案校验通过：plan_only、未真实执行、备份目标、回滚目标、失败恢复计划、安全边界和敏感信息检查均符合要求。');
}
