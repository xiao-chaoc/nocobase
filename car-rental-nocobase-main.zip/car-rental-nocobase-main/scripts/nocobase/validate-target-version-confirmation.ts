declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };

const { existsSync, readFileSync } = require('fs');
const path = require('path');

const rootDir = process.cwd();
const decisionPath = path.join(rootDir, 'docs/nocobase-target-version-decision.md');

const extractField = (content: string, field: string): string | undefined => {
  const escapedField = field.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`\\|\\s*\\\`${escapedField}\\\`\\s*\\|\\s*(?:\\\`([^\\\`]*)\\\`|([^|]*?))\\s*\\|`);
  const match = content.match(pattern);
  return (match?.[1] ?? match?.[2])?.trim();
};

const failures: string[] = [];

if (!existsSync(decisionPath)) {
  failures.push('缺少 docs/nocobase-target-version-decision.md，无法确认目标 NocoBase 版本。');
} else {
  const content = readFileSync(decisionPath, 'utf8') as string;
  const decisionStatus = extractField(content, 'decision_status');
  const targetVersion = extractField(content, 'target_version');
  const packageManager = extractField(content, 'package_manager');
  const confirmedPackageManager = extractField(content, 'confirmed_package_manager');
  const iopgpsRealSyncAllowed = extractField(content, 'iopgps_real_sync_allowed');
  const mockDataOnly = extractField(content, 'mock_data_only');
  const confirmedBy = extractField(content, 'confirmed_by');
  const confirmedAt = extractField(content, 'confirmed_at');

  if (decisionStatus !== 'confirmed') {
    failures.push(`目标 NocoBase 版本尚未人工确认：decision_status 当前为 ${decisionStatus ?? '缺失'}，必须为 confirmed。`);
  }

  if (!targetVersion || targetVersion === 'unset' || targetVersion === 'latest-full') {
    failures.push(`目标 NocoBase 版本无效：target_version 当前为 ${targetVersion ?? '缺失'}，不能为 unset 或 latest-full。`);
  }

  if (packageManager !== 'yarn') {
    failures.push(`包管理器确认错误：package_manager 当前为 ${packageManager ?? '缺失'}，NocoBase v2.0.61 宿主工程检测基准必须为 yarn。`);
  }

  if (confirmedPackageManager !== 'yarn') {
    failures.push(`包管理器确认错误：confirmed_package_manager 当前为 ${confirmedPackageManager ?? '缺失'}，NocoBase v2.0.61 宿主工程检测基准必须为 yarn。`);
  }

  if (iopgpsRealSyncAllowed === 'true') {
    failures.push('安全边界错误：iopgps_real_sync_allowed 必须为 false，当前不允许真实 IOPGPS 同步。');
  }

  if (mockDataOnly !== 'true') {
    failures.push(`安全边界错误：mock_data_only 必须为 true，当前值为 ${mockDataOnly ?? '缺失'}。`);
  }

  if (!confirmedBy || confirmedBy === 'unset') {
    failures.push('缺少人工确认人：confirmed_by 必须填写。');
  }

  if (!confirmedAt || confirmedAt === 'unset') {
    failures.push('缺少人工确认时间：confirmed_at 必须填写。');
  }
}

console.log('目标 NocoBase 版本确认校验');
console.log('检查范围：仅读取 docs/nocobase-target-version-decision.md。');
console.log('安全边界：不读取 .env，不读取 .env.test，不连接 NocoBase，不访问外部网络，不安装依赖，不写数据库。');

if (failures.length > 0) {
  console.error('检查未通过：目标版本未达到进入真实 adapter 实现的条件。');
  for (const failure of failures) {
    console.error(`- ${failure}`);
  }
  process.exit(1);
}

console.log('检查通过：目标 NocoBase 版本已人工确认，可进入下一阶段隔离测试接入准备。');
