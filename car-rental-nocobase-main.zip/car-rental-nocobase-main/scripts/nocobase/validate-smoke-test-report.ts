declare const require: any;
declare const process: { exit(code?: number): never };

const fs = require('fs');
const path = require('path');

import type { SmokeTestReport, SmokeTestStepName, SmokeTestDryRunResult } from '../../packages/shared/nocobase-automation/src';

const reportPath = path.resolve('test-data/generated/automated-smoke-test-report.generated.json');
const requiredSteps: SmokeTestStepName[] = [
  'repository_scan',
  'generate_registration_plan',
  'validate_registration_plan',
  'dry_run_register_collections',
  'validate_collection_registration',
  'dry_run_register_runtime',
  'validate_runtime_registration',
  'dry_run_initialize_pages',
  'validate_page_initialization',
  'seed_test_data',
  'validate_test_data',
  'dry_run_import_test_data',
  'validate_seed_data_import',
  'preflight_nas_test',
  'generate_smoke_report',
];
const requiredArtifacts = [
  'test-data/generated/automated-registration-plan.generated.json',
  'test-data/generated/collection-registration-dry-run.generated.json',
  'test-data/generated/runtime-registration-dry-run.generated.json',
  'test-data/generated/page-initialization-dry-run.generated.json',
  'test-data/generated/seed-data-import-dry-run.generated.json',
];

const errors: string[] = [];
if (!fs.existsSync(reportPath)) {
  console.error('缺少 Smoke Test 报告，请先运行：npm run smoke:dry-run');
  process.exit(1);
}

const raw = fs.readFileSync(reportPath, 'utf8') as string;
const parsed = JSON.parse(raw) as { result: SmokeTestDryRunResult; report: SmokeTestReport; dry_run_only?: boolean };
const stepNames = new Set(parsed.result?.steps?.map((step) => step.name) ?? []);
for (const stepName of requiredSteps) {
  if (!stepNames.has(stepName)) errors.push(`报告缺少必要步骤：${stepName}`);
}
for (const artifact of requiredArtifacts) {
  if (!parsed.report?.artifacts?.includes(artifact)) errors.push(`报告缺少必要产物：${artifact}`);
  if (!fs.existsSync(path.resolve(artifact))) errors.push(`产物文件不存在：${artifact}`);
}
const preflightStep = parsed.result.steps.find((step) => step.name === 'preflight_nas_test');
if (!preflightStep || !['passed', 'skipped', 'warning'].includes(preflightStep.status)) {
  errors.push('NAS preflight 必须已执行通过，或明确 skipped/warning。');
}
if (parsed.report.success && parsed.report.failed_steps !== 0) {
  errors.push('报告 success=true 时 failed_steps 必须为 0。');
}
if (!parsed.report.success && parsed.report.blockers.length === 0) {
  errors.push('报告 success=false 时必须列出 blockers。');
}

const secretPatterns = [
  /sk-[A-Za-z0-9_-]{20,}/,
  /AKIA[0-9A-Z]{16}/,
  /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/,
  /access_token["'\s:=]+(?!TEST_|MOCK_|MASKED_|PLACEHOLDER_|已脱敏)[A-Za-z0-9._-]{16,}/i,
  /login_key["'\s:=]+(?!TEST_|MOCK_|MASKED_|PLACEHOLDER_|已脱敏)[A-Za-z0-9._-]{12,}/i,
];
for (const pattern of secretPatterns) {
  if (pattern.test(raw)) errors.push(`报告疑似包含真实密钥或凭据：${pattern}`);
}
const sensitiveFilePatterns = [/https?:\/\/[^\s"']*(payment|screenshot|scan|contract)[^\s"']*/i, /\b\d{15}(?:\d{2}[0-9Xx])?\b/];
for (const pattern of sensitiveFilePatterns) {
  if (pattern.test(raw)) errors.push(`报告疑似包含真实证件、付款截图或合同扫描件：${pattern}`);
}
const lower = raw.toLowerCase();
for (const forbidden of ['booking', 'reservation', 'short_rental', 'driver_login', 'customer_portal', 'vehicle_category_rental']) {
  if (lower.includes(forbidden)) errors.push(`报告包含禁止业务模式：${forbidden}`);
}

if (errors.length > 0) {
  console.error('Smoke Test 报告校验失败：');
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log('Smoke Test 报告校验通过：步骤、产物、NAS preflight 状态、敏感数据与禁止业务模式均符合 dry-run 要求。');
