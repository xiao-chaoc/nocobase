declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };
declare const module: any;

import { inspectNocobaseEnvironment, RealSeedDataImportAdapter } from '../../packages/shared/nocobase-automation/src';
import type { RealSeedDataImportContext, SeedDataImportPlan } from '../../packages/shared/nocobase-automation/src';

const fs = require('fs');
const path = require('path');

export function generateRealSeedDataImportPlan(rootDir = process.cwd()) {
  const inputPath = path.join(rootDir, 'test-data', 'generated', 'seed-data-import-dry-run.generated.json');
  if (!fs.existsSync(inputPath)) throw new Error('缺少测试数据导入 dry-run 产物，请先运行 npm run dry-run:import-test-data。');
  const parsed = JSON.parse(fs.readFileSync(inputPath, 'utf8'));
  const importPlan: SeedDataImportPlan = parsed.importPlan ?? parsed.plan ?? parsed;
  const registrationPlanPath = path.join(rootDir, 'test-data', 'generated', 'automated-registration-plan.generated.json');
  const context: RealSeedDataImportContext = {
    mode: 'plan_only',
    adapterEnvironment: inspectNocobaseEnvironment({ mode: 'dry_run' }),
    allowRealExecution: false,
    requireBackup: true,
    requireRollbackPlan: true,
    requireTransaction: true,
    sourceDir: path.join(rootDir, 'test-data', 'generated'),
    operator: 'codex-web-draft',
    notes: [
      '本脚本只生成真实 Seed Data Import adapter 草案。',
      registrationPlanPath && fs.existsSync(registrationPlanPath) ? '已发现自动化注册计划产物，可作为后续真实 Collection 对齐参考。' : '未发现自动化注册计划补充产物。',
      '不连接 NocoBase，不写数据库，不上传文件，不允许 real 模式。',
    ],
  };
  const adapter = new RealSeedDataImportAdapter();
  const plan = adapter.buildRealSeedDataImportPlan(importPlan, context);
  if (plan.mode === 'real') throw new Error('当前脚本不允许 real 模式。');
  const report = adapter.validateRealSeedDataImportPlan(plan);
  const output = {
    generated_at: '2026-06-04T00:00:00.000Z',
    draft_only: true,
    real_execution_allowed: false,
    executed: false,
    source: 'seed-data-import-dry-run.generated.json',
    plan,
    report,
  };
  const outputPath = path.join(rootDir, 'test-data', 'generated', 'real-seed-data-import-plan.generated.json');
  fs.writeFileSync(outputPath, `${JSON.stringify(output, null, 2)}\n`, 'utf8');
  return { outputPath, output };
}

if (typeof module !== 'undefined' && module === require.main) {
  try {
    const result = generateRealSeedDataImportPlan();
    if (!result.output.report.success) {
      console.error('真实 Seed Data Import 草案生成后校验失败：');
      for (const error of result.output.report.errors) console.error(`- ${error}`);
      process.exit(1);
    }
    console.log(`真实 Seed Data Import 草案已生成：${result.outputPath}`);
    console.log(`模式：${result.output.plan.mode}，实体：${result.output.plan.entities.length} 个，步骤：${result.output.plan.steps.length} 个。`);
    console.log('本脚本未连接 NocoBase、未写数据库、未上传文件、未创建记录、未执行事务。');
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}
