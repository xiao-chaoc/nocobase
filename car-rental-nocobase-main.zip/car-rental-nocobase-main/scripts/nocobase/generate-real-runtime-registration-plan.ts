declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };
declare const module: any;

import {
  buildRuntimeRegistrationPlanFromAutomatedPlan,
  RealRuntimeRegistrationAdapter,
  createDefaultRealRuntimeRegistrationContext,
} from '../../packages/shared/nocobase-automation/src';
import type { RuntimeRegistrationPlan } from '../../packages/shared/nocobase-automation/src';

const fs = require('fs');
const path = require('path');

export function generateRealRuntimeRegistrationPlan(rootDir = process.cwd()) {
  const inputPath = path.join(rootDir, 'test-data', 'generated', 'automated-registration-plan.generated.json');
  if (!fs.existsSync(inputPath)) throw new Error(`缺少自动化注册计划文件：${inputPath}`);
  const parsed = JSON.parse(fs.readFileSync(inputPath, 'utf8'));
  const source = parsed.plan ?? parsed;
  const runtimePlan: RuntimeRegistrationPlan = buildRuntimeRegistrationPlanFromAutomatedPlan(source);
  const adapter = new RealRuntimeRegistrationAdapter();
  const context = createDefaultRealRuntimeRegistrationContext('plan_only');
  const plan = adapter.buildRealRuntimeRegistrationPlan(runtimePlan, context);
  if (plan.mode === 'real') throw new Error('当前脚本不允许 real 模式。');
  const report = adapter.validateRealRuntimeRegistrationPlan(plan);
  const output = {
    generated_at: '2026-06-04T00:00:00.000Z',
    draft_only: true,
    real_execution_allowed: false,
    executed: false,
    source: 'automated-registration-plan.generated.json',
    plan,
    report,
  };
  const outputDir = path.join(rootDir, 'test-data', 'generated');
  fs.mkdirSync(outputDir, { recursive: true });
  const outputPath = path.join(outputDir, 'real-runtime-registration-plan.generated.json');
  fs.writeFileSync(outputPath, `${JSON.stringify(output, null, 2)}\n`, 'utf8');
  return { outputPath, output };
}

if (typeof module !== 'undefined' && module === require.main) {
  try {
    const result = generateRealRuntimeRegistrationPlan();
    if (!result.output.report.success) {
      console.error('真实 Runtime 注册草案生成后校验失败：');
      for (const error of result.output.report.errors) console.error(`- ${error}`);
      process.exit(1);
    }
    console.log(`真实 Runtime 注册草案已生成：${result.outputPath}`);
    console.log(`模式：${result.output.plan.mode}，服务：${result.output.plan.services.length} 个，动作：${result.output.plan.actions.length} 个，权限角色：${result.output.plan.permissions.length} 个，定时任务：${result.output.plan.schedules.length} 个，i18n：${result.output.plan.i18n.length} 个。`);
    console.log('本脚本未连接 NocoBase、未写数据库、未注册服务/动作/权限/定时任务、未加载 i18n。');
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}
