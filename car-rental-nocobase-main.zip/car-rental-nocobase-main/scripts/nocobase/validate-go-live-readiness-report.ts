declare const require: any;
declare const process: { exit(code?: number): never };

const fs = require('fs');
const path = require('path');

import {
  getRequiredGoLiveReadinessGateNames,
  type GoLiveReadinessGateName,
  type GoLiveReadinessReport,
  type ReadinessLevel,
} from '../../packages/shared/nocobase-automation/src';

const inputPath = path.resolve('test-data/generated/go-live-readiness-report.generated.json');
const legalReadinessLevels: ReadinessLevel[] = ['dry_run_only', 'nas_base_environment_ready', 'plugin_integration_test_ready', 'uat_ready', 'production_not_ready', 'production_ready'];
const errors: string[] = [];

if (!fs.existsSync(inputPath)) {
  console.error('缺少 go-live readiness 报告，请先运行：npm run generate:go-live-readiness');
  process.exit(1);
}

const raw = fs.readFileSync(inputPath, 'utf8') as string;
const parsed = JSON.parse(raw) as { report: GoLiveReadinessReport; summary?: string };
const report = parsed.report;
if (!report) errors.push('报告 JSON 缺少 report 对象。');

const gateNames = new Set<GoLiveReadinessGateName>((report?.gates ?? []).map((gate) => gate.name));
for (const gateName of getRequiredGoLiveReadinessGateNames()) {
  if (!gateNames.has(gateName)) errors.push(`报告缺少必要 gate：${gateName}`);
}
const productionGate = report?.gates?.find((gate) => gate.name === 'production_readiness');
if (report?.readiness_level === 'production_ready' || productionGate?.status === 'passed') {
  const evidence = [...(productionGate?.evidence ?? []), ...(report?.evidence_files ?? [])].join('\n');
  if (!evidence.includes('真实 NocoBase adapter') || !evidence.includes('UAT') || !evidence.includes('生产检查')) {
    errors.push('不能标记 production_ready，除非有真实 adapter、UAT 和生产检查通过证据。');
  }
}
const adapterGate = report?.gates?.find((gate) => gate.name === 'real_nocobase_adapter_readiness');
if (adapterGate?.status !== 'passed' && (report?.readiness_level === 'plugin_integration_test_ready' || report?.allowed_next_stage?.includes('plugin_integration_test_ready'))) {
  errors.push('真实 NocoBase adapter 未通过时，不能允许进入 plugin_integration_test_ready。');
}
const smokeGate = report?.gates?.find((gate) => gate.name === 'smoke_test_dry_run');
if (smokeGate?.status !== 'passed' && report?.blockers?.length === 0) errors.push('smoke test 未通过时必须列出 blockers。');
if (report?.success) {
  const failedGates = report.gates.filter((gate) => gate.status === 'failed');
  if (failedGates.length > 0) errors.push(`报告 success=true 时不应存在 failed gates：${failedGates.map((gate) => gate.name).join(', ')}`);
}
if (!legalReadinessLevels.includes(report?.readiness_level)) errors.push(`readiness_level 非法：${report?.readiness_level}`);
if (!report?.next_actions || report.next_actions.length === 0) errors.push('next_actions 不能为空。');

const secretPatterns = [/sk-[A-Za-z0-9_-]{20,}/, /AKIA[0-9A-Z]{16}/, /access_token["'\s:=]+(?!TEST_|MOCK_|MASKED_|PLACEHOLDER_|已脱敏)[A-Za-z0-9._-]{16,}/i, /login_key["'\s:=]+(?!TEST_|MOCK_|MASKED_|PLACEHOLDER_|已脱敏)[A-Za-z0-9._-]{12,}/i];
for (const pattern of secretPatterns) {
  if (pattern.test(raw)) errors.push(`报告疑似包含真实密钥风险：${pattern}`);
}
const lower = raw.toLowerCase();
for (const forbidden of ['booking', 'reservation', 'short_rental_order', 'driver_login', 'customer_portal', 'vehicle_category_rental']) {
  if (lower.includes(forbidden)) errors.push(`报告包含禁止业务模式：${forbidden}`);
}

if (errors.length > 0) {
  console.error('go-live readiness 报告校验失败：');
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log('go-live readiness 报告校验通过：gate、readiness_level、生产边界、真实 adapter 边界、敏感数据和禁止业务模式均符合预检要求。');
