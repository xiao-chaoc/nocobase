declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };
declare const module: any;

import { RealPageRegistrationAdapter, validateRealPageSchemaDraft } from '../../packages/shared/nocobase-automation/src';
import type { RealPageRegistrationPlan } from '../../packages/shared/nocobase-automation/src';

const fs = require('fs');
const path = require('path');

const REQUIRED_PAGE_NAMES = [
  'driver-list',
  'vehicle-list',
  'contract-list',
  'active-contracts',
  'rent-ledger-list',
  'rent-calendar',
  'payment-list',
  'deposit-list',
  'contract-documents',
  'gps-devices',
  'gps-status',
  'operation-logs',
];

export function validateGeneratedRealPageRegistrationPlan(rootDir = process.cwd()) {
  const filePath = path.join(rootDir, 'test-data', 'generated', 'real-page-registration-plan.generated.json');
  const errors: string[] = [];
  const warnings: string[] = [];
  if (!fs.existsSync(filePath)) return { passed: false, errors: [`缺少真实 Page 注册草案文件：${filePath}`], warnings };
  const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
  const plan: RealPageRegistrationPlan = parsed.plan;
  const adapter = new RealPageRegistrationAdapter();
  const report = adapter.validateRealPageRegistrationPlan(plan);
  const schema = validateRealPageSchemaDraft(plan);
  errors.push(...report.errors, ...schema.errors);
  warnings.push(...report.warnings, ...schema.warnings);

  if (plan.mode === 'real') errors.push('真实 Page 注册草案不得使用 real 模式。');
  if (parsed.executed || parsed.real_execution_allowed || report.executed) errors.push('真实 Page 注册草案不得标记为已执行或允许真实执行。');

  const pageNames = new Set(plan.pages.map((page) => page.name));
  for (const pageName of REQUIRED_PAGE_NAMES) {
    if (!pageNames.has(pageName)) errors.push(`缺少核心页面：${pageName}`);
  }
  if (plan.menus.length < 10) errors.push('真实 Page 注册草案菜单数量不足。');
  if (plan.blocks.length === 0) errors.push('真实 Page 注册草案必须包含区块。');
  if (plan.actions.some((action) => action.danger && !action.confirmationRequired)) errors.push('危险页面动作必须启用确认提示。');
  if (plan.actions.some((action) => action.requiredRoles.length === 0)) errors.push('页面动作必须包含 requiredRoles。');

  const text = JSON.stringify(plan).toLowerCase();
  for (const forbidden of ['booking', 'reservation', 'short_rental_order', 'driver_login', 'customer_portal', 'vehicle_category_rental']) {
    if (text.includes(forbidden)) errors.push(`不允许出现禁用业务：${forbidden}`);
  }
  if (text.includes('gps 参与租金计算') || text.includes('gps参与租金计算') || text.includes('gps_rent_calculation')) errors.push('GPS 不得参与租金计算。');
  if (text.includes('押金计入租金已付') || text.includes('押金作为租金已付') || text.includes('deposit_as_rent_payment')) errors.push('押金不得计入租金已付。');
  if (text.includes('payment_screenshot') && !text.includes('字段级权限')) errors.push('付款截图必须提示字段级权限控制。');
  if (!plan.rollbackPlan || plan.rollbackPlan.length === 0) errors.push('真实 Page 注册草案必须包含回滚计划。');
  if (!plan.postRegistrationValidationPlan || plan.postRegistrationValidationPlan.length === 0) errors.push('真实 Page 注册草案必须包含注册后核验计划。');

  return { passed: errors.length === 0 && report.success, errors: [...new Set(errors)], warnings: [...new Set(warnings)] };
}

if (typeof module !== 'undefined' && module === require.main) {
  const result = validateGeneratedRealPageRegistrationPlan();
  for (const warning of result.warnings) console.warn(`警告：${warning}`);
  if (!result.passed) {
    console.error('真实 Page 注册草案校验失败：');
    for (const error of result.errors) console.error(`- ${error}`);
    process.exit(1);
  }
  console.log('真实 Page 注册草案校验通过：plan_only、未真实执行、核心页面、菜单、区块、危险动作确认、禁用业务边界、GPS 与押金边界、敏感字段权限提示均符合要求。');
}
