declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };

const { existsSync, readFileSync } = require('fs');
const path = require('path');

const rootDir = process.cwd();

const requiredFiles = [
  '.github/ISSUE_TEMPLATE/nocobase-target-version-confirmation.yml',
  '.github/pull_request_template.md',
  'docs/nocobase-target-version-operator-checklist.md',
  'docs/nocobase-target-version-commit-policy.md',
  'docs/nocobase-target-version-review-checklist.md',
  'docs/nocobase-target-version-confirmation-workflow.md',
  'docs/nocobase-target-version-decision.md',
  'scripts/nocobase/validate-target-version-input.ts',
  'scripts/nocobase/apply-target-version-confirmation.ts',
  'scripts/nocobase/validate-can-start-real-adapter.ts',
];

const failures: string[] = [];

const readRequiredFile = (relativePath: string): string => {
  const absolutePath = path.join(rootDir, relativePath);
  if (!existsSync(absolutePath)) {
    failures.push(`缺少必要流程文件：${relativePath}`);
    return '';
  }
  return readFileSync(absolutePath, 'utf8') as string;
};

for (const requiredFile of requiredFiles) readRequiredFile(requiredFile);

const issueTemplate = readRequiredFile('.github/ISSUE_TEMPLATE/nocobase-target-version-confirmation.yml');
const prTemplate = readRequiredFile('.github/pull_request_template.md');
const operatorChecklist = readRequiredFile('docs/nocobase-target-version-operator-checklist.md');
const commitPolicy = readRequiredFile('docs/nocobase-target-version-commit-policy.md');
const reviewChecklist = readRequiredFile('docs/nocobase-target-version-review-checklist.md');
const workflowDoc = readRequiredFile('docs/nocobase-target-version-confirmation-workflow.md');

for (const forbidden of ['APP_KEY', 'DB_PASSWORD', 'IOPGPS_LOGIN_KEY']) {
  if (issueTemplate.includes(forbidden)) failures.push(`Issue 模板不能包含 ${forbidden}。`);
}

if (!prTemplate.includes('latest-full')) failures.push('PR 模板必须包含 latest-full 检查。');
if (!prTemplate.includes('.env')) failures.push('PR 模板必须包含 .env 检查。');
if (!operatorChecklist.includes('validate:target-version-input')) failures.push('人工确认操作清单必须包含 validate:target-version-input。');
if (!commitPolicy.includes('filled.json')) failures.push('版本确认提交规范必须禁止 filled.json。');
if (!reviewChecklist.includes('validate:can-start-real-adapter')) failures.push('review checklist 必须包含 validate:can-start-real-adapter。');
if (!workflowDoc.includes('目标版本未确认前不能继续真实 adapter')) failures.push('workflow 文档必须说明版本未确认前不能继续真实 adapter。');

console.log('目标 NocoBase 版本确认流程文件校验');
console.log('检查范围：GitHub Issue 模板、PR 模板、人工清单、提交规范、review checklist、既有门禁脚本。');
console.log('安全边界：不读取 .env，不读取 .env.test，不连接 NocoBase，不访问外部网络，不安装依赖，不写数据库。');

if (failures.length > 0) {
  console.error('检查未通过：目标版本确认流程文件不完整或内容不符合要求。');
  for (const failure of failures) console.error(`- ${failure}`);
  process.exit(1);
}

console.log('检查通过：目标版本确认流程文件齐备，且未要求填写敏感密钥。');
