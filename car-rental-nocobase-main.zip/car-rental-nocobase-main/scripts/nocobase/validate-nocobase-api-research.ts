declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };

const { existsSync, readFileSync, statSync } = require('fs');
const path = require('path');

const rootDir = process.cwd();

const requiredFiles = [
  'docs/nocobase-target-version-research.md',
  'docs/nocobase-plugin-api-research.md',
  'docs/real-adapter-api-mapping.md',
  'docs/real-adapter-gap-analysis.md',
  'docs/real-adapter-implementation-backlog.md',
];

const requiredKeywords = [
  '目标版本',
  '插件生命周期',
  'Collection 注册',
  '服务方法注册',
  '权限 ACL',
  'UI Schema',
  'i18n',
  '定时任务',
  '工作流',
  '文件存储',
  '模板打印',
  '备份',
  '回滚',
  '待验证',
  '官方来源',
  '不得伪造 API',
  '不得生产库调试',
];

const toAbsolute = (relativePath: string): string => path.join(rootDir, relativePath);

const failures: string[] = [];
const contents: string[] = [];

for (const filePath of requiredFiles) {
  const absolutePath = toAbsolute(filePath);
  if (!existsSync(absolutePath) || !statSync(absolutePath).isFile()) {
    failures.push(`缺失调研文档：${filePath}`);
    continue;
  }
  const content = readFileSync(absolutePath, 'utf8') as string;
  contents.push(content);
  console.log(`文档存在：${filePath}`);
}

const combinedContent = contents.join('\n');
for (const keyword of requiredKeywords) {
  if (!combinedContent.includes(keyword)) {
    failures.push(`调研文档缺失关键章节或关键词：${keyword}`);
  }
}

console.log('NocoBase API 调研文档覆盖检查');
console.log('检查范围：仅检查本地文档，不连接 NocoBase，不访问真实数据库，不调用外部 API。');
console.log(`文档数量检查：${failures.some((item) => item.startsWith('缺失调研文档')) ? '失败' : '通过'}`);
console.log(`关键词覆盖检查：${failures.some((item) => item.startsWith('调研文档缺失')) ? '失败' : '通过'}`);

if (failures.length > 0) {
  console.error('检查未通过：');
  for (const failure of failures) {
    console.error(`- ${failure}`);
  }
  process.exit(1);
}

console.log('检查通过：NocoBase 目标版本与插件 API 调研文档已覆盖本轮关键区域。');
