declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never; argv: string[] };
declare const module: any;

import { RealBackupRollbackAdapter } from '../../packages/shared/nocobase-automation/src';
import type { RealBackupRollbackMode } from '../../packages/shared/nocobase-automation/src';

const fs = require('fs');
const path = require('path');

export function generateRealBackupRollbackPlan(rootDir = process.cwd()) {
  const requestedMode = (process.argv.find((arg) => arg.startsWith('--mode='))?.split('=')[1] ?? 'plan_only') as RealBackupRollbackMode;
  if (requestedMode === 'real') throw new Error('当前脚本不允许 real 模式。');
  const adapter = new RealBackupRollbackAdapter();
  const report = adapter.generateBackupRollbackReport({
    mode: requestedMode,
    allowRealExecution: false,
    requireOperatorConfirmation: false,
    requireIsolatedDatabase: true,
    requireMockDataOnly: true,
    requireIopgpsDisabled: true,
    backupDirectory: 'backups-test/real-backup-rollback-draft',
    rollbackDirectory: 'backups-test/real-backup-rollback-draft/rollback',
    operator: 'codex-web-draft',
    notes: ['脚本只生成真实 Backup / Rollback 草案，不连接 NocoBase，不执行备份，不执行回滚，不读取 .env.test。'],
  });
  const generatedDir = path.join(rootDir, 'test-data', 'generated');
  fs.mkdirSync(generatedDir, { recursive: true });
  const outputPath = path.join(generatedDir, 'real-backup-rollback-plan.generated.json');
  const output = {
    generated_at: '2026-06-05T00:00:00.000Z',
    draft_only: true,
    real_execution_allowed: false,
    executed: false,
    report,
  };
  fs.writeFileSync(outputPath, `${JSON.stringify(output, null, 2)}\n`, 'utf8');
  return { outputPath, output };
}

if (typeof module !== 'undefined' && module === require.main) {
  try {
    const result = generateRealBackupRollbackPlan();
    const report = result.output.report;
    console.log(`真实 Backup / Rollback 草案已生成：${result.outputPath}`);
    console.log(`模式：${report.mode}，备份步骤：${report.backupPlan.steps.length} 个，回滚步骤：${report.rollbackPlan.steps.length} 个，失败恢复计划：${report.failureRecoveryPlans.length} 个。`);
    console.log('本脚本未连接 NocoBase、未执行备份、未执行回滚、未读取 .env.test、未删除文件。');
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}
