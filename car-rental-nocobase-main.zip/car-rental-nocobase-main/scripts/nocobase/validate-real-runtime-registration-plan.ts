declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };
declare const module: any;

import { CORE_ACTION_NAMES, CORE_ROLE_NAMES, CORE_SERVICE_NAMES, RealRuntimeRegistrationAdapter, validateRealRuntimeSchemaDraft } from '../../packages/shared/nocobase-automation/src';
import type { RealRuntimeRegistrationPlan } from '../../packages/shared/nocobase-automation/src';

const fs = require('fs');
const path = require('path');

export function validateGeneratedRealRuntimeRegistrationPlan(rootDir = process.cwd()) {
  const filePath = path.join(rootDir, 'test-data', 'generated', 'real-runtime-registration-plan.generated.json');
  const errors: string[] = [];
  const warnings: string[] = [];
  if (!fs.existsSync(filePath)) return { passed: false, errors: [`缺少真实 Runtime 注册草案文件：${filePath}`], warnings };
  const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
  const plan: RealRuntimeRegistrationPlan = parsed.plan;
  const adapter = new RealRuntimeRegistrationAdapter();
  const report = adapter.validateRealRuntimeRegistrationPlan(plan);
  const schema = validateRealRuntimeSchemaDraft(plan);
  errors.push(...report.errors, ...schema.errors);
  warnings.push(...report.warnings, ...schema.warnings);

  if (plan.mode === 'real') errors.push('真实 Runtime 注册草案不得使用 real 模式。');
  if (parsed.executed || parsed.real_execution_allowed || report.executed) errors.push('真实 Runtime 注册草案不得标记为已执行或允许真实执行。');

  for (const serviceName of CORE_SERVICE_NAMES) {
    if (!plan.services.some((service) => service.handlerName === serviceName || service.name.endsWith(`.${serviceName}`) || service.name === serviceName)) errors.push(`缺少核心服务：${serviceName}`);
  }
  for (const actionName of CORE_ACTION_NAMES) {
    if (!plan.actions.some((action) => action.name === actionName)) errors.push(`缺少核心动作：${actionName}`);
  }
  const roles = new Set(plan.permissions.map((permission) => permission.role));
  for (const role of CORE_ROLE_NAMES) {
    if (!roles.has(role)) errors.push(`缺少核心角色：${role}`);
  }
  for (const item of plan.i18n) {
    for (const language of ['zh-CN', 'en-US', 'fr-FR']) {
      if (!item.languages.includes(language)) errors.push(`i18n ${item.namespace} 缺少语言：${language}`);
    }
  }

  const text = JSON.stringify(plan).toLowerCase();
  for (const forbidden of ['booking', 'reservation', 'short_rental_order', 'driver_login', 'customer_portal', 'vehicle_category_rental']) {
    if (text.includes(forbidden)) errors.push(`不允许出现禁用业务：${forbidden}`);
  }
  if (text.includes('gps 参与租金计算') || text.includes('gps参与租金计算') || text.includes('gps_rent_calculation')) errors.push('GPS 不得参与租金计算。');
  if (text.includes('押金计入租金已付') || text.includes('押金作为租金已付') || text.includes('deposit_as_rent_payment')) errors.push('押金不得计入租金已付。');
  if (plan.schedules.some((schedule) => schedule.sourcePlugin === 'plugin-iopgps' && schedule.enabledByDefault)) errors.push('IOPGPS 定时任务没有保持默认关闭。');

  return { passed: errors.length === 0 && report.success, errors: [...new Set(errors)], warnings: [...new Set(warnings)] };
}

if (typeof module !== 'undefined' && module === require.main) {
  const result = validateGeneratedRealRuntimeRegistrationPlan();
  for (const warning of result.warnings) console.warn(`警告：${warning}`);
  if (!result.passed) {
    console.error('真实 Runtime 注册草案校验失败：');
    for (const error of result.errors) console.error(`- ${error}`);
    process.exit(1);
  }
  console.log('真实 Runtime 注册草案校验通过：plan_only、未真实执行、核心服务/动作/六角色、三语言、禁用业务边界、GPS 与押金边界、IOPGPS 默认关闭均符合要求。');
}
