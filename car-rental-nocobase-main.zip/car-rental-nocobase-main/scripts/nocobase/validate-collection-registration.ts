declare const require: any;
declare const process: { exit(code?: number): never };

const fs = require('fs');
const path = require('path');
import {
  validateCollectionRegistrationPlan,
  validateCriticalCollections,
  validateCriticalUniqueConstraints,
  validateSensitiveFields,
  type CollectionRegistrationBatchResult,
  type NocobaseCollectionPlan,
} from '../../packages/shared/nocobase-automation/src';

const inputPath = path.resolve('test-data/generated/collection-registration-dry-run.generated.json');

if (!fs.existsSync(inputPath)) {
  console.error('缺少 Collection dry-run 注册结果，请先运行：npm run dry-run:register-collections');
  process.exit(1);
}

const parsed = JSON.parse(fs.readFileSync(inputPath, 'utf8')) as {
  collectionPlans: NocobaseCollectionPlan[];
  result: CollectionRegistrationBatchResult;
};

const errors: string[] = [];

if (!parsed.result?.success) {
  errors.push('Collection dry-run 注册结果不是 success。');
  errors.push(...(parsed.result?.errors ?? []));
}

const serialized = JSON.stringify(parsed).toLowerCase();
for (const forbidden of ['bookings', 'reservations', 'short_rental_orders', 'driver_login', 'customer_portal', 'vehicle_category_rental']) {
  if (serialized.includes(forbidden)) {
    errors.push(`注册结果中出现禁止对象或逻辑：${forbidden}`);
  }
}

for (const validation of [
  validateCollectionRegistrationPlan(parsed.collectionPlans),
  validateCriticalCollections(parsed.collectionPlans),
  validateCriticalUniqueConstraints(parsed.collectionPlans),
  validateSensitiveFields(parsed.collectionPlans),
]) {
  if (!validation.passed) {
    errors.push(...validation.errors);
  }
}

const criticalResults = new Map((parsed.result?.results ?? []).map((item) => [item.collectionName, item]));
for (const collectionName of [
  'drivers',
  'vehicles',
  'lease_contracts',
  'rent_daily_ledgers',
  'rent_payments',
  'rent_payment_allocations',
  'deposit_records',
  'operation_logs',
  'gps_devices',
  'gps_daily_mileages',
  'iopgps_settings',
  'contract_templates',
  'contract_documents',
]) {
  const result = criticalResults.get(collectionName);
  if (!result || (!result.success && !result.skipped)) {
    errors.push(`关键 Collection 未成功注册或可跳过：${collectionName}`);
  }
}

if (errors.length > 0) {
  console.error('Collection dry-run 注册结果校验失败：');
  for (const error of errors) {
    console.error(`- ${error}`);
  }
  process.exit(1);
}

console.log('Collection dry-run 注册结果校验通过：关键 Collections、唯一约束、敏感字段和业务边界均符合计划。');
