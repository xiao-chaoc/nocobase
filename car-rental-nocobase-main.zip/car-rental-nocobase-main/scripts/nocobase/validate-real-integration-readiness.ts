declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };

const { existsSync, readFileSync, statSync } = require('fs');
const path = require('path');

const rootDir = process.cwd();

const requiredFiles = [
  'docs/real-nocobase-integration-runbook.md',
  'docs/real-adapter-implementation-sequence.md',
  'docs/real-nocobase-host-requirements.md',
  'docs/real-integration-risk-register.md',
  'docs/real-collection-registration-adapter.md',
  'docs/real-runtime-registration-adapter.md',
  'docs/real-page-registration-adapter.md',
  'docs/real-seed-data-import-adapter.md',
  'docs/real-smoke-test-adapter.md',
  'docs/real-backup-rollback-adapter.md',
  'scripts/nocobase/generate-real-collection-registration-plan.ts',
  'scripts/nocobase/validate-real-collection-registration-plan.ts',
  'scripts/nocobase/generate-real-runtime-registration-plan.ts',
  'scripts/nocobase/validate-real-runtime-registration-plan.ts',
  'scripts/nocobase/generate-real-page-registration-plan.ts',
  'scripts/nocobase/validate-real-page-registration-plan.ts',
  'scripts/nocobase/generate-real-seed-data-import-plan.ts',
  'scripts/nocobase/validate-real-seed-data-import-plan.ts',
  'scripts/nocobase/generate-real-smoke-test-plan.ts',
  'scripts/nocobase/validate-real-smoke-test-plan.ts',
  'scripts/nocobase/generate-real-backup-rollback-plan.ts',
  'scripts/nocobase/validate-real-backup-rollback-plan.ts',
];

const requiredPackageScripts = [
  'generate:real-collection-plan',
  'validate:real-collection-plan',
  'generate:real-runtime-plan',
  'validate:real-runtime-plan',
  'generate:real-page-plan',
  'validate:real-page-plan',
  'generate:real-seed-data-plan',
  'validate:real-seed-data-plan',
  'generate:real-smoke-test-plan',
  'validate:real-smoke-test-plan',
  'generate:real-backup-rollback-plan',
  'validate:real-backup-rollback-plan',
  'validate:real-integration-readiness',
];

const forbiddenPaths = [
  '.env',
  '.env.test',
  'payment-screenshots',
  'real-payment-screenshots',
  'contract-scans',
  'real-contract-scans',
  'driver-documents',
  'real-driver-documents',
  'storage/payment-screenshots',
  'storage/contract-scans',
  'storage/driver-documents',
  'test-data/real-payment-screenshots',
  'test-data/real-contract-scans',
  'test-data/real-driver-documents',
];

const toAbsolute = (relativePath: string): string => path.join(rootDir, relativePath);

const missingFiles = requiredFiles.filter((filePath) => !existsSync(toAbsolute(filePath)) || !statSync(toAbsolute(filePath)).isFile());
const existingForbiddenPaths = forbiddenPaths.filter((filePath) => existsSync(toAbsolute(filePath)));

const packageJsonPath = toAbsolute('package.json');
const packageJson = JSON.parse(readFileSync(packageJsonPath, 'utf8')) as { scripts?: Record<string, string> };
const scripts = packageJson.scripts ?? {};
const missingPackageScripts = requiredPackageScripts.filter((scriptName) => !scripts[scriptName]);

const failures = [
  ...missingFiles.map((filePath) => `缺失关键文件：${filePath}`),
  ...missingPackageScripts.map((scriptName) => `package.json 缺失脚本：${scriptName}`),
  ...existingForbiddenPaths.map((filePath) => `禁止存在的真实环境或真实文件路径：${filePath}`),
];

console.log('真实 NocoBase 工程接入 readiness 检查');
console.log('检查范围：仅检查当前仓库文档、草案、脚本和安全边界。');
console.log('安全边界：不连接 NocoBase，不读取 .env.test，不执行真实注册，不写数据库。');
console.log(`关键文件检查：${missingFiles.length === 0 ? '通过' : '失败'}`);
console.log(`package.json 脚本检查：${missingPackageScripts.length === 0 ? '通过' : '失败'}`);
console.log(`禁止路径检查：${existingForbiddenPaths.length === 0 ? '通过' : '失败'}`);

if (failures.length > 0) {
  console.error('检查未通过：');
  for (const failure of failures) {
    console.error(`- ${failure}`);
  }
  process.exit(1);
}

console.log('检查通过：当前仓库具备进入完整 NocoBase 工程真实接入准备的文档与草案条件。');
