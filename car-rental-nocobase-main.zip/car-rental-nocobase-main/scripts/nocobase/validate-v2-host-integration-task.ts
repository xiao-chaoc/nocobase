declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };

const { existsSync, readFileSync, statSync } = require('fs');
const path = require('path');

const rootDir = process.cwd();
const failures: string[] = [];

const requiredFiles = [
  'docs/nocobase-v2.0.61-host-integration-task.md',
  'docs/nocobase-v2.0.61-host-directory-plan.md',
  'docs/nocobase-v2.0.61-host-bootstrap-commands.md',
  'docs/nocobase-v2.0.61-plugin-copy-plan.md',
  'docs/task-real-environment-adapter-v2.0.61.md',
  'docs/task-real-collection-adapter-v2.0.61.md',
];

const toAbsolute = (relativePath: string): string => path.join(rootDir, relativePath);
const existsFile = (relativePath: string): boolean => {
  const absolutePath = toAbsolute(relativePath);
  return existsSync(absolutePath) && statSync(absolutePath).isFile();
};
const read = (relativePath: string): string => readFileSync(toAbsolute(relativePath), 'utf8') as string;

for (const filePath of requiredFiles) {
  if (!existsFile(filePath)) {
    failures.push(`缺少任务包文件：${filePath}`);
  } else {
    console.log(`文件存在：${filePath}`);
  }
}

const existingContents = requiredFiles.filter(existsFile).map(read);
const combinedContent = existingContents.join('\n');

const requireKeyword = (keyword: string, message: string): void => {
  if (!combinedContent.includes(keyword)) failures.push(message);
};

requireKeyword('v2.0.61', '文档必须包含 v2.0.61。');
requireKeyword('yarn', '文档必须包含 yarn。');
requireKeyword('postgresql', '文档必须包含 postgresql。');
requireKeyword('source_host', '文档必须包含 source_host。');
requireKeyword('packages_plugins', '文档必须包含 packages_plugins。');
requireKeyword('iopgps_real_sync_allowed = false', '文档必须包含 iopgps_real_sync_allowed = false。');
requireKeyword('mock_data_only = true', '文档必须包含 mock_data_only = true。');
requireKeyword('不在当前仓库 clone NocoBase', '文档必须明确不在当前仓库 clone NocoBase。');
requireKeyword('不提交完整 NocoBase 源码', '文档必须明确不提交完整 NocoBase 源码。');
requireKeyword('不使用生产库', '文档必须明确不使用生产库。');
requireKeyword('不启用真实 IOPGPS', '文档必须明确不启用真实 IOPGPS。');
requireKeyword('不复制 `.env`', '文档必须明确不复制 .env。');
requireKeyword('不复制 `filled.json`', '文档必须明确不复制 filled.json。');
requireKeyword('当前不能 production_ready', '文档必须明确当前不能 production_ready。');

console.log('NocoBase v2.0.61 宿主工程接入任务包校验');
console.log('检查范围：只检查本地文档。');
console.log('安全边界：不连接 NocoBase，不安装依赖，不写数据库，不访问外部网络，不读取 .env，不读取 .env.test。');

if (failures.length > 0) {
  console.error('检查未通过：');
  for (const failure of failures) console.error(`- ${failure}`);
  process.exit(1);
}

console.log('检查通过：NocoBase v2.0.61 宿主工程接入任务包完整，且仍保持 mock_data_only 与真实 IOPGPS 禁用边界。');
