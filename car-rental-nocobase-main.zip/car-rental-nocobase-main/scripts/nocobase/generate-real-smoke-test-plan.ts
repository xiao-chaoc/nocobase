declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };
declare const module: any;

import { inspectNocobaseEnvironment, RealSmokeTestAdapter } from '../../packages/shared/nocobase-automation/src';
import type { RealCollectionRegistrationPlan, RealPageRegistrationPlan, RealRuntimeRegistrationPlan, RealSeedDataImportPlan, RealSmokeTestContext } from '../../packages/shared/nocobase-automation/src';

const fs = require('fs');
const path = require('path');

const inputs = [
  ['realCollectionPlan', 'real-collection-registration-plan.generated.json', 'npm run generate:real-collection-plan'],
  ['realRuntimePlan', 'real-runtime-registration-plan.generated.json', 'npm run generate:real-runtime-plan'],
  ['realPagePlan', 'real-page-registration-plan.generated.json', 'npm run generate:real-page-plan'],
  ['realSeedDataPlan', 'real-seed-data-import-plan.generated.json', 'npm run generate:real-seed-data-plan'],
] as const;

export function generateRealSmokeTestPlan(rootDir = process.cwd()) {
  const generatedDir = path.join(rootDir, 'test-data', 'generated');
  const loaded: {
    realCollectionPlan?: RealCollectionRegistrationPlan;
    realRuntimePlan?: RealRuntimeRegistrationPlan;
    realPagePlan?: RealPageRegistrationPlan;
    realSeedDataPlan?: RealSeedDataImportPlan;
  } = {};
  const missing: string[] = [];
  for (const [key, fileName, command] of inputs) {
    const filePath = path.join(generatedDir, fileName);
    if (!fs.existsSync(filePath)) {
      missing.push(`缺少 ${fileName}，请先运行 ${command}。`);
      continue;
    }
    const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    (loaded as any)[key] = parsed.plan ?? parsed;
  }
  if (missing.length > 0) throw new Error(missing.join('\n'));
  const context: RealSmokeTestContext = {
    mode: 'plan_only',
    adapterEnvironment: inspectNocobaseEnvironment({ mode: 'dry_run' }),
    allowRealExecution: false,
    requireBackup: true,
    requireRollbackPlan: true,
    requireIsolatedDatabase: true,
    requireMockDataOnly: true,
    requireIopgpsDisabled: true,
    operator: 'codex-web-draft',
    notes: ['生成真实 Smoke Test 草案，不连接 NocoBase、不写数据库、不执行业务动作、不允许 real 模式。'],
  };
  const adapter = new RealSmokeTestAdapter();
  const plan = adapter.buildRealSmokeTestPlan({ ...loaded, context });
  if (plan.mode === 'real') throw new Error('当前脚本不允许 real 模式。');
  const report = adapter.generateRealSmokeTestReportDraft(plan);
  const output = {
    generated_at: '2026-06-04T00:00:00.000Z',
    draft_only: true,
    real_execution_allowed: false,
    executed: false,
    source: inputs.map(([, fileName]) => fileName),
    plan,
    report,
  };
  const outputPath = path.join(generatedDir, 'real-smoke-test-plan.generated.json');
  fs.writeFileSync(outputPath, `${JSON.stringify(output, null, 2)}\n`, 'utf8');
  return { outputPath, output };
}

if (typeof module !== 'undefined' && module === require.main) {
  try {
    const result = generateRealSmokeTestPlan();
    console.log(`真实 Smoke Test 草案已生成：${result.outputPath}`);
    console.log(`模式：${result.output.plan.mode}，阶段：${result.output.plan.stages.length} 个，步骤：${result.output.plan.steps.length} 个。`);
    console.log('本脚本未连接 NocoBase、未写数据库、未执行业务动作、未调用 IOPGPS、未生成合同文件。');
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}
