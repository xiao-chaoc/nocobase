declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };
declare const module: any;

import { RealSmokeTestAdapter, validateRealSmokeTestPlan } from '../../packages/shared/nocobase-automation/src';
import type { RealSmokeTestPlan } from '../../packages/shared/nocobase-automation/src';

const fs = require('fs');
const path = require('path');

export function validateGeneratedRealSmokeTestPlan(rootDir = process.cwd()) {
  const filePath = path.join(rootDir, 'test-data', 'generated', 'real-smoke-test-plan.generated.json');
  const errors: string[] = [];
  const warnings: string[] = [];
  if (!fs.existsSync(filePath)) return { passed: false, errors: [`缺少真实 Smoke Test 草案文件：${filePath}`], warnings };
  const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
  const plan: RealSmokeTestPlan = parsed.plan;
  const adapter = new RealSmokeTestAdapter();
  const report = adapter.generateRealSmokeTestReportDraft(plan);
  const planValidation = validateRealSmokeTestPlan(plan);
  errors.push(...planValidation.errors, ...report.errors);
  warnings.push(...planValidation.warnings, ...report.warnings);
  if (plan.mode === 'real' || report.mode === 'real') errors.push('真实 Smoke Test 草案不得使用 real 模式。');
  if (parsed.executed || parsed.real_execution_allowed || report.executed) errors.push('真实 Smoke Test 草案不得标记为已执行或允许真实执行。');
  const stages = new Set(plan.stages);
  for (const stage of ['environment_check', 'collection_registration_check', 'runtime_registration_check', 'page_registration_check', 'seed_data_import_check', 'core_business_flow_check', 'permission_check', 'gps_mock_check', 'contract_document_check', 'failure_isolation_check', 'rollback_check']) {
    if (!stages.has(stage as any)) errors.push(`缺少阶段：${stage}`);
    if (!plan.steps.some((step) => step.stage === stage)) errors.push(`缺少阶段步骤：${stage}`);
  }
  const text = JSON.stringify(plan).toLowerCase();
  for (const forbidden of ['booking', 'reservation', 'short_rental_order', 'driver_login', 'customer_portal', 'vehicle_category_rental']) if (text.includes(forbidden)) errors.push(`不允许出现禁用业务：${forbidden}`);
  if (text.includes('gps_rent_calculation') || text.includes('gps 参与租金计算') || text.includes('gps参与租金计算')) errors.push('GPS 不得参与租金计算。');
  if (text.includes('deposit_as_rent_payment') || text.includes('押金计入租金已付') || text.includes('押金作为租金已付')) errors.push('押金不得计入租金已付。');
  for (const forbidden of ['真实密钥', '真实司机资料', '真实付款截图', '真实合同扫描件']) {
    if (text.includes(forbidden) && !text.includes('不允许')) warnings.push(`计划提及 ${forbidden}，请确认仅作为禁止说明。`);
  }
  if (!plan.businessChecks.some((step) => step.title.includes('单日不可超付'))) errors.push('核心业务 smoke test 缺少单日不可超付。');
  if (!plan.businessChecks.some((step) => step.title.includes('付款必须分配到具体日期'))) errors.push('核心业务 smoke test 缺少付款必须分配到具体日期。');
  if (!plan.businessChecks.some((step) => step.title.includes('未来应收不计入当前欠款'))) errors.push('核心业务 smoke test 缺少未来应收不计入当前欠款。');
  if (!plan.permissionChecks.length) errors.push('权限 smoke test 不能为空。');
  if (!plan.steps.some((step) => step.stage === 'gps_mock_check')) errors.push('GPS mock smoke test 不能为空。');
  if (!plan.steps.some((step) => step.stage === 'contract_document_check')) errors.push('合同文件 smoke test 不能为空。');
  if (!plan.failureIsolationChecks.length || !plan.rollbackChecks.length) errors.push('失败隔离和回滚 smoke test 不能为空。');
  const uniqueErrors = [...new Set(errors)];
  return { passed: uniqueErrors.length === 0, errors: uniqueErrors, warnings: [...new Set(warnings)] };
}

if (typeof module !== 'undefined' && module === require.main) {
  const result = validateGeneratedRealSmokeTestPlan();
  for (const warning of result.warnings) console.warn(`警告：${warning}`);
  if (!result.passed) {
    console.error('真实 Smoke Test 草案校验失败：');
    for (const error of result.errors) console.error(`- ${error}`);
    process.exit(1);
  }
  console.log('真实 Smoke Test 草案校验通过：plan_only、未真实执行、阶段完整、步骤完整、核心业务、权限、GPS mock、合同文件、失败隔离、回滚和业务边界均符合要求。');
}
