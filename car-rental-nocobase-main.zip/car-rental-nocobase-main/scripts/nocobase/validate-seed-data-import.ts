declare const require: any;
declare const process: { exit(code?: number): never };

const fs = require('fs');
const path = require('path');
import {
  validateDepositBusinessRules,
  validateGpsMockRules,
  validateNoSensitiveRealData,
  validatePaymentAllocationBusinessRules,
  validateRentLedgerBusinessRules,
  validateSeedDataImportPlan,
  type SeedDataImportPlan,
  type SeedDataImportResult,
} from '../../packages/shared/nocobase-automation/src';

const inputPath = path.resolve('test-data/generated/seed-data-import-dry-run.generated.json');
if (!fs.existsSync(inputPath)) {
  console.error('缺少测试数据导入 dry-run 结果，请先运行：npm run dry-run:import-test-data');
  process.exit(1);
}

const parsed = JSON.parse(fs.readFileSync(inputPath, 'utf8')) as { importPlan: SeedDataImportPlan; result: SeedDataImportResult };
const errors: string[] = [];
if (!parsed.result?.success) {
  errors.push('测试数据导入 dry-run 结果不是 success。');
  errors.push(...(parsed.result?.errors ?? []));
}
const planValidation = validateSeedDataImportPlan(parsed.importPlan);
if (!planValidation.passed) errors.push(...planValidation.errors);
for (const entityType of parsed.importPlan.importOrder) {
  if (!parsed.result.entityResults.some((item) => item.entityType === entityType)) errors.push(`核心实体未处理：${entityType}`);
}
const serialized = JSON.stringify(parsed).toLowerCase();
for (const forbidden of ['booking', 'reservation', 'short_rental_orders', 'driver_login', 'vehicle_category_rental']) {
  if (serialized.includes(forbidden)) errors.push(`导入结果中出现禁止对象或逻辑：${forbidden}`);
}
for (const phrase of ['gps_rent_calculation', 'deposit_as_rent_payment', '真实 access_token', '真实 login_key', '单日超付']) {
  if (serialized.includes(phrase)) errors.push(`导入结果中出现禁止风险：${phrase}`);
}
if (!parsed.result.summary.canEnterSmokeTest) errors.push('导入 dry-run 结果尚不可进入 smoke test。');

if (errors.length > 0) {
  console.error('测试数据导入 dry-run 结果校验失败：');
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log('测试数据导入 dry-run 结果校验通过：核心实体、引用、唯一键、敏感数据、台账、付款、押金和 GPS mock 边界均符合计划。');
