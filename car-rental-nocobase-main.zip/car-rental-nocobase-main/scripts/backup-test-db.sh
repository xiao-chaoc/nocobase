#!/usr/bin/env bash
set -euo pipefail

# 测试环境数据库备份脚本草案，不是生产备份方案。
# 使用条件：在包含 docker-compose.test.yml 和 .env.test 的测试运行目录执行。
# 安全提示：不要把 backups-test/*.dump 提交到 Git，不要用于生产环境。

COMPOSE_FILE="${COMPOSE_FILE:-docker-compose.test.yml}"
ENV_FILE="${ENV_FILE:-.env.test}"
BACKUP_DIR="${BACKUP_DIR:-backups-test}"

if [[ ! -f "$COMPOSE_FILE" ]]; then
  echo "未找到 $COMPOSE_FILE，请在 NAS 测试运行目录执行。" >&2
  exit 1
fi

if [[ ! -f "$ENV_FILE" ]]; then
  echo "未找到 $ENV_FILE。请先从 .env.test.example 复制并填写测试占位值。" >&2
  exit 1
fi

set -a
# shellcheck disable=SC1090
source "$ENV_FILE"
set +a

: "${DB_DATABASE:?缺少 DB_DATABASE}"
: "${DB_USER:?缺少 DB_USER}"

mkdir -p "$BACKUP_DIR"
BACKUP_FILE="$BACKUP_DIR/nocobase-test-${DB_DATABASE}-$(date +%Y%m%d-%H%M%S).dump"

echo "准备备份测试数据库：$DB_DATABASE"
echo "备份文件：$BACKUP_FILE"
echo "注意：本脚本只用于测试环境，不要把备份文件提交到 Git。"

docker compose -f "$COMPOSE_FILE" --env-file "$ENV_FILE" exec -T postgres \
  pg_dump -U "$DB_USER" -d "$DB_DATABASE" -Fc > "$BACKUP_FILE"

echo "测试数据库备份完成：$BACKUP_FILE"
