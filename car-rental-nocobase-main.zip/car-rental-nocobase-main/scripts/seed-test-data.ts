declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };
declare const module: any;

import type { Weekday } from '../packages/plugins/plugin-rental-core/src/server/types/commonTypes';
import type { RentDailyLedger } from '../packages/plugins/plugin-rental-core/src/server/types/ledgerTypes';
import { calculateFixedTermEndDate } from '../packages/plugins/plugin-rental-core/src/server/services/dateBillingUtils';
import { generateFixedTermDailyLedgerPreview, generateOpenEndedDailyLedgerPreview, summarizeLedgerPreview } from '../packages/plugins/plugin-rental-core/src/server/services/ledgerGenerationService';
import { TEST_DATA_NOW, TEST_DATA_TODAY, addDays, ensureDir, getTestDataPaths, readFixture, writeGenerated } from './test-data-common';

interface DriverFixture { driver_no: string; name: string; phone: string; id_no: string; license_no: string; [key: string]: unknown }
interface VehicleFixture { vehicle_no: string; plate_no: string; [key: string]: unknown }
interface GpsDeviceFixture { imei: string; vehicle_no: string; device_status: string; [key: string]: unknown }
interface RateScenario { scenario_no: string; weekly_payable_days: 3 | 4 | 5 | 6 | 7; default_free_weekdays: Weekday[]; daily_rent_amount: number }
interface ContractTemplateFixture { template_id: string; language: 'zh-CN' | 'en-US' | 'fr-FR'; [key: string]: unknown }
interface SeedOptions { rootDir?: string }

function withId<T extends Record<string, unknown>>(items: T[], prefix: string): T[] {
  return items.map((item, index) => ({ [`${prefix}_id`]: `TEST-${prefix.toUpperCase()}-${String(index + 1).padStart(4, '0')}`, ...item } as T));
}

function ledgerContract(contract: any) {
  return {
    contract_id: contract.contract_id,
    driver_id: contract.driver_id,
    vehicle_id: contract.vehicle_id,
    contract_type: contract.contract_type,
    start_date: contract.start_date,
    term_months: contract.term_months ?? undefined,
    calculated_end_date: contract.calculated_end_date,
    termination_date: contract.termination_date,
    weekly_payable_days: contract.weekly_payable_days,
    default_free_weekdays: contract.default_free_weekdays,
    daily_rent_amount: contract.daily_rent_amount,
    week_start_day: contract.week_start_day,
  };
}

function setLedgerState(ledger: RentDailyLedger, state: string): RentDailyLedger {
  const next: RentDailyLedger = { ...ledger };
  if (!next.is_payable) return next;
  if (state === 'paid') {
    next.paid_amount = next.due_amount;
    next.waived_amount = 0;
    next.balance_amount = 0;
    next.payment_status = 'paid';
    next.calendar_status = 'paid';
    next.unpaid_reason = 'none';
    next.shortfall_disposition = 'none';
  } else if (state === 'partial_debt') {
    next.paid_amount = Math.floor(next.due_amount / 2);
    next.waived_amount = 0;
    next.balance_amount = next.due_amount - next.paid_amount;
    next.payment_status = 'partial';
    next.calendar_status = 'partial_debt';
    next.unpaid_reason = 'driver_promised_to_pay';
    next.shortfall_disposition = 'debt';
  } else if (state === 'waived') {
    next.paid_amount = 0;
    next.waived_amount = next.due_amount;
    next.balance_amount = 0;
    next.payment_status = 'waived';
    next.calendar_status = 'waived';
    next.unpaid_reason = 'pending_waiver_approval';
    next.shortfall_disposition = 'waived';
  } else if (state === 'partial_waived') {
    next.paid_amount = Math.floor(next.due_amount / 2);
    next.waived_amount = next.due_amount - next.paid_amount;
    next.balance_amount = 0;
    next.payment_status = 'waived';
    next.calendar_status = 'partial_waived';
    next.unpaid_reason = 'pending_waiver_approval';
    next.shortfall_disposition = 'waived';
  } else if (state === 'dispute') {
    next.paid_amount = 0;
    next.waived_amount = 0;
    next.balance_amount = next.due_amount;
    next.payment_status = 'unpaid';
    next.calendar_status = 'dispute';
    next.unpaid_reason = 'dispute';
    next.shortfall_disposition = 'dispute';
  } else if (state === 'cancelled') {
    next.paid_amount = 0;
    next.waived_amount = 0;
    next.balance_amount = 0;
    next.due_amount = 0;
    next.payment_status = 'cancelled';
    next.calendar_status = 'cancelled';
    next.unpaid_reason = 'none';
    next.non_payable_reason = 'cancelled';
    next.is_payable = false;
    next.status = 'cancelled';
  }
  return next;
}

function firstPayable(ledgers: RentDailyLedger[], contractId: string, offset = 0): RentDailyLedger {
  const list = ledgers.filter((ledger) => ledger.contract_id === contractId && ledger.is_payable && ledger.rent_date <= TEST_DATA_TODAY);
  return list[offset];
}

function buildPaymentsAndAllocations(ledgers: RentDailyLedger[]) {
  const paymentSpecs = [
    { payment_no: 'TEST-PAY-0001', contract_id: 'TEST-CONTRACT-0001', ledgerOffsets: [0], status: 'confirmed', screenshot: 'TEST_PAYMENT_SCREENSHOT_001' },
    { payment_no: 'TEST-PAY-0002', contract_id: 'TEST-CONTRACT-0001', ledgerOffsets: [1, 2], status: 'confirmed', screenshot: 'TEST_PAYMENT_SCREENSHOT_002' },
    { payment_no: 'TEST-PAY-0003', contract_id: 'TEST-CONTRACT-0002', ledgerOffsets: [0], status: 'confirmed', partial: true, screenshot: 'TEST_PAYMENT_SCREENSHOT_003' },
    { payment_no: 'TEST-PAY-0004', contract_id: 'TEST-CONTRACT-0003', ledgerOffsets: [0], status: 'confirmed', partialWaiver: true, screenshot: 'TEST_PAYMENT_SCREENSHOT_004' },
    { payment_no: 'TEST-PAY-0005', contract_id: 'TEST-CONTRACT-0001', ledgerOffsets: [3], status: 'reversed', screenshot: 'TEST_PAYMENT_SCREENSHOT_005' },
  ];
  const payments: any[] = [];
  const allocations: any[] = [];
  for (const [index, spec] of paymentSpecs.entries()) {
    const targetLedgers = spec.ledgerOffsets.map((offset) => firstPayable(ledgers, spec.contract_id, offset));
    const amount = targetLedgers.reduce((sum, ledger) => sum + (spec.partial || spec.partialWaiver ? Math.floor(ledger.due_amount / 2) : ledger.due_amount), 0);
    const payment_id = `TEST-PAYMENT-${String(index + 1).padStart(4, '0')}`;
    payments.push({
      payment_id,
      payment_no: spec.payment_no,
      contract_id: spec.contract_id,
      driver_id: targetLedgers[0].driver_id,
      vehicle_id: targetLedgers[0].vehicle_id,
      paid_amount: amount,
      payment_method: 'test_manual_transfer',
      payment_screenshot: spec.screenshot,
      status: spec.status,
      paid_at: `2026-06-${String(1 + index).padStart(2, '0')}T09:00:00.000Z`,
      confirmed_at: `2026-06-${String(1 + index).padStart(2, '0')}T10:00:00.000Z`,
      reversed_at: spec.status === 'reversed' ? '2026-06-10T10:00:00.000Z' : null,
      remark: 'TEST_PAYMENT_ONLY',
    });
    for (const [allocationIndex, ledger] of targetLedgers.entries()) {
      allocations.push({
        allocation_id: `TEST-ALLOC-${String(allocations.length + 1).padStart(4, '0')}`,
        payment_id,
        ledger_id: ledger.ledger_id,
        contract_id: ledger.contract_id,
        rent_date: ledger.rent_date,
        allocated_amount: spec.partial || spec.partialWaiver ? Math.floor(ledger.due_amount / 2) : ledger.due_amount,
        status: spec.status === 'reversed' ? 'reversed' : 'confirmed',
        remark: allocationIndex === 0 ? 'TEST_ALLOCATION_PRIMARY' : 'TEST_ALLOCATION_MULTI_DAY',
      });
    }
  }
  return { payments, allocations };
}

export function seedTestData(options: SeedOptions = {}): string[] {
  const rootDir = options.rootDir ?? process.cwd();
  const paths = getTestDataPaths(rootDir);
  ensureDir(paths.generatedDir);

  const drivers = withId(readFixture<DriverFixture[]>('drivers.json', rootDir), 'driver');
  const vehicles = withId(readFixture<VehicleFixture[]>('vehicles.json', rootDir), 'vehicle');
  const gpsDevices = withId(readFixture<GpsDeviceFixture[]>('gps-devices.json', rootDir), 'device');
  const rates = readFixture<RateScenario[]>('rental-rate-scenarios.json', rootDir);
  const templates = readFixture<ContractTemplateFixture[]>('contract-templates.json', rootDir);
  const company = readFixture<Record<string, unknown>>('company-profile.json', rootDir);

  const contracts = [
    { contract_id: 'TEST-CONTRACT-0001', contract_no: 'TEST-CTR-20260101-0001', contract_type: 'fixed_term', driver_id: 'TEST-DRIVER-0001', vehicle_id: 'TEST-VEHICLE-0001', start_date: '2026-01-01', term_months: 6, rate: rates[2], deposit_required_amount: 1000, deposit_received_amount: 1000 },
    { contract_id: 'TEST-CONTRACT-0002', contract_no: 'TEST-CTR-20260201-0002', contract_type: 'fixed_term', driver_id: 'TEST-DRIVER-0002', vehicle_id: 'TEST-VEHICLE-0002', start_date: '2026-02-01', term_months: 9, rate: rates[3], deposit_required_amount: 1200, deposit_received_amount: 600 },
    { contract_id: 'TEST-CONTRACT-0003', contract_no: 'TEST-CTR-20260301-0003', contract_type: 'fixed_term', driver_id: 'TEST-DRIVER-0003', vehicle_id: 'TEST-VEHICLE-0003', start_date: '2026-03-01', term_months: 12, rate: rates[4], deposit_required_amount: 1500, deposit_received_amount: 1500 },
    { contract_id: 'TEST-CONTRACT-0004', contract_no: 'TEST-CTR-20260401-0004', contract_type: 'open_ended', driver_id: 'TEST-DRIVER-0004', vehicle_id: 'TEST-VEHICLE-0004', start_date: '2026-04-01', term_months: null, rate: rates[2], deposit_required_amount: 1000, deposit_received_amount: 800 },
    { contract_id: 'TEST-CONTRACT-0005', contract_no: 'TEST-CTR-20260501-0005', contract_type: 'open_ended', driver_id: 'TEST-DRIVER-0005', vehicle_id: 'TEST-VEHICLE-0005', start_date: '2026-05-01', term_months: null, rate: rates[0], deposit_required_amount: 900, deposit_received_amount: 0 },
  ].map((contract: any) => ({
    contract_id: contract.contract_id,
    contract_no: contract.contract_no,
    contract_type: contract.contract_type,
    driver_id: contract.driver_id,
    vehicle_id: contract.vehicle_id,
    start_date: contract.start_date,
    term_months: contract.term_months,
    calculated_end_date: contract.contract_type === 'fixed_term' ? calculateFixedTermEndDate(contract.start_date, contract.term_months) : null,
    termination_date: null,
    weekly_payable_days: contract.rate.weekly_payable_days,
    default_free_weekdays: contract.rate.default_free_weekdays,
    daily_rent_amount: contract.rate.daily_rent_amount,
    deposit_required_amount: contract.deposit_required_amount,
    deposit_received_amount: contract.deposit_received_amount,
    week_start_day: 'monday',
    ledger_generate_until: contract.contract_type === 'open_ended' ? addDays(contract.start_date, 90) : calculateFixedTermEndDate(contract.start_date, contract.term_months),
    status: 'active',
    remark: 'TEST_CONTRACT_NO_SHORT_RENTAL',
  }));

  const billingWeeks: any[] = [];
  let ledgers: RentDailyLedger[] = [];
  for (const contract of contracts) {
    const preview = contract.contract_type === 'fixed_term'
      ? generateFixedTermDailyLedgerPreview(ledgerContract(contract), TEST_DATA_TODAY)
      : generateOpenEndedDailyLedgerPreview(ledgerContract(contract), contract.start_date, 90, TEST_DATA_TODAY);
    ledgers.push(...preview.ledgers);
    billingWeeks.push({
      billing_week_id: `TEST-BILLING-WEEK-${String(billingWeeks.length + 1).padStart(4, '0')}`,
      contract_id: contract.contract_id,
      week_start_day: contract.week_start_day,
      weekly_payable_days: contract.weekly_payable_days,
      default_free_weekdays: contract.default_free_weekdays,
      daily_rent_amount: contract.daily_rent_amount,
      summary: preview.summary,
      remark: 'TEST_BILLING_RULE_SNAPSHOT',
    });
  }

  const payableForState = ledgers.filter((ledger) => ledger.is_payable && ledger.rent_date <= TEST_DATA_TODAY);
  const stateMap = new Map<string, string>([
    [String(payableForState[0].ledger_id), 'paid'],
    [String(payableForState[1].ledger_id), 'paid'],
    [String(payableForState[2].ledger_id), 'partial_debt'],
    [String(payableForState[3].ledger_id), 'waived'],
    [String(payableForState[4].ledger_id), 'partial_waived'],
    [String(payableForState[5].ledger_id), 'dispute'],
    [String(payableForState[6].ledger_id), 'cancelled'],
  ]);
  ledgers = ledgers.map((ledger) => setLedgerState(ledger, stateMap.get(String(ledger.ledger_id)) ?? 'default'));
  const ledgerSummary = summarizeLedgerPreview(ledgers, TEST_DATA_TODAY);
  const { payments, allocations } = buildPaymentsAndAllocations(ledgers);

  const deposits = [
    { deposit_id: 'TEST-DEPOSIT-0001', contract_id: 'TEST-CONTRACT-0001', required_amount: 1000, received_amount: 1000, deducted_amount: 0, refunded_amount: 0, waived_amount: 0, available_amount: 1000, status: 'held', proof_file: 'TEST_DEPOSIT_SCREENSHOT_001' },
    { deposit_id: 'TEST-DEPOSIT-0002', contract_id: 'TEST-CONTRACT-0002', required_amount: 1200, received_amount: 600, deducted_amount: 0, refunded_amount: 0, waived_amount: 0, available_amount: 600, status: 'collected', proof_file: 'TEST_DEPOSIT_SCREENSHOT_002' },
    { deposit_id: 'TEST-DEPOSIT-0003', contract_id: 'TEST-CONTRACT-0003', required_amount: 1500, received_amount: 1500, deducted_amount: 300, refunded_amount: 0, waived_amount: 0, available_amount: 1200, status: 'partially_deducted', proof_file: 'TEST_DEPOSIT_SCREENSHOT_003' },
    { deposit_id: 'TEST-DEPOSIT-0004', contract_id: 'TEST-CONTRACT-0004', required_amount: 1000, received_amount: 800, deducted_amount: 0, refunded_amount: 200, waived_amount: 0, available_amount: 600, status: 'partially_refunded', proof_file: 'TEST_DEPOSIT_SCREENSHOT_004', refund_proof_file: 'TEST_DEPOSIT_REFUND_PROOF_001' },
    { deposit_id: 'TEST-DEPOSIT-0005', contract_id: 'TEST-CONTRACT-0005', required_amount: 900, received_amount: 0, deducted_amount: 0, refunded_amount: 0, waived_amount: 900, available_amount: 0, status: 'waived', proof_file: null },
  ];

  const gpsSnapshots = gpsDevices.slice(0, 8).map((device: any, index) => ({
    snapshot_id: `TEST-GPS-SNAPSHOT-${String(index + 1).padStart(4, '0')}`,
    vehicle_id: `TEST-VEHICLE-${String(index + 1).padStart(4, '0')}`,
    device_id: device.device_id,
    imei: device.imei,
    lat: 0.01 * (index + 1),
    lng: 0.02 * (index + 1),
    address: `TEST-GPS-ADDRESS-${String(index + 1).padStart(4, '0')}`,
    speed: index === 0 ? 30 : 0,
    acc_status: index === 0 ? 'on' : 'off',
    position_type: 'test_mock',
    gps_status: ['normal', 'normal', 'offline', 'fault', 'normal', 'low_power', 'power_cut', 'unknown'][index],
    gps_time: `2026-06-${String(10 + index).padStart(2, '0')}T08:00:00.000Z`,
    raw_response: { test: true, imei: device.imei },
    created_at: TEST_DATA_NOW,
  }));

  const gpsMileages = gpsDevices.slice(0, 8).map((device: any, index) => ({
    mileage_id: `TEST-GPS-MILEAGE-${String(index + 1).padStart(4, '0')}`,
    vehicle_id: `TEST-VEHICLE-${String(index + 1).padStart(4, '0')}`,
    device_id: device.device_id,
    imei: device.imei,
    mileage_date: '2026-06-14',
    start_time: '2026-06-14T00:00:00.000Z',
    end_time: '2026-06-14T23:59:59.000Z',
    mileage_km: 10 + index,
    runtime_seconds: 3600 + index * 60,
    contract_id: contracts[index % contracts.length].contract_id,
    driver_id: contracts[index % contracts.length].driver_id,
    raw_response: { test: true, source: 'mock' },
    sync_status: 'success',
    error_message: null,
    remark: 'GPS 里程只用于运营核查，不参与租金计算。',
  }));

  const contractDocuments = contracts.flatMap((contract: any, contractIndex: number) => templates.map((template, templateIndex) => {
    const status = ['generated', 'printed', 'signed', 'scanned', 'voided'][(contractIndex + templateIndex) % 5];
    return {
      document_id: `TEST-DOC-${String(contractIndex + 1).padStart(2, '0')}-${template.language}`,
      document_no: `TEST-DOC-NO-${String(contractIndex + 1).padStart(2, '0')}-${template.language}`,
      contract_id: contract.contract_id,
      template_id: template.template_id,
      language: template.language,
      generated_docx_file: `TEST_CONTRACT_${template.language}_DOCX_PLACEHOLDER`,
      generated_pdf_file: `TEST_CONTRACT_${template.language}_PDF_PLACEHOLDER`,
      printed_at: ['printed', 'signed', 'scanned'].includes(status) ? TEST_DATA_NOW : null,
      signed_at: ['signed', 'scanned'].includes(status) ? TEST_DATA_NOW : null,
      signed_scan_file: status === 'scanned' ? `TEST_SIGNED_SCAN_${template.language}_PLACEHOLDER` : null,
      status,
      voided_at: status === 'voided' ? TEST_DATA_NOW : null,
      voided_reason: status === 'voided' ? 'TEST_VOID_REASON' : null,
      created_at: TEST_DATA_NOW,
      updated_at: TEST_DATA_NOW,
      remark: 'TEST_CONTRACT_DOCUMENT_NO_REAL_FILE',
    };
  }));

  const operationActions = ['contract_created', 'contract_activated', 'ledger_generated', 'payment_created', 'payment_confirmed', 'payment_reversed', 'unpaid_reason_changed', 'waiver_requested', 'waiver_approved', 'deposit_created', 'deposit_deducted', 'deposit_refunded', 'gps_sync_failed', 'contract_document_generated', 'contract_document_scanned'];
  const operationLogs = operationActions.map((action, index) => ({
    log_id: `TEST-OPLOG-${String(index + 1).padStart(4, '0')}`,
    action,
    operator_id: 'TEST-OPERATOR-0001',
    target_collection: action.startsWith('gps') ? 'gps_devices' : action.startsWith('contract_document') ? 'contract_documents' : 'lease_contracts',
    target_id: `TEST-TARGET-${String(index + 1).padStart(4, '0')}`,
    reason: 'TEST_OPERATION_REASON',
    before: { id_no: '[已隐藏]', payment_screenshot: '[已隐藏]', masked_secret: '[已隐藏]' },
    after: { credential_placeholder: '[已隐藏]', signed_scan_file: '[已隐藏]' },
    occurred_at: TEST_DATA_NOW,
    remark: 'TEST_OPERATION_LOG_MASKED',
  }));

  const outputs: Record<string, unknown> = {
    'drivers.generated.json': drivers,
    'vehicles.generated.json': vehicles,
    'gps-devices.generated.json': gpsDevices,
    'lease-contracts.generated.json': contracts,
    'contract-billing-weeks.generated.json': billingWeeks,
    'rent-daily-ledgers.generated.json': ledgers,
    'rent-payments.generated.json': payments,
    'rent-payment-allocations.generated.json': allocations,
    'deposit-records.generated.json': deposits,
    'gps-location-snapshots.generated.json': gpsSnapshots,
    'gps-daily-mileages.generated.json': gpsMileages,
    'contract-documents.generated.json': contractDocuments,
    'operation-logs.generated.json': operationLogs,
    'generation-summary.generated.json': { generated_at: TEST_DATA_NOW, today: TEST_DATA_TODAY, ledger_summary: ledgerSummary, company_profile: company.company_no },
  };
  for (const [fileName, value] of Object.entries(outputs)) writeGenerated(fileName, value, rootDir);
  return Object.keys(outputs).sort();
}

if (typeof module !== 'undefined' && module === require.main) {
  const files = seedTestData();
  console.log(`已生成测试数据文件：${files.join(', ')}`);
}
