declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };
declare const module: any;

import { compareDate, failCli, listGeneratedJsonFiles, readGenerated } from './test-data-common';

interface ValidationResult { passed: boolean; errors: string[] }
interface ValidateOptions { rootDir?: string }

function uniqueBy(items: any[], field: string, errors: string[], label: string): void {
  const seen = new Set<string>();
  for (const item of items) {
    const value = item[field];
    if (!value) errors.push(`${label} 缺少 ${field}`);
    if (seen.has(value)) errors.push(`${label} ${field} 重复：${value}`);
    seen.add(value);
  }
}

function containsForbiddenText(value: unknown): boolean {
  const text = JSON.stringify(value).toLowerCase();
  return text.includes('booking') || text.includes('reservation') || text.includes('short_rental_orders') || text.includes('short-rental');
}

function containsRealFileUrl(value: unknown): boolean {
  const text = JSON.stringify(value).toLowerCase();
  return text.includes('http://') || text.includes('https://') || text.includes('/uploads/') || text.includes('file://');
}

function containsSensitiveLeak(value: unknown): boolean {
  const text = JSON.stringify(value).toLowerCase();
  if (text.includes('access_token')) return true;
  if (text.includes('login_key')) return true;
  return /\b[0-9]{15,18}\b/.test(text);
}

export function validateTestData(options: ValidateOptions = {}): ValidationResult {
  const rootDir = options.rootDir ?? process.cwd();
  const errors: string[] = [];
  const requiredFiles = [
    'drivers.generated.json',
    'vehicles.generated.json',
    'gps-devices.generated.json',
    'lease-contracts.generated.json',
    'contract-billing-weeks.generated.json',
    'rent-daily-ledgers.generated.json',
    'rent-payments.generated.json',
    'rent-payment-allocations.generated.json',
    'deposit-records.generated.json',
    'gps-location-snapshots.generated.json',
    'gps-daily-mileages.generated.json',
    'contract-documents.generated.json',
    'operation-logs.generated.json',
  ];
  const files = listGeneratedJsonFiles(rootDir);
  for (const fileName of requiredFiles) if (!files.includes(fileName)) errors.push(`缺少生成文件：${fileName}`);
  if (errors.length > 0) return { passed: false, errors };

  const drivers = readGenerated<any[]>('drivers.generated.json', rootDir);
  const vehicles = readGenerated<any[]>('vehicles.generated.json', rootDir);
  const contracts = readGenerated<any[]>('lease-contracts.generated.json', rootDir);
  const ledgers = readGenerated<any[]>('rent-daily-ledgers.generated.json', rootDir);
  const payments = readGenerated<any[]>('rent-payments.generated.json', rootDir);
  const allocations = readGenerated<any[]>('rent-payment-allocations.generated.json', rootDir);
  const deposits = readGenerated<any[]>('deposit-records.generated.json', rootDir);
  const gpsMileages = readGenerated<any[]>('gps-daily-mileages.generated.json', rootDir);
  const contractDocuments = readGenerated<any[]>('contract-documents.generated.json', rootDir);
  const operationLogs = readGenerated<any[]>('operation-logs.generated.json', rootDir);

  uniqueBy(drivers, 'driver_no', errors, 'drivers');
  uniqueBy(vehicles, 'vehicle_no', errors, 'vehicles');
  uniqueBy(vehicles, 'plate_no', errors, 'vehicles');
  uniqueBy(contracts, 'contract_no', errors, 'contracts');

  for (let i = 0; i < contracts.length; i += 1) {
    for (let j = i + 1; j < contracts.length; j += 1) {
      const a = contracts[i];
      const b = contracts[j];
      if (a.vehicle_id !== b.vehicle_id) continue;
      const aEnd = a.calculated_end_date ?? a.termination_date ?? '9999-12-31';
      const bEnd = b.calculated_end_date ?? b.termination_date ?? '9999-12-31';
      if (compareDate(a.start_date, bEnd) <= 0 && compareDate(b.start_date, aEnd) <= 0) {
        errors.push(`同一车辆存在冲突合同：${a.contract_no} / ${b.contract_no}`);
      }
    }
  }

  const ledgerById = new Map<string, any>();
  const ledgerDateKeys = new Set<string>();
  for (const ledger of ledgers) {
    ledgerById.set(ledger.ledger_id, ledger);
    const key = `${ledger.contract_id}:${ledger.rent_date}`;
    if (ledgerDateKeys.has(key)) errors.push(`每日台账 contract_id + rent_date 重复：${key}`);
    ledgerDateKeys.add(key);
    if (!ledger.is_payable && ledger.due_amount !== 0) errors.push(`免租或取消日 due_amount 必须为 0：${ledger.ledger_id}`);
    if (ledger.is_payable && ledger.due_amount <= 0) errors.push(`应收日 due_amount 必须大于 0：${ledger.ledger_id}`);
  }

  const allocatedByLedger = new Map<string, number>();
  for (const allocation of allocations) {
    const ledger = ledgerById.get(allocation.ledger_id);
    if (!ledger) {
      errors.push(`付款分配指向不存在的台账：${allocation.allocation_id}`);
      continue;
    }
    const nextAmount = (allocatedByLedger.get(allocation.ledger_id) ?? 0) + allocation.allocated_amount;
    allocatedByLedger.set(allocation.ledger_id, nextAmount);
    if (nextAmount > ledger.due_amount) errors.push(`付款分配导致单日超付：${allocation.ledger_id}`);
  }
  for (const payment of payments) {
    const sum = allocations.filter((allocation) => allocation.payment_id === payment.payment_id).reduce((total, allocation) => total + allocation.allocated_amount, 0);
    if (sum !== payment.paid_amount) errors.push(`付款金额与分配合计不一致：${payment.payment_no}`);
    if (containsRealFileUrl(payment.payment_screenshot)) errors.push(`付款截图不能是真实 URL：${payment.payment_no}`);
  }

  const totalPaid = ledgers.reduce((sum, ledger) => sum + ledger.paid_amount, 0);
  const depositReceived = deposits.reduce((sum, deposit) => sum + deposit.received_amount, 0);
  if (totalPaid + depositReceived === totalPaid) errors.push('押金数据未覆盖实收场景。');
  for (const deposit of deposits) {
    if (deposit.received_amount > deposit.required_amount) errors.push(`押金实收不能超过应收：${deposit.deposit_id}`);
    if (containsRealFileUrl(deposit)) errors.push(`押金文件字段不能是真实 URL：${deposit.deposit_id}`);
  }

  const mileageKeys = new Set<string>();
  for (const mileage of gpsMileages) {
    const key = `${mileage.device_id}:${mileage.mileage_date}`;
    if (mileageKeys.has(key)) errors.push(`gps_daily_mileages device_id + mileage_date 重复：${key}`);
    mileageKeys.add(key);
    if (mileage.remark && !String(mileage.remark).includes('不参与租金计算')) errors.push(`GPS 里程备注需要说明不参与租金计算：${mileage.mileage_id}`);
  }

  if (containsRealFileUrl(contractDocuments)) errors.push('contract documents 不能包含真实文件 URL。');
  if (containsSensitiveLeak(operationLogs)) errors.push('operation logs 不能泄露 access_token、login_key 或真实证件号。');

  const allGenerated = { drivers, vehicles, contracts, ledgers, payments, allocations, deposits, gpsMileages, contractDocuments, operationLogs };
  if (containsForbiddenText(allGenerated)) errors.push('生成数据中不得包含 booking、reservation、short_rental_orders 等短租数据。');

  return { passed: errors.length === 0, errors };
}

if (typeof module !== 'undefined' && module === require.main) {
  const result = validateTestData();
  if (!result.passed) {
    console.error('测试数据校验失败：');
    failCli(result.errors);
  }
  console.log('测试数据校验通过。');
}
