#!/usr/bin/env bash
set -euo pipefail

EXECUTE=false
for arg in "$@"; do
  if [ "$arg" = "--execute" ]; then
    EXECUTE=true
  fi
done

echo "NocoBase 宿主工程工作区准备脚本（默认 dry-run）。"
echo "本脚本只检查变量并打印建议命令；不会默认 clone NocoBase、不会安装依赖、不会写入宿主工程。"

if [ -z "${NOCOBASE_HOST_DIR:-}" ]; then
  echo "错误：未设置 NOCOBASE_HOST_DIR。"
  exit 1
fi

if [ -z "${CURRENT_PROJECT_DIR:-}" ]; then
  echo "错误：未设置 CURRENT_PROJECT_DIR。"
  exit 1
fi

if [ -z "${NOCOBASE_TARGET_VERSION:-}" ]; then
  echo "错误：未设置 NOCOBASE_TARGET_VERSION。目标版本必须人工确认后才能准备宿主工程。"
  exit 1
fi

echo "当前项目目录：${CURRENT_PROJECT_DIR}"
echo "宿主工程目录：${NOCOBASE_HOST_DIR}"
echo "目标版本：${NOCOBASE_TARGET_VERSION}"

echo "建议人工执行的步骤如下："
echo "1. 在当前仓库外部准备完整 NocoBase 源码。"
echo "2. 在宿主工程中切换到目标版本：${NOCOBASE_TARGET_VERSION}。"
echo "3. 使用隔离测试数据库和测试 storage。"
echo "4. 禁用真实 IOPGPS 同步。"
echo "5. 再运行 dry-run 校验脚本。"

echo "提醒：不要在当前仓库提交完整 NocoBase 源码，不要提交 .env 或真实密钥。"

if [ "$EXECUTE" = "true" ]; then
  if [ "${CONFIRM_NOCOBASE_HOST_BOOTSTRAP_EXECUTE:-}" != "yes" ]; then
    echo "错误：即使传入 --execute，也必须设置 CONFIRM_NOCOBASE_HOST_BOOTSTRAP_EXECUTE=yes。"
    exit 1
  fi
  echo "已进入显式执行模式，但本轮脚本草案不执行真实写入，仅输出计划。"
else
  echo "dry-run 模式：未执行任何真实写入。"
fi
