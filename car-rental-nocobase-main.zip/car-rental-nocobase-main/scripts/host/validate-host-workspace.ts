declare const require: any;
declare const process: { env: Record<string, string | undefined>; cwd(): string; argv: string[]; exit(code?: number): never };

const { existsSync, statSync } = require('fs');
const path = require('path');

const failures: string[] = [];
const execute = process.argv.includes('--execute');
const hostDir = process.env.NOCOBASE_HOST_DIR;
const projectDir = process.env.CURRENT_PROJECT_DIR || process.cwd();
const targetVersion = process.env.NOCOBASE_TARGET_VERSION;

console.log('NocoBase 宿主工作区校验（默认 dry-run）。');
console.log('本脚本不读取 .env.test 真实值，不安装依赖，不默认写入宿主工程。');

if (!hostDir) failures.push('未设置 NOCOBASE_HOST_DIR。');
if (!targetVersion) failures.push('未设置 NOCOBASE_TARGET_VERSION，目标版本必须人工确认。');

if (hostDir) {
  if (!existsSync(path.join(hostDir, 'package.json'))) failures.push('宿主工程缺少 package.json。');
  if (!existsSync(path.join(hostDir, 'packages')) && !existsSync(path.join(hostDir, 'storage', 'plugins'))) failures.push('宿主工程缺少 packages 或 storage/plugins。');
  const relative = path.relative(projectDir, hostDir);
  if (relative && !relative.startsWith('..') && !path.isAbsolute(relative)) {
    failures.push('检测到宿主工程可能位于当前仓库内部，禁止把完整 NocoBase 源码放入当前仓库。');
  }
}

for (const pluginName of ['plugin-rental-core', 'plugin-contract-documents', 'plugin-iopgps']) {
  const pluginDir = path.join(projectDir, 'packages', 'plugins', pluginName);
  if (!existsSync(pluginDir) || !statSync(pluginDir).isDirectory()) {
    failures.push(`当前项目插件目录不存在：${pluginName}`);
  }
  if (existsSync(path.join(pluginDir, '.env')) || existsSync(path.join(pluginDir, '.env.test'))) {
    failures.push(`插件目录包含禁止复制的环境文件：${pluginName}`);
  }
}

const sharedDir = path.join(projectDir, 'packages', 'shared', 'nocobase-automation');
if (!existsSync(sharedDir) || !statSync(sharedDir).isDirectory()) {
  failures.push('当前项目缺少 packages/shared/nocobase-automation。');
}
if (existsSync(path.join(projectDir, '.env')) || existsSync(path.join(projectDir, '.env.test'))) {
  failures.push('当前项目根目录存在 .env 或 .env.test，禁止纳入复制范围。');
}

if (execute && process.env.CONFIRM_NOCOBASE_HOST_BOOTSTRAP_EXECUTE !== 'yes') {
  failures.push('传入 --execute 时必须设置 CONFIRM_NOCOBASE_HOST_BOOTSTRAP_EXECUTE=yes。');
}

if (failures.length > 0) {
  for (const failure of failures) console.error(`错误：${failure}`);
  process.exit(1);
}

console.log('检查通过：宿主工作区符合 dry-run 校验要求，未执行真实写入。');
