declare const require: any;
declare const process: { env: Record<string, string | undefined>; cwd(): string; argv: string[]; exit(code?: number): never };

const { existsSync, statSync, cpSync, mkdirSync } = require('fs');
const path = require('path');

const execute = process.argv.includes('--execute');
const hostDir = process.env.NOCOBASE_HOST_DIR;
const projectDir = process.env.CURRENT_PROJECT_DIR || process.cwd();

const plannedCopies = [
  { name: 'plugin-rental-core', source: 'packages/plugins/plugin-rental-core', target: 'packages/plugins/plugin-rental-core' },
  { name: 'plugin-contract-documents', source: 'packages/plugins/plugin-contract-documents', target: 'packages/plugins/plugin-contract-documents' },
  { name: 'plugin-iopgps', source: 'packages/plugins/plugin-iopgps', target: 'packages/plugins/plugin-iopgps' },
  { name: 'nocobase-automation', source: 'packages/shared/nocobase-automation', target: 'packages/shared/nocobase-automation' },
];

const failures: string[] = [];

console.log('项目插件复制计划（默认 dry-run）。');
console.log('本脚本不默认复制文件，不覆盖宿主工程文件，不读取 .env.test 真实值。');

if (!hostDir) failures.push('未设置 NOCOBASE_HOST_DIR。');
if (!projectDir) failures.push('未设置 CURRENT_PROJECT_DIR。');

for (const item of plannedCopies) {
  const sourcePath = path.join(projectDir, item.source);
  const targetPath = hostDir ? path.join(hostDir, item.target) : item.target;
  if (!existsSync(sourcePath) || !statSync(sourcePath).isDirectory()) {
    failures.push(`源目录不存在：${item.source}`);
  }
  if (existsSync(path.join(sourcePath, '.env')) || existsSync(path.join(sourcePath, '.env.test'))) {
    failures.push(`源目录包含禁止复制的环境文件：${item.source}`);
  }
  if (hostDir && existsSync(targetPath)) {
    failures.push(`目标目录已存在，为避免覆盖已停止：${targetPath}`);
  }
  console.log(`计划复制：${item.name}`);
  console.log(`  来源：${sourcePath}`);
  console.log(`  目标：${targetPath}`);
}

if (execute && process.env.CONFIRM_NOCOBASE_HOST_BOOTSTRAP_EXECUTE !== 'yes') {
  failures.push('传入 --execute 时必须设置 CONFIRM_NOCOBASE_HOST_BOOTSTRAP_EXECUTE=yes。');
}

if (failures.length > 0) {
  for (const failure of failures) console.error(`错误：${failure}`);
  process.exit(1);
}

if (!execute) {
  console.log('dry-run 模式：未执行任何复制或写入宿主工程。');
  process.exit(0);
}

for (const item of plannedCopies) {
  const sourcePath = path.join(projectDir, item.source);
  const targetPath = path.join(hostDir as string, item.target);
  mkdirSync(path.dirname(targetPath), { recursive: true });
  cpSync(sourcePath, targetPath, { recursive: true, errorOnExist: true, force: false });
  console.log(`已复制：${item.name}`);
}
