declare const require: any;
declare const process: { env: Record<string, string | undefined>; cwd(): string; argv: string[]; exit(code?: number): never };

const { existsSync, statSync } = require('fs');
const path = require('path');

const failures: string[] = [];
const warnings: string[] = [];
const execute = process.argv.includes('--execute');

const hostDir = process.env.NOCOBASE_HOST_DIR;
const projectDir = process.env.CURRENT_PROJECT_DIR || process.cwd();
const targetVersion = process.env.NOCOBASE_TARGET_VERSION;
const iopgpsSyncEnabled = process.env.IOPGPS_SYNC_ENABLED;

console.log('NocoBase 宿主工程前置条件检查（默认 dry-run）。');
console.log('本脚本不读取 .env.test 真实值，不安装依赖，不写入宿主工程。');

if (!hostDir) failures.push('未设置 NOCOBASE_HOST_DIR。');
if (!projectDir) failures.push('未设置 CURRENT_PROJECT_DIR。');
if (!targetVersion) failures.push('未设置 NOCOBASE_TARGET_VERSION，目标版本必须人工确认。');

if (hostDir) {
  const hostPackageJson = path.join(hostDir, 'package.json');
  const hostPackagesDir = path.join(hostDir, 'packages');
  const hostStoragePluginsDir = path.join(hostDir, 'storage', 'plugins');
  if (!existsSync(hostDir) || !statSync(hostDir).isDirectory()) {
    failures.push(`宿主工程目录不存在或不是目录：${hostDir}`);
  } else if (!existsSync(hostPackageJson) || (!existsSync(hostPackagesDir) && !existsSync(hostStoragePluginsDir))) {
    failures.push('目标目录不像完整 NocoBase 工程：缺少 package.json，或缺少 packages / storage/plugins。');
  }
}

const projectPluginsDir = path.join(projectDir, 'packages', 'plugins');
if (!existsSync(projectPluginsDir) || !statSync(projectPluginsDir).isDirectory()) {
  failures.push('当前项目缺少 packages/plugins。');
}

if (iopgpsSyncEnabled !== 'false') {
  warnings.push('IOPGPS_SYNC_ENABLED 未明确设置为 false；宿主接入准备阶段必须保持 IOPGPS 禁用。');
}

if (execute && process.env.CONFIRM_NOCOBASE_HOST_BOOTSTRAP_EXECUTE !== 'yes') {
  failures.push('传入 --execute 时必须设置 CONFIRM_NOCOBASE_HOST_BOOTSTRAP_EXECUTE=yes。');
}

for (const warning of warnings) console.warn(`警告：${warning}`);
for (const failure of failures) console.error(`错误：${failure}`);

if (failures.length > 0) process.exit(1);

console.log('检查通过：宿主工程前置条件满足 dry-run 校验要求。');
