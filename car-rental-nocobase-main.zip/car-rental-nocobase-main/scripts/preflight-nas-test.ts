declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };
declare const module: any;

const fs = require('fs');
const path = require('path');

const requiredPaths = [
  'docker-compose.test.yml',
  '.env.test.example',
  'docs/deployment-nas-test.md',
  'docs/plugin-install-test.md',
  'docs/plugin-package-test.md',
  'docs/test-data.md',
  'scripts/seed-test-data.ts',
  'scripts/validate-test-data.ts',
  'scripts/check-plugin-structure.ts',
  'scripts/check-plugin-registration.ts',
  'scripts/backup-test-db.sh',
  'scripts/restore-test-db.sh',
  'scripts/check-nas-test-env.sh',
  'test-data/fixtures',
];

const forbiddenPaths = [
  '.env',
  '.env.test',
  'payment-screenshots',
  'signed-contracts',
  'driver-documents',
  'driver-licenses',
  'contract-scans',
];

function safeLine(line: string): boolean {
  return line.includes('TEST_') || line.includes('PLACEHOLDER') || line.includes('[已隐藏]') || line.includes('example.invalid') || line.includes('字段') || line.includes('code') || line.includes('token') && line.includes('不') || line.includes('login_key') && line.includes('不');
}

function scanTextRisks(rootDir: string): string[] {
  const warnings: string[] = [];
  const filesToScan = ['.env.test.example', 'docker-compose.test.yml'];
  for (const relativeFile of filesToScan) {
    const filePath = path.join(rootDir, relativeFile);
    if (!fs.existsSync(filePath)) continue;
    const lines = fs.readFileSync(filePath, 'utf8').split('\n');
    lines.forEach((line: string, index: number) => {
      const lower = line.toLowerCase();
      if ((lower.includes('access_token') || lower.includes('login_key')) && !safeLine(line)) {
        warnings.push(`${relativeFile}:${index + 1} 含 token/login_key 字样，请人工确认不是真实值。`);
      }
    });
  }
  return warnings;
}

export function preflightNasTest(rootDir = process.cwd()): { passed: boolean; errors: string[]; warnings: string[] } {
  const errors: string[] = [];
  const warnings: string[] = [];

  for (const relativePath of requiredPaths) {
    if (!fs.existsSync(path.join(rootDir, relativePath))) errors.push(`缺少测试准备文件或目录：${relativePath}`);
  }

  const generatedDir = path.join(rootDir, 'test-data', 'generated');
  if (!fs.existsSync(generatedDir)) {
    warnings.push('test-data/generated 不存在，可先运行 npm run seed:test-data 生成。');
  }

  for (const relativePath of forbiddenPaths) {
    if (fs.existsSync(path.join(rootDir, relativePath))) errors.push(`发现风险路径，不应提交或保留在仓库：${relativePath}`);
  }

  const composePath = path.join(rootDir, 'docker-compose.test.yml');
  if (fs.existsSync(composePath)) {
    const compose = fs.readFileSync(composePath, 'utf8');
    if (!compose.includes('storage-test/nocobase')) errors.push('docker-compose.test.yml 未使用 storage-test/nocobase。');
    if (!compose.includes('storage-test/postgres')) errors.push('docker-compose.test.yml 未使用 storage-test/postgres。');
    if (compose.includes('./storage-test:/app/nocobase/storage')) errors.push('docker-compose.test.yml 仍存在旧的 storage-test 整体挂载。');
    if (compose.includes('- ./packages/plugins') || compose.includes('- packages/plugins')) errors.push('docker-compose.test.yml 不应直接挂载 packages/plugins。');
  }

  warnings.push(...scanTextRisks(rootDir));

  return { passed: errors.length === 0, errors, warnings };
}

if (typeof module !== 'undefined' && module === require.main) {
  const result = preflightNasTest();
  for (const warning of result.warnings) console.warn(`警告：${warning}`);
  if (!result.passed) {
    console.error('NAS 测试前自检失败：');
    for (const error of result.errors) console.error(`- ${error}`);
    process.exit(1);
  }
  console.log('NAS 测试前自检通过：关键文件、脚本、fixtures 和风险路径检查完成。');
}
