declare const require: any;
declare const process: { exit(code?: number): never };
declare const module: any;

import { contractDocumentsPluginRegistration } from '../packages/plugins/plugin-contract-documents/src/server/pluginRegistration';
import { iopgpsPluginRegistration } from '../packages/plugins/plugin-iopgps/src/server/pluginRegistration';
import { rentalCorePluginRegistration } from '../packages/plugins/plugin-rental-core/src/server/pluginRegistration';

interface RegistrationLike {
  pluginName?: string;
  dependencies?: readonly string[];
  collections?: readonly unknown[];
  services?: readonly unknown[];
  permissions?: readonly unknown[];
  i18nNamespaces?: readonly unknown[];
  scheduledTasks?: readonly unknown[];
  actions?: readonly unknown[];
  notes?: readonly string[];
}

const registrations: Record<string, RegistrationLike> = {
  'plugin-rental-core': rentalCorePluginRegistration,
  'plugin-iopgps': iopgpsPluginRegistration,
  'plugin-contract-documents': contractDocumentsPluginRegistration,
};

function hasArray(value: unknown): boolean {
  return Array.isArray(value);
}

function notesInclude(registration: RegistrationLike, text: string): boolean {
  return Boolean(registration.notes?.some((note) => note.includes(text)));
}

export function checkPluginRegistration(): { passed: boolean; errors: string[] } {
  const errors: string[] = [];
  for (const [name, registration] of Object.entries(registrations)) {
    if (!registration) errors.push(`${name} 缺少 pluginRegistration。`);
    if (!registration.pluginName) errors.push(`${name} 缺少 pluginName。`);
    if (!hasArray(registration.collections) || registration.collections!.length === 0) errors.push(`${name} 缺少 collections。`);
    if (!hasArray(registration.services) || registration.services!.length === 0) errors.push(`${name} 缺少 services。`);
    if (!hasArray(registration.permissions)) errors.push(`${name} 缺少 permissions 或权限说明。`);
    if (!hasArray(registration.i18nNamespaces)) errors.push(`${name} 缺少 i18nNamespaces 或说明。`);
    if (!hasArray(registration.scheduledTasks)) errors.push(`${name} 缺少 scheduledTasks 或说明。`);
    if (!hasArray(registration.actions)) errors.push(`${name} 缺少 actions 或说明。`);
  }

  if (rentalCorePluginRegistration.dependencies.includes('plugin-iopgps')) errors.push('plugin-rental-core 不应依赖 plugin-iopgps。');
  if (rentalCorePluginRegistration.dependencies.includes('plugin-contract-documents')) errors.push('plugin-rental-core 不应依赖 plugin-contract-documents。');
  if (!iopgpsPluginRegistration.dependencies.includes('plugin-rental-core')) errors.push('plugin-iopgps 必须依赖 plugin-rental-core。');
  if (!contractDocumentsPluginRegistration.dependencies.includes('plugin-rental-core')) errors.push('plugin-contract-documents 必须依赖 plugin-rental-core。');
  if (!notesInclude(iopgpsPluginRegistration, 'GPS 数据不参与租金计算')) errors.push('plugin-iopgps notes 必须说明 GPS 不参与租金计算。');
  if (!notesInclude(iopgpsPluginRegistration, '不能影响租金台账和付款')) errors.push('plugin-iopgps notes 必须说明 GPS 失败不影响租金台账和付款。');
  if (!notesInclude(contractDocumentsPluginRegistration, '不处理租金')) errors.push('plugin-contract-documents notes 必须说明不处理租金。');
  if (!notesInclude(contractDocumentsPluginRegistration, '不处理付款')) errors.push('plugin-contract-documents notes 必须说明不处理付款。');
  if (!notesInclude(contractDocumentsPluginRegistration, '不处理 GPS')) errors.push('plugin-contract-documents notes 必须说明不处理 GPS。');

  return { passed: errors.length === 0, errors };
}

if (typeof module !== 'undefined' && module === require.main) {
  const result = checkPluginRegistration();
  if (!result.passed) {
    console.error('插件注册描述检查失败：');
    for (const error of result.errors) console.error(`- ${error}`);
    process.exit(1);
  }
  console.log('插件注册描述检查通过：依赖、collections、services、权限说明、i18n、定时任务、动作和边界说明均符合草案要求。');
}
