declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };
declare const module: any;

const fs = require('fs');
const path = require('path');

export function validateNasTestDocs(rootDir = process.cwd()): { passed: boolean; errors: string[] } {
  const requiredFiles = [
    'docker-compose.test.yml',
    '.env.test.example',
    'docs/deployment-nas-test.md',
    'docs/plugin-install-test.md',
    'scripts/backup-test-db.sh',
    'scripts/restore-test-db.sh',
    'scripts/check-nas-test-env.sh',
    'scripts/clean-nas-test-runtime.sh',
  ];
  const errors: string[] = [];
  for (const file of requiredFiles) {
    if (!fs.existsSync(path.join(rootDir, file))) errors.push(`缺少文件：${file}`);
  }
  const compose = fs.existsSync(path.join(rootDir, 'docker-compose.test.yml')) ? fs.readFileSync(path.join(rootDir, 'docker-compose.test.yml'), 'utf8') : '';
  const envExample = fs.existsSync(path.join(rootDir, '.env.test.example')) ? fs.readFileSync(path.join(rootDir, '.env.test.example'), 'utf8') : '';
  const deploymentDoc = fs.existsSync(path.join(rootDir, 'docs/deployment-nas-test.md')) ? fs.readFileSync(path.join(rootDir, 'docs/deployment-nas-test.md'), 'utf8') : '';

  if (!compose.includes('nocobase/nocobase:latest-full')) errors.push('docker-compose.test.yml 未声明测试 NocoBase 镜像。');
  if (!compose.includes('postgres:16')) errors.push('docker-compose.test.yml 未声明 postgres:16。');
  if (!compose.includes('13000:80')) errors.push('docker-compose.test.yml 未声明 13000:80 端口。');
  if (!compose.includes('storage-test/nocobase')) errors.push('docker-compose.test.yml 未分离 NocoBase storage-test/nocobase 挂载。');
  if (!compose.includes('storage-test/postgres')) errors.push('docker-compose.test.yml 未分离 PostgreSQL storage-test/postgres 挂载。');
  if (compose.includes('./storage-test:/app/nocobase/storage')) errors.push('docker-compose.test.yml 仍存在旧的 storage-test 整体挂载。');
  if (compose.includes('- ./packages/plugins') || compose.includes('- packages/plugins')) errors.push('docker-compose.test.yml 不应直接挂载 packages/plugins。');
  for (const line of compose.split('\n')) {
    const trimmed = line.trim();
    if (/password\s*[:=]/i.test(trimmed) && !trimmed.includes('${') && !trimmed.includes('TEST_')) {
      errors.push('docker-compose.test.yml 疑似包含真实密码。');
    }
  }
  if (!envExample.includes('IOPGPS_SYNC_ENABLED=false')) errors.push('.env.test.example 必须默认关闭 IOPGPS 同步。');
  if (!envExample.includes('TEST_')) errors.push('.env.test.example 应使用 TEST 占位值。');
  if (/sk_live|ghp_|AKIA|BEGIN PRIVATE KEY|真实密钥/i.test(envExample)) errors.push('.env.test.example 疑似包含真实密钥。');
  if (!deploymentDoc.includes('不能用于生产')) errors.push('NAS 测试部署文档必须明确不能用于生产。');
  if (!deploymentDoc.includes('storage-test/nocobase')) errors.push('NAS 测试部署文档必须说明 storage-test/nocobase。');
  if (!deploymentDoc.includes('storage-test/postgres')) errors.push('NAS 测试部署文档必须说明 storage-test/postgres。');
  if (!deploymentDoc.includes('Raw') || !deploymentDoc.includes('git clone')) errors.push('NAS 测试部署文档必须提醒使用 Raw 或 git clone，避免保存 GitHub HTML 页面。');

  return { passed: errors.length === 0, errors };
}

if (typeof module !== 'undefined' && module === require.main) {
  const result = validateNasTestDocs();
  if (!result.passed) {
    console.error('NAS 测试文档校验失败：');
    for (const error of result.errors) console.error(`- ${error}`);
    process.exit(1);
  }
  console.log('NAS 测试文档校验通过。');
}
