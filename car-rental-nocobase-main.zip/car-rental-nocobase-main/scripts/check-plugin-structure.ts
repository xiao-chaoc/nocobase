declare const require: any;
declare const process: { cwd(): string; exit(code?: number): never };
declare const module: any;

const fs = require('fs');
const path = require('path');

const plugins = ['plugin-rental-core', 'plugin-iopgps', 'plugin-contract-documents'];
const requiredRelativeFiles = [
  'package.json',
  'src/server/index.ts',
  'src/server/pluginRegistration.ts',
  'src/server/services/index.ts',
  'src/server/types/index.ts',
  'src/server/collections/index.ts',
  'src/locale/zh-CN.json',
  'src/locale/en-US.json',
  'src/locale/fr-FR.json',
];

export function checkPluginStructure(rootDir = process.cwd()): { passed: boolean; errors: string[] } {
  const errors: string[] = [];
  for (const plugin of plugins) {
    const pluginDir = path.join(rootDir, 'packages', 'plugins', plugin);
    if (!fs.existsSync(pluginDir)) {
      errors.push(`缺少插件目录：${plugin}`);
      continue;
    }
    for (const relativeFile of requiredRelativeFiles) {
      const filePath = path.join(pluginDir, relativeFile);
      if (!fs.existsSync(filePath)) errors.push(`${plugin} 缺少文件：${relativeFile}`);
    }
  }
  return { passed: errors.length === 0, errors };
}

if (typeof module !== 'undefined' && module === require.main) {
  const result = checkPluginStructure();
  if (!result.passed) {
    console.error('插件结构检查失败：');
    for (const error of result.errors) console.error(`- ${error}`);
    process.exit(1);
  }
  console.log('插件结构检查通过：三个插件基础目录、入口、服务、类型、Collection 和 locale 文件均存在。');
}
