#!/usr/bin/env bash
set -euo pipefail

# NAS 测试环境检查脚本草案，只用于测试环境。
# 本脚本不连接真实数据库，不调用真实 IOPGPS，不用于生产部署。

ERRORS=0
WARNINGS=0

check_file() {
  local file="$1"
  if [[ -f "$file" ]]; then
    echo "✓ 找到文件：$file"
  else
    echo "✗ 缺少文件：$file" >&2
    ERRORS=$((ERRORS + 1))
  fi
}

check_dir() {
  local dir="$1"
  if [[ -d "$dir" ]]; then
    echo "✓ 找到目录：$dir"
  else
    echo "✗ 缺少目录：$dir" >&2
    ERRORS=$((ERRORS + 1))
  fi
}

check_compose_contains() {
  local pattern="$1"
  local message="$2"
  if grep -Fq -- "$pattern" docker-compose.test.yml; then
    echo "✓ $message"
  else
    echo "✗ docker-compose.test.yml 缺少：$pattern" >&2
    ERRORS=$((ERRORS + 1))
  fi
}

check_compose_not_contains() {
  local pattern="$1"
  local message="$2"
  if grep -Fq -- "$pattern" docker-compose.test.yml; then
    echo "✗ docker-compose.test.yml 不应包含：$pattern" >&2
    ERRORS=$((ERRORS + 1))
  else
    echo "✓ $message"
  fi
}

if command -v docker >/dev/null 2>&1; then
  echo "✓ docker 已安装"
else
  echo "✗ docker 未安装或当前用户不可用" >&2
  ERRORS=$((ERRORS + 1))
fi

if docker compose version >/dev/null 2>&1; then
  echo "✓ docker compose 可用"
else
  echo "✗ docker compose 不可用" >&2
  ERRORS=$((ERRORS + 1))
fi

check_file docker-compose.test.yml
check_file .env.test
check_dir storage-test/nocobase
check_dir storage-test/postgres
check_dir backups-test
check_dir templates

if [[ -f docker-compose.test.yml ]]; then
  check_compose_contains "storage-test/nocobase" "Compose 已分离 NocoBase storage 测试目录。"
  check_compose_contains "storage-test/postgres" "Compose 已分离 PostgreSQL 测试数据库目录。"
  check_compose_not_contains "./storage-test:/app/nocobase/storage" "Compose 未把整个 storage-test 挂载为 NocoBase storage。"
  check_compose_not_contains "- ./packages/plugins" "Compose 未直接挂载 packages/plugins。"
  check_compose_not_contains "- packages/plugins" "Compose 未直接挂载 packages/plugins。"
fi

if command -v ss >/dev/null 2>&1; then
  if ss -ltn | awk '{print $4}' | grep -q ':13000$'; then
    echo "⚠ 端口 13000 可能已被占用，请人工确认。"
    WARNINGS=$((WARNINGS + 1))
  else
    echo "✓ 未检测到端口 13000 被监听。"
  fi
elif command -v netstat >/dev/null 2>&1; then
  if netstat -ltn | awk '{print $4}' | grep -q ':13000$'; then
    echo "⚠ 端口 13000 可能已被占用，请人工确认。"
    WARNINGS=$((WARNINGS + 1))
  else
    echo "✓ 未检测到端口 13000 被监听。"
  fi
else
  echo "⚠ 当前环境无法自动检查端口 13000，请人工确认。"
  WARNINGS=$((WARNINGS + 1))
fi

if [[ "$ERRORS" -gt 0 ]]; then
  echo "NAS 测试环境检查失败：$ERRORS 项错误，$WARNINGS 项警告。" >&2
  exit 1
fi

echo "NAS 测试环境基础文件检查通过：$WARNINGS 项警告需人工确认。"
